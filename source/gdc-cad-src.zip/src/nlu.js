// 言葉の読み取り（AI を使わない・無料・即時・オフライン・データは外に出ない）
// ふだんの日本語の頼みごと →「決まった書き方のコマンド」（docs/コマンドの使い方.txt）に直す。
//   interpret(text, context) → { lines: [...], reply: "短い返事", ask: "聞き返し（あれば）", pending, candidates }
//   checkAgainst(text, lines, context) → 小さい AI モデルが作ったコマンドを、頼みごとの数値と照らし合わせて確かめる・直す
//   buildContext({ app, store, call, ctx }) → interpret に渡す「今のモデル」の要約（commandline.js から使う）
// 分からないところは推測で形を壊さず、聞き返す（ask）か、近い言い方の候補を出す。
import { kanjiNumbers, kanjiToNum, speechToCommand } from "./voice.js";

const NUM = "-?\\d+(?:\\.\\d+)?";
const fmt = (v) => String(+(+v).toFixed(3));
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// ---------------------------------------------------------------- 部品名のゆれ
// 先頭がその呼び名の正式な名前。聞き間違い風（ひらがな）も入れておく
const PARTS = [
  ["床板", "ゆか板", "ゆかいた", "床いた", "底板", "そこ板", "そこいた", "床パネル", "フロア板", "フロアパネル", "フロア"],
  ["天板", "てんいた", "天いた", "上板", "トップ板", "天面板"],
  ["側板", "そくいた", "側いた", "がわいた", "がわ板", "横板", "サイド板", "サイドパネル", "側面板"],
  ["背板", "せいた", "背いた", "裏板", "うら板", "後ろ板", "背面板", "バック板"],
  ["棚板", "たないた", "棚いた", "たな板", "棚"],
  ["扉", "とびら", "ドア"],
  ["柱", "はしら", "支柱", "ポール"],
  ["脚", "あし"],
  ["壁", "かべ", "壁板", "壁パネル"],
  ["天井", "天井板", "てんじょう", "天井パネル"],
  ["仕切り板", "仕切り", "しきり", "仕切板", "しきり板"],
  ["前板", "まえいた", "前いた", "幕板"],
];
const CANON = new Map(); for (const g of PARTS) for (const w of g) CANON.set(w, g[0]);
const GENERIC = /^(幅|奥行|高さ|厚さ|長さ|直径|太さ|縦|横|半径|円柱|球|ボール|シリンダー|板|いた|箱|はこ|ボックス|直方体|ブロック|四角|もの|物|やつ|の|部品|パーツ|ボディ|形|これ|それ|あれ)$/;
const VERTICAL = /側板|背板|壁|扉|仕切り|前板|パネル/; // 立っている板（厚さが横向き）

const COLORS = [["赤", /赤|あか|レッド/], ["青", /青|あお|ブルー/], ["緑", /緑|みどり|グリーン/], ["黄", /黄色|黄|きいろ|イエロー/], ["白", /白|しろ|ホワイト/], ["黒", /黒|くろ|ブラック/],
  ["グレー", /グレー|灰色|はいいろ|ねずみ色|グレイ/], ["オレンジ", /オレンジ|橙|だいだい/], ["茶", /茶色|茶|ちゃいろ|ブラウン/], ["水色", /水色|みずいろ|空色/], ["ピンク", /ピンク|桃色/], ["紫", /紫|むらさき|パープル/], ["木", /木目|木の色|木色/]];
const MATS = [["PETフォーム", /PETフォーム|PET|ペット|発泡/i], ["FRPサンドイッチ", /FRPサンドイッチ|サンドイッチ/i], ["FRP(ガラス)", /FRP|エフアールピー|ガラス繊維/i], ["合板", /合板|ベニヤ|コンパネ/],
  ["杉", /杉|スギ/], ["アルミ", /アルミ/], ["ステンレス", /ステンレス|ステン|SUS/i], ["鋼", /鋼|鉄|スチール/], ["ABS", /ABS/i], ["アクリル", /アクリル/], ["ゴム", /ゴム/]];
// ボルトの呼び径 → 通し穴の径（JIS 中級）
const BOLT = { 3: 3.4, 4: 4.5, 5: 5.5, 6: 6.6, 8: 9, 10: 11, 12: 13.5, 16: 17.5 };

// 聞き間違い・言い換え → このソフトの言葉
const FIX = [
  [/熱さ|暑さ|あつさ|厚み|あつみ|板厚/g, "厚さ"], [/奥行き|おくゆき|奥ゆき|奥ゆき/g, "奥行"], [/横幅|よこはば|はば/g, "幅"], [/たかさ/g, "高さ"], [/ふかさ/g, "深さ"],
  [/直系|直経|ちょっけい/g, "直径"], [/半経|はんけい/g, "半径"], [/あな|孔|アナ/g, "穴"], [/ながさ/g, "長さ"],
  [/四すみ|よすみ|4すみ|4隅|四つ角|4つの角|四つの角|4角/g, "四隅"], [/かど/g, "角"], [/まるめ|まるく/g, (m) => m === "まるめ" ? "丸め" : "丸く"],
  [/めんとり|面とり/g, "面取り"], [/ふぃれっと|フィレ(?!ット)/g, "フィレット"], [/えんちゅう|円中/g, "円柱"], [/まるぼう/g, "丸棒"],
  [/いどう|異動/g, "移動"], [/全て|すべて|ぜんぶ|みんな|全部/g, "全部"], [/かいてん/g, "回転"], [/ピッチ|ぴっち/g, "ピッチ"],
  [/とりけし|取り消し|取消し|取消/g, "取り消し"], [/もとに戻|元にもど|もとにもど/g, "元に戻"], [/ちゅうおう|まんなか/g, "真ん中"], [/たいしょう|対照/g, "対称"],
  [/みぎ/g, "右"], [/となり/g, "隣"], [/さかさま|さかさ|逆さ(?!ま)/g, "逆さま"], [/ひだり/g, "左"], [/おもさ|重量|質量/g, "重さ"], [/たいせき/g, "体積"], [/おおきさ/g, "大きさ"], [/ざいりょう|材質|素材/g, "材料"],
];

// ---------------------------------------------------------------- 文を整える
export function normalizeJa(text) {
  let s = String(text || "").normalize("NFKC");
  s = s.replace(/[「」『』“”"]/g, " ").replace(/[ \t　]+/g, " ");
  // 言いよどみ
  s = s.replace(/(^|[\s、,。])(?:えーっと|えっと|ええと|えーと|えーと|あのー*|あのう|うーん|うんと|んーと|んー|えー+|まあ|そうですね|じゃあ|じゃ|ほら|なんか|ええ)(?=[\s、,。]|$)/g, "$1 ");
  for (const [a, b] of FIX) s = s.replace(a, b);
  // 「ひとつ」「二つ」など
  s = s.replace(/ひとつ/g, "1つ").replace(/ふたつ/g, "2つ").replace(/みっつ/g, "3つ").replace(/よっつ/g, "4つ").replace(/いつつ/g, "5つ").replace(/むっつ/g, "6つ")
    .replace(/いちまい/g, "1枚").replace(/にまい/g, "2枚").replace(/さんまい/g, "3枚").replace(/よんまい/g, "4枚")
    .replace(/([一二三四五六七八九十]+)(?=つ|か所|箇所|ヶ所|カ所|ヵ所)/g, (m) => String(kanjiToNum(m)));
  s = kanjiNumbers(s);
  s = s.replace(/(\d)\s*(?:点|てん)\s*(\d)/g, "$1.$2");
  // 「幅60センチ奥行き40で」: センチだけで話しているとき、単位を言わなかった幅・奥行・高さ・長さもセンチとみなす
  s = s.replace(/(\d+(?:\.\d+)?)\s*から\s*(?=[RC]?\d)/g, ""); // 「5から8に」→「8に」
  s = s.split(/(?<=[ぁ-ん]て[、,])|(?<=[。\n])/).map((s) => {
  // 「全部センチ」「単位はセンチ」: 単位のない寸法をすべてセンチに
  if (/(?:全部|すべて|単位は|みんな)\s*センチ/.test(s)) {
    s = s.replace(/(?:全部|すべて|単位は|みんな)\s*センチ(?:で)?/, " ").replace(/((?:幅|奥行き?|高さ|長さ|厚さ|厚み|縦|横|直径|太さ)\s*(?:は|が|を|:)?\s*)(\d+(?:\.\d+)?)(?!\s*(?:\d|\.|センチ|cm|ミリ|mm|メートル|m))/gi, "$1$2センチ").replace(/(\d+(?:\.\d+)?)\s*(?:x|×|かける)\s*(\d+(?:\.\d+)?)(?:\s*(?:x|×|かける)\s*(\d+(?:\.\d+)?))?(?!\s*センチ)/g, (m, a, b, c) => [a, b, c].filter(Boolean).map((v) => v + "センチ").join("x"));
  }
  if (/\d\s*(?:センチ|cm)/i.test(s) && !/\d\s*(?:ミリ|mm|メートル|m(?![a-z]))/i.test(s)) {
    s = s.replace(/(?<![\d.])(\d+(?:\.\d+)?)\s*(?:x|×|かける)\s*(\d+(?:\.\d+)?)(?!\s*(?:x|×|かける|\d|\.))(?!\s*(?:センチ|cm|ミリ|mm))/g, (m, a, b) => +a <= 300 && +b <= 300 ? `${a}センチx${b}センチ` : m);
    s = s.replace(/((?:幅|奥行き?|高さ|長さ|縦|横)\s*(?:は|が|を|:)?\s*)(\d+(?:\.\d+)?)(?!\s*(?:\d|\.|センチ|cm|ミリ|mm|メートル|m|個|枚|本|つ|倍|度|%))/gi, (m, k, v) => +v <= 300 ? `${k}${v}センチ` : m);
  }
  return s; }).join("");
  // 「1メートル20センチ」「1メートル20」
  s = s.replace(/(\d+)\s*(?:メートル|m)\s*(\d+(?:\.\d+)?)\s*(?:センチ|cm)/gi, (m, a, b) => `${+a * 1000 + +b * 10}`).replace(/(\d+)\s*(?:メートル|m)\s*(\d{2})(?![\d.]|\s*(?:ミリ|mm|センチ|cm))/gi, (m, a, b) => `${+a * 1000 + +b * 10}`);
  // 「1メートル半」「3センチ半」
  s = s.replace(/(\d+)\s*(メートル|センチ|ミリ|m|cm|mm)\s*半/gi, "$1.5$2");
  // 単位 → mm
  s = s.replace(/(\d+(?:\.\d+)?)\s*(?:センチメートル|センチ|せんち|cm|㎝)(?![a-wyz])/gi, (m, v) => fmt(v * 10))
    .replace(/(\d+(?:\.\d+)?)\s*(?:ミリメートル|ミリ|みり|mm|㎜)/gi, "$1")
    .replace(/(\d+(?:\.\d+)?)\s*(?:メートル|めーとる|m)(?![a-z])/gi, (m, v) => fmt(v * 1000))
    .replace(/ミリメートル|ミリ/g, "");
  s = s.replace(/(\d+(?:\.\d+)?)\s*(?:ファイ|φ|⌀|ø)/gi, "Ø$1").replace(/(?:ファイ|パイ|φ|⌀|ø)\s*(?=\d)/gi, "Ø").replace(/(\d+(?:\.\d+)?)\s*(?:アール)/g, "R$1").replace(/アール\s*(?=\d)/g, "R").replace(/(?:^|(?<=[^A-Za-z]))r(?=\d)/g, "R")
    .replace(/シー\s*(?=\d)/g, "C").replace(/エム\s*(?=\d)/g, "M").replace(/マイナス\s*/g, "-").replace(/プラス\s*(?=\d)/g, "+");
  for (let i = 0; i < 2; i++) s = s.replace(/(\d)\s*(?:かける|掛ける|×|\*|バイ|x|X)\s*(?=\d)/g, "$1x");
  // 敬語・お願いの言い方
  s = s.replace(/(て|で)(?:くださいませんか|ください|下さい|くださ|くれますか|くれる\?|くれない\?|くれ|もらえますか|もらえる\?|もらえない\?|もらえる|もらいたい|ほしい|欲しい|いただけますか|いただけますでしょうか|頂けますか|いただきたい|ちょうだい|おいて)/g, "$1")
    .replace(/(?:を)?お願いします|をお願い|お願い|おねがいします|おねがい|よろしく/g, "").replace(/ますか|ませんか|ましょう/g, "ます");
  return s.replace(/[ ]+/g, " ").trim();
}

// 文の区切り（「。」・改行・「それから」・「〜して、」）
function splitClauses(s, partWords = []) {
  const hasPart = (x) => partWords.some((w) => x.includes(w));
  const out = [];
  const parts = s.split(/(?<=[。！!？?\n])|(?:^|[\s、,])(?:それから|次に|そのあと|その後|そして|続けて|それと|あとは|あと|最後に|ついでに)(?:[\s、,]|$)/);
  for (let p of parts) {
    if (!p) continue;
    const q = /[？?]\s*$/.test(p) || /(?:かな|ですか|か)\s*[。]?$/.test(p.trim());
    p = p.replace(/[。！!？?\n]+/g, " ").trim();
    if (!p) continue;
    // 「作って、それの…」「動かして、」など、動詞のて形＋「、」で切る（「40で、」「床板で、」では切らない）
    const sub = p.split(/(?<=[ぁ-ん](?:て|で)(?:から)?)[、,]\s*|(?<=[ぁ-ん](?:て|で)から)\s*/);
    for (const x of sub) {
      // 「天板を青に、床板を緑に」: 「、」の両側に別の部品と「を・は」があれば、別の頼みごと
      const segs = x.split(/、/); let cur = "";
      for (let k = 0; k < segs.length; k++) {
        const seg = segs[k];
        if (cur && ((hasPart(cur) && /[をは]/.test(cur) && hasPart(seg) && /[をは]/.test(seg)) || (/[をはに]/.test(cur) && /^\s*(?:角|辺|穴|色|材料|名前)\s*[はを]/.test(seg)))) { out.push({ text: cur.trim(), q }); cur = seg; }
        else cur = cur ? cur + "、" + seg : seg;
      }
      if (cur.trim()) out.push({ text: cur.trim(), q });
    }
  }
  return out;
}

// ---------------------------------------------------------------- 決まった書き方か
const KW = "ビス接合|板厚|板|直方体|箱|ボックス|ブロック|円柱|球|スケッチ終了|スケッチ|長方形|四角形?|矩形パターン|矩形|円弧|円形パターン|円|線|ライン|折れ線|点|押し出し|押出し?|穴|フィレット|面取り|移動|コピー|複製|削除|スケール|尺度|回す|回転|置く|配置|色|材料|材質|名前変更|改名|非表示|表示|ミラー|パターン|分割|結合|シェル|プレスプル|構築平面|作業平面|多角形|長穴|スロット|抑制解除|抑制|ロールバック解除|ロールバック|パラメータ|変数|コンポーネント|視点|ビュー|全体表示|部品一覧|部品表|干渉チェック|干渉|重さ|重量|体積|大きさ|寸法|外形|使い方|ヘルプ|図面|STEP|STL|OBJ|GLB";
const KW_RE = new RegExp(`^(?:${KW})(?=[\\s\\dØRCMx#=,.+-]|$)`, "i");
const WHOLE = /^(?:元に戻す(?:\s*\d+)?|やり直し(?:\s*\d+)?|すべて表示|全部表示|全体表示|使い方|部品一覧|干渉チェック|ロールバック解除|スケッチ終了|(?:STEP|STL|OBJ|GLB)\s*(?:で|に)?\s*書き出し|図面\s*(?:PDF|DXF|SVG)|手順を書き出し)$/i;
const OK_KANA = /厚さ|高さ|深さ|長さ|太さ|縦の辺|上の辺|下の辺|水平の辺|すべての辺|全部の辺|すべて|ざぐり径|ざぐり深さ|ざぐり|分の|閉じる|閉じ|置く|回す|押し出し|書き出し|方向|個/g;
export function isFixedCommand(line, context = {}) {
  const L = String(line || "").trim(); if (!L) return false;
  if (L.startsWith("#")) return true;
  if (WHOLE.test(L)) return true;
  let head = (L.match(KW_RE) || [])[0];
  if (!head) {
    const names = [...(context.bodies || []).map((b) => b.name), ...(context.features || []).map((f) => f.name)].filter(Boolean).sort((a, b) => b.length - a.length);
    const n = names.find((x) => L.startsWith(x + " "));
    if (!n) return false;
    head = n;
  }
  let rest = L.slice(head.length).replace(/(?:名前|名前変更|コンポーネント)\s*\S+/g, " ");
  if (/^(名前変更|改名)$/.test(head)) rest = rest.replace(/\S+\s*$/, " "); // 新しい名前は何でもよい
  for (const n of [...(context.bodies || []).map((b) => b.name), ...(context.features || []).map((f) => f.name)].filter(Boolean).sort((a, b) => b.length - a.length)) rest = rest.split(n).join(" ");
  rest = rest.replace(OK_KANA, " ");
  return !/[ぁ-ん]/.test(rest);
}

// ---------------------------------------------------------------- 数値の読み取り
const num = (s) => (s == null ? null : +s);
function dimsOf(c) {
  const d = {};
  const take = (key, re) => {
    if (d[key] != null) return;
    const m = c.match(new RegExp(`(?:${re})\\s*(?:は|が|を|の|:|=|約|だいたい)?\\s*(${NUM})`)) || c.match(new RegExp(`(${NUM})\\s*(?:の)?\\s*(?:${re})(?![\\d])`));
    if (m) d[key] = +m[1];
  };
  take("w", "幅|横(?!に|へ|の辺|向)|W|間口");
  take("d", "奥行|奥|D");
  take("h", "高さ|H|丈");
  take("t", "厚さ|T|厚");
  take("r", "半径");
  take("dia", "直径|外径|(?<!半)径|太さ|Ø");
  take("tate", "縦");
  take("len", "長さ|L");
  const x = c.match(new RegExp(`(${NUM})x(${NUM})(?:x(${NUM}))?`));
  if (x) { d.xyz = [+x[1], +x[2], x[3] != null ? +x[3] : null]; }
  const sq = c.match(new RegExp(`(${NUM})\\s*角`)); if (sq && !/四隅|角を|角に/.test(c.slice(sq.index, sq.index + sq[0].length + 2))) d.square = +sq[1];
  return d;
}
// 倍率（「半分」「2倍」「3分の1」「50%」）
function factorOf(c) {
  let m;
  if ((m = c.match(new RegExp(`(${NUM})\\s*分の\\s*(${NUM})`)))) return +m[2] / +m[1];
  if ((m = c.match(new RegExp(`(${NUM})\\s*倍`)))) return +m[1];
  if ((m = c.match(new RegExp(`(${NUM})\\s*(?:%|パーセント)`)))) return +m[1] / 100;
  if (/半分/.test(c)) return 0.5;
  if (/(?<!\d)倍(?:に|へ|の|$)/.test(c)) return 2;
  return null;
}
function countOf(c) { const m = c.match(/(\d+)\s*(?:枚|個|本|つ|か所|箇所|ヶ所|カ所|段|台)/); return m ? +m[1] : null; }
function pitchOf(c) {
  const m = c.match(new RegExp(`(${NUM})\\s*(?:の)?\\s*(?:ピッチ|間隔|おき|ごと|ずつ|離して|あけて)`)) || c.match(new RegExp(`(?:ピッチ|間隔|おき|ごと|離して|あけて)\\s*(?:は|を|が|:)?\\s*(${NUM})`));
  return m ? +m[1] : null;
}

// ---------------------------------------------------------------- 状態（文をまたいで「それ」を追う）
function sim0(context = {}) {
  const bodies = (context.bodies || []).map((b) => ({ ...b, min: [...(b.min || [0, 0, 0])], max: [...(b.max || b.size || [0, 0, 0])] }));
  for (const b of bodies) if (!b.size) b.size = b.max.map((v, i) => v - b.min[i]);
  return { bodies, features: (context.features || []).map((f) => ({ ...f })), selected: [...(context.selected || [])], last: context.lastBody || null, lastHole: null, lastFillet: null };
}
const bodyByName = (sim, n) => sim.bodies.find((b) => b.name === n);
const sizeOf = (b) => b.max.map((v, i) => +(v - b.min[i]).toFixed(4));
function nextName(sim, type, base) {
  const used = new Set([...sim.features.map((f) => f.name), ...sim.bodies.map((b) => b.name)]);
  let k = sim.features.filter((f) => f.type === type).length + 1;
  while (used.has(base + k)) k++;
  return base + k;
}

// 文の中で言っている部品（名前・呼び名のゆれ・代名詞）
function mentions(c, sim) {
  const found = [];
  const words = new Set([...sim.bodies.map((b) => b.name), ...CANON.keys()]);
  const sorted = [...words].filter(Boolean).sort((a, b) => b.length - a.length);
  let rest = c;
  for (const w of sorted) {
    let i;
    const isBody = sim.bodies.some((b) => b.name === w);
    while ((i = rest.indexOf(w)) >= 0) {
      if (!isBody && i > 0 && /[一-龥ァ-ヶ]/.test(rest[i - 1]) && w.length <= 2 && !/[ぁ-ん]/.test(w)) { rest = rest.slice(0, i) + "\u0000".repeat(w.length) + rest.slice(i + w.length); continue; }
      // 「棚板」の中の「棚」、「床板」の中の「床」は数えない（長い方を先に消している）
      found.push({ word: w, at: i, canon: CANON.get(w) || w });
      rest = rest.slice(0, i) + "\u0000".repeat(w.length) + rest.slice(i + w.length);
    }
  }
  found.sort((a, b) => a.at - b.at);
  for (const m of found) {
    const ex = sim.bodies.filter((b) => b.name === m.word);
    if (ex.length) { m.bodies = ex; continue; }
    const grp = PARTS.find((g) => g[0] === m.canon);
    m.bodies = sim.bodies.filter((b) => b.name === m.canon);
    if (!m.bodies.length) m.bodies = sim.bodies.filter((b) => grp && grp.includes(b.name));
    if (!m.bodies.length) m.bodies = sim.bodies.filter((b) => b.name.startsWith(m.canon) && /^[\d_\s(（-]/.test(b.name.slice(m.canon.length)));
  }
  return found;
}
// 対象のボディ（名前 → 代名詞 → 選択中 → 直前 → 1 つしかない）
function targets(c, sim, { allowAll = true, exclude = [] } = {}) {
  const ms = mentions(c, sim).filter((m) => !exclude.includes(m.word));
  const without = c.match(/(\S+?)\s*(?:以外|を除いて|をのぞいて|は除いて|はのぞいて)/);
  if (without) {
    const ex = mentions(without[1], sim).flatMap((m) => m.bodies);
    if (ex.length) return { list: sim.bodies.filter((b) => !ex.includes(b)), how: "except", ex };
  }
  const allWord = /全部(?!の(?:角|辺|エッジ|角を|穴))|全体|まとめて|両方|どれも/.test(c.replace(/全部の(?:角|辺|エッジ)/g, ""));
  const named = ms.filter((m) => m.bodies.length);
  if (named.length) {
    const list = [];
    for (const m of named) {
      // 「棚板」と言って棚板・棚板_2 があるとき: 「全部の棚板」「棚板を全部」なら全部、そうでなければ同じ名前のもの
      const exact = m.bodies.filter((b) => b.name === m.word || b.name === m.canon);
      const pick = allWord || !exact.length ? m.bodies : exact;
      for (const b of pick) if (!list.includes(b)) list.push(b);
    }
    return { list, how: "name", mentions: ms };
  }
  if (allowAll && allWord && sim.bodies.length) return { list: [...sim.bodies], how: "all", mentions: ms };
  const sel = sim.selected.map((n) => bodyByName(sim, n)).filter(Boolean);
  const last = sim.last && bodyByName(sim, sim.last);
  if (/これ|この|ここ|選んだ|選択/.test(c)) { if (sel.length) return { list: sel, how: "this", mentions: ms }; if (last) return { list: [last], how: "this", mentions: ms }; }
  if (/それ|その|そいつ|さっき|今の|いま作った|今作った|作ったもの|作ったやつ/.test(c)) { if (last) return { list: [last], how: "that", mentions: ms }; if (sel.length) return { list: sel, how: "that", mentions: ms }; }
  if (sel.length) return { list: sel, how: "sel", mentions: ms };
  if (last) return { list: [last], how: "last", mentions: ms };
  if (sim.bodies.length === 1) return { list: [sim.bodies[0]], how: "only", mentions: ms };
  return { list: [], how: "none", mentions: ms };
}
const names = (bs) => bs.map((b) => b.name).join(" ");
const jnames = (bs) => bs.map((b) => b.name).join("・");
function whichAsk(sim, what) {
  const cands = sim.bodies.slice(0, 6).map((b) => b.name);
  return `どの部品${what}ですか？${cands.length ? `（${cands.join("・")}）` : ""}`;
}
function unionBox(bs) { return [[0, 1, 2].map((i) => Math.min(...bs.map((b) => b.min[i]))), [0, 1, 2].map((i) => Math.max(...bs.map((b) => b.max[i])))]; }

// ---------------------------------------------------------------- それぞれの頼みごと
const H = {};

H.undo = (c) => {
  if (!/取り消し|元に戻|もとに戻|やっぱりやめ|やっぱやめ|やめて|なかったことに|なしで|なしに|アンドゥ|undo|戻して|もどして/i.test(c)) return null;
  if (/(?:右|左|上|下|手前|奥|位置|場所|原点)(?:に|へ)\S*(?:戻して|もどして)|隠した|非表示|表示/.test(c) && !/元に|取り消/.test(c)) return null;
  const m = c.match(/(\d+)\s*(?:つ|回|個|手順|ステップ)?\s*(?:前|分)?/);
  const n = m ? +m[1] : null;
  return { lines: [n && n > 1 ? `元に戻す ${n}` : "元に戻す"], reply: n && n > 1 ? `${n} つ前まで戻します` : "直前の操作を取り消します" };
};
H.redo = (c) => /やり直し|やりなおし|リドゥ|redo|取り消しを取り消/i.test(c) && !/最初から/.test(c) ? { lines: ["やり直し"], reply: "取り消した操作をやり直します" } : null;
H.help = (c) => /使い方|ヘルプ|何ができ|なにができ|どう言え|書き方/.test(c) ? { lines: ["使い方"], reply: "使える言い方の一覧を出します" } : null;
H.export = (c) => {
  if (!/書き出|エクスポート|出力|保存|ダウンロード|ファイルに|データに|送りたい|渡したい|欲しい|ほしい/.test(c) && !/(?:図面|STEP|STP|STL|OBJ|GLB).*(?:PDF|DXF|に)\s*(?:したい|して|する)?$/i.test(c) && !/(?:図面|STEP|STP|STL|OBJ|GLB|PDF|DXF).*で\s*$/i.test(c)) return null;
  if (/図面|PDF|DXF/i.test(c)) { const k = /DXF/i.test(c) ? "DXF" : "PDF"; return { lines: [`図面 ${k}`], reply: `図面を ${k} で書き出します` }; }
  const f = (c.match(/STEP|STP|STL|OBJ|GLB/i) || [])[0]; if (!f) return /書き出|エクスポート/.test(c) ? { ask: "どの形式で書き出しますか？（STEP・STL・OBJ・図面 PDF・図面 DXF）" } : null;
  const F = f.toUpperCase() === "STP" ? "STEP" : f.toUpperCase();
  return { lines: [`${F} で書き出し`], reply: `${F} で書き出します` };
};
H.view = (c) => {
  if (/全体(?:を|が)?(?:表示|見せ|見え|見る)|全部(?:が)?見え|画面に合わせ|ズーム|全体表示/.test(c)) return { lines: ["全体表示"], reply: "全体が見えるようにします" };
  const m = c.match(/(真上|上|真下|下|正面|前|後ろ|背面|裏|右|左)(?:側)?(?:から|の向き|の視点)(?:見|の視点|の向き|に)?/);
  if (m && /見|視点|向き|ビュー/.test(c)) {
    const v = { 真上: "上", 上: "上", 真下: "下", 下: "下", 正面: "正面", 前: "正面", 後ろ: "背面", 背面: "背面", 裏: "下", 右: "右", 左: "左" }[m[1]];
    return { lines: [`視点 ${v}`], reply: `${v}から見た向きにします` };
  }
  if (/^視点/.test(c)) return null;
  return null;
};
H.query = (c, sim, { q }) => {
  const ask = q || /(?:重さ|体積|大きさ|寸法|サイズ)\s*$/.test(c) || /計算|求めて|出して|見たい|表示して/.test(c) && /重さ|体積|大きさ|寸法/.test(c) || /教えて|知りたい|いくら|いくつ|どれくらい|どのくらい|何キロ|何グラム|何kg|何ミリ|何センチ|何枚|何個|何本|計って|測って|はかって|調べて|確認して|チェック/.test(c);
  if (!ask) return null;
  if (/干渉|ぶつか|当たって|重なって/.test(c)) return { lines: ["干渉チェック"], reply: "部品どうしがぶつかっていないか調べます" };
  if (/何枚|何個|何本|全部で|部品(?:の)?(?:数|一覧|表)|いくつある|数を/.test(c) && !/重さ|体積|何キロ|何グラム|kg|キロ/.test(c)) return { lines: ["部品一覧"], reply: "部品の数を数えます" };
  const kind = /重さ|何キロ|何グラム|kg|キロ|重い/.test(c) ? "重さ" : /体積|容積/.test(c) ? "体積" : /大きさ|寸法|サイズ|外形|幅|奥行|高さ|厚さ|長さ|何ミリ|何センチ/.test(c) ? "大きさ" : null;
  if (!kind) return null;
  const t = targets(c, sim);
  let all = t.how === "all" || t.how === "none" || (t.how !== "name" && t.how !== "this" && t.how !== "that" && t.how !== "except");
  let list = all ? [] : t.list;
  if (all && t.how !== "all" && sim.topic && bodyByName(sim, sim.topic)) list = [bodyByName(sim, sim.topic)];
  return { lines: [list.length ? `${kind} ${names(list)}` : kind], reply: `${list.length ? jnames(list) + "の" : "全部の"}${kind}を調べます` };
};
H.hideShow = (c, sim) => {
  if (/全部(?:を)?(?:表示|見せ|出し)|全部見えるように|隠したのを(?:全部)?(?:戻|表示)/.test(c) && !/から見|視点/.test(c)) return { lines: ["すべて表示"], reply: "隠した部品をすべて表示します" };
  const hide = /隠し|非表示|見えなく|見えないように|消さずに/.test(c);
  const show = !hide && /(?:を|も)(?:表示|見せ|出し)|再表示|表示して/.test(c) && !/から見/.test(c);
  if (!hide && !show) return null;
  const t = targets(c, sim, { allowAll: true });
  if (!t.list.length) return { ask: whichAsk(sim, hide ? "を隠す" : "を表示する") };
  return { lines: [`${hide ? "非表示" : "表示"} ${names(t.list)}`], reply: `${jnames(t.list)}を${hide ? "隠します" : "表示します"}` };
};
H.del = (c, sim) => {
  if (!/消して|消す|削除|いらない|要らない|不要|なくして|無くして|取り除|除去|捨て/.test(c)) return null;
  if (/穴/.test(c)) {
    const h = holeFeature(c, sim); if (!h) return { ask: "どの穴を消しますか？" };
    return { lines: [`抑制 ${h.name}`], reply: `${h.name}を無効にします（「抑制解除 ${h.name}」で戻せます）` };
  }
  const fl = /丸め|フィレット|角の丸|面取り/.test(c) && sim.features.filter((f) => f.type === (/面取り/.test(c) ? "chamfer" : "fillet")).pop();
  if (fl) return { lines: [`抑制 ${fl.name}`], reply: `${fl.name}を無効にします` };
  const t = targets(c, sim);
  if (!t.list.length || (t.how !== "name" && t.how !== "this" && t.how !== "that" && t.how !== "all" && t.how !== "except" && t.how !== "sel")) return { ask: whichAsk(sim, "を消す") };
  return { lines: [`削除 ${names(t.list)}`], reply: `${jnames(t.list)}を削除します` };
};
H.rename = (c, sim) => {
  let m = c.match(/名前を\s*(\S+?)\s*(?:に|へ)(?:変え|して|変更|する|$)/) || c.match(/(\S+?)\s*(?:という|って)名前/) || c.match(/(\S+?)\s*と(?:呼ぶ|呼んで|名付け|名づけ)/) || c.match(/名前\s*(?:は|を)?\s*(\S+?)\s*(?:で|に)?$/);
  if (!m) return null;
  let nn = m[1].split(/[をはがの、,]/).pop();
  const before = c.slice(0, m.index + m[1].length - nn.length);
  const t = targets(before || c, sim, { exclude: [nn] });
  const b = t.list.length === 1 ? t.list[0] : null;
  if (!b) return { ask: whichAsk(sim, "の名前を変える") };
  if (!nn || bodyByName(sim, nn) === b) return null;
  const old = b.name; b.name = nn; if (sim.last === old) sim.last = nn;
  return { lines: [`名前変更 ${old} ${nn}`], reply: `${old}の名前を「${nn}」にします` };
};
H.material = (c, sim) => {
  const hit = MATS.find(([, re]) => re.test(c));
  if (!hit) return null;
  if (!/材料|で作|にして|に変え|にする|製|に$|へ|で$/.test(c)) return null;
  const t = targets(c.replace(hit[1], " "), sim);
  if (!t.list.length) return { ask: whichAsk(sim, "の材料") };
  return { lines: [`材料 ${names(t.list)} ${hit[0]}`], reply: `${jnames(t.list)}の材料を${hit[0]}にします` };
};
H.color = (c, sim) => {
  const hex = (c.match(/#[0-9a-fA-F]{6}/) || [])[0];
  const hit = COLORS.find(([, re]) => re.test(c));
  if (!hex && !hit) return null;
  if (!(hit && new RegExp(`(?:${hit[1].source})\\s*$`).test(c)) && !(/色|く(?:して|する|塗|な)|く$|(?:は|を)\s*\S{0,4}$|に(?:して|する|塗|変え|$)|で塗|塗って|ペイント|カラー/.test(c))) return null;
  const col = hex || hit[0];
  void col;
  const t = targets(c.replace(hit ? hit[1] : hex, " "), sim);
  if (!t.list.length) return { ask: whichAsk(sim, "の色") };
  return { lines: [`色 ${col} ${names(t.list)}`], reply: `${jnames(t.list)}を${col}${hex ? "" : "色"}にします`.replace("色色", "色") };
};
H.scale = (c, sim) => {
  const k = factorOf(c);
  if (k == null) return null;
  const dimKey = /幅|奥行|高さ|厚さ|長さ|直径|径|穴|R\d|角/.test(c);
  if (dimKey) return null;
  if (!/大きさ|サイズ|全体|全部|拡大|縮小|大きく|小さく|縮め|スケール|倍|半分|分の/.test(c)) return null;
  if (/コピー|並べ|枚|ピッチ/.test(c)) return null;
  const t = targets(c, sim);
  const all = t.how === "all" || t.how === "none" || (sim.bodies.length > 1 && !["name", "this", "that", "except"].includes(t.how));
  if (!(k > 0) || k > 1000) return { ask: "何倍にしますか？（例: 2倍・半分・10分の1）" };
  const ks = fmt(k);
  if (all) { for (const b of sim.bodies) { b.min = b.min.map((v) => v * k); b.max = b.max.map((v) => v * k); } return { lines: [`スケール ${ks}`], reply: `全部の大きさを ${ks} 倍にします（原点が基準）` }; }
  return { lines: [`スケール ${ks} ${names(t.list)} 中心`], reply: `${jnames(t.list)}を、その場で ${ks} 倍にします` };
};

// ---- 穴
function holeFeature(c, sim) {
  const holes = sim.features.filter((f) => f.type === "hole");
  const named = holes.filter((f) => c.includes(f.name)).sort((a, b) => b.name.length - a.name.length)[0];
  if (named) return named;
  if (sim.lastHole) return holes.find((f) => f.name === sim.lastHole) || { name: sim.lastHole };
  const t = mentions(c, sim).flatMap((m) => m.bodies);
  const onBody = t.length ? holes.filter((f) => t.some((b) => b.name === f.body)).pop() : null;
  return onBody || holes[holes.length - 1] || null;
}
const FACE_WORDS = [["上面", /上面|上の面|表面|天面|上から/], ["下面", /下面|下の面|裏面|裏側|底面|下から/], ["前面", /前面|正面|前の面|手前の面/], ["背面", /背面|後ろの面|奥の面|裏の面/], ["左面", /左面|左の面|左側面/], ["右面", /右面|右の面|右側面/]];
H.hole = (c, sim) => {
  if (!/穴|ボルト|ビス|ねじ|ネジ|M\d/.test(c)) return null;
  let dia = null, m;
  const c0 = c; c = c.replace(/(穴|フィレット|面取り|押し出し)\d+/g, (x) => x.replace(/\d+$/, "#"));
  if ((m = c.match(/M(\d+)/))) dia = BOLT[+m[1]] || +m[1] + 1;
  if (dia == null && (m = c.match(new RegExp(`Ø\\s*(${NUM})`)))) dia = +m[1];
  if (dia == null && (m = c.match(new RegExp(`(?:直径|穴径|径|太さ)\\s*(?:は|を|が)?\\s*(${NUM})`)))) dia = +m[1];
  if (dia == null && (m = c.match(new RegExp(`(${NUM})\\s*(?:の|で)?\\s*(?:丸)?穴`)))) dia = +m[1];
  if (dia == null && (m = c.match(new RegExp(`穴#?(?:の大きさ|のサイズ|の径|の直径)?\\s*(?:は|を|が)?\\s*(${NUM})(?!\\s*(?:個|つ|か所|箇所|ヶ所|カ所))`)))) dia = +m[1];
  if (dia == null && (m = c.match(new RegExp(`半径\\s*(${NUM})`)))) dia = +m[1] * 2;
  const depth = (c.match(new RegExp(`深さ\\s*(?:は|を)?\\s*(${NUM})`)) || c.match(new RegExp(`(${NUM})\\s*(?:の)?深さ`)) || [])[1];
  const change = /変え|変更|直して|直す|広げ|大きく|小さく|にして|に修正/.test(c);
  const layoutWords = /四隅|角に|真ん中|中央|中心|両端|端から|縁から|ふちから|位置|座標|,|並べ|等間隔|ピッチ|間隔/.test(c);
  // 既にある穴を直す
  if (change && !layoutWords && sim.features.some((f) => f.type === "hole")) {
    const h = holeFeature(c0, sim);
    const parts = [], rep = [];
    if (dia != null) { parts.push(`${h.name} 径 ${fmt(dia)}`); rep.push(`径を ${fmt(dia)}`); }
    if (depth != null) { parts.push(`${h.name} 深さ ${fmt(depth)}`); rep.push(`深さを ${fmt(depth)}`); }
    if (/貫通|突き抜/.test(c)) { parts.push(`${h.name} 貫通`); rep.push("貫通"); }
    if (!parts.length) { const fk = factorOf(c); if (fk && h.d) { parts.push(`${h.name} 径 ${fmt(h.d * fk)}`); rep.push(`径を ${fmt(h.d * fk)}`); } }
    if (!parts.length) return { ask: `${h.name}をどう変えますか？（例: 穴を10ミリに・深さ5に）` };
    return { lines: parts, reply: `${h.name}の${rep.join("、")}にします` };
  }
  const t = targets(c, sim);
  const b = t.list[0];
  if (!b) return { ask: sim.bodies.length ? whichAsk(sim, "に穴をあける") : "穴をあける部品がまだありません。先に板などを作ってください（例: 幅600 奥行400 厚さ20 の板）" };
  if (dia == null) return { ask: `穴の直径はいくつにしますか？（例: 8ミリの穴）`, need: "dia" };
  const face = (FACE_WORDS.find(([, re]) => re.test(c)) || ["上面"])[0];
  const sz = sizeOf(b);
  const [U, V] = { 上面: [sz[0], sz[1]], 下面: [sz[0], sz[1]], 前面: [sz[0], sz[2]], 背面: [sz[0], sz[2]], 左面: [sz[1], sz[2]], 右面: [sz[1], sz[2]] }[face];
  const marg = (c.match(new RegExp(`(?:端|縁|ふち|へり|角|外側|辺|エッジ)(?:から|より)\\s*(?:は|を)?\\s*(${NUM})`)) || c.match(new RegExp(`(${NUM})\\s*(?:の|で)?\\s*(?:ところ|位置|内側|入った|入れた|内に|離し|離れ|控え)`)) || [])[1];
  let pts = null, rep = "";
  const coords = [...c.matchAll(new RegExp(`(${NUM})\\s*,\\s*(${NUM})`, "g"))].map((x) => [+x[1], +x[2]]);
  const cnt = countOf(c);
  if (coords.length) { pts = coords; rep = `${coords.length} か所に`; }
  else if (/四隅|角に|隅に|コーナー/.test(c)) {
    if (marg == null) return { ask: "四隅の穴は、端から何ミリのところにしますか？（例: 端から30）", need: "margin" };
    const e = +marg; pts = [[e, e], [U - e, e], [U - e, V - e], [e, V - e]]; rep = `四隅（端から ${fmt(e)}）に`;
  } else if (/両端|左右/.test(c)) {
    if (marg == null) return { ask: "両端の穴は、端から何ミリのところにしますか？（例: 端から30）", need: "margin" };
    const e = +marg; pts = [[e, V / 2], [U - e, V / 2]]; rep = `両端（端から ${fmt(e)}）に`;
  } else if (/真ん中|中央|中心|まんなか/.test(c) && !(cnt > 1)) { pts = [[U / 2, V / 2]]; rep = "真ん中に"; }
  else if (cnt > 1 && /並べ|等間隔|ピッチ|間隔|おき|一列|1列/.test(c)) {
    const p = pitchOf(c);
    if (p != null) { const x0 = (U - p * (cnt - 1)) / 2; pts = Array.from({ length: cnt }, (_, i) => [x0 + p * i, V / 2]); rep = `${cnt} 個（${fmt(p)} ピッチ、中央に一列）`; }
    else if (marg != null) { const e = +marg; pts = Array.from({ length: cnt }, (_, i) => [e + (U - 2 * e) * i / (cnt - 1), V / 2]); rep = `${cnt} 個（端から ${fmt(e)}、等間隔に一列）`; }
    else return { ask: "穴の間隔（ピッチ）か、端からの距離を教えてください（例: 100ピッチで / 端から30で）", need: "pitch" };
  }
  if (!pts) return { ask: "穴の位置はどこにしますか？（例: 四隅に端から30 ／ 真ん中に ／ 位置 30,25）", need: "pos" };
  if (pts.some(([x, y]) => x < 0 || y < 0 || x > U + 1e-9 || y > V + 1e-9)) return { ask: `穴の位置が${b.name}の${face}（${fmt(U)}×${fmt(V)}）からはみ出します。端からの距離を確かめてください` };
  const P = pts.map(([x, y]) => `${fmt(x)},${fmt(y)}`).join(" ");
  const hn = nextName(sim, "hole", "穴");
  sim.features.push({ name: hn, type: "hole", body: b.name, d: dia }); sim.lastHole = hn;
  return { lines: [`穴 ${face} Ø${fmt(dia)}${depth != null ? " 深さ" + fmt(depth) : ""} 位置 ${P} ${b.name}`], reply: `${b.name}の${face}${rep} Ø${fmt(dia)} の穴を${depth != null ? `深さ ${fmt(depth)} で` : ""}あけます` };
};

// ---- 角の丸め・面取り
H.fillet = (c, sim) => {
  const cham = /面取り|C\d|糸面/.test(c);
  if (!(cham || /丸め|丸く|丸み|フィレット|R\d|アール|角を?R/.test(c))) return null;
  if (/丸棒|丸い棒|円柱/.test(c)) return null;
  let m, r = null;
  if (cham) r = (c.match(new RegExp(`C\\s*(${NUM})`)) || c.match(new RegExp(`面取り\\s*(?:を|は)?\\s*(${NUM})`)) || c.match(new RegExp(`(${NUM})\\s*(?:の|で)?\\s*面取り`)) || [])[1];
  else r = (c.match(new RegExp(`R\\s*(${NUM})`)) || c.match(new RegExp(`半径\\s*(?:は|を)?\\s*(${NUM})`)) || c.match(new RegExp(`(${NUM})\\s*(?:の|で)?\\s*(?:丸|R|フィレット)`)) || c.match(new RegExp(`(?:丸め|丸く|フィレット)\\D{0,4}?(${NUM})`)) || [])[1];
  if (/糸面/.test(c) && r == null) r = 0.5;
  const type = cham ? "chamfer" : "fillet";
  const change = /変え|変更|直し|直す|に修正|大きく|小さく/.test(c);
  const ex = sim.features.filter((f) => f.type === type);
  if (change && ex.length) {
    const named = ex.find((f) => c.includes(f.name));
    const t = targets(c, sim); const onB = t.how === "name" ? ex.filter((f) => t.list.some((b) => b.name === f.body)).pop() : null;
    const f = named || onB || (sim.lastFillet && ex.find((x) => x.name === sim.lastFillet)) || ex[ex.length - 1];
    if (r == null) return { ask: `${f.name}を${cham ? "C" : "R"}いくつにしますか？` };
    return { lines: [`${f.name} ${cham ? "C" : "R"} ${fmt(r)}`], reply: `${f.name}を${cham ? "C" : "R"}${fmt(r)}にします` };
  }
  const kind = /全部の(?:角|辺|エッジ)|(?:角|辺)(?:を|、|\s)*全部|全部(?:を)?面取り|すべての(?:角|辺)|全部(?:を)?丸|全部の|全体の角|全周/.test(c) ? "すべての辺" : /縦|垂直|立って/.test(c) ? "縦の辺" : /上の(?:角|辺)|上側|上面の|天面の/.test(c) ? "上の辺" : /下の(?:角|辺)|下側|底の/.test(c) ? "下の辺" : /水平|横の辺/.test(c) ? "水平の辺" : null;
  let t = targets(c.replace(/全部の(?:角|辺|エッジ)|全部/g, " "), sim);
  if (!t.list.length && sim.bodies.length) t = { list: [...sim.bodies], how: "all" };
  if (!t.list.length) return { ask: "丸める部品がまだありません。先に板などを作ってください" };
  if (r == null) return { ask: cham ? "面取りの大きさはいくつにしますか？（例: C2）" : "丸める大きさ（R）はいくつにしますか？（例: R5）", need: "r" };
  const out = [], reps = [];
  for (const b of t.list) {
    const sz = sizeOf(b);
    // 「角を丸く」だけのとき: 寝ている板なら四隅（縦の辺）、それ以外はすべての辺
    const k = kind || (sz[2] <= Math.min(sz[0], sz[1]) && b.type !== "cylinder" ? "縦の辺" : "すべての辺");
    out.push(`${cham ? "面取り C" : "フィレット R"}${fmt(r)} ${k} ${b.name}`);
    const fn = nextName(sim, type, cham ? "面取り" : "フィレット"); sim.features.push({ name: fn, type, body: b.name }); sim.lastFillet = fn;
    reps.push(`${b.name}の${k}`);
  }
  return { lines: out, reply: `${reps.join("・")}を${cham ? "C" : "R"}${fmt(r)}で${cham ? "面取り" : "丸め"}ます` };
};

// ---- 並べる（矩形パターン）
H.pattern = (c, sim, opt = {}) => {
  const cnt = countOf(c), p = pitchOf(c);
  if (!(cnt > 1) || !(p != null || /並べ|ピッチ|間隔|等間隔|おき/.test(c))) return null;
  if (/穴|丸め|面取り/.test(c)) return null;
  const t = opt.target ? { list: [opt.target], how: "name" } : targets(c, sim);
  const b = t.list[0];
  if (!b) {
    const pm = mentions(c, sim)[0];
    return { ask: pm ? `${pm.canon}がまだありません。先に${pm.canon}の大きさを教えてください（例: 幅564 奥行400 厚さ18 の${pm.canon}）` : whichAsk(sim, "を並べる"), need: "body" };
  }
  if (p == null) return { ask: `${b.name}を並べる間隔（ピッチ）は何ミリにしますか？（例: 300ピッチ）`, need: "pitch" };
  const sz = sizeOf(b);
  let dir = /横|左右|右へ|右に|X/.test(c) ? "X" : /奥|前後|Y/.test(c) ? "Y" : /縦に|上下|上に|上へ|高さ方向|段|Z/.test(c) ? "Z" : null;
  if (!dir) dir = /棚/.test(b.name) || (sz[2] <= Math.min(sz[0], sz[1]) && /段|上/.test(c)) ? "Z" : sz[0] <= Math.min(sz[1], sz[2]) ? "X" : /棚/.test(b.name) ? "Z" : "X";
  for (let i = 1; i < cnt; i++) { const nb = { ...b, name: `${b.name}_${i + 1}`, min: [...b.min], max: [...b.max] }; const ax = "XYZ".indexOf(dir); nb.min[ax] += p * i; nb.max[ax] += p * i; sim.bodies.push(nb); }
  return { lines: [`矩形パターン ${b.name} ${dir}方向 ${cnt}個 間隔${fmt(p)}`], reply: `${b.name}を${{ X: "横（X）", Y: "奥（Y）", Z: "上（Z）" }[dir]}方向に ${fmt(p)} ピッチで ${cnt} 枚に並べます` };
};

// ---- 対称（ミラー）
H.mirror = (c, sim, opt = {}) => {
  if (!/対称|ミラー|鏡|反対側にも|反対側に|向かい側|左右に|両側に/.test(c)) return null;
  if (/穴|丸め|面取り/.test(c)) return null;
  const t = opt.target ? { list: [opt.target], how: "name" } : targets(c, sim);
  const bs = t.list;
  if (!bs.length) {
    const pm = mentions(c, sim)[0];
    return { ask: pm ? `${pm.canon}がまだありません。先に${pm.canon}の大きさを教えてください（例: 高さ900 奥行400 厚さ18 の${pm.canon}）` : whichAsk(sim, "を対称にする"), need: "body" };
  }
  const plane = /前後|手前と奥/.test(c) ? "XZ" : /上下/.test(c) ? "XY" : "YZ";
  const ax = { YZ: 0, XZ: 1, XY: 2 }[plane];
  const others = sim.bodies.filter((b) => !bs.includes(b) && !bs.some((x) => b.name.startsWith(x.name + "(")));
  let ref = mentions(c, sim).filter((m) => m.bodies.length && !m.bodies.some((x) => bs.includes(x))).flatMap((m) => m.bodies);
  if (!ref.length) { const vol = (b) => sizeOf(b).reduce((a, x) => a * Math.max(x, 1e-6), 1); const mx = Math.max(0, ...others.map(vol)); ref = others.filter((b) => vol(b) >= mx * 0.2); }
  if (!ref.length) return { ask: "どこを中心に対称にしますか？（例: 床板の真ん中で左右対称に）" };
  const [lo, hi] = unionBox(ref);
  const pos = (lo[ax] + hi[ax]) / 2;
  for (const b of bs) { const nb = { ...b, name: `${b.name}(ミラー)`, min: [...b.min], max: [...b.max] }; nb.min[ax] = 2 * pos - b.max[ax]; nb.max[ax] = 2 * pos - b.min[ax]; sim.bodies.push(nb); }
  return { lines: [`ミラー ${names(bs)} ${plane} 位置 ${fmt(pos)}`], reply: `${jnames(bs)}を${{ YZ: "左右", XZ: "前後", XY: "上下" }[plane]}対称に（${jnames(ref)}の真ん中 ${fmt(pos)} で反転して）もう 1 枚作ります` };
};

// ---- 向きと移動量
const DIRS = [["右", 0, 1], ["左", 0, -1], ["奥", 1, 1], ["後ろ", 1, 1], ["うしろ", 1, 1], ["向こう", 1, 1], ["手前", 1, -1], ["前", 1, -1], ["上", 2, 1], ["下", 2, -1]];
function moveVector(c) {
  const v = [0, 0, 0]; let any = false, needNum = false;
  const clean = c.replace(/奥行|上面|下面|前面|背面|上の辺|下の辺|上から|下から|前から|右面|左面|以上|以下|上げ|下げ|手前に引/g, (m) => /上げ/.test(m) ? "上げ" : /下げ/.test(m) ? "下げ" : /手前に引/.test(m) ? "手前に引" : "\u0001".repeat(m.length));
  const axisRe = new RegExp(`([XYZ])\\s*(?:方向|軸)?\\s*(?:に|へ|を)?\\s*(${NUM})`, "gi");
  for (const m of clean.matchAll(axisRe)) { v["XYZ".indexOf(m[1].toUpperCase())] += +m[2]; any = true; }
  if (any) return { v, any, needNum };
  const used = new Set();
  const nums = [...clean.matchAll(new RegExp(`(?<![A-Za-zØ\\d.])(${NUM})(?!\\s*(?:度|°|枚|個|本|つ|倍|分の|%))`, "g"))].map((m) => ({ v: +m[1], at: m.index, end: m.index + m[0].length }));
  const dirs = [];
  for (const [w, ax, sg] of DIRS) { let i = -1; while ((i = clean.indexOf(w, i + 1)) >= 0) { if (dirs.some((d) => i >= d.at && i < d.at + d.w.length)) continue; dirs.push({ w, ax, sg, at: i }); } }
  for (const m of clean.matchAll(/上げ|持ち上げ|下げ|引き下げ|おろ|降ろ/g)) dirs.push({ w: m[0], ax: 2, sg: /上げ/.test(m[0]) ? 1 : -1, at: m.index });
  dirs.sort((a, b) => a.at - b.at);
  const seen = new Set();
  for (const d of dirs) {
    const key = d.ax + ":" + d.at; if (seen.has(key)) continue; seen.add(key);
    // 向きの後ろの数 → 前の数 の順に、まだ使っていない一番近い数
    const after = nums.filter((n) => !used.has(n) && n.at > d.at).sort((a, b) => a.at - b.at)[0];
    const before = nums.filter((n) => !used.has(n) && n.end <= d.at).sort((a, b) => b.at - a.at)[0];
    const nextDir = dirs.find((x) => x.at > d.at && x !== d);
    let n = after && (!nextDir || after.at < nextDir.at) ? after : before || after;
    if (!n) { needNum = true; continue; }
    used.add(n); v[d.ax] += d.sg * n.v; any = true;
  }
  return { v, any, needNum: needNum || (!any && dirs.length > 0), dirs };
}
H.copy = (c, sim) => {
  if (!/コピー|複製|もう1つ|もう1枚|もう1本|もう1個|同じもの|同じのを|同じやつ/.test(c)) return null;
  const t = targets(c, sim); const bs = t.list;
  if (!bs.length) return { ask: whichAsk(sim, "をコピーする") };
  const mv = moveVector(c);
  if (!mv.any) return { ask: `${jnames(bs)}のコピーをどこに置きますか？（例: 右に500 ／ 上に300）`, need: "dir" };
  for (const b of bs) sim.bodies.push({ ...b, name: `${b.name}(コピー)`, min: b.min.map((x, i) => x + mv.v[i]), max: b.max.map((x, i) => x + mv.v[i]) });
  return { lines: [`コピー ${names(bs)} ${mv.v.map(fmt).join(",")}`], reply: `${jnames(bs)}をコピーして（${mv.v.map(fmt).join(", ")}）ずらして置きます` };
};
H.rotate = (c, sim) => {
  if (!/回して|回す|回転|回り|まわり|向きを変え|立てて|寝かせ|倒して|ひっくり返|逆さま|上下逆/.test(c)) return null;
  let ang = (c.match(new RegExp(`(${NUM})\\s*(?:度|°)`)) || [])[1];
  if (ang == null && /ひっくり返|裏返|逆さま|上下逆/.test(c)) ang = 180;
  if (ang == null && /立てて|寝かせ|倒して|直角/.test(c)) ang = 90;
  const t = targets(c, sim); const bs = t.list;
  if (!bs.length) return { ask: whichAsk(sim, "を回す") };
  if (ang == null) return { ask: `${jnames(bs)}を何度回しますか？（例: 90度）`, need: "angle" };
  // 上から見て反時計回りが +。「時計回り」「右回り」は -
  if (!/反時計|左回り|逆回り/.test(c) && /時計回り|右回り/.test(c)) ang = -ang;
  const axis = (c.match(/([XYZ])\s*軸/i) || [])[1]?.toUpperCase() || (/立てて|寝かせ|倒して|ひっくり返|裏返|逆さま|上下逆/.test(c) ? (/横に倒|左右/.test(c) ? "Y" : "X") : "Z");
  return { lines: [`回す ${names(bs)} ${fmt(ang)} 軸 ${axis}`], reply: `${jnames(bs)}を ${axis} 軸のまわりに ${fmt(ang)}° 回します` };
};
// 置く・動かす（相対の向き・〜の上に・真ん中に・原点に）
H.move = (c, sim) => {
  const verb = /動か|移動|ずら|寄せ|移し|持って|もって|スライド|置い|置く|載せ|乗せ|のせ|配置|上げ|下げ|おろ|降ろ|戻して|もどして|合わせ|揃え|そろえ/.test(c);
  const ms = mentions(c, sim).filter((m) => m.bodies.length);
  // 「天板を側板の上に置いて」「床板の真ん中に」
  const rel = c.match(/(\S+?)の\s*(上|下|右|左|前|手前|奥|後ろ|隣|横|真ん中|中央|中心)(?:の真ん中|の中央|の中心)?(?:側)?\s*(?:に|へ)/);
  const refM = rel && ms.find((m) => rel[1].endsWith(m.word));
  if (refM && (verb || /(?:に|へ)\s*$/.test(c))) {
    const t = targets(c.replace(new RegExp(`${esc(refM.word)}\\s*の\\s*${rel[2]}`), " "), sim, { exclude: [refM.word] });
    const bs = t.list.filter((b) => !refM.bodies.includes(b));
    if (!bs.length) return { ask: `${refM.word}の${rel[2]}に何を置きますか？` };
    const ref = refM.bodies[0];
    let side = { 上: "上", 下: "下", 右: "右", 左: "左", 前: "前", 手前: "前", 奥: "奥", 後ろ: "奥", 隣: "右", 横: "右" }[rel[2]];
    const center = /真ん中|中央|中心|まんなか/.test(c);
    if (!side) { // 「床板の真ん中に」: 高さはそのまま、横・奥を真ん中に
      const [lo, hi] = unionBox(bs); const cx = (ref.min[0] + ref.max[0]) / 2, cy = (ref.min[1] + ref.max[1]) / 2, cz = (lo[2] + hi[2]) / 2;
      applyMove(bs, [cx - (lo[0] + hi[0]) / 2, cy - (lo[1] + hi[1]) / 2, 0]);
      return { lines: [`置く ${names(bs)} 中心 ${fmt(cx)},${fmt(cy)},${fmt(cz)}`], reply: `${jnames(bs)}を${ref.name}の真ん中に合わせます（高さはそのまま）` };
    }
    // 小さいものを大きいものの上・下に載せるときは、真ん中にそろえる
    const [blo, bhi] = unionBox(bs);
    const auto = !center && /上|下/.test(side) && bhi[0] - blo[0] < ref.max[0] - ref.min[0] && bhi[1] - blo[1] < ref.max[1] - ref.min[1];
    const ctr = center || auto;
    placeSim(bs, ref, side, ctr);
    if (ctr !== center) return { lines: [`置く ${names(bs)} ${side} ${ref.name} 中央`], reply: `${jnames(bs)}を${ref.name}の${side}の真ん中に置きます` };
    return { lines: [`置く ${names(bs)} ${side} ${ref.name}${center ? " 中央" : ""}`], reply: `${jnames(bs)}を${ref.name}の${side === "前" ? "手前" : side}に${center ? "真ん中をそろえて" : ""}置きます` };
  }
  if (/原点/.test(c) && verb) {
    const t = targets(c, sim); if (!t.list.length) return { ask: whichAsk(sim, "を原点に置く") };
    const [lo] = unionBox(t.list); applyMove(t.list, lo.map((x) => -x));
    return { lines: [`置く ${names(t.list)} 位置 0,0,0`], reply: `${jnames(t.list)}の角を原点に合わせます` };
  }
  const pos = c.match(new RegExp(`(?:位置|座標|場所)\\s*(?:を|は)?\\s*(${NUM})\\s*,\\s*(${NUM})(?:\\s*,\\s*(${NUM}))?`));
  if (pos && verb) {
    const t = targets(c, sim); if (!t.list.length) return { ask: whichAsk(sim, "を置く") };
    const p = [+pos[1], +pos[2], pos[3] != null ? +pos[3] : t.list[0].min[2]];
    applyMove(t.list, p.map((x, i) => x - unionBox(t.list)[0][i]));
    return { lines: [`置く ${names(t.list)} 位置 ${p.map(fmt).join(",")}`], reply: `${jnames(t.list)}を ${p.map(fmt).join(", ")} に置きます` };
  }
  if (/真ん中|中央|まんなか/.test(c) && verb && !/穴/.test(c)) {
    const t = targets(c, sim); const bs = t.list; if (!bs.length) return { ask: whichAsk(sim, "を真ん中に置く") };
    const others = sim.bodies.filter((b) => !bs.includes(b));
    if (!others.length) return { ask: "何の真ん中に置きますか？（例: 床板の真ん中に）" };
    const [rlo, rhi] = unionBox(others), [lo, hi] = unionBox(bs);
    const cx = (rlo[0] + rhi[0]) / 2, cy = (rlo[1] + rhi[1]) / 2, cz = (lo[2] + hi[2]) / 2;
    applyMove(bs, [cx - (lo[0] + hi[0]) / 2, cy - (lo[1] + hi[1]) / 2, 0]);
    return { lines: [`置く ${names(bs)} 中心 ${fmt(cx)},${fmt(cy)},${fmt(cz)}`], reply: `${jnames(bs)}をほかの部品の真ん中に合わせます（高さはそのまま）` };
  }
  const mv = moveVector(c);
  if (!verb && !(mv.any && !/作|穴|丸|色|枚|本|個|倍|度/.test(c))) return null;
  if (!mv.any) {
    if (!mv.dirs || !mv.dirs.length) return null;
    const t = targets(c, sim);
    return { ask: `${t.list.length ? jnames(t.list) + "を" : ""}何ミリ動かしますか？（例: 右に100）`, need: "num" };
  }
  const t = targets(c, sim); const bs = t.list;
  if (!bs.length) return { ask: whichAsk(sim, "を動かす") };
  applyMove(bs, mv.v);
  return { lines: [`移動 ${names(bs)} ${mv.v.map(fmt).join(",")}`], reply: `${jnames(bs)}を${describeMove(mv.v)}動かします` };
};
function describeMove(v) {
  const w = [["右", "左"], ["奥", "手前"], ["上", "下"]];
  return v.map((x, i) => (x ? `${w[i][x > 0 ? 0 : 1]}に ${fmt(Math.abs(x))}` : "")).filter(Boolean).join("、") + " ";
}
function applyMove(bs, d) { for (const b of bs) { b.min = b.min.map((x, i) => x + d[i]); b.max = b.max.map((x, i) => x + d[i]); } }
function placeSim(bs, ref, side, center) {
  const [lo, hi] = unionBox(bs); const d = [0, 0, 0];
  const ax = /上|下/.test(side) ? 2 : /右|左/.test(side) ? 0 : 1, pos = /上|右|奥/.test(side);
  d[ax] = pos ? ref.max[ax] - lo[ax] : ref.min[ax] - hi[ax];
  if (center) for (const i of [0, 1, 2]) if (i !== ax) d[i] = (ref.min[i] + ref.max[i]) / 2 - (lo[i] + hi[i]) / 2;
  applyMove(bs, d);
}

// ---- 作る（板・円柱・球）
function createName(c, sim) {
  for (const m of mentions(c, sim)) if (/^\s*(?:を|が|は|も|、|ほし|欲し|で[、,\s])/.test(c.slice(m.at + m.word.length)) && !m.bodies.length) return m.canon;
  // 「〜を作って」「〜が欲しい」の「〜」
  const m = c.match(/([一-龥ァ-ヶーA-Za-z々]+?\d*)\s*(?:を|が|は|も)\s*(?:\d+\s*(?:枚|個|本|つ))?[^。]*?(?:作|つく|追加|用意|足し|出し|置|欲し|ほし|置き|並べ|$)/);
  let n = m ? m[1] : null;
  if (!n) { const k = c.match(/の\s*([一-龥ァ-ヶーA-Za-z々]+)\s*$/); if (k) n = k[1]; }
  if (!n) return null;
  n = n.replace(/^(?:新しい|新しく|あと|もう)/, "");
  return GENERIC.test(n) ? null : CANON.get(n) || n;
}
H.create = (c, sim) => {
  const verb = /作っ|作る|作り|作成|つくっ|つくる|追加|用意|足して|足す|新しく|出して|置いて|置く|欲しい|ほしい|立てて|並べて/.test(c);
  const d = dimsOf(c);
  const hasDims = d.w != null || d.d != null || d.h != null || d.t != null || d.dia != null || d.xyz || d.square != null || d.len != null;
  const shapeWord = /円柱|丸棒|丸い棒|パイプ|ポール|球|ボール|板|箱|ボックス|直方体|ブロック|パネル|柱|脚|棚|扉|壁|天井|ベース|台/.test(c);
  const noBodyDims = hasDims && !sim.bodies.length && (d.w != null || d.d != null || d.t != null || d.xyz);
  if (!verb && !noBodyDims && !(hasDims && shapeWord && !mentions(c, sim).some((m) => m.bodies.length && !/作|追加/.test(c)))) return null;
  if (!hasDims && !shapeWord) return null;
  if (!hasDims && !/作|つく|追加|用意|新しく|欲し|ほし/.test(c)) return null;
  const ms = mentions(c, sim);
  let nm = createName(c, sim);
  const exists = nm && bodyByName(sim, nm);
  // 既にある部品を「置いて」「並べて」だけ → ここではない（動かす・並べる）
  if (exists && !hasDims && !/作|追加|用意|新しく|もう/.test(c)) return null;
  if (!hasDims) {
    if (/並べ|対称|ピッチ|枚/.test(c) && exists) return null;
    const what = nm || "板";
    return { ask: `${what}の大きさを教えてください（例: 幅600 奥行400 厚さ20${/円柱|丸棒|柱|パイプ/.test(c) ? " ／ 直径50 高さ100" : ""}）`, need: "dims" };
  }
  if (exists) { let k = 2; while (bodyByName(sim, nm + k)) k++; nm = nm + k; }
  const nameOpt = nm ? ` 名前 ${nm}` : "";
  let line, size, rep;
  const pos0 = (c.match(new RegExp(`位置\\s*(${NUM})\\s*,\\s*(${NUM})(?:\\s*,\\s*(${NUM}))?`)) || null);
  const P = pos0 ? [+pos0[1], +pos0[2], pos0[3] != null ? +pos0[3] : 0] : null;
  const posOpt = P ? ` 位置 ${P.map(fmt).join(",")}` : "";
  if (/円柱|丸棒|丸い棒|パイプ|ポール/.test(c) || (/柱|脚/.test(c) && (d.dia != null || d.r != null))) {
    const dia = d.dia ?? (d.r != null ? d.r * 2 : null), h = d.h ?? d.len ?? d.t;
    if (dia == null || h == null) return { ask: `${nm || "円柱"}の${dia == null ? "直径" : "高さ"}を教えてください（例: 直径50 高さ100）`, need: "dims" };
    line = `円柱 直径${fmt(dia)} 高さ${fmt(h)}${posOpt}${nameOpt}`; size = [dia, dia, h]; rep = `${nm || "円柱"}（直径 ${fmt(dia)}、高さ ${fmt(h)}）`;
  } else if (/球|ボール/.test(c)) {
    const dia = d.dia ?? (d.r != null ? d.r * 2 : null);
    if (dia == null) return { ask: "球の直径を教えてください（例: 直径100）", need: "dims" };
    line = `球 直径${fmt(dia)}${posOpt}${nameOpt}`; size = [dia, dia, dia]; rep = `球（直径 ${fmt(dia)}）`;
  } else {
    let w = d.w, dp = d.d, h = d.h, t = d.t;
    if (d.xyz) { [w, dp] = [d.xyz[0], d.xyz[1]]; if (d.xyz[2] != null) h = d.xyz[2]; }
    if (d.square != null) { w = w ?? d.square; dp = dp ?? d.square; }
    if (d.len != null && w == null) w = d.len;
    else if (d.len != null && w != null && dp == null) { dp = w; w = d.len; } // 「長さ1500 幅300」→ 長い方が幅
    if (d.tate != null) { if (VERTICAL.test(nm || "") || /立て/.test(c)) h = h ?? d.tate; else if (dp == null) dp = d.tate; }
    const vertical = (nm && VERTICAL.test(nm)) || /立て|縦に置/.test(c);
    if (h != null && t != null) {
      // 高さと厚さの両方 → 立っている板（厚さは横向き）
      if (w == null && dp != null) w = t; else if (dp == null && w != null) dp = t; else if (w == null && dp == null) { if (/側板|横板|仕切り/.test(nm || "")) { w = t; } else dp = t; }
      else h = h; // 幅・奥行・高さ・厚さ全部 → 厚さは使わない
    } else if (h == null && t != null) {
      if (vertical && (w == null || dp == null) && !(w == null && dp == null)) { h = w == null ? null : null; }
      h = t;
      if (vertical && w != null && dp == null) { dp = t; h = d.len ?? null; }
    }
    // 立っている板で「縦」「横」と言ったとき
    if (vertical && h == null) { const tate = (c.match(new RegExp(`縦\\s*(${NUM})`)) || [])[1]; if (tate) h = +tate; }
    if (w == null && dp == null && h == null) return { ask: "大きさを教えてください（例: 幅600 奥行400 厚さ20）", need: "dims" };
    const miss = [w == null ? "幅" : null, dp == null ? "奥行" : null, h == null ? (vertical ? "高さ" : "厚さ") : null].filter(Boolean);
    if (miss.length) return { ask: `${nm || "板"}の${miss.join("・")}を教えてください（今わかっているのは${[w != null ? "幅 " + fmt(w) : "", dp != null ? "奥行 " + fmt(dp) : "", h != null ? "厚さ " + fmt(h) : ""].filter(Boolean).join("・")}）`, need: "dims" };
    line = `板 幅${fmt(w)} 奥行${fmt(dp)} 厚さ${fmt(h)}${posOpt}${nameOpt}`; size = [w, dp, h]; rep = `${nm || "板"}（${fmt(w)}×${fmt(dp)}×${fmt(h)}）`;
  }
  const nb = { name: nm || `ボディ${sim.bodies.length + 1}`, type: /^円柱/.test(line) ? "cylinder" : /^球/.test(line) ? "sphere" : "box", min: P ? [...P] : [0, 0, 0], max: (P || [0, 0, 0]).map((v, i) => v + size[i]) };
  sim.bodies.push(nb); sim.last = nb.name; sim.created = nb;
  sim.features.push({ name: nb.name, type: nb.type, body: nb.name });
  const out = { lines: [line], reply: `${rep}を作ります` };
  // 同じ文の続き（「〜の上に置いて」「3枚 300ピッチで」「左右対称に」）
  const rest = c.replace(/^.*?(?:作って|作る|作り|作成して|追加して|用意して)/, "");
  const follow = [];
  if (!nm) out.unnamed = true;
  const rel = c.match(/(\S+?)の\s*(上|下|右|左|前|手前|奥|後ろ|隣|横)(?:側)?\s*(?:に|へ)/);
  const refM = rel && mentions(rel[1], sim).find((m) => m.bodies.length && !m.bodies.includes(nb));
  if (refM) { const side = { 上: "上", 下: "下", 右: "右", 左: "左", 前: "前", 手前: "前", 奥: "奥", 後ろ: "奥", 隣: "右", 横: "右" }[rel[2]]; const center = /真ん中|中央|中心/.test(c) || side === "上" || side === "下"; placeSim([nb], refM.bodies[0], side, center); follow.push({ lines: [`置く ${nb.name} ${side} ${refM.bodies[0].name}${center ? " 中央" : ""}`], reply: `${refM.bodies[0].name}の${side}に置きます` }); }
  const cnt = countOf(c);
  if (cnt > 1 && (pitchOf(c) != null || /並べ/.test(c)) && !/対称/.test(c)) { const r = H.pattern(c, sim, { target: nb }); if (r) follow.push(r); }
  else if (/対称|ミラー|左右に|両側に/.test(c)) { const r = H.mirror(c, sim, { target: nb }); if (r) follow.push(r); }
  void rest;
  for (const f of follow) { if (f.ask) return { ...out, ask: f.ask }; out.lines.push(...f.lines); out.reply += "。" + f.reply; }
  return out;
};

// ---- 寸法を変える（「高さを900に」「幅を半分に」「厚さを5増やして」）
const KEYW = [["w", /幅|横幅|横(?!に|へ|の辺|向)/], ["d", /奥行|奥(?!に|へ|の面)/], ["h", /高さ|丈/], ["t", /厚さ/], ["dia", /直径|径|太さ/], ["len", /長さ/]];
const ADJ = [["t", /厚く|薄く/, "厚さ"], ["h", /高く|低く/, "高さ"], ["len", /長く|短く/, "長さ"], ["dia", /太く|細く/, "直径"], ["w", /広く|狭く/, "幅"]];
H.modify = (c, sim) => {
  for (const [k, re, w] of ADJ) {
    if (!re.test(c) || KEYW.some(([, r]) => r.test(c))) continue;
    const c2 = c.replace(new RegExp(`(${NUM})\\s*(?:だけ)?\\s*(${re.source})`), `${w}を$1$2`);
    c = c2 !== c ? c2 : c.replace(re, (x) => `${w}を${x} `);
  }
  const keys = KEYW.filter(([, re]) => re.test(c)).map(([k]) => k);
  if (!keys.length) return null;
  const t = targets(c, sim);
  const b = t.list[0];
  if (!b) return { ask: whichAsk(sim, "の寸法") };
  if (t.list.length > 1 && t.how !== "name") return { ask: whichAsk(sim, "の寸法") };
  const sz = sizeOf(b);
  const out = [], reps = [];
  for (const k of keys) {
    const re = KEYW.find((x) => x[0] === k)[1];
    const seg = c.slice(c.search(re));
    let m, v = null;
    const cur = { w: sz[0], d: sz[1], h: sz[2], t: Math.min(...sz), dia: sz[0], len: Math.max(...sz) }[k];
    const segOwn = seg.replace(new RegExp(`^(?:${re.source})`), "").split(/(?:幅|奥行|高さ|厚さ|直径|長さ)/)[0];
    const fo = segOwn.match(new RegExp(`^\\s*(?:は|を|が|も)?\\s*(?:${NUM}\\s*(?:倍|分の)|半分)`)) ? factorOf(segOwn) : null;
    if (fo != null) v = cur * fo;
    else if ((m = segOwn.match(new RegExp(`^\\s*(?:は|を|が|も)?\\s*(?:もう)?\\s*(${NUM})\\s*(?:だけ)?\\s*(増や|足|伸ば|長く|高く|厚く|太く|広げ|広く|大きく|プラス|減ら|引|縮め|短く|低く|薄く|細く|狭く|小さく|マイナス)`)))) {
      v = /増や|足|伸ば|長く|高く|厚く|太く|広げ|広く|大きく|プラス/.test(m[2]) ? cur + +m[1] : cur - +m[1];
    } else if ((m = segOwn.match(new RegExp(`^\\s*(?:は|を|が|も)?\\s*(?:\\+)(${NUM})`)))) v = cur + +m[1];
    else if ((m = segOwn.match(new RegExp(`^\\s*(?:は|を|が|も|:|=)?\\s*(${NUM})`)))) v = +m[1];
    else { const f = factorOf(segOwn); if (f != null) v = cur * f; }
    if (v == null && keys.length === 1) { const m2 = c.match(new RegExp(`(${NUM})\\s*の?\\s*(?:${re.source})`)) || c.match(new RegExp(`(${NUM})\\s*(?:に|へ|で)`)); if (m2) v = +m2[1]; }
    if (v == null) {
      if (/もう少し|少し|ちょっと/.test(c) || ADJ.some(([, re]) => re.test(c))) return { ask: `${b.name}の${{ w: "幅", d: "奥行", h: "高さ", t: "厚さ", dia: "直径", len: "長さ" }[k]}をいくつにしますか？（今は ${fmt(cur)}）`, need: "num" };
      continue;
    }
    if (!(v > 0)) return { ask: `${b.name}の寸法が 0 以下になってしまいます（今は ${fmt(cur)}）。いくつにしますか？` };
    const lab = { w: "幅", d: "奥行", h: "高さ", t: "厚さ", dia: "直径", len: "長さ" }[k];
    let cmd;
    if (b.type === "cylinder") cmd = k === "dia" || k === "w" || k === "d" ? "直径" : "高さ";
    else if (b.type === "extrude") { if (k === "w" || k === "d" || k === "dia") return { ask: `${b.name}はスケッチから作った形なので、${lab}はスケッチで直してください（言葉で変えられるのは高さ＝押し出しの距離です）` }; cmd = "距離"; }
    else if (b.type === "sphere") cmd = "直径";
    else if (b.type === "box" || !b.type) {
      const axis = k === "w" ? 0 : k === "d" ? 1 : k === "h" ? 2 : k === "t" ? sz.indexOf(Math.min(...sz)) : k === "len" ? sz.indexOf(Math.max(...sz)) : null;
      if (axis == null) return { ask: `${b.name}は板なので、幅・奥行・厚さ（高さ）で言ってください` };
      cmd = ["幅", "奥行", k === "h" ? "高さ" : "厚さ"][axis];
      b.max[axis] = b.min[axis] + v;
    } else return { ask: `${b.name}（${b.type}）の${lab}は言葉では直せません。画面のタイムラインから直してください` };
    out.push(`${b.name} ${cmd} ${fmt(v)}`); reps.push(`${lab}を ${fmt(v)}`);
  }
  if (!out.length) return null;
  return { lines: out, reply: `${b.name}の${reps.join("、")}にします` };
};

// ---------------------------------------------------------------- 候補（分からないとき）
export const EXAMPLES = [
  "幅60センチ奥行き40で厚さ2センチの床板を作って", "それの四隅に8ミリの穴を端から3センチで", "これを右に100動かして", "棚板を3枚、300ピッチで並べて",
  "全部の角をR5で丸めて", "天板だけ赤くして", "床板の重さは？", "さっきの取り消して", "側板を左右対称に", "高さを900に変えて", "穴を10ミリに変えて",
  "全部のサイズを半分に", "天板を側板の上に置いて", "柱を90度回して", "床板をアルミにして", "全部で何枚？", "STEPで書き出して", "上から見せて",
];
function bigrams(s) { const a = []; for (let i = 0; i < s.length - 1; i++) a.push(s.slice(i, i + 2)); return a; }
export function suggest(text, n = 3) {
  const g = new Set(bigrams(normalizeJa(text)));
  return EXAMPLES.map((e) => ({ e, s: bigrams(normalizeJa(e)).filter((x) => g.has(x)).length })).sort((a, b) => b.s - a.s).slice(0, n).map((x) => x.e);
}

// ---------------------------------------------------------------- 本体
const ORDER = ["undo", "redo", "help", "export", "view", "query", "hideShow", "del", "rename", "material", "color", "hole", "fillet", "create", "pattern", "mirror", "copy", "rotate", "scale", "move", "modify"];
function interpretClause(cl, sim) {
  const c = cl.text;
  // 決まった書き方なら、そのまま通す
  const fixed = speechToCommand(c);
  if (fixed.split("\n").every((l) => isFixedCommand(l, { bodies: sim.bodies, features: sim.features }))) {
    const ls = fixed.split("\n").filter(Boolean);
    trackFixed(ls, sim);
    return { lines: ls, reply: "", fixed: true };
  }
  for (const k of ORDER) {
    const r = H[k](c, sim, { q: cl.q });
    if (r) {
      // 話題の部品（「それから重さを教えて」の対象）
      if (r.lines && r.lines.length) { const t = mentions(c, sim).flatMap((m) => m.bodies); if (t.length === 1) { sim.topic = t[0].name; if (!["query", "undo", "redo", "view", "export", "help"].includes(k)) sim.last = t[0].name; } }
      return { ...r, intent: k };
    }
  }
  return null;
}
// 決まった書き方で作ったものも「それ」で指せるように
function trackFixed(lines, sim) {
  for (const l of lines) {
    const m = l.match(/^(?:板|直方体|箱|円柱|球).*名前\s*(\S+)/);
    if (m) { const d = dimsOf(l); const s = l.startsWith("円柱") ? [d.dia, d.dia, d.h] : l.startsWith("球") ? [d.dia, d.dia, d.dia] : d.xyz ? d.xyz : [d.w, d.d, d.t ?? d.h]; sim.bodies.push({ name: m[1], type: l.startsWith("円柱") ? "cylinder" : l.startsWith("球") ? "sphere" : "box", min: [0, 0, 0], max: s.map((x) => x || 0) }); sim.last = m[1]; }
  }
}

export function interpret(text, context = {}) {
  const raw = String(text || "").trim();
  if (!raw) return { lines: [], reply: "", ask: "何をしましょうか？" };
  const sim = sim0(context);
  // 聞き返しへの答え（「20で」「端から30」）: 前の頼みごとにつなげて読み直す
  if (context.pending && context.pending.text) {
    const alone = interpretInner(raw, sim0(context));
    const merged = interpretInner(context.pending.text + " " + normalizeJa(raw).replace(/^(?:じゃあ|では|なら)\s*/, ""), sim0(context));
    const vague = !alone.lines.length || alone.ask || alone.unknown || !/[てで]$|して|作|変え|動か|消|隠|置|並べ|丸め|塗|戻|教え|[?？]/.test(raw);
    if (vague && merged.lines.length && !merged.ask) return merged;
    if (vague && merged.ask && merged.ask !== context.pending.ask && merged.lines.length >= alone.lines.length) return merged;
  }
  return interpretInner(raw, sim);
}
function interpretInner(raw, sim) {
  const s = normalizeJa(raw);
  if (!s.replace(/[\s、,。！!？?]/g, "")) return { lines: [], reply: "", ask: "何をしましょうか？（例: 「幅600 奥行400 厚さ20 の床板を作って」）", unknown: true };
  const clauses = splitClauses(s, [...sim.bodies.map((b) => b.name), ...[...CANON.keys()].filter((w) => w.length >= 2)]);
  const lines = [], replies = [];
  for (let i = 0; i < clauses.length; i++) {
    let r = interpretClause(clauses[i], sim);
    // 「幅600、」だけの切れ端は次の文とつなげて読む
    // 足りない情報が次の文にあるとき（「穴を四隅に。径は8。端から30。」）は、つなげて読み直す
    for (let j = i + 1, text = clauses[i].text, lastAsk = r && r.ask; (!r || r.ask) && j < clauses.length && j <= i + 3; j++) {
      text += " " + clauses[j].text;
      const joined = { text, q: clauses[j].q };
      const r2 = interpretClause(joined, sim0Copy(sim));
      if (r2 && !r2.ask && r2.lines?.length) { r = interpretClause(joined, sim); i = j; break; }
      if (!r2 || (r2.ask && r2.ask === lastAsk)) break;
      lastAsk = r2.ask;
    }
    if (!r) {
      const cands = suggest(clauses[i].text);
      return { lines, last: sim.last, reply: replies.join("。"), ask: `「${clauses[i].text}」が分かりませんでした。たとえば「${cands[0]}」「${cands[1]}」のように言ってみてください`, candidates: cands, unknown: true, pending: null };
    }
    if (r.ask) {
      return { lines, last: sim.last, reply: replies.join("。"), ask: r.ask, need: r.need, pending: { text: clauses.slice(i).map((x) => x.text).join("。"), ask: r.ask } };
    }
    lines.push(...r.lines);
    if (r.reply) replies.push(r.reply);
  }
  return { lines, last: sim.last, reply: replies.length ? replies.join("。") + "。" : lines.length ? "書かれたとおりに実行します。" : "", ask: null, pending: null };
}
function sim0Copy(sim) { return { ...sim, bodies: sim.bodies.map((b) => ({ ...b, min: [...b.min], max: [...b.max] })), features: sim.features.map((f) => ({ ...f })), selected: [...sim.selected] }; }

// ---------------------------------------------------------------- 小さい AI モデルの答えを確かめる
// text: 利用者の頼みごと、lines: AI が作ったコマンド。数値の取り違え（単位の 10 倍・1000 倍、言っていない数）と
// 書き方の間違いを見つけ、直せるものは直す。nlu 自身の読み取りも返す（AI と食い違うときの比べ用）
export function checkAgainst(text, lines, context = {}) {
  const L = (Array.isArray(lines) ? lines : String(lines || "").split(/\r?\n/)).map((x) => String(x).trim()).filter((x) => x && !x.startsWith("#"));
  const s = normalizeJa(text);
  const said = [...s.matchAll(new RegExp(NUM, "g"))].map((m) => +m[0]);
  const k = factorOf(s); if (k) said.push(k);
  const sizes = (context.bodies || []).flatMap((b) => (b.size || (b.max && b.min ? b.max.map((v, i) => v - b.min[i]) : [])).concat(b.min || [], b.max || []));
  const base = [...new Set([...said, ...sizes, 0])];
  const derived = new Set(base.map((x) => +(+x).toFixed(3)));
  for (const a of base) for (const b of base) for (const v of [a + b, a - b, b - a, a / 2, (a - b) / 2, a * 2, a - 2 * b, a * b, a / (b || 1)]) derived.add(+v.toFixed(3));
  const nameNums = new Set([...(context.bodies || []).map((b) => b.name), ...(context.features || []).map((f) => f.name)]);
  const issues = [], fixed = [];
  const used = new Set();
  for (const line of L) {
    if (!isFixedCommand(line, context)) issues.push({ line, kind: "syntax", message: `「${line}」は決まった書き方ではありません` });
    let out = line;
    let body = line; for (const n of nameNums) body = body.split(n).join(" ");
    for (const m of body.matchAll(new RegExp(`(?<![A-Za-z])${NUM}`, "g"))) {
      const v = +m[0]; used.add(+v.toFixed(3));
      if (derived.has(+v.toFixed(3)) || /^[1-9]$/.test(m[0]) && /個|方向|軸/.test(body)) continue;
      const hit = [10, 1000, 0.1, 0.001].map((f) => +(v * f).toFixed(3)).find((x) => said.includes(x));
      if (hit != null) { issues.push({ line, kind: "unit", message: `${v} は ${hit} の間違いのようです（単位）`, from: v, to: hit }); out = out.replace(new RegExp(`(?<![\\d.])${esc(m[0])}(?![\\d.])`), fmt(hit)); used.add(hit); }
      else issues.push({ line, kind: "number", message: `${v} は頼みごとにない数です`, value: v });
    }
    fixed.push(out);
  }
  const fu = new Set([...used]);
  for (const v of said) {
    if (v === k) continue;
    const ok = fu.has(+v.toFixed(3)) || [...fu].some((u) => [...base].some((b) => Math.abs(b - u) === v || Math.abs(b - 2 * v - u) < 1e-6 || Math.abs(u - (b - v)) < 1e-6));
    if (!ok && !/^\d$/.test(String(v))) issues.push({ kind: "missing", message: `頼みごとの ${v} が使われていません`, value: v });
  }
  const nlu = interpret(text, context);
  const ok = !issues.length;
  return { ok, issues, lines: fixed, nlu, suggestion: !ok && nlu.lines.length && !nlu.ask ? nlu.lines : null };
}

// ---------------------------------------------------------------- 今のモデルの要約（interpret の context）
// app: アプリ、store: データ、call: 形状エンジン呼び出し、ctx: commandline の ctx（lastBody など）
export async function buildContext({ app, store, call, ctx = {}, pending = null, lastBody = null, lastName = null }) {
  const ms = (app && app.meshes) || [];
  const feats = (store && store.project && store.project.features) || [];
  const fById = new Map(feats.map((f) => [f.id, f]));
  const out = { bodies: [], features: [], selected: [], lastBody: null, pending };
  let list = [];
  try { if (ms.length) list = (await call("measure", { ids: ms.map((m) => m.id), density: 1 })).list; } catch { /* 大きさが分からなくても続ける */ }
  for (const m of ms) {
    const r = list.find((x) => x.id === m.id);
    const f = fById.get(m.src);
    const type = f ? (f.type === "move" || f.type === "mirror" || f.type === "pattern" || f.type === "cpattern" ? "copy" : f.type) : null;
    out.bodies.push({ name: m.name, id: m.id, type, hidden: !!m.hidden, min: r ? r.bounds[0] : [0, 0, 0], max: r ? r.bounds[1] : [0, 0, 0] });
  }
  const nameOfBody = new Map(ms.map((m) => [m.id, m.name]));
  for (const f of feats) out.features.push({ name: f.name, type: f.type, body: nameOfBody.get(f.body) || null, d: f.d != null && isFinite(+f.d) ? +f.d : undefined });
  out.selected = [...new Set(((app && app.selection) || []).map((x) => x.bodyId).filter(Boolean))].map((id) => nameOfBody.get(id)).filter(Boolean);
  const lb = lastBody || ctx.lastBody;
  out.lastBody = (lastName && ms.some((m) => m.name === lastName) && lastName) || (lb && nameOfBody.get(lb)) || null;
  return out;
}
