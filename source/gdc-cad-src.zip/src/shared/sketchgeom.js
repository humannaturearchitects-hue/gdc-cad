// スケッチの平面フレームと閉じた輪郭（プロファイル）の検出
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

export const STD_PLANES = {
  XY: { origin: [0, 0, 0], xDir: [1, 0, 0], normal: [0, 0, 1] },  // 上面
  XZ: { origin: [0, 0, 0], xDir: [1, 0, 0], normal: [0, -1, 0] }, // 正面
  YZ: { origin: [0, 0, 0], xDir: [0, 1, 0], normal: [1, 0, 0] },  // 右側面
};

export function sketchPlaneFrame(plane, num = (x) => +x || 0) {
  let base;
  if (!plane || plane.type === "std" || plane.type === "cplane") base = STD_PLANES[(plane && plane.type === "std" && plane.name) || "XY"];
  else base = { origin: plane.origin, xDir: plane.xDir, normal: plane.normal };
  const normal = norm(base.normal);
  const xDir = norm(base.xDir);
  const yDir = cross(normal, xDir);
  const off = num(plane && plane.offset, 0) || 0;
  const origin = [0, 1, 2].map((i) => base.origin[i] + normal[i] * off);
  return { origin, xDir, yDir, normal };
}

// 3点を通る円弧
export function arcFrom3(a, b, m) {
  const ax = a[0], ay = a[1], bx = b[0], by = b[1], mx = m[0], my = m[1];
  const d = 2 * (ax * (my - by) + mx * (by - ay) + bx * (ay - my));
  if (Math.abs(d) < 1e-12) return null;
  const ux = ((ax * ax + ay * ay) * (my - by) + (mx * mx + my * my) * (by - ay) + (bx * bx + by * by) * (ay - my)) / d;
  const uy = ((ax * ax + ay * ay) * (bx - mx) + (mx * mx + my * my) * (ax - bx) + (bx * bx + by * by) * (mx - ax)) / d;
  const r = Math.hypot(ax - ux, ay - uy);
  const t0 = Math.atan2(ay - uy, ax - ux);
  const tm = Math.atan2(my - uy, mx - ux);
  const t1 = Math.atan2(by - uy, bx - ux);
  const norm2 = (t) => { while (t < 0) t += 2 * Math.PI; return t; };
  const ccw = norm2(tm - t0) < norm2(t1 - t0);
  let sweep = ccw ? norm2(t1 - t0) : -norm2(t0 - t1);
  return { cx: ux, cy: uy, r, t0, sweep };
}

export function sampleArc(a, b, m, n = 24) {
  const c = arcFrom3(a, b, m);
  if (!c) return [a, b];
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const t = c.t0 + (c.sweep * i) / n;
    pts.push([c.cx + c.r * Math.cos(t), c.cy + c.r * Math.sin(t)]);
  }
  return pts;
}

export function resolveEntity(e, num) {
  const o = { ...e };
  for (const k of ["x", "y", "w", "h", "cx", "cy", "d", "x1", "y1", "x2", "y2", "xm", "ym"]) {
    if (e[k] !== undefined) o[k] = num(e[k]);
  }
  return o;
}

function polyArea(pts) {
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    s += a[0] * b[1] - b[0] * a[1];
  }
  return Math.abs(s) / 2;
}

function bboxOf(pts) {
  const min = [Infinity, Infinity], max = [-Infinity, -Infinity];
  for (const p of pts) { min[0] = Math.min(min[0], p[0]); min[1] = Math.min(min[1], p[1]); max[0] = Math.max(max[0], p[0]); max[1] = Math.max(max[1], p[1]); }
  return { min, max };
}

// ---------------------------------------------------------------- プロファイル検出
// 線・円弧・長方形・円を交点で分割し、線で囲まれた最小の領域（面）を全て求める（Fusion と同じ考え方）
const TAU = Math.PI * 2;
const normAng = (t) => { t %= TAU; return t < 0 ? t + TAU : t; };

export function arcParams(a, b, m) {
  const c = arcFrom3(a, b, m);
  return c ? { cx: c.cx, cy: c.cy, r: c.r, t0: c.t0, sweep: c.sweep } : null;
}
export const arcPoint = (g, s) => { const t = g.t0 + g.sweep * s; return [g.cx + g.r * Math.cos(t), g.cy + g.r * Math.sin(t)]; };
export function arcParamOf(g, p) {
  const t = Math.atan2(p[1] - g.cy, p[0] - g.cx);
  const d = g.sweep >= 0 ? normAng(t - g.t0) : normAng(g.t0 - t);
  return d / Math.abs(g.sweep);
}

// 2 つの曲線の交点（各曲線上のパラメータ 0..1）
export function intersect(A, B, eps) {
  const out = [];
  const lineLine = (L1, L2) => {
    const [x1, y1] = L1.a, [x2, y2] = L1.b, [x3, y3] = L2.a, [x4, y4] = L2.b;
    const d = (x2 - x1) * (y4 - y3) - (y2 - y1) * (x4 - x3);
    if (Math.abs(d) < 1e-14) return; // 平行（重なりは無視）
    const t = ((x3 - x1) * (y4 - y3) - (y3 - y1) * (x4 - x3)) / d;
    const u = ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1)) / d;
    const l1 = Math.hypot(x2 - x1, y2 - y1), l2 = Math.hypot(x4 - x3, y4 - y3);
    if (t * l1 >= -eps && (t - 1) * l1 <= eps && u * l2 >= -eps && (u - 1) * l2 <= eps) out.push([Math.min(1, Math.max(0, t)), Math.min(1, Math.max(0, u))]);
  };
  // 点が円弧上（掃引範囲内）なら 0..1 のパラメータ、範囲外なら null
  const onArc = (g, p) => {
    const t = Math.atan2(p[1] - g.cy, p[0] - g.cx);
    const sw = Math.abs(g.sweep);
    const d = g.sweep >= 0 ? normAng(t - g.t0) : normAng(g.t0 - t);
    if (sw >= TAU - 1e-12) return d / TAU;
    const tolA = eps / g.r;
    if (d <= sw + tolA) return Math.min(1, d / sw);
    if (TAU - d <= tolA) return 0;
    return null;
  };
  const lineArc = (L, g, flip) => {
    const dx = L.b[0] - L.a[0], dy = L.b[1] - L.a[1];
    const fx = L.a[0] - g.cx, fy = L.a[1] - g.cy;
    const qa = dx * dx + dy * dy, qb = 2 * (fx * dx + fy * dy), qc = fx * fx + fy * fy - g.r * g.r;
    let disc = qb * qb - 4 * qa * qc;
    if (disc < -eps * eps * qa) return;
    disc = Math.max(0, disc);
    const len = Math.sqrt(qa);
    for (const sg of disc === 0 ? [1] : [1, -1]) {
      const t = (-qb + sg * Math.sqrt(disc)) / (2 * qa);
      if (t * len < -eps || (t - 1) * len > eps) continue;
      const tt = Math.min(1, Math.max(0, t));
      const p = [L.a[0] + dx * tt, L.a[1] + dy * tt];
      const s = onArc(g, p);
      if (s === null) continue;
      out.push(flip ? [s, tt] : [tt, s]);
    }
  };
  const arcArc = (g1, g2) => {
    const dx = g2.cx - g1.cx, dy = g2.cy - g1.cy, d = Math.hypot(dx, dy);
    if (d < 1e-12 || d > g1.r + g2.r + eps || d < Math.abs(g1.r - g2.r) - eps) return;
    const a = (g1.r * g1.r - g2.r * g2.r + d * d) / (2 * d);
    const h = Math.sqrt(Math.max(0, g1.r * g1.r - a * a));
    const mx = g1.cx + (a * dx) / d, my = g1.cy + (a * dy) / d;
    const pts = h < eps ? [[mx, my]] : [[mx + (h * -dy) / d, my + (h * dx) / d], [mx - (h * -dy) / d, my - (h * dx) / d]];
    for (const p of pts) { const s1 = onArc(g1, p), s2 = onArc(g2, p); if (s1 !== null && s2 !== null) out.push([s1, s2]); }
  };
  if (A.type === "line" && B.type === "line") lineLine(A, B);
  else if (A.type === "line") lineArc(A, B.g, false);
  else if (B.type === "line") lineArc(B, A.g, true);
  else arcArc(A.g, B.g);
  return out;
}

function pointInPoly(p, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > p[1]) !== (yj > p[1]) && p[0] < ((xj - xi) * (p[1] - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

// 領域の内側にある点（反時計回りの左側に少しずらす）
function interiorPoint(loop) {
  const P = loop.poly;
  const size = Math.max(loop.bbox.max[0] - loop.bbox.min[0], loop.bbox.max[1] - loop.bbox.min[1]) || 1;
  for (let i = 0; i < P.length; i++) {
    const a = P[i], b = P[(i + 1) % P.length];
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if (L < 1e-9) continue;
    const off = Math.min(L * 0.25, size * 1e-3);
    const q = [(a[0] + b[0]) / 2 - ((b[1] - a[1]) / L) * off, (a[1] + b[1]) / 2 + ((b[0] - a[0]) / L) * off];
    if (pointInPoly(q, P)) return q;
  }
  return [(loop.bbox.min[0] + loop.bbox.max[0]) / 2, (loop.bbox.min[1] + loop.bbox.max[1]) / 2];
}

// a が b を内側に含むか（隣り合う領域は含まない）
export function loopContains(a, b) {
  if (a === b || a.area <= b.area) return false;
  const A = a.bbox, B = b.bbox, e = 1e-6;
  if (!(A.min[0] <= B.min[0] + e && A.min[1] <= B.min[1] + e && A.max[0] >= B.max[0] - e && A.max[1] >= B.max[1] - e)) return false;
  return pointInPoly(b.inner || interiorPoint(b), a.poly);
}

export function findLoops(entities, num = (x) => +x || 0) {
  // 1) 曲線を集める
  const curves = [];
  entities.forEach((raw, idx) => {
    if (raw.construction) return;
    let e;
    try { e = resolveEntity(raw, num); } catch { return; }
    if (e.type === "rect") {
      if (Math.abs(e.w) < 1e-9 || Math.abs(e.h) < 1e-9) return;
      const p = [[e.x, e.y], [e.x + e.w, e.y], [e.x + e.w, e.y + e.h], [e.x, e.y + e.h]];
      for (let k = 0; k < 4; k++) curves.push({ type: "line", a: p[k], b: p[(k + 1) % 4], idx });
    } else if (e.type === "line") {
      if (Math.hypot(e.x2 - e.x1, e.y2 - e.y1) > 1e-9) curves.push({ type: "line", a: [e.x1, e.y1], b: [e.x2, e.y2], idx });
    } else if (e.type === "arc") {
      const g = arcParams([e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym]);
      if (g) curves.push({ type: "arc", g, idx });
    } else if (e.type === "circle") {
      const r = Math.abs(e.d) / 2;
      if (r > 1e-9) curves.push({ type: "arc", g: { cx: e.cx, cy: e.cy, r, t0: 0, sweep: TAU }, idx, full: true });
    }
  });
  if (!curves.length) return [];
  let ext = 0;
  for (const c of curves) {
    if (c.type === "line") ext = Math.max(ext, ...c.a.map(Math.abs), ...c.b.map(Math.abs));
    else ext = Math.max(ext, Math.abs(c.g.cx) + c.g.r, Math.abs(c.g.cy) + c.g.r);
  }
  const eps = Math.max(1e-6, ext * 1e-9);

  // 2) 交点で分割
  const cuts = curves.map(() => [0, 1]);
  for (let i = 0; i < curves.length; i++) for (let j = i + 1; j < curves.length; j++) {
    for (const [s, t] of intersect(curves[i], curves[j], eps)) { cuts[i].push(s); cuts[j].push(t); }
  }
  const verts = [];
  const vid = (p) => {
    for (let k = 0; k < verts.length; k++) if (Math.abs(verts[k][0] - p[0]) <= eps * 10 && Math.abs(verts[k][1] - p[1]) <= eps * 10) return k;
    verts.push([p[0], p[1]]);
    return verts.length - 1;
  };
  const pieces = [];
  const fullCircles = [];
  curves.forEach((c, i) => {
    const ps = [...new Set(cuts[i].map((x) => +x.toFixed(12)))].sort((x, y) => x - y);
    if (c.full && ps.length <= 2) { fullCircles.push(c); return; }
    const at = (s) => (c.type === "line" ? [c.a[0] + (c.b[0] - c.a[0]) * s, c.a[1] + (c.b[1] - c.a[1]) * s] : arcPoint(c.g, s));
    for (let k = 0; k < ps.length - 1; k++) {
      const s0 = ps[k], s1 = ps[k + 1];
      const len = c.type === "line" ? (s1 - s0) * Math.hypot(c.b[0] - c.a[0], c.b[1] - c.a[1]) : (s1 - s0) * Math.abs(c.g.sweep) * c.g.r;
      if (len < eps * 10) continue;
      const u = vid(at(s0)), v = vid(at(s1));
      if (u === v && c.type === "line") continue;
      pieces.push({ type: c.type, u, v, m: c.type === "arc" ? at((s0 + s1) / 2) : null, g: c.g, s0, s1, idx: c.idx });
    }
  });

  // 3) 行き止まりの線を除く
  let alive = pieces.map(() => true);
  for (let changed = true; changed;) {
    changed = false;
    const deg = verts.map(() => 0);
    pieces.forEach((p, i) => { if (alive[i]) { deg[p.u]++; deg[p.v]++; } });
    pieces.forEach((p, i) => { if (alive[i] && (deg[p.u] < 2 || deg[p.v] < 2)) { alive[i] = false; changed = true; } });
  }

  // 4) 半辺で面をたどる
  const tangent = (p, fwd) => {
    if (p.type === "line") { const a = verts[fwd ? p.u : p.v], b = verts[fwd ? p.v : p.u]; return Math.atan2(b[1] - a[1], b[0] - a[0]); }
    const s = fwd ? p.s0 : p.s1;
    const t = p.g.t0 + p.g.sweep * s;
    const sg = (p.g.sweep >= 0 ? 1 : -1) * (fwd ? 1 : -1);
    return Math.atan2(sg * Math.cos(t), -sg * Math.sin(t));
  };
  const H = []; // half-edges
  pieces.forEach((p, i) => {
    if (!alive[i]) return;
    H.push({ p, from: p.u, to: p.v, fwd: true, ang: tangent(p, true) });
    H.push({ p, from: p.v, to: p.u, fwd: false, ang: tangent(p, false) });
  });
  for (let k = 0; k < H.length; k += 2) { H[k].twin = H[k + 1]; H[k + 1].twin = H[k]; }
  const out = verts.map(() => []);
  for (const h of H) out[h.from].push(h);
  for (const list of out) list.sort((a, b) => a.ang - b.ang);
  const nextOf = (h) => {
    const list = out[h.to];
    const k = list.indexOf(h.twin);
    return list[(k - 1 + list.length) % list.length];
  };
  const loops = [];
  const seen = new Set();
  for (const h0 of H) {
    if (seen.has(h0)) continue;
    const cyc = [];
    let h = h0, guard = 0;
    while (!seen.has(h) && guard++ < 10000) { seen.add(h); cyc.push(h); h = nextOf(h); }
    if (h !== h0) continue;
    const segs = cyc.map((e) => {
      const a = verts[e.from], b = verts[e.to];
      return e.p.type === "arc" ? { type: "arc", a, b, m: e.p.m } : { type: "line", a, b };
    });
    const poly = [];
    for (const sg of segs) { if (sg.type === "arc") poly.push(...sampleArc(sg.a, sg.b, sg.m, 24).slice(0, -1)); else poly.push(sg.a); }
    let area2 = 0;
    for (let i = 0; i < poly.length; i++) { const a = poly[i], b = poly[(i + 1) % poly.length]; area2 += a[0] * b[1] - b[0] * a[1]; }
    if (area2 / 2 <= eps * eps * 100) continue; // 外周（時計回り）や面積ゼロは除外
    loops.push({ kind: "chain", segs, poly, src: [...new Set(cyc.map((e) => e.p.idx))] });
  }
  for (const c of fullCircles) {
    const g = c.g, poly = [];
    for (let i = 0; i < 64; i++) { const t = (i / 64) * TAU; poly.push([g.cx + g.r * Math.cos(t), g.cy + g.r * Math.sin(t)]); }
    loops.push({ kind: "circle", cx: g.cx, cy: g.cy, r: g.r, poly, src: [c.idx] });
  }
  for (const l of loops) {
    l.bbox = { ...bboxOf(l.poly), area: polyArea(l.poly) };
    l.area = l.bbox.area;
    l.inner = interiorPoint(l);
  }
  loops.sort((a, b) => Math.min(...a.src) - Math.min(...b.src) || b.area - a.area);
  return loops;
}
