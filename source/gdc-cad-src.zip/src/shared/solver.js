// スケッチ拘束ソルバー（減衰付き最小二乗 / Levenberg–Marquardt）
// 変数 = 線・円弧・円の座標（数値のもの）。同じ位置にある端点は 1 つの点として扱う（一致）。
// 拘束: h 水平 / v 垂直 / par 平行 / perp 直交 / eq 等長 / fix 固定 / len 長さ / ang 角度 / dist 平行線間の距離
import { resolveEntity } from "./sketchgeom.js";

const isNumField = (v) => typeof v === "number" || (typeof v === "string" && /^-?\d+(\.\d+)?$/.test(v.trim()));
const PTS = { line: [["x1", "y1"], ["x2", "y2"]], arc: [["x1", "y1"], ["x2", "y2"], ["xm", "ym"]], circle: [["cx", "cy"]], point: [["x", "y"]] };

let idc = 0;
export const newEntityId = () => "e" + Date.now().toString(36).slice(-4) + (idc++).toString(36);

// id の付与・重複解消と、存在しない図形を参照する拘束の削除
export function normalizeSketch(entities, constraints = []) {
  const seen = new Set();
  const ents = entities.map((e) => {
    let id = e.id;
    if (!id || seen.has(id)) id = newEntityId();
    seen.add(id);
    return id === e.id ? e : { ...e, id };
  });
  const ids = new Set(ents.map((e) => e.id));
  const cons = (constraints || []).filter((c) => [c.a, c.b].filter(Boolean).every((x) => ids.has(x)));
  return { entities: ents, constraints: cons };
}

export function constraintNeedsSolve(constraints) { return constraints && constraints.length > 0; }

export function solveSketch(entities, constraints, num, { drag = null, maxIter = 60 } = {}) {
  if (!constraints || !constraints.length) {
    if (!drag) return { entities, ok: true };
  }
  const idx = new Map(entities.map((e, i) => [e.id, i]));
  // 1) 変数
  const vals = [];
  const slot = new Map(); // "i:field" -> var index or {const}
  const resolved = entities.map((raw) => { try { return resolveEntity(raw, num); } catch { return null; } });
  const pointVars = []; // {i, fx, fy, xv, yv}
  const key = (p) => `${p[0].toFixed(6)},${p[1].toFixed(6)}`;
  const byPos = new Map();
  entities.forEach((raw, i) => {
    const e = resolved[i];
    if (!e || !PTS[e.type]) return;
    PTS[e.type].forEach(([fx, fy], k) => {
      const p = [e[fx], e[fy]];
      const isMid = e.type === "arc" && k === 2;
      // 投影した図形（ボディから写した線）は動かさない（Fusion と同じく固定）
      const free = isNumField(raw[fx]) && isNumField(raw[fy]) && !raw.proj;
      let xv, yv;
      const pk = key(p);
      if (!isMid && free && byPos.has(pk)) { [xv, yv] = byPos.get(pk); }
      else if (free) { xv = vals.push(p[0]) - 1; yv = vals.push(p[1]) - 1; if (!isMid) byPos.set(pk, [xv, yv]); }
      else { xv = { c: p[0] }; yv = { c: p[1] }; }
      slot.set(`${i}:${fx}`, xv); slot.set(`${i}:${fy}`, yv);
      pointVars.push({ i, fx, fy, xv, yv });
    });
  });
  if (!vals.length) return { entities, ok: true };
  const x0 = vals.slice();
  const g = (x, s) => (typeof s === "number" ? x[s] : s.c);
  const P = (x, i, fx, fy) => [g(x, slot.get(`${i}:${fx}`)), g(x, slot.get(`${i}:${fy}`))];
  // 点として扱える図形（スケッチ点・円の中心）
  const PL = (x, i) => { const e = resolved[i]; return e.type === "point" ? P(x, i, "x", "y") : P(x, i, "cx", "cy"); };
  const isPL = (e) => e && (e.type === "point" || e.type === "circle");
  const lineD = (x, i) => { const a = P(x, i, "x1", "y1"), b = P(x, i, "x2", "y2"); return [b[0] - a[0], b[1] - a[1], a, b]; };

  // 2) 残差
  const res = []; // {f:(x)=>number, w}
  const W = 1;
  for (const c of constraints || []) {
    const ia = idx.get(c.a), ib = idx.get(c.b);
    const ea = resolved[ia], eb = resolved[ib];
    const isLine = (e) => e && e.type === "line";
    switch (c.type) {
      case "h": if (isLine(ea)) res.push({ f: (x) => lineD(x, ia)[1], w: W }); break;
      case "v": if (isLine(ea)) res.push({ f: (x) => lineD(x, ia)[0], w: W }); break;
      case "par": if (isLine(ea) && isLine(eb)) res.push({ f: (x) => { const [ax, ay] = lineD(x, ia), [bx, by] = lineD(x, ib); return (ax * by - ay * bx) / (Math.hypot(ax, ay) * Math.hypot(bx, by) + 1e-12) * 100; }, w: W }); break;
      case "perp": if (isLine(ea) && isLine(eb)) res.push({ f: (x) => { const [ax, ay] = lineD(x, ia), [bx, by] = lineD(x, ib); return (ax * bx + ay * by) / (Math.hypot(ax, ay) * Math.hypot(bx, by) + 1e-12) * 100; }, w: W }); break;
      case "eq":
        if (isLine(ea) && isLine(eb)) res.push({ f: (x) => { const [ax, ay] = lineD(x, ia), [bx, by] = lineD(x, ib); return Math.hypot(ax, ay) - Math.hypot(bx, by); }, w: W });
        break;
      case "len": if (isLine(ea)) { const L = num(c.value); res.push({ f: (x) => { const [dx, dy] = lineD(x, ia); return Math.hypot(dx, dy) - L; }, w: W }); } break;
      case "ang": if (isLine(ea) && isLine(eb)) {
        const t = (num(c.value) * Math.PI) / 180;
        res.push({ f: (x) => { const [ax, ay] = lineD(x, ia), [bx, by] = lineD(x, ib); const a = Math.abs(Math.atan2(ax * by - ay * bx, ax * bx + ay * by)); const a2 = Math.min(a, Math.PI - a); const want = Math.min(t, Math.PI - t); return (a2 - want) * 100; }, w: W });
      } break;
      case "dist": if (isLine(ea) && isLine(eb)) {
        const D = num(c.value);
        res.push({ f: (x) => { const [ax, ay, a] = lineD(x, ia); const [, , b, b2] = lineD(x, ib); const L = Math.hypot(ax, ay) || 1; const m = [(b[0] + b2[0]) / 2, (b[1] + b2[1]) / 2]; return Math.abs((m[0] - a[0]) * ay - (m[1] - a[1]) * ax) / L - D; }, w: W });
      } break;
      case "pldist": if (isPL(ea) && isLine(eb)) {
        // 点（円の中心）と線の距離
        const D = num(c.value);
        res.push({ f: (x) => { const p = PL(x, ia); const [bx, by, a] = lineD(x, ib); const L = Math.hypot(bx, by) || 1; return Math.abs((p[0] - a[0]) * by - (p[1] - a[1]) * bx) / L - D; }, w: W });
      } break;
      case "ppdist": if (isPL(ea) && isPL(eb)) {
        // 2 点の距離（h: 横方向, v: 縦方向, a: 直線距離）
        const D = num(c.value), m = c.mode || "a";
        res.push({ f: (x) => { const p = PL(x, ia), q = PL(x, ib); return (m === "h" ? Math.abs(q[0] - p[0]) : m === "v" ? Math.abs(q[1] - p[1]) : Math.hypot(q[0] - p[0], q[1] - p[1])) - D; }, w: W });
      } break;
      case "fix": {
        const e = ea; if (!e || !PTS[e.type]) break;
        // at に書かれた座標だけを固定（at が無ければ図形全体をその場に固定）
        const at = c.at || Object.fromEntries(PTS[e.type].flat().map((f) => [f, e[f]]));
        for (const [f, v] of Object.entries(at)) {
          const sv = slot.get(`${ia}:${f}`);
          if (typeof sv === "number") res.push({ f: (x) => x[sv] - v, w: W });
        }
        break;
      }
      default: break;
    }
  }
  // スケッチ原点 (0,0) にある点は原点に一致（固定）— ドラッグ中のその点は除く
  {
    const done = new Set();
    for (const pv of pointVars) {
      if (typeof pv.xv !== "number" || done.has(pv.xv)) continue;
      if (Math.abs(vals[pv.xv]) < 1e-9 && Math.abs(vals[pv.yv]) < 1e-9) {
        if (drag && drag.i === pv.i && drag.fx === pv.fx) continue;
        done.add(pv.xv);
        const xv = pv.xv, yv = pv.yv;
        res.push({ f: (x) => x[xv], w: W }, { f: (x) => x[yv], w: W });
      }
    }
  }
  // 円弧の通過点: 両端から等距離に保つ（端点が動いても形がくずれない）
  entities.forEach((raw, i) => {
    const e = resolved[i];
    if (!e || e.type !== "arc") return;
    res.push({ f: (x) => { const a = P(x, i, "x1", "y1"), b = P(x, i, "x2", "y2"), m = P(x, i, "xm", "ym"); return Math.hypot(m[0] - a[0], m[1] - a[1]) - Math.hypot(m[0] - b[0], m[1] - b[1]); }, w: W });
  });
  const hardN = res.length;
  // ドラッグ中の点は目標位置へ（弱い拘束）
  if (drag) {
    const sx = slot.get(`${drag.i}:${drag.fx}`), sy = slot.get(`${drag.i}:${drag.fy}`);
    if (typeof sx === "number") res.push({ f: (x) => x[sx] - drag.to[0], w: 0.05 });
    if (typeof sy === "number") res.push({ f: (x) => x[sy] - drag.to[1], w: 0.05 });
  }
  // 変化を最小に（自由度が残る部分は今の位置のまま）
  const n = vals.length;
  for (let k = 0; k < n; k++) res.push({ f: (x) => x[k] - x0[k], w: 1e-4 });

  // 3) LM: ①ドラッグ・最小変化を含めて解く → ②拘束だけで仕上げる（拘束を厳密に満たす）
  const runLM = (x, list, iters) => {
    const evalR = (xx) => list.map((q) => q.f(xx) * Math.sqrt(q.w));
    let r = evalR(x);
    let cost = r.reduce((s2, v) => s2 + v * v, 0);
    let lam = 1e-3;
    for (let it = 0; it < iters; it++) {
      const m = r.length;
      const J = new Array(m);
      for (let i = 0; i < m; i++) J[i] = new Float64Array(n);
      for (let k = 0; k < n; k++) {
        const h = 1e-7 * Math.max(1, Math.abs(x[k]));
        const xk = x[k]; x[k] = xk + h;
        const r2 = evalR(x); x[k] = xk;
        for (let i = 0; i < m; i++) J[i][k] = (r2[i] - r[i]) / h;
      }
      const A = Array.from({ length: n }, () => new Float64Array(n));
      const gvec = new Float64Array(n);
      for (let i = 0; i < m; i++) {
        const Ji = J[i];
        for (let a2 = 0; a2 < n; a2++) {
          if (Ji[a2] === 0) continue;
          gvec[a2] += Ji[a2] * r[i];
          for (let b2 = a2; b2 < n; b2++) A[a2][b2] += Ji[a2] * Ji[b2];
        }
      }
      for (let a2 = 0; a2 < n; a2++) for (let b2 = 0; b2 < a2; b2++) A[a2][b2] = A[b2][a2];
      let improved = false;
      for (let tries = 0; tries < 10; tries++) {
        const M = A.map((row, a2) => { const rr = Float64Array.from(row); rr[a2] += lam * (row[a2] + 1e-6); return rr; });
        const delta = gauss(M, Array.from(gvec, (v) => -v));
        if (!delta) { lam *= 10; continue; }
        const xn = x.map((v, k) => v + delta[k]);
        const rn = evalR(xn);
        const cn = rn.reduce((s2, v) => s2 + v * v, 0);
        if (cn < cost) { x = xn; r = rn; cost = cn; lam = Math.max(1e-12, lam / 5); improved = true; break; }
        lam *= 10;
      }
      if (!improved || cost < 1e-24) break;
    }
    return x;
  };
  let x = runLM(vals.slice(), res, maxIter);
  const hard = res.slice(0, hardN);
  if (hard.length) {
    // 仕上げ: 拘束 + ごく弱い「今の位置からあまり動かさない」
    const xs = x.slice();
    const fin = [...hard, ...xs.map((v, k) => ({ f: (xx) => xx[k] - xs[k], w: 1e-12 }))];
    x = runLM(x, fin, maxIter);
  }
  const r = res.map((q) => q.f(x));
  const hardErr = hardN ? Math.max(...r.slice(0, hardN).map(Math.abs)) : 0;
  // 4) 書き戻し
  const out = entities.map((e) => ({ ...e }));
  for (const pv of pointVars) {
    if (typeof pv.xv === "number") out[pv.i][pv.fx] = +x[pv.xv].toFixed(6);
    if (typeof pv.yv === "number") out[pv.i][pv.fy] = +x[pv.yv].toFixed(6);
  }
  return { entities: out, ok: hardErr < 1e-4, error: hardErr };
}

function gauss(A, b) {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    if (Math.abs(M[p][c]) < 1e-14) return null;
    [M[c], M[p]] = [M[p], M[c]];
    for (let r = c + 1; r < n; r++) {
      const f = M[r][c] / M[c][c];
      if (f === 0) continue;
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  const x = new Array(n).fill(0);
  for (let r = n - 1; r >= 0; r--) {
    let s = M[r][n];
    for (let k = r + 1; k < n; k++) s -= M[r][k] * x[k];
    x[r] = s / M[r][r];
  }
  return x;
}
