// パラメータ式の評価（例: "幅/2 + 10", "L - 2*t"）
const MATH = {
  sin: (d) => Math.sin((d * Math.PI) / 180),
  cos: (d) => Math.cos((d * Math.PI) / 180),
  tan: (d) => Math.tan((d * Math.PI) / 180),
  sqrt: Math.sqrt, abs: Math.abs, min: Math.min, max: Math.max,
  round: Math.round, floor: Math.floor, ceil: Math.ceil,
  PI: Math.PI, pi: Math.PI,
};

const IDENT = /[A-Za-z_぀-ヿ㐀-鿿ｦ-ﾟ][A-Za-z0-9_぀-ヿ㐀-鿿ｦ-ﾟ]*/g;

function compile(expr, lookup) {
  let src = String(expr).trim()
    .replace(/[（]/g, "(").replace(/[）]/g, ")")
    .replace(/[＋]/g, "+").replace(/[－−‐]/g, "-")
    .replace(/[＊×]/g, "*").replace(/[／÷]/g, "/")
    .replace(/[０-９．]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0))
    .replace(/\^/g, "**");
  // 単位: mm（そのまま）・cm（×10）・m（×1000）・in（×25.4）。数字のすぐ後ろに書いたときだけ単位とみなす
  src = src.replace(/(\d+(?:\.\d*)?|\.\d+)\s*(cm|センチ)(?![A-Za-z])/g, "($1*10)")
    .replace(/(\d+(?:\.\d*)?|\.\d+)\s*(m|メートル)(?![A-Za-z])/g, "($1*1000)")
    .replace(/(\d+(?:\.\d*)?|\.\d+)\s*(in|インチ)(?![A-Za-z])/g, "($1*25.4)")
    .replace(/(\d)\s*ミリ/g, "$1");
  src = src.replace(/(\d)\s*(mm|deg|°)\b/g, "$1").replace(/(\d)\s*°/g, "$1");
  const out = src.replace(IDENT, (id) => {
    if (id === "mm" || id === "deg") return "";
    if (Object.prototype.hasOwnProperty.call(MATH, id)) return `M.${id}`;
    const v = lookup(id);
    if (v === undefined) throw new Error(`「${id}」は数値でもパラメータ名でもありません（数値・式・パラメータ名、単位 mm/cm/m が使えます）`);
    return `(${v})`;
  });
  if (/[^0-9eE+\-*/().,\sM.a-zA-Z_]/.test(out)) throw new Error(`「${expr}」は式として読めません（例: 600/2+10、60cm）`);
  // eslint-disable-next-line no-new-func
  let val;
  try { val = new Function("M", `return (${out});`)(MATH); } catch { throw new Error(`「${expr}」は式として読めません（かっこの数や記号を確かめてください。例: 600/2+10）`); }
  if (typeof val !== "number" || !isFinite(val)) throw new Error(`「${expr}」の値を計算できません（0 で割っていないか確認してください）`);
  return val;
}

export function makeEvaluator(params) {
  const defs = new Map(params.map((p) => [p.name, p.expr]));
  const cache = new Map();
  const stack = new Set();
  const lookup = (name) => {
    if (cache.has(name)) return cache.get(name);
    if (!defs.has(name)) return undefined;
    if (stack.has(name)) throw new Error(`パラメータが循環参照しています: ${name}`);
    stack.add(name);
    const v = compile(defs.get(name), lookup);
    stack.delete(name);
    cache.set(name, v);
    return v;
  };
  return (x) => {
    if (typeof x === "number") return x;
    if (x === null || x === undefined || x === "") return 0;
    const s = String(x).trim();
    if (/^-?\d+(\.\d+)?$/.test(s)) return parseFloat(s);
    return compile(s, lookup);
  };
}

export function evaluateParams(params) {
  const ev = makeEvaluator(params);
  return params.map((p) => {
    try { return { ...p, value: ev(p.expr), error: null }; } catch (e) { return { ...p, value: NaN, error: e.message }; }
  });
}
