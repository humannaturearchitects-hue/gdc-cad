// パラメータ式の評価（例: "幅/2 + 10", "L - 2*t"）
const MATH = {
  sin: (d) => Math.sin((d * Math.PI) / 180),
  cos: (d) => Math.cos((d * Math.PI) / 180),
  tan: (d) => Math.tan((d * Math.PI) / 180),
  sqrt: Math.sqrt, abs: Math.abs, min: Math.min, max: Math.max,
  round: Math.round, floor: Math.floor, ceil: Math.ceil,
  PI: Math.PI, pi: Math.PI,
};

const IDENT = /[A-Za-z_぀-ヿ㐀-鿿ｦ-ﾟ][A-Za-z0-9_぀-ヿ㐀-鿿ｦ-ﾟ]*/g;

function compile(expr, lookup) {
  let src = String(expr).trim()
    .replace(/[（]/g, "(").replace(/[）]/g, ")")
    .replace(/[＋]/g, "+").replace(/[－−‐]/g, "-")
    .replace(/[＊×]/g, "*").replace(/[／÷]/g, "/")
    .replace(/[０-９．]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0))
    .replace(/\^/g, "**");
  src = src.replace(/(\d)\s*(mm|deg|°)\b/g, "$1").replace(/(\d)\s*°/g, "$1");
  const out = src.replace(IDENT, (id) => {
    if (id === "mm" || id === "deg") return "";
    if (Object.prototype.hasOwnProperty.call(MATH, id)) return `M.${id}`;
    const v = lookup(id);
    if (v === undefined) throw new Error(`不明なパラメータ: ${id}`);
    return `(${v})`;
  });
  if (/[^0-9eE+\-*/().,\sM.a-zA-Z_]/.test(out)) throw new Error(`式が不正です: ${expr}`);
  // eslint-disable-next-line no-new-func
  const fn = new Function("M", `return (${out});`);
  const val = fn(MATH);
  if (typeof val !== "number" || !isFinite(val)) throw new Error(`式の値が不正です: ${expr}`);
  return val;
}

export function makeEvaluator(params) {
  const defs = new Map(params.map((p) => [p.name, p.expr]));
  const cache = new Map();
  const stack = new Set();
  const lookup = (name) => {
    if (cache.has(name)) return cache.get(name);
    if (!defs.has(name)) return undefined;
    if (stack.has(name)) throw new Error(`パラメータが循環参照しています: ${name}`);
    stack.add(name);
    const v = compile(defs.get(name), lookup);
    stack.delete(name);
    cache.set(name, v);
    return v;
  };
  return (x) => {
    if (typeof x === "number") return x;
    if (x === null || x === undefined || x === "") return 0;
    const s = String(x).trim();
    if (/^-?\d+(\.\d+)?$/.test(s)) return parseFloat(s);
    return compile(s, lookup);
  };
}

export function evaluateParams(params) {
  const ev = makeEvaluator(params);
  return params.map((p) => {
    try { return { ...p, value: ev(p.expr), error: null }; } catch (e) { return { ...p, value: NaN, error: e.message }; }
  });
}
