// スケッチ拘束の「見える化」: 自由度・拘束状態（完全拘束／拘束不足／過拘束／矛盾）・足りないもの・矛盾の相手を調べる。
// 形は変えない（判定と表示のためだけ）。解くのは solver.js のまま。
//
// 考え方: 図形の座標を変数にし、拘束を「0 になるべき式」として並べる。
//   自由度 = 変数の数 − 式の勾配（ヤコビ行列）の階数。
//   前の式の組み合わせで表せる式 = 冗長（過拘束）。式を満たせない = 矛盾（solver が解けない）。
// 変数の作り方は solver.js と同じ（同じ位置の端点は 1 つの点＝一致、原点にある点は原点に一致、
// 投影した線・式で書いた値は動かない）。solver が動かさない長方形・円の直径も、ここでは自由度として数える。
// 「dim」拘束（長方形の幅・高さ、円の直径、円弧の半径を寸法として決めた印）は solver には影響しない。
import { solveSketch } from "./solver.js";
import { resolveEntity } from "./sketchgeom.js";

const isNumField = (v) => typeof v === "number" || (typeof v === "string" && /^-?\d+(\.\d+)?$/.test(v.trim()));
const PTS = { line: [["x1", "y1"], ["x2", "y2"]], arc: [["x1", "y1"], ["x2", "y2"], ["xm", "ym"]], circle: [["cx", "cy"]], point: [["x", "y"]] };
const TYPE_JA = { line: "線", arc: "円弧", circle: "円", point: "点", rect: "長方形" };
export const CONSTRAINT_JA = { h: "水平", v: "垂直", par: "平行", perp: "直交", eq: "等長", fix: "固定", len: "長さ", ang: "角度", dist: "距離", pldist: "点と線の距離", ppdist: "2 点の距離", dim: "寸法" };
const DIM_JA = { w: "幅", h: "高さ", d: "直径", r: "半径" };
const DIMENSIONAL = new Set(["len", "ang", "dist", "pldist", "ppdist", "dim"]);

// 図形の呼び名（線1・円2 …。種類ごとに番号）
export function entityNames(entities) {
  const cnt = {};
  return entities.map((e) => { const t = TYPE_JA[e.type] || "図形"; cnt[t] = (cnt[t] || 0) + 1; return `${e.construction ? "補助" : ""}${t}${cnt[t]}`; });
}

// 拘束の説明（「長さ 60（線2）」など）
export function describeConstraint(c, entities, num, names = entityNames(entities)) {
  const nm = (id) => { const i = entities.findIndex((e) => e.id === id); return i >= 0 ? names[i] : "?"; };
  const fmt = (v) => { try { const x = num(v); return String(+x.toFixed(3)); } catch { return String(v); } };
  const who = c.b ? `${nm(c.a)}–${nm(c.b)}` : nm(c.a);
  if (c.type === "dim") {
    const i = entities.findIndex((e) => e.id === c.a), e = entities[i];
    let v = ""; try { if (e) { const r = resolveEntity(e, num); v = c.key === "r" ? fmt(arcR(r) ?? 0) : fmt(Math.abs(r[c.key])); } } catch { /* */ }
    return `寸法 ${DIM_JA[c.key] || c.key} ${v}（${who}）`;
  }
  const val = c.value !== undefined ? ` ${fmt(c.value)}${c.type === "ang" ? "°" : ""}` : "";
  const mode = c.type === "ppdist" ? ({ h: "（横）", v: "（縦）" }[c.mode] || "") : "";
  return `${CONSTRAINT_JA[c.type] || c.type}${mode}${val}（${who}）`;
}

function arcR(e) {
  const ax = e.x1, ay = e.y1, bx = e.xm, by = e.ym, cx = e.x2, cy = e.y2;
  const d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
  if (Math.abs(d) < 1e-12) return null;
  const ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d;
  const uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d;
  return Math.hypot(ax - ux, ay - uy);
}
function arcC(a, m, b) {
  const [ax, ay] = a, [bx, by] = m, [cx, cy] = b;
  const d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
  if (Math.abs(d) < 1e-12) return [NaN, NaN, NaN];
  const ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d;
  const uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d;
  return [ux, uy, Math.hypot(ax - ux, ay - uy)];
}

// 角度の差を -π〜π に
const wrap = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };

// 変数と式を組み立てる
function buildSystem(entities, constraints, num) {
  const resolved = entities.map((raw) => { try { return resolveEntity(raw, num); } catch { return null; } });
  const vals = [];
  const slot = new Map(); // "i:field" -> 変数番号 or {c: 値}
  const owner = [];       // 変数番号 → 持ち主の図形（一致した点は複数）
  const byPos = new Map();
  const key = (p) => `${p[0].toFixed(6)},${p[1].toFixed(6)}`;
  const addVar = (v, i) => { owner.push(new Set([i])); return vals.push(v) - 1; };
  let coincident = 0;
  entities.forEach((raw, i) => {
    const e = resolved[i];
    if (!e) return;
    if (PTS[e.type]) {
      PTS[e.type].forEach(([fx, fy], k) => {
        const p = [e[fx], e[fy]];
        const isMid = e.type === "arc" && k === 2;
        const free = isNumField(raw[fx]) && isNumField(raw[fy]) && !raw.proj;
        let xv, yv;
        const pk = key(p);
        if (!isMid && free && byPos.has(pk)) { [xv, yv] = byPos.get(pk); owner[xv].add(i); owner[yv].add(i); coincident++; }
        else if (free) { xv = addVar(p[0], i); yv = addVar(p[1], i); if (!isMid) byPos.set(pk, [xv, yv]); }
        else { xv = { c: p[0] }; yv = { c: p[1] }; }
        slot.set(`${i}:${fx}`, xv); slot.set(`${i}:${fy}`, yv);
      });
    }
    // solver が動かさない値（円の直径・長方形）も、利用者がドラッグや入力で変えられるので自由度に数える
    if (e.type === "circle") slot.set(`${i}:d`, isNumField(raw.d) && !raw.proj ? addVar(Math.abs(e.d), i) : { c: Math.abs(e.d) });
    if (e.type === "rect") for (const f of ["x", "y", "w", "h"]) slot.set(`${i}:${f}`, isNumField(raw[f]) && !raw.proj ? addVar(e[f], i) : { c: e[f] });
  });
  const g = (x, s) => (typeof s === "number" ? x[s] : s.c);
  const V = (x, i, f) => g(x, slot.get(`${i}:${f}`));
  const P = (x, i, fx, fy) => [V(x, i, fx), V(x, i, fy)];
  const PL = (x, i) => (resolved[i].type === "point" ? P(x, i, "x", "y") : P(x, i, "cx", "cy"));
  const isPL = (e) => e && (e.type === "point" || e.type === "circle");
  const isLine = (e) => e && e.type === "line";
  const lineD = (x, i) => { const a = P(x, i, "x1", "y1"), b = P(x, i, "x2", "y2"); return [b[0] - a[0], b[1] - a[1], a, b]; };
  const x0 = vals.slice();

  const eqs = []; // { f, src: "origin"|"arc"|k(拘束の番号) }
  // 原点にある点は原点に一致（solver と同じ）。長方形の角が原点にあるときも同じ扱い
  {
    const done = new Set();
    for (const [, [xv, yv]] of byPos) {
      if (done.has(xv) || Math.abs(vals[xv]) > 1e-9 || Math.abs(vals[yv]) > 1e-9) continue;
      done.add(xv);
      eqs.push({ f: (x) => x[xv], src: "origin", ents: [...owner[xv]] }, { f: (x) => x[yv], src: "origin", ents: [...owner[xv]] });
    }
    resolved.forEach((e, i) => {
      if (!e || e.type !== "rect") return;
      const cs = [[0, 0], [1, 0], [1, 1], [0, 1]];
      for (const [cx, cy] of cs) {
        const fx = (x) => V(x, i, "x") + cx * V(x, i, "w"), fy = (x) => V(x, i, "y") + cy * V(x, i, "h");
        if (Math.abs(fx(x0)) < 1e-9 && Math.abs(fy(x0)) < 1e-9) { eqs.push({ f: fx, src: "origin", ents: [i] }, { f: fy, src: "origin", ents: [i] }); break; }
      }
    });
  }
  resolved.forEach((e, i) => {
    if (!e || e.type !== "arc") return;
    eqs.push({ f: (x) => { const a = P(x, i, "x1", "y1"), b = P(x, i, "x2", "y2"), m = P(x, i, "xm", "ym"); return Math.hypot(m[0] - a[0], m[1] - a[1]) - Math.hypot(m[0] - b[0], m[1] - b[1]); }, src: "arc", ents: [i] });
  });
  const idx = new Map(entities.map((e, i) => [e.id, i]));
  const sgn = (v) => (v < 0 ? -1 : 1);
  (constraints || []).forEach((c, k) => {
    const ia = idx.get(c.a), ib = idx.get(c.b);
    const ea = resolved[ia], eb = resolved[ib];
    const push = (f) => eqs.push({ f, src: k, ents: [ia, ib].filter((q) => q !== undefined) });
    let val = null;
    if (c.value !== undefined) { try { val = num(c.value); } catch { val = null; } }
    // 絶対値を含む式は、今の形の側の枝（なめらかな式）にして勾配を正しく取る
    switch (c.type) {
      case "h": if (isLine(ea)) push((x) => lineD(x, ia)[1]); break;
      case "v": if (isLine(ea)) push((x) => lineD(x, ia)[0]); break;
      case "par": if (isLine(ea) && isLine(eb)) push((x) => { const [ax, ay] = lineD(x, ia), [bx, by] = lineD(x, ib); return (ax * by - ay * bx) / (Math.hypot(ax, ay) * Math.hypot(bx, by) + 1e-12); }); break;
      case "perp": if (isLine(ea) && isLine(eb)) push((x) => { const [ax, ay] = lineD(x, ia), [bx, by] = lineD(x, ib); return (ax * bx + ay * by) / (Math.hypot(ax, ay) * Math.hypot(bx, by) + 1e-12); }); break;
      case "eq": if (isLine(ea) && isLine(eb)) push((x) => { const [ax, ay] = lineD(x, ia), [bx, by] = lineD(x, ib); return Math.hypot(ax, ay) - Math.hypot(bx, by); }); break;
      case "len": if (isLine(ea) && val !== null) push((x) => { const [dx, dy] = lineD(x, ia); return Math.hypot(dx, dy) - val; }); break;
      case "ang": if (isLine(ea) && isLine(eb) && val !== null) {
        const ang = (x) => { const [ax, ay] = lineD(x, ia), [bx, by] = lineD(x, ib); return Math.atan2(ax * by - ay * bx, ax * bx + ay * by); };
        const t = (val * Math.PI) / 180, a0 = ang(x0);
        const target = [t, -t, Math.PI - t, t - Math.PI].sort((p, q) => Math.abs(wrap(a0 - p)) - Math.abs(wrap(a0 - q)))[0];
        push((x) => wrap(ang(x) - target));
      } break;
      case "dist": if (isLine(ea) && isLine(eb) && val !== null) {
        const sd = (x) => { const [ax, ay, a] = lineD(x, ia); const [, , b, b2] = lineD(x, ib); const L = Math.hypot(ax, ay) || 1; const m = [(b[0] + b2[0]) / 2, (b[1] + b2[1]) / 2]; return ((m[0] - a[0]) * ay - (m[1] - a[1]) * ax) / L; };
        const s = sgn(sd(x0)); push((x) => s * sd(x) - val);
      } break;
      case "pldist": if (isPL(ea) && isLine(eb) && val !== null) {
        const sd = (x) => { const p = PL(x, ia); const [bx, by, a] = lineD(x, ib); const L = Math.hypot(bx, by) || 1; return ((p[0] - a[0]) * by - (p[1] - a[1]) * bx) / L; };
        const s = sgn(sd(x0)); push((x) => s * sd(x) - val);
      } break;
      case "ppdist": if (isPL(ea) && isPL(eb) && val !== null) {
        const m = c.mode || "a";
        if (m === "a") push((x) => { const p = PL(x, ia), q = PL(x, ib); return Math.hypot(q[0] - p[0], q[1] - p[1]) - val; });
        else { const ax = m === "h" ? 0 : 1; const s = sgn(PL(x0, ib)[ax] - PL(x0, ia)[ax]); push((x) => s * (PL(x, ib)[ax] - PL(x, ia)[ax]) - val); }
      } break;
      case "fix": {
        if (!ea) break;
        if (ea.type === "rect") { push((x) => V(x, ia, "x") - ea.x); push((x) => V(x, ia, "y") - ea.y); break; }
        if (!PTS[ea.type]) break;
        const at = c.at && Object.keys(c.at).length ? c.at : Object.fromEntries(PTS[ea.type].flat().map((f) => [f, ea[f]]));
        for (const [f, v] of Object.entries(at)) if (slot.has(`${ia}:${f}`)) push((x) => V(x, ia, f) - v);
        break;
      }
      case "dim": {
        if (!ea) break;
        if ((c.key === "w" || c.key === "h") && ea.type === "rect") { const v0 = ea[c.key]; push((x) => V(x, ia, c.key) - v0); }
        else if (c.key === "d" && ea.type === "circle") { const v0 = Math.abs(ea.d); push((x) => V(x, ia, "d") - v0); }
        else if (c.key === "r" && ea.type === "arc") { const r0 = arcR(ea); if (r0) push((x) => arcC(P(x, ia, "x1", "y1"), P(x, ia, "xm", "ym"), P(x, ia, "x2", "y2"))[2] - r0); }
        break;
      }
      default: break;
    }
  });
  return { vals: x0, eqs, resolved, slot, V, P, owner, coincident };
}

function gradient(f, x) {
  const n = x.length, gr = new Float64Array(n);
  const xx = x.slice();
  for (let k = 0; k < n; k++) {
    const h = 1e-6 * Math.max(1, Math.abs(x[k]));
    xx[k] = x[k] + h; const a = f(xx);
    xx[k] = x[k] - h; const b = f(xx);
    xx[k] = x[k];
    gr[k] = (a - b) / (2 * h);
  }
  return gr;
}

// 勾配が、すでにある式の勾配の組み合わせで表せない部分（長さ）を返す。表せないなら基底に加える
function orthoAdd(basis, row, add) {
  const r = Float64Array.from(row);
  const n0 = Math.hypot(...r);
  if (!(n0 > 1e-12)) return 0;
  for (let k = 0; k < r.length; k++) r[k] /= n0;
  for (let pass = 0; pass < 2; pass++) for (const q of basis) { let d = 0; for (let k = 0; k < r.length; k++) d += r[k] * q[k]; if (d) for (let k = 0; k < r.length; k++) r[k] -= d * q[k]; }
  const n1 = Math.hypot(...r);
  if (add && n1 > 1e-6) { for (let k = 0; k < r.length; k++) r[k] /= n1; basis.push(r); }
  return n1;
}

// entities, constraints: スケッチのデータ。num: パラメータの評価関数
// 戻り値: { status, dof, vars, rank, count, counts, redundant:[拘束番号], conflict:[拘束番号], missing:[{i,name,what:[...]}], ... }
export function analyzeSketch(entities, constraints = [], num, { checkConflict = true } = {}) {
  entities = entities || []; constraints = constraints || [];
  const names = entityNames(entities);
  const counts = { dim: 0, geo: 0, coincident: 0, origin: 0 };
  for (const c of constraints) DIMENSIONAL.has(c.type) ? counts.dim++ : counts.geo++;
  const base = { names, count: constraints.length, counts, redundant: [], conflict: [], missing: [], hints: [] };
  if (!entities.length) return { ...base, status: "empty", dof: 0, vars: 0, rank: 0 };
  let sys;
  try { sys = buildSystem(entities, constraints, num); } catch (e) { return { ...base, status: "error", dof: 0, vars: 0, rank: 0, error: e.message }; }
  const { vals, eqs } = sys;
  counts.coincident = sys.coincident;
  counts.origin = eqs.filter((q) => q.src === "origin").length / 2;
  const basis = [];
  const redundant = new Set();
  for (const q of eqs) {
    let g; try { g = gradient(q.f, vals); } catch { continue; }
    const left = orthoAdd(basis, g, true);
    // 固定は「念のための固定」でも過拘束としない（Fusion と同じ）
    if (left <= 1e-6 && typeof q.src === "number" && constraints[q.src].type !== "fix") redundant.add(q.src);
  }
  const rank = basis.length;
  const dof = vals.length - rank;
  // 矛盾（solver で解けない）: どの拘束を外すと解けるかを調べて、相手を特定する
  let conflict = [];
  if (checkConflict) conflict = findConflicts(entities, constraints, num);
  // 足りないもの: 図形ごとに、まだ動ける量（長さ・向き・位置・直径 …）
  const missing = [];
  if (dof > 0) {
    const { resolved, V, P } = sys;
    const free = (fn) => { try { return orthoAdd(basis, gradient(fn, vals), false) > 1e-5; } catch { return false; } };
    const ptFree = (i, fx, fy) => free((x) => V(x, i, fx)) || free((x) => V(x, i, fy));
    resolved.forEach((e, i) => {
      if (!e) return;
      const what = [];
      if (e.type === "line") {
        if (free((x) => { const a = P(x, i, "x1", "y1"), b = P(x, i, "x2", "y2"); return Math.hypot(b[0] - a[0], b[1] - a[1]); })) what.push("長さ");
        if (free((x) => { const a = P(x, i, "x1", "y1"), b = P(x, i, "x2", "y2"); return Math.atan2(b[1] - a[1], b[0] - a[0]); })) what.push("向き");
        if (ptFree(i, "x1", "y1") && ptFree(i, "x2", "y2")) what.push("位置");
      } else if (e.type === "circle") {
        if (free((x) => V(x, i, "d"))) what.push("直径");
        if (ptFree(i, "cx", "cy")) what.push("位置");
      } else if (e.type === "arc") {
        const C = (x) => arcC(P(x, i, "x1", "y1"), P(x, i, "xm", "ym"), P(x, i, "x2", "y2"));
        if (free((x) => C(x)[2])) what.push("半径");
        if (free((x) => C(x)[0]) || free((x) => C(x)[1])) what.push("位置");
        if (ptFree(i, "x1", "y1") || ptFree(i, "x2", "y2")) { if (!what.length) what.push("端の位置"); }
      } else if (e.type === "point") {
        if (ptFree(i, "x", "y")) what.push("位置");
      } else if (e.type === "rect") {
        if (free((x) => V(x, i, "w"))) what.push("幅");
        if (free((x) => V(x, i, "h"))) what.push("高さ");
        if (free((x) => V(x, i, "x")) || free((x) => V(x, i, "y"))) what.push("位置");
      }
      if (what.length) missing.push({ i, name: names[i], what });
    });
  }
  const hints = [];
  if (missing.some((m) => m.what.some((w) => ["長さ", "幅", "高さ", "直径", "半径"].includes(w)))) hints.push("大きさ: 寸法の数字をクリックして値を入れる（または「寸法」ボタン）");
  if (missing.some((m) => m.what.includes("向き"))) hints.push("向き: 水平・垂直・平行・直交・角度の拘束を付ける");
  if (missing.some((m) => m.what.some((w) => w === "位置" || w === "端の位置"))) hints.push("位置: 角や中心を原点に合わせる、原点からの距離（寸法）を付ける、または「固定」");
  const status = conflict.length ? "conflict" : redundant.size ? "over" : dof === 0 ? "full" : "under";
  return { ...base, status, dof, vars: vals.length, rank, redundant: [...redundant].sort((a, b) => a - b), conflict, missing, hints };
}

// solver で解けないときに、矛盾にかかわる拘束の番号を返す（解けるなら []）
export function findConflicts(entities, constraints, num, { limit = 80 } = {}) {
  const solvable = (cons) => { try { return solveSketch(entities, cons, num).ok; } catch { return false; } };
  if (!constraints.length || solvable(constraints)) return [];
  const out = [];
  const cand = constraints.map((c, k) => k).filter((k) => constraints[k].type !== "dim").slice(-limit);
  for (const k of cand) if (solvable(constraints.filter((_, j) => j !== k))) out.push(k);
  if (out.length) return out;
  // 1 つ外すだけでは直らない（矛盾が複数）: 寸法の値を持つ拘束を全部候補として返す
  return cand.filter((k) => constraints[k].value !== undefined || constraints[k].type === "fix");
}

// 拘束を足そうとして解けなかったとき: 新しい拘束と、ぶつかった既存の拘束を説明する
export function explainConflict(entities, oldCons, newCons, num) {
  const ks = findConflicts(entities, newCons, num);
  const oldKeys = new Set(oldCons.map((c) => JSON.stringify(c)));
  const names = entityNames(entities);
  const items = ks.map((k) => ({ k, c: newCons[k], isNew: !oldKeys.has(JSON.stringify(newCons[k])), text: describeConstraint(newCons[k], entities, num, names) }));
  const added = items.filter((x) => x.isNew), others = items.filter((x) => !x.isNew);
  let message = "拘束が矛盾しています";
  if (added.length && others.length) message += `: ${added.map((x) => x.text).join("・")} は ${others.map((x) => x.text).join("・")} とぶつかります`;
  else if (items.length) message += `: ${items.map((x) => x.text).join("・")}`;
  return { message: message + "（追加しませんでした）", items };
}
