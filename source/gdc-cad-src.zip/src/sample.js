// サンプル: パラメトリックな取付ベース（パラメータを変えると全体が追従）
import { newProject } from "./store.js";

export function sampleProject() {
  const p = newProject();
  p.name = "サンプル_取付ベース";
  p.params = [
    { name: "幅", expr: "300", comment: "X方向" },
    { name: "奥行", expr: "200", comment: "Y方向" },
    { name: "厚さ", expr: "20", comment: "板厚" },
    { name: "穴径", expr: "12", comment: "取付穴" },
    { name: "穴位置", expr: "25", comment: "端からの距離" },
    { name: "ボス径", expr: "80", comment: "" },
  ];
  p.features = [
    {
      id: "S1", type: "sketch", name: "スケッチ1", plane: { type: "std", name: "XY", offset: "0" },
      entities: [
        { type: "rect", x: 0, y: 0, w: "幅", h: "奥行" },
        { type: "circle", cx: "穴位置", cy: "穴位置", d: "穴径" },
        { type: "circle", cx: "幅-穴位置", cy: "穴位置", d: "穴径" },
        { type: "circle", cx: "幅-穴位置", cy: "奥行-穴位置", d: "穴径" },
        { type: "circle", cx: "穴位置", cy: "奥行-穴位置", d: "穴径" },
      ],
    },
    { id: "E1", type: "extrude", name: "押し出し1", sketch: "S1", profiles: [0], distance: "厚さ", direction: "one", operation: "new", bodyName: "ベース", color: "#8fa3b8" },
    { id: "C1", type: "cylinder", name: "円柱1", position: ["幅/2", "奥行/2", "厚さ"], axis: "Z", d: "ボス径", h: "60", operation: "join", target: "" },
    {
      id: "S2", type: "sketch", name: "スケッチ2", plane: { type: "std", name: "XY", offset: "厚さ+60" },
      entities: [{ type: "circle", cx: "幅/2", cy: "奥行/2", d: "ボス径/2" }],
    },
    { id: "E2", type: "extrude", name: "押し出し2", sketch: "S2", profiles: [0], distance: "50", direction: "reverse", operation: "cut" },
    { id: "F1", type: "fillet", name: "フィレット1", body: "B_E1", edges: [[0, 0, 10, 0, 0, 1], [300, 0, 10, 0, 0, 1], [300, 200, 10, 0, 0, 1], [0, 200, 10, 0, 0, 1]], radius: "15" },
  ];
  p.bodyProps = { B_E1: { color: "#8fa3b8", material: { name: "アルミ", density: 2.7 } } };
  return p;
}
