// 形状計算ワーカー（OpenCascade / replicad）
// メインスレッドから project（パラメータ＋フィーチャ履歴）を受け取り、
// 先頭から順に再計算してボディのメッシュを返す。
import opencascade from "replicad-opencascadejs";
import * as R from "replicad";
import { makeEvaluator } from "../shared/expr.js";
import { findLoops, sketchPlaneFrame, loopContains } from "../shared/sketchgeom.js";
import { solveSketch } from "../shared/solver.js";

let oc = null;
let lastBodies = [];
let snapCache = new Map();   // 手順ごとの途中経過（キー = それまでの手順のハッシュ）
let lastBuildInfo = { reused: 0, total: 0 };
let jointInfo = {};
let holeInfo = {}; // 穴の位置と寸法（画面に寸法線を出すため）
const meshCache = new WeakMap(); // 形状 → メッシュ（同じ形状は作り直さない）
let meshSeq = 0;
let sentMeshKeys = new Set();     // メインスレッドが持っているメッシュ

function hashStr(str) {
  let h1 = 0x811c9dc5, h2 = 0x1000193;
  for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i); h1 = Math.imul(h1 ^ c, 16777619); h2 = Math.imul(h2 + c, 2654435761); }
  return (h1 >>> 0).toString(36) + (h2 >>> 0).toString(36) + str.length.toString(36);
}
function stableJSON(o) {
  if (Array.isArray(o)) return "[" + o.map(stableJSON).join(",") + "]";
  if (o && typeof o === "object") return "{" + Object.keys(o).filter((k) => k !== "visible").sort().map((k) => JSON.stringify(k) + ":" + stableJSON(o[k])).join(",") + "}";
  return JSON.stringify(o);
} // {id,name,color,shape}
let lastSketches = {};

// WASM 本体はメインスレッドから受け取る（単一HTML版でも動くように）
let resolveReady;
const ready = new Promise((r) => (resolveReady = r));
let initError = null, failInit = null;
async function init(wasmBinary) {
  const failed = new Promise((_, rej) => (failInit = rej));
  return Promise.race([initInner(wasmBinary), failed]);
}
async function initInner(wasmBinary) {
  // WASM はファイル読み込み（fetch）を使わず、受け取ったバイト列から直接起動する。
  // Safari ではファイルから開いたページのワーカー内で blob の fetch が通らないことがあるため。
  oc = await opencascade({
    instantiateWasm: (imports, done) => {
      WebAssembly.instantiate(wasmBinary, imports).then((r) => done(r.instance)).catch((e) => { initError = e; failInit && failInit(e); });
      return {};
    },
  }).then((m) => m, (e) => { throw initError || e; });
  R.setOC(oc);
  resolveReady();
}

// ---------------------------------------------------------------- utils
const V = {
  dot2: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  mul: (a, s) => [a[0] * s, a[1] * s, a[2] * s],
};

function planeFromFrame(f, extraOffset = 0) {
  const o = V.add(f.origin, V.mul(f.normal, extraOffset));
  return new R.Plane(o, f.xDir, f.normal);
}

function toWorld(f, u, v) {
  return V.add(f.origin, V.add(V.mul(f.xDir, u), V.mul(f.yDir, v)));
}

function loopDrawing(loop) {
  // loop: {kind:'rect'|'circle'|'chain', ...} 2D
  if (loop.kind === "circle") return R.drawCircle(loop.r).translate(loop.cx, loop.cy);
  if (loop.kind === "rect") {
    return R.drawRectangle(loop.w, loop.h).translate(loop.cx, loop.cy);
  }
  const segs = loop.segs;
  let pen = R.draw(segs[0].a);
  for (let i = 0; i < segs.length; i++) {
    const s = segs[i];
    const last = i === segs.length - 1;
    if (s.type === "arc") pen = pen.threePointsArcTo(s.b, s.m);
    else if (!last) pen = pen.lineTo(s.b);
  }
  return segs[segs.length - 1].type === "arc" ? pen.close() : pen.close();
}

function bboxContains(a, b) {
  // a contains b
  return a.min[0] <= b.min[0] + 1e-6 && a.min[1] <= b.min[1] + 1e-6 &&
    a.max[0] >= b.max[0] - 1e-6 && a.max[1] >= b.max[1] - 1e-6 &&
    (a.area > b.area + 1e-9);
}

// プロファイル（領域）: 選択ループから、その直下に含まれるループ（穴）を除いた領域の和
function profileDrawing(loops, indices) {
  const depthOf = (i) => loops.filter((o) => loopContains(o, loops[i])).length;
  const sel = (indices === "all" || !indices || !indices.length)
    ? loops.map((_, i) => i).filter((i) => depthOf(i) % 2 === 0)
    : indices.filter((i) => i < loops.length);
  if (!sel.length) throw new Error("閉じた輪郭（プロファイル）がありません。線の端どうしがつながっているか確認してください");
  const directChildren = (i) => loops.map((_, j) => j).filter((j) => loopContains(loops[i], loops[j]) &&
    !loops.some((k) => k !== loops[i] && k !== loops[j] && loopContains(loops[i], k) && loopContains(k, loops[j])));
  let result = null;
  for (const i of sel) {
    let dr = loopDrawing(loops[i]);
    for (const j of directChildren(i)) dr = dr.cut(loopDrawing(loops[j]));
    result = result ? result.fuse(dr) : dr;
  }
  return result;
}

function nearestIndex(list, p, maxDist = 2) {
  // 位置だけを使う（向きの値が付いた配列でも先頭の X,Y,Z のみ）
  const v = R.makeVertex ? R.makeVertex(p.slice(0, 3)) : null;
  let best = -1, bd = Infinity;
  list.forEach((el, i) => {
    let d;
    try { d = R.measureDistanceBetween(v, el); } catch { d = Infinity; }
    if (d < bd) { bd = d; best = i; }
  });
  return bd <= maxDist ? best : -1;
}

function nearestParallel(edges, p, maxDist) {
  const d = [p[3], p[4], p[5]];
  const L = Math.hypot(...d) || 1;
  const v = R.makeVertex([p[0], p[1], p[2]]);
  let best = -1, bd = Infinity;
  edges.forEach((e, i) => {
    try {
      if (e.geomType !== "LINE") return;
      const a = e.startPoint, b = e.endPoint;
      const t = [b.x - a.x, b.y - a.y, b.z - a.z];
      const tl = Math.hypot(...t) || 1;
      const dot = Math.abs((t[0] * d[0] + t[1] * d[1] + t[2] * d[2]) / (tl * L));
      if (dot < 0.999) return;
      const dist = R.measureDistanceBetween(v, e);
      if (dist < bd) { bd = dist; best = i; }
    } catch { /* */ }
  });
  return bd <= maxDist ? best : -1;
}

const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
function circumCenter(a, b, c) {
  const ab = V.sub(b, a), ac = V.sub(c, a);
  const n = cross3(ab, ac); const nn = n[0] * n[0] + n[1] * n[1] + n[2] * n[2];
  if (nn < 1e-18) return null;
  const t1 = V.mul(cross3(n, ab), (ac[0] * ac[0] + ac[1] * ac[1] + ac[2] * ac[2]));
  const t2 = V.mul(cross3(ac, n), (ab[0] * ab[0] + ab[1] * ab[1] + ab[2] * ab[2]));
  return V.add(a, V.mul(V.add(t1, t2), 1 / (2 * nn)));
}
function perpTo(n) {
  const c = Math.abs(n[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0];
  const x = cross3(n, c); const L = Math.hypot(...x) || 1; return x.map((v) => v / L);
}
function faceInfo(shape, pt) {
  const faces = shape.faces;
  const k = nearestIndex(faces, pt.slice(0, 3), diag(shape) * 0.25 + 1);
  if (k < 0) throw new Error("面が見つかりません");
  const f = faces[k];
  const c = f.center, n = f.normalAt(pt.slice(0, 3));
  return { c: [c.x, c.y, c.z], n: [n.x, n.y, n.z] };
}
function makeCone(r1, r2, h, base, dir) {
  // 円錐台（皿もみ用）: 2 つの円をロフト
  const n = dir; const L = Math.hypot(...n); const d = n.map((v) => v / L);
  const pl1 = new R.Plane(base, perpTo(d), d);
  const pl2 = new R.Plane(V.add(base, V.mul(d, h)), perpTo(d), d);
  const s1 = R.drawCircle(r1).sketchOnPlane(pl1);
  const s2 = R.drawCircle(Math.max(r2, 0.01)).sketchOnPlane(pl2);
  return s1.loftWith(s2);
}

// 干渉チェック: 重なっているボディの組と重なり体積
function interference(ids) {
  const list = bodiesFor(ids);
  const out = [];
  const bbs = list.map((b) => b.shape.boundingBox.bounds);
  for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
    const [a0, a1] = bbs[i], [b0, b1] = bbs[j];
    if (a0[0] > b1[0] || a1[0] < b0[0] || a0[1] > b1[1] || a1[1] < b0[1] || a0[2] > b1[2] || a1[2] < b0[2]) continue;
    try {
      const common = list[i].shape.clone().intersect(list[j].shape.clone());
      const v = R.measureShapeVolumeProperties(common).volume;
      if (v > 1e-3) out.push({ a: list[i].id, b: list[j].id, an: list[i].name, bn: list[j].name, volume: v });
    } catch { /* */ }
  }
  return out;
}

// ジョイント軸: 指定点に最も近いエッジ。直線ならその向き、円・円弧なら中心軸
function jointAxis(bodies, pick) {
  if (!pick) return null;
  const v = R.makeVertex(pick.slice(0, 3));
  let best = null, bd = Infinity;
  for (const b of bodies) {
    for (const e of b.shape.edges) {
      let d; try { d = R.measureDistanceBetween(v, e); } catch { continue; }
      if (d < bd) { bd = d; best = e; }
    }
  }
  if (!best || bd > 5) return null;
  const P = (t) => { const q = best.pointAt(t); return [q.x, q.y, q.z]; };
  if (best.geomType === "CIRCLE") {
    const a = P(0), b2 = P(1 / 3), c = P(2 / 3);
    const u = V.sub(b2, a), w = V.sub(c, a);
    let n = cross3(u, w); const nl = Math.hypot(...n); n = n.map((x) => x / nl);
    // 3 点を通る円の中心
    const uu = dot3(u, u), ww = dot3(w, w), uw = dot3(u, w);
    const den = 2 * (uu * ww - uw * uw);
    const s1 = (ww * (uu - uw)) / den, s2 = (uu * (ww - uw)) / den;
    const center = V.add(a, V.add(V.mul(u, s1), V.mul(w, s2)));
    return { p: center, d: n, type: "circle" };
  }
  const a = P(0), b2 = P(1);
  const d = V.sub(b2, a); const L = Math.hypot(...d) || 1;
  return { p: a, d: d.map((x) => x / L), type: "line" };
}

function diag(shape) {
  try { const [a, b] = shape.boundingBox.bounds; return Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]); } catch { return 100; }
}

function parseColor(c) { return c || "#9aa3ad"; }

// ---------------------------------------------------------------- build
function buildProject(project, upto) {
  const evalr = makeEvaluator(project.params || []);
  const num = (x, def = 0) => {
    if (x === undefined || x === null || x === "") return def;
    return evalr(x);
  };
  // 形状は replicad の GC（FinalizationRegistry）に任せる（キャッシュと共有するため明示削除しない）
  const feats = project.features || [];
  const n = upto === undefined || upto === null ? feats.length : Math.min(upto, feats.length);
  // ---- 途中経過キャッシュ: 変更のあった手順から後だけ計算し直す
  const keys = [];
  let k = hashStr(JSON.stringify(project.params || []));
  for (let i = 0; i < n; i++) { k = hashStr(k + "|" + stableJSON(feats[i])); keys.push(k); }
  let start = 0, snap = null;
  for (let i = n - 1; i >= 0; i--) { const sn = snapCache.get(keys[i]); if (sn) { start = i + 1; snap = sn; break; } }
  const bodies = snap ? snap.bodies.map((b) => ({ ...b })) : [];
  const sketches = snap ? { ...snap.sketches } : {};
  const errors = snap ? snap.errors.slice() : [];
  let nextBody = snap ? snap.nextBody : 1;
  const newCache = new Map();
  for (let i = 0; i < start; i++) { const sn = snapCache.get(keys[i]); if (sn) newCache.set(keys[i], sn); }
  lastBuildInfo = { reused: start, total: n };

  const getBody = (id) => bodies.find((b) => b.id === id);
  const lastBody = () => bodies[bodies.length - 1];

  // 結合先が指定されていないとき: 選んだ面のボディ → 面スケッチのボディ → 形が触れているボディ（Fusion と同じ考え方）
  function touchedBody(f, tool) {
    const fromFace = (f.items || []).find((it) => it.face && getBody(it.face.body));
    if (fromFace) return getBody(fromFace.face.body);
    for (const it of f.items || []) { const sk = it.sketch && feats.find((x) => x.id === it.sketch); if (sk && sk.plane && sk.plane.ref && getBody(sk.plane.ref.body)) return getBody(sk.plane.ref.body); }
    let best = null, bv = 0;
    for (const b of bodies) {
      try {
        const [a0, a1] = b.shape.boundingBox.bounds, [b0, b1] = tool.boundingBox.bounds;
        const ov = [0, 1, 2].map((i) => Math.min(a1[i], b1[i]) - Math.max(a0[i], b0[i]));
        if (ov.every((x) => x >= -1e-6)) { const v = ov.reduce((m, x) => m * Math.max(x, 1e-3), 1); if (!best || v > bv) { best = b; bv = v; } }
      } catch { /* */ }
    }
    return best;
  }

  function applyOp(f, tool, defaultName) {
    const op = f.operation || "new";
    if (op === "new" || !bodies.length) {
      void defaultName;
      bodies.push({ id: f.bodyId || `B_${f.id}`, name: f.bodyName || `ボディ${nextBody}`, color: f.color, shape: tool, src: f.id, component: f.component || null });
      nextBody++;
      return;
    }
    if (op === "join") {
      const t = getBody(f.target) || touchedBody(f, tool) || lastBody();
      t.shape = t.shape.fuse(tool);
      return;
    }
    if (op === "intersect") {
      const t = getBody(f.target) || touchedBody(f, tool) || lastBody();
      t.shape = t.shape.intersect(tool);
      return;
    }
    if (op === "cut") {
      const targets = (f.targets && f.targets.length) ? f.targets.map(getBody).filter(Boolean) : bodies;
      let removed = 0;
      for (const t of targets) {
        try {
          const bb1 = t.shape.boundingBox, bb2 = tool.boundingBox;
          const [a0, a1] = bb1.bounds, [b0, b1] = bb2.bounds;
          const overlap = a0[0] <= b1[0] && a1[0] >= b0[0] && a0[1] <= b1[1] && a1[1] >= b0[1] && a0[2] <= b1[2] && a1[2] >= b0[2];
          if (!overlap) continue;
          const v0 = R.measureShapeVolumeProperties(t.shape).volume;
          t.shape = t.shape.cut(tool);
          removed += v0 - R.measureShapeVolumeProperties(t.shape).volume;
        } catch (e) { /* skip */ }
      }
      // 何も削れていないときは、利用者に分かるように知らせる（形は変えない）
      if (removed < 1e-6) throw new Error("切り取りがボディに当たっていません。方向を「反対方向」にするか、範囲を「全体を貫通」にしてください");
    }
  }

  for (let i = start; i < n; i++) {
    const f = feats[i];
    if (f.suppressed) { newCache.set(keys[i], { bodies: bodies.map((b) => ({ ...b })), sketches: { ...sketches }, errors: errors.slice(), nextBody }); continue; }
    try {
      switch (f.type) {
        case "scale": {
          // 尺度（大きさを何倍にするか）。中心は原点、またはボディの中心
          const targets = (f.bodies && f.bodies.length ? f.bodies.map(getBody) : bodies.slice()).filter(Boolean);
          const k = num(f.factor, 1);
          if (!(k > 0)) throw new Error("倍率は 0 より大きい数にしてください");
          for (const b of targets) {
            let c = (f.center || [0, 0, 0]).map((v) => num(v));
            if (f.about === "body") { const [lo, hi] = b.shape.boundingBox.bounds; c = [0, 1, 2].map((i) => (lo[i] + hi[i]) / 2); }
            b.shape = b.shape.clone().scale(k, c);
          }
          break;
        }
        case "remove": {
          // ボディの削除（Fusion と同じくタイムラインに残る）
          const ids = new Set(f.bodies || []);
          for (let i = bodies.length - 1; i >= 0; i--) if (ids.has(bodies[i].id)) bodies.splice(i, 1);
          break;
        }
        case "plane": {
          // 構築平面（Fusion の「構築」）: オフセット / 角度 / 中間
          const kind = f.kind || "offset";
          const pn0 = (a) => { if (!a || a.length < 6) return null; const n = a.slice(3, 6); const L = Math.hypot(...n) || 1; return { p: a.slice(0, 3), n: n.map((x) => x / L) }; };
          // 基準が面なら今の形で面を探し直し、構築平面なら今のその平面を使う（後から寸法を変えても追従）
          const pn = (a, key) => {
            const r = pn0(a); if (!r) return r;
            const cp = f[key + "Plane"] && sketches[f[key + "Plane"]];
            if (cp) return { p: cp.frame.origin, n: cp.frame.normal };
            const ref = f[key + "Ref"];
            if (ref) { const fr = followFace({ origin: r.p, normal: r.n }, ref, bodies); return { p: fr.origin, n: r.n }; }
            return r;
          };
          let P, N, X = null;
          if (kind === "offset") {
            const b = pn(f.base, "base"); if (!b) throw new Error("基準の面または平面を選んでください");
            P = V.add(b.p, V.mul(b.n, num(f.distance, 0))); N = b.n;
          } else if (kind === "mid") {
            const a = pn(f.base, "base"), b = pn(f.base2, "base2"); if (!a || !b) throw new Error("2 つの面（または平面）を選んでください");
            P = V.mul(V.add(a.p, b.p), 0.5); N = a.n;
            // 2 つの面の高さの中間（面の法線方向）
            const h1 = V.dot2(a.p, N), h2 = V.dot2(b.p, N); P = V.add(V.sub(P, V.mul(N, V.dot2(P, N))), V.mul(N, (h1 + h2) / 2));
          } else {
            const b = pn(f.base, "base"), e = f.edge; if (!b || !e || e.length < 6) throw new Error("回転の軸にする直線のエッジと、基準の面を選んでください");
            const A = e.slice(0, 3); let dd = e.slice(3, 6); const dl = Math.hypot(...dd) || 1; dd = dd.map((x) => x / dl);
            const t = num(f.angle, 90) * Math.PI / 180, c = Math.cos(t), s2 = Math.sin(t);
            // 基準の法線を、エッジの周りに回す（ロドリゲスの回転）
            const n = b.n, kxn = cross3(dd, n), kdn = V.dot2(dd, n);
            N = [0, 1, 2].map((i) => n[i] * c + kxn[i] * s2 + dd[i] * kdn * (1 - c));
            P = A; X = dd;
          }
          const L = Math.hypot(...N) || 1; N = N.map((x) => x / L);
          if (!X) { const cands = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]; X = cands.map((c2) => [c2, Math.abs(V.dot2(c2, N))]).sort((a, b) => a[1] - b[1])[0][0]; }
          X = V.sub(X, V.mul(N, V.dot2(X, N))); const XL = Math.hypot(...X) || 1; X = X.map((x) => x / XL);
          // 原点はワールド原点を平面に投影した点（座標がモデルとそろう）
          const origin = V.mul(N, V.dot2(P, N));
          sketches[f.id] = { frame: { origin, xDir: X, yDir: cross3(N, X), normal: N }, loops: [], pts: [], isPlane: true };
          break;
        }
        case "sketch": {
          let frame;
          if (f.plane && f.plane.type === "cplane") {
            const pf = sketches[f.plane.ref];
            if (!pf) throw new Error("スケッチの構築平面がありません");
            const off = num(f.plane.offset, 0) || 0;
            frame = { ...pf.frame, origin: V.add(pf.frame.origin, V.mul(pf.frame.normal, off)) };
          } else frame = sketchPlaneFrame(f.plane, num);
          // 面に描いたスケッチは、その面が動いたら（厚みの変更など）一緒に動く
          if (f.plane && f.plane.type === "face" && f.plane.ref) frame = followFace(frame, f.plane.ref, bodies);
          let ents = f.entities || [];
          if (f.constraints && f.constraints.length) { const r = solveSketch(ents, f.constraints, num); if (!r.ok) throw new Error("スケッチの拘束を満たせません（寸法・パラメータを確認してください）"); ents = r.entities; }
          const loops = findLoops(ents, num);
          // 穴の位置に使う点（スケッチ点と円の中心）
          const pts = [];
          for (const e of ents) { if (e.construction) continue; try { if (e.type === "point") pts.push({ kind: "point", p: [num(e.x), num(e.y)] }); else if (e.type === "circle") pts.push({ kind: "circle", p: [num(e.cx), num(e.cy)] }); } catch { /* */ } }
          sketches[f.id] = { frame, loops, pts };
          break;
        }
        case "extrude": {
          // Fusion の押し出し: 複数スケッチのプロファイル＋平らな面をまとめて、開始・方向・範囲を指定
          // items があればそれを使う（空なら未選択）。古いデータは sketch + profiles
          const items = Array.isArray(f.items) ? f.items : (f.sketch ? [{ sketch: f.sketch, loops: f.profiles && f.profiles.length ? f.profiles : "all" }] : []);
          if (!items.length) throw new Error("プロファイルまたは面を選択してください");
          const mode = f.direction || "one";
          const extent = f.extent || "dist";
          const so = num(f.startOffset, 0) || 0;
          // 全体の大きさ（「全体」「対象まで」で使う長さ）
          let L = 100;
          for (const b of bodies) { try { const [a, c] = b.shape.boundingBox.bounds; L = Math.max(L, ...[a, c].map((q) => Math.hypot(q[0], q[1], q[2]))); } catch { /* */ } }
          L = L * 3 + 100;
          const d1 = extent === "dist" ? num(f.distance, 10) : L;
          const d2 = extent === "dist" ? num(f.distance2, 10) : L;
          // 対象（面・平面）: 点と法線
          let toPl = null;
          if (extent === "to") {
            if (!f.to) throw new Error("「対象まで」の面または平面を選択してください");
            toPl = { p: f.to.slice(0, 3), n: f.to.slice(3, 6) };
            if (f.toPlane && sketches[f.toPlane]) toPl = { p: sketches[f.toPlane].frame.origin, n: sketches[f.toPlane].frame.normal };
            else if (f.toRef) toPl.p = followFace({ origin: toPl.p, normal: toPl.n }, f.toRef, bodies).origin;
          }
          // 一つの断面（平面上）を押し出す。base = 断面の平面上の点、n = 法線
          const span = (base, n) => {
            if (extent === "to") {
              // 対象の平面までの符号付き距離（断面の中心から）で向きを決める
              const s = V.dot ? V.dot(V.sub(toPl.p, base), n) : (toPl.p[0] - base[0]) * n[0] + (toPl.p[1] - base[1]) * n[1] + (toPl.p[2] - base[2]) * n[2];
              return s >= 0 ? [so, L] : [so - L, L];
            }
            if (mode === "one") return [so, d1];
            if (mode === "reverse") return [so - d1, d1];
            if (mode === "symmetric") return [so - d1 / 2, d1];
            return [so - d2, d1 + d2]; // two
          };
          const tools = [];
          const groups = new Map();
          for (const it of items) {
            if (it.sketch) { const g = groups.get(it.sketch) || []; if (it.loops === "all") g.push("all"); else if (Array.isArray(it.loops)) g.push(...it.loops); else g.push(it.loop); groups.set(it.sketch, g); }
          }
          for (const [skId, loops] of groups) {
            const sk = sketches[skId];
            if (!sk) throw new Error("参照スケッチがありません");
            const dr = profileDrawing(sk.loops, loops.includes("all") ? "all" : [...new Set(loops)]);
            const fr = sk.frame;
            const [off, len] = span(fr.origin, fr.normal);
            tools.push(dr.sketchOnPlane(planeFromFrame(fr, off)).extrude(len));
          }
          for (const it of items) {
            if (!it.face) continue;
            const b = getBody(it.face.body);
            if (!b) throw new Error("面のボディがありません");
            const faces = b.shape.faces;
            const pt = it.face.point.slice(0, 3);
            const k = nearestIndex(faces, pt, diag(b.shape) * 0.25 + 1);
            if (k < 0) throw new Error("面が見つかりません");
            const face = faces[k];
            if (face.geomType !== "PLANE") throw new Error("曲面は押し出せません（平らな面を選んでください）");
            const nv = face.normalAt(pt); const n = [nv.x, nv.y, nv.z];
            const [off, len] = span(pt, n);
            let t = R.basicFaceExtrusion(face, new R.Vector(V.mul(n, len)));
            if (Math.abs(off) > 1e-9) t = t.translate(V.mul(n, off));
            tools.push(t);
          }
          let solid = tools[0];
          for (let i = 1; i < tools.length; i++) solid = solid.fuse(tools[i]);
          // 「対象まで」: 対象の平面の向こう側を切り落とす（斜めの面でも端が面に合う）
          if (toPl) {
            const n = toPl.n; const ref = items[0].face ? items[0].face.point.slice(0, 3) : sketches[[...groups.keys()][0]].frame.origin;
            const side = ((toPl.p[0] - ref[0]) * n[0] + (toPl.p[1] - ref[1]) * n[1] + (toPl.p[2] - ref[2]) * n[2]) >= 0 ? 1 : -1;
            const slab = R.drawRectangle(L * 4, L * 4).sketchOnPlane(new R.Plane(toPl.p, perpTo(n), n)).extrude(side * L * 2);
            solid = solid.cut(slab);
          }
          applyOp(f, solid, f.name);
          break;
        }
        case "revolve": {
          const sk = sketches[f.sketch];
          if (!sk) throw new Error("参照スケッチがありません");
          const dr = profileDrawing(sk.loops, f.profiles);
          const fr = sk.frame;
          let origin = fr.origin, dir = fr.yDir;
          if (f.axis === "u") dir = fr.xDir;
          else if (f.axis === "v") dir = fr.yDir;
          else if (f.axis && f.axis.line) {
            const [x1, y1, x2, y2] = f.axis.line.map((x) => num(x));
            origin = toWorld(fr, x1, y1);
            dir = V.sub(toWorld(fr, x2, y2), origin);
          }
          const solid = dr.sketchOnPlane(planeFromFrame(fr)).revolve(dir, { origin, angle: num(f.angle, 360) });
          applyOp(f, solid, f.name);
          break;
        }
        case "box": {
          const [x, y, z] = (f.position || [0, 0, 0]).map((v) => num(v));
          const s = R.makeBox([x, y, z], [x + num(f.w, 10), y + num(f.d, 10), z + num(f.h, 10)]);
          applyOp(f, s, f.name);
          break;
        }
        case "cylinder": {
          const [x, y, z] = (f.position || [0, 0, 0]).map((v) => num(v));
          const ax = { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }[f.axis || "Z"];
          const s = R.makeCylinder(num(f.d, 10) / 2, num(f.h, 10), [x, y, z], ax);
          applyOp(f, s, f.name);
          break;
        }
        case "sphere": {
          const [x, y, z] = (f.position || [0, 0, 0]).map((v) => num(v));
          const s = R.makeSphere(num(f.d, 10) / 2).translate(x, y, z);
          applyOp(f, s, f.name);
          break;
        }
        case "fillet":
        case "chamfer": {
          const b = getBody(f.body);
          if (!b) throw new Error("対象ボディがありません");
          const edges = b.shape.edges;
          const picked = [];
          const dg = diag(b.shape);
          // 言葉で「縦の辺」などと指定したものは、今の形から毎回選び直す（寸法を変えても正しい辺に）
          if (f.edgeKind) for (const x of edgesByKind(b.shape, f.edgeKind)) picked.push(x.e);
          for (const p of f.edgeKind ? [] : f.edges || []) {
            let k = nearestIndex(edges, p.slice(0, 3), dg * 0.02 + 0.5);
            // 寸法変更で位置がずれた場合: 同じ向きの直線エッジから最も近いものを探す
            if (k < 0 && p.length >= 6) k = nearestParallel(edges, p, dg * 0.6);
            if (k < 0) k = nearestIndex(edges, p.slice(0, 3), dg * 0.05 + 1);
            if (k >= 0 && !picked.includes(edges[k])) picked.push(edges[k]);
          }
          if (!picked.length) throw new Error("エッジが見つかりません（形状が変わった可能性）");
          const r = num(f.radius, 2);
          const finder = (e) => e.inList(picked);
          b.shape = f.type === "fillet" ? b.shape.fillet(r, finder) : b.shape.chamfer(r, finder);
          break;
        }
        case "shell": {
          const b = getBody(f.body);
          if (!b) throw new Error("対象ボディがありません");
          const faces = b.shape.faces;
          const picked = [];
          const tolF = diag(b.shape) * 0.25 + 1;
          for (const p of f.faces || []) {
            const k = nearestIndex(faces, p, tolF);
            if (k >= 0) picked.push(faces[k]);
          }
          const th = num(f.thickness, 2);
          if (picked.length) b.shape = b.shape.shell(th, (fi) => fi.inList(picked));
          else {
            // 開ける面がないとき: 中を空洞にする（外側 − 内側にずらした形）
            const off = b.shape.clone().shell(th, (fi) => fi.inList([]));
            b.shape = th >= 0 ? b.shape.cut(off) : off.cut(b.shape);
          }
          break;
        }
        case "move": {
          const targets = (f.bodies || []).map(getBody).filter(Boolean);
          const t = (f.translate || [0, 0, 0]).map((v) => num(v));
          const ang = num(f.angle, 0);
          const ax = { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }[f.rotAxis || "Z"];
          const c = (f.center || [0, 0, 0]).map((v) => num(v));
          for (const b of targets) {
            let s = b.shape.clone(); // 移動・回転は元の形状を消すので複製してから（キャッシュ保護）
            if (ang) s = s.rotate(ang, c, ax);
            s = s.translate(t[0], t[1], t[2]);
            if (f.copy) bodies.push({ id: `B_${f.id}_${b.id}`, name: `${b.name}(コピー)`, color: b.color, shape: s, src: f.id, component: b.component }), nextBody++;
            else b.shape = s;
          }
          break;
        }
        case "mirror": {
          const targets = (f.bodies || []).map(getBody).filter(Boolean);
          const pl = { XY: [0, 0, 1], XZ: [0, 1, 0], YZ: [1, 0, 0] }[f.plane || "YZ"];
          const off = num(f.offset, 0);
          const origin = V.mul(pl, off);
          for (const b of targets) {
            const s = b.shape.clone().mirror(pl, origin);
            if (f.join) b.shape = b.shape.fuse(s);
            else { bodies.push({ id: `B_${f.id}_${b.id}`, name: `${b.name}(ミラー)`, color: b.color, shape: s, src: f.id, component: b.component }); nextBody++; }
          }
          break;
        }
        case "pattern": {
          const targets = (f.bodies || []).map(getBody).filter(Boolean);
          const dir = { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }[f.dir || "X"];
          const cnt = Math.max(1, Math.round(num(f.count, 2)));
          const sp = num(f.spacing, 50);
          const dir2 = f.dir2 ? { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }[f.dir2] : null;
          const cnt2 = dir2 ? Math.max(1, Math.round(num(f.count2, 1))) : 1;
          const sp2 = num(f.spacing2, 50);
          for (const b of targets) {
            const base = b.shape;
            let acc = base;
            for (let a = 0; a < cnt; a++) for (let c = 0; c < cnt2; c++) {
              if (a === 0 && c === 0) continue;
              const off = V.add(V.mul(dir, sp * a), dir2 ? V.mul(dir2, sp2 * c) : [0, 0, 0]);
              const s = base.clone().translate(off[0], off[1], off[2]);
              if (f.join) acc = acc.fuse(s);
              else { bodies.push({ id: `B_${f.id}_${b.id}_${a}_${c}`, name: `${b.name}_${a + 1}${dir2 ? "-" + (c + 1) : ""}`, color: b.color, shape: s, src: f.id, component: b.component }); nextBody++; }
            }
            if (f.join) b.shape = acc;
          }
          break;
        }
        case "combine": {
          const t = getBody(f.target);
          if (!t) throw new Error("ターゲットボディがありません");
          const tools = (f.tools || []).map(getBody).filter(Boolean).filter((b) => b !== t);
          for (const tb of tools) {
            if (f.op === "cut") t.shape = t.shape.cut(tb.shape);
            else if (f.op === "intersect") t.shape = t.shape.intersect(tb.shape);
            else t.shape = t.shape.fuse(tb.shape);
            if (!f.keepTools) { const k = bodies.indexOf(tb); if (k >= 0) bodies.splice(k, 1); }
          }
          break;
        }
        case "hole": {
          // 穴（Fusion 方式）: 単一の穴＝面＋基準エッジからの距離（丸いエッジなら同心）／ スケッチの点から（複数）
          const dg = bodies.reduce((m, b) => Math.max(m, diag(b.shape)), 100);
          const d = num(f.d, 10), depth = f.through ? dg * 2 : num(f.depth, 20);
          const spots = []; // {p, down(穴をあける向き), body}
          const placement = f.placement || (f.points && f.points.length ? "legacy" : "single");
          if (placement === "coords") {
            // 座標で指定（Fusion の寸法入力と同じく、すべて数値で）: 基準＝面の角 / 原点 / 2 本の辺
            if (!f.face) throw new Error("穴をあける面をクリックしてください");
            const b = getBody(f.body);
            if (!b) throw new Error("対象ボディがありません");
            const n0 = f.face.slice(3, 6); const nL = Math.hypot(...n0) || 1; const n = n0.map((x) => x / nL);
            let p = f.face.slice(0, 3);
            if (f.faceRef) p = followFace({ origin: p, normal: n }, f.faceRef, bodies).origin;
            // 面の座標軸: ワールド軸に近い向き（上面なら X・Y、正面なら X・Z）
            const cands = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
            let u = cands.map((c) => [c, Math.abs(V.dot2(c, n))]).sort((a, c) => a[1] - c[1])[0][0];
            u = V.sub(u, V.mul(n, V.dot2(u, n))); const uL = Math.hypot(...u); u = u.map((x) => x / uL);
            const v = cross3(n, u);
            const h = V.dot2(p, n);
            const to2 = (q) => [V.dot2(q, u), V.dot2(q, v)];
            const to3 = (c) => [0, 1, 2].map((i) => u[i] * c[0] + v[i] * c[1] + n[i] * h);
            const ref = f.ref || "corner";
            const rows = (f.pos || []).filter((r) => String(r[0]).trim() !== "" && String(r[1]).trim() !== "").map((r) => [num(r[0], 0), num(r[1], 0)]);
            if (!rows.length) throw new Error("面の上をクリックして穴を置くか、X・Y を入力してください");
            const info = { ref, n, u, v, centers: [], dims: [], corner: null };
            let centers2 = [];
            if (ref === "edges") {
              const refs = [];
              for (const rk of ["ref1", "ref2"]) {
                const r = f[rk]; if (!r) continue;
                const edges = b.shape.edges;
                const k = nearestIndex(edges, r.slice(0, 3), diag(b.shape) * 0.25 + 1);
                if (k < 0) continue;
                const e = edges[k];
                const s0 = e.pointAt(0), s1 = e.pointAt(1);
                const Q = to2([s0.x, s0.y, s0.z]), Q2 = to2([s1.x, s1.y, s1.z]);
                let D = [Q2[0] - Q[0], Q2[1] - Q[1]]; const DL = Math.hypot(...D);
                if (DL < 1e-9) continue;
                D = D.map((x) => x / DL);
                let N = [-D[1], D[0]];
                const P2 = to2(p);
                if ((P2[0] - Q[0]) * N[0] + (P2[1] - Q[1]) * N[1] < 0) N = N.map((x) => -x);
                refs.push({ Q, N });
              }
              if (refs.length < 2) throw new Error("基準の辺を 2 本クリックしてください");
              const [a, c] = refs;
              const det = a.N[0] * c.N[1] - a.N[1] * c.N[0];
              if (Math.abs(det) < 1e-9) throw new Error("基準の辺 2 本が平行です。交わる向きの辺を選んでください");
              rows.forEach(([o1, o2], ri) => {
                const r1 = o1 + a.N[0] * a.Q[0] + a.N[1] * a.Q[1], r2 = o2 + c.N[0] * c.Q[0] + c.N[1] * c.Q[1];
                const C = [(r1 * c.N[1] - a.N[1] * r2) / det, (a.N[0] * r2 - r1 * c.N[0]) / det];
                centers2.push(C);
                info.dims.push({ a: to3([C[0] - a.N[0] * o1, C[1] - a.N[1] * o1]), b: to3(C), value: o1, row: ri, col: 0 });
                info.dims.push({ a: to3([C[0] - c.N[0] * o2, C[1] - c.N[1] * o2]), b: to3(C), value: o2, row: ri, col: 1 });
              });
            } else {
              let corner = [0, 0];
              if (ref === "circle") {
                // 丸い辺の中心を (0,0) に（同心の穴）
                const r = f.ref1; if (!r) throw new Error("基準にする丸い辺をクリックしてください");
                const edges = b.shape.edges; const k = nearestIndex(edges, r.slice(0, 3), diag(b.shape) * 0.25 + 1);
                const e = k >= 0 ? edges[k] : null;
                if (!e || e.geomType !== "CIRCLE") throw new Error("丸い辺（穴や円柱の縁）を選んでください");
                const a = e.pointAt(0), bq = e.pointAt(0.33), c = e.pointAt(0.66);
                const cc = circumCenter([a.x, a.y, a.z], [bq.x, bq.y, bq.z], [c.x, c.y, c.z]);
                corner = to2(cc);
              } else if (ref === "corner") {
                // 面の外形の左下（u・v の最小）を基準 (0,0) に
                const faces = b.shape.faces; const k = nearestIndex(faces, p, diag(b.shape) * 0.25 + 1);
                if (k < 0) throw new Error("面が見つかりません");
                let mu = Infinity, mv = Infinity;
                for (const e of faces[k].edges) for (let i = 0; i <= 8; i++) { const q = e.pointAt(i / 8); const c2 = to2([q.x, q.y, q.z]); mu = Math.min(mu, c2[0]); mv = Math.min(mv, c2[1]); }
                corner = [mu, mv];
              }
              info.corner = to3(corner);
              rows.forEach(([x, y], ri) => {
                const C = [corner[0] + x, corner[1] + y];
                centers2.push(C);
                info.dims.push({ a: to3([corner[0], C[1]]), b: to3(C), value: x, row: ri, col: 0 });
                info.dims.push({ a: to3([C[0], corner[1]]), b: to3(C), value: y, row: ri, col: 1 });
              });
            }
            for (const C of centers2) { const c3 = to3(C); info.centers.push(c3); spots.push({ p: c3, n, bodies: [b] }); }
            holeInfo[f.id] = info;
          } else if (placement === "single") {
            if (!f.face) throw new Error("穴をあける面をクリックしてください");
            const b = getBody(f.body);
            if (!b) throw new Error("対象ボディがありません");
            let p = f.face.slice(0, 3); const n0 = f.face.slice(3, 6);
            if (f.faceRef) p = followFace({ origin: p, normal: n0.map((x) => x / (Math.hypot(...n0) || 1)) }, f.faceRef, bodies).origin;
            const nL = Math.hypot(...n0) || 1; const n = n0.map((v) => v / nL);
            const u = perpTo(n), v = cross3(n, u);
            const to2 = (q) => [V.dot2(q, u), V.dot2(q, v)];
            let C = to2(p);
            const refs = [];
            for (const [rk, ok] of [["ref1", "off1"], ["ref2", "off2"]]) {
              const r = f[rk]; if (!r) continue;
              const edges = b.shape.edges;
              const k = nearestIndex(edges, r.slice(0, 3), diag(b.shape) * 0.25 + 1);
              if (k < 0) continue;
              const e = edges[k];
              if (e.geomType === "CIRCLE") {
                // 丸いエッジ → その中心に（同心）
                const a = e.pointAt(0), bq = e.pointAt(0.33), c = e.pointAt(0.66);
                const cc = circumCenter([a.x, a.y, a.z], [bq.x, bq.y, bq.z], [c.x, c.y, c.z]);
                if (cc) { C = to2(cc); refs.length = 0; refs.concentric = true; break; }
                continue;
              }
              const s0 = e.pointAt(0), s1 = e.pointAt(1);
              const Q = to2([s0.x, s0.y, s0.z]), Q2 = to2([s1.x, s1.y, s1.z]);
              let D = [Q2[0] - Q[0], Q2[1] - Q[1]]; const DL = Math.hypot(...D);
              if (DL < 1e-9) continue; // 面に垂直な辺は使えない
              D = D.map((x) => x / DL);
              let N = [-D[1], D[0]];
              if ((to2(p)[0] - Q[0]) * N[0] + (to2(p)[1] - Q[1]) * N[1] < 0) N = N.map((x) => -x);
              refs.push({ Q, N, off: num(f[ok], 0) });
            }
            if (!refs.concentric) {
              if (refs.length === 1) { const r = refs[0]; const cur = (C[0] - r.Q[0]) * r.N[0] + (C[1] - r.Q[1]) * r.N[1]; C = [C[0] + r.N[0] * (r.off - cur), C[1] + r.N[1] * (r.off - cur)]; }
              else if (refs.length === 2) {
                const [a, bb] = refs;
                const det = a.N[0] * bb.N[1] - a.N[1] * bb.N[0];
                if (Math.abs(det) > 1e-9) {
                  const r1 = a.off + a.N[0] * a.Q[0] + a.N[1] * a.Q[1], r2 = bb.off + bb.N[0] * bb.Q[0] + bb.N[1] * bb.Q[1];
                  C = [(r1 * bb.N[1] - a.N[1] * r2) / det, (a.N[0] * r2 - r1 * bb.N[0]) / det];
                } else for (const r of refs) { const cur = (C[0] - r.Q[0]) * r.N[0] + (C[1] - r.Q[1]) * r.N[1]; C = [C[0] + r.N[0] * (r.off - cur), C[1] + r.N[1] * (r.off - cur)]; }
              }
            }
            const h = V.dot2(p, n);
            const c3 = [0, 1, 2].map((i) => u[i] * C[0] + v[i] * C[1] + n[i] * h);
            spots.push({ p: c3, n, bodies: [b] });
          } else if (placement === "sketch") {
            const sk = sketches[f.sketchRef];
            if (!sk) throw new Error("穴の位置にするスケッチを選んでください");
            const list = sk.pts.filter((q) => f.useCircles !== false || q.kind === "point");
            if (!list.length) throw new Error("このスケッチに点（または円）がありません。スケッチで「点」を置いてください");
            const n = f.flip ? sk.frame.normal.map((x) => -x) : sk.frame.normal;
            for (const q of list) spots.push({ p: toWorld(sk.frame, q.p[0], q.p[1]), n, bodies: null, both: !!f.through && f.style !== "cbore" && f.style !== "csink" });
          } else {
            for (const pt of f.points || []) {
              const n0 = pt.length >= 6 ? pt.slice(3, 6) : [0, 0, 1]; const L = Math.hypot(...n0) || 1;
              spots.push({ p: pt.slice(0, 3), n: n0.map((x) => x / L), bodies: f.body ? [getBody(f.body)].filter(Boolean) : null });
            }
          }
          let hit = 0;
          for (const sp of spots) {
            const down = sp.n.map((x) => -x);
            const start = sp.both ? V.add(sp.p, V.mul(sp.n, depth)) : V.add(sp.p, V.mul(sp.n, 0.01));
            let tool = R.makeCylinder(d / 2, (sp.both ? depth * 2 : depth) + 0.01, start, down);
            if (f.style === "cbore") tool = tool.fuse(R.makeCylinder(num(f.cboreD, d * 1.8) / 2, num(f.cboreDepth, d * 0.6) + 0.01, start, down));
            if (f.style === "csink") {
              const cd = num(f.csinkD, d * 2), hh = (cd - d) / 2 / Math.tan((num(f.csinkAngle, 90) / 2) * Math.PI / 180);
              tool = tool.fuse(makeCone(cd / 2, d / 2, hh + 0.01, start, down));
            }
            for (const t of sp.bodies || bodies) {
              try { const v0 = R.measureShapeVolumeProperties(t.shape).volume; t.shape = t.shape.cut(tool.clone()); if (v0 - R.measureShapeVolumeProperties(t.shape).volume > 1e-6) hit++; } catch { /* 穴が当たらないボディは無視 */ }
            }
          }
          if (spots.length && !hit) throw new Error("穴がボディに当たっていません（スケッチの点の位置か、「反転」を確認してください）");
          break;
        }
        case "cpattern": {
          // 円形パターン
          const targets = (f.bodies || []).map(getBody).filter(Boolean);
          const ax = { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }[f.axis || "Z"];
          const c = (f.center || [0, 0, 0]).map((v) => num(v));
          const cnt = Math.max(1, Math.round(num(f.count, 6)));
          const total = num(f.angle, 360);
          const step = Math.abs(total) >= 360 - 1e-9 ? total / cnt : total / Math.max(1, cnt - 1);
          for (const b of targets) {
            const base = b.shape;
            let acc = base;
            for (let k = 1; k < cnt; k++) {
              const s2 = base.clone().rotate(step * k, c, ax);
              if (f.join) acc = acc.fuse(s2);
              else { bodies.push({ id: `B_${f.id}_${b.id}_${k}`, name: `${b.name}_${k + 1}`, color: b.color, shape: s2, src: f.id, component: b.component }); nextBody++; }
            }
            if (f.join) b.shape = acc;
          }
          break;
        }
        case "presspull": {
          // 面の押し出し（Fusion の「プレス/プル」）: 平らな面をそのまま押し出す / 押し込む
          const b = getBody(f.body);
          if (!b) throw new Error("対象ボディがありません");
          const faces = b.shape.faces;
          const k = nearestIndex(faces, (f.face || [0, 0, 0]).slice(0, 3), diag(b.shape) * 0.25 + 1);
          if (k < 0) throw new Error("面が見つかりません");
          const face = faces[k];
          const pt = (f.face || []).slice(0, 3);
          const nv = face.normalAt(pt);
          const dist = num(f.distance, 10);
          const tool = R.basicFaceExtrusion(face, new R.Vector([nv.x * dist, nv.y * dist, nv.z * dist]));
          if (f.operation === "new") { bodies.push({ id: `B_${f.id}`, name: f.bodyName || `ボディ${nextBody}`, color: b.color, shape: tool, src: f.id, component: f.component || b.component }); nextBody++; }
          else if (dist >= 0) b.shape = b.shape.fuse(tool);
          else b.shape = b.shape.cut(tool);
          break;
        }
        case "split": {
          // ボディの分割（平面で 2 つに）
          const b = getBody(f.body);
          if (!b) throw new Error("対象ボディがありません");
          let plane;
          if (f.plane === "face" && f.face) {
            const n = f.face.slice(3, 6), p0 = f.face.slice(0, 3);
            plane = new R.Plane(p0, perpTo(n), n);
          } else {
            const fr = { XY: [[0, 0, 1], [1, 0, 0]], XZ: [[0, 1, 0], [1, 0, 0]], YZ: [[1, 0, 0], [0, 1, 0]] }[f.plane || "XY"];
            plane = new R.Plane(V.mul(fr[0], num(f.offset, 0)), fr[1], fr[0]);
          }
          const res = b.shape.clone().split(plane);
          const parts = [res.positive, res.negative].filter(Boolean);
          if (parts.length < 2) throw new Error("平面がボディを横切っていません");
          b.shape = parts[0];
          bodies.push({ id: `B_${f.id}`, name: `${b.name}_2`, color: b.color, shape: parts[1], src: f.id, component: b.component });
          nextBody++;
          break;
        }
        case "loft": {
          // ロフト: 2 つ以上のスケッチのプロファイルを滑らかにつなぐ
          const secs = (f.sections || []).map((sec) => {
            const sk = sketches[sec.sketch];
            if (!sk) throw new Error("参照スケッチがありません");
            return profileDrawing(sk.loops, [sec.profile ?? 0]).sketchOnPlane(planeFromFrame(sk.frame));
          });
          if (secs.length < 2) throw new Error("2 つ以上のスケッチを選んでください");
          const solid = secs[0].loftWith(secs.slice(1), { ruled: !!f.ruled });
          applyOp(f, solid, f.name);
          break;
        }
        case "align": {
          // 位置合わせ: 動かすボディの面を、相手の面にぴったり合わせる（向かい合わせ）
          const b = getBody(f.body);
          if (!b) throw new Error("動かすボディを選んでください");
          if (!f.from || !f.to) throw new Error("面を 2 つ選んでください");
          const fa = faceInfo(b.shape, f.from);
          const tb = getBody(f.toBody) || null;
          const fb = tb ? faceInfo(tb.shape, f.to) : { c: f.to.slice(0, 3), n: f.to.slice(3, 6) };
          const target = f.flip ? fb.n : V.mul(fb.n, -1);
          let s2 = b.shape.clone();
          const axis = cross3(fa.n, target);
          const sin = Math.hypot(...axis), cos = dot3(fa.n, target);
          let ca = fa.c;
          if (sin > 1e-9 || cos < 0) {
            const ang = Math.atan2(sin, cos) * 180 / Math.PI;
            const ax = sin > 1e-9 ? axis.map((v) => v / sin) : perpTo(fa.n);
            s2 = s2.rotate(ang, fa.c, ax);
          }
          // 回転後の面の中心から相手の面の中心へ（"plane" は法線方向だけ）
          let mv = V.sub(fb.c, ca);
          if (f.mode === "plane") mv = V.mul(fb.n, dot3(mv, fb.n));
          mv = V.add(mv, V.mul(fb.n, num(f.offset, 0)));
          b.shape = s2.translate(mv[0], mv[1], mv[2]);
          break;
        }
        case "joint": {
          // ジョイント: 回転（ヒンジ）またはスライド。軸は選んだエッジ（直線 or 円＝ピン）から
          const ax = jointAxis(bodies, f.axis);
          if (!ax) throw new Error("軸にするエッジを選んでください");
          jointInfo[f.id] = ax;
          const v = num(f.value, 0);
          for (const id of f.bodies || []) {
            const b = getBody(id);
            if (!b) continue;
            b.shape = f.kind === "slider" ? b.shape.clone().translate(ax.d[0] * v, ax.d[1] * v, ax.d[2] * v) : b.shape.clone().rotate(v, ax.p, ax.d);
          }
          break;
        }
        case "import": {
          const shape = importCache(f);
          const solids = shape.solids && shape.solids.length ? shape.solids : [shape];
          const names = f.names || [];
          const colors = f.colors || [];
          solids.forEach((s, k) => {
            bodies.push({ id: `${f.id}_${k}`, name: names[k] || `${f.fileName || "インポート"}_${k + 1}`, color: colors[k], shape: s.clone ? s.clone() : s, src: f.id, component: (f.bodyComp && f.bodyComp[k]) || f.component || null });
          });
          break;
        }
        case "bodyprops": {
          // ボディ名・色・表示の上書き（タイムラインには出さない）
          break;
        }
        default:
          break;
      }
    } catch (e) {
      // 形状計算エンジン内部の失敗は、何が起きたか分かる言葉に（英語の内部エラーをそのまま見せない）
      let msg = String(e && e.message ? e.message : e);
      if (!e || !e.message || /WebAssembly|Standard_|BRep|StdFail|Exception|undefined|null/.test(msg)) {
        msg = ({
          shell: "シェルを作れませんでした。厚さを薄く（または厚く）するか、穴・フィレットより前にシェルを入れてください",
          fillet: "フィレットを作れませんでした。半径を小さくするか、辺を選び直してください",
          chamfer: "面取りを作れませんでした。距離を小さくするか、辺を選び直してください",
          combine: "結合できませんでした。ボディが重なっているか確認してください",
          loft: "ロフトを作れませんでした。断面の形・向きを確認してください",
          revolve: "回転できませんでした。形が回転の軸をまたいでいないか確認してください",
          split: "分割できませんでした。平面がボディを横切っているか確認してください",
        }[f.type] || "形を計算できませんでした（寸法や手順の順番を変えてみてください）");
      }
      errors.push({ featureId: f.id, message: msg });
    }
    newCache.set(keys[i], { bodies: bodies.map((b) => ({ ...b })), sketches: { ...sketches }, errors: errors.slice(), nextBody });
  }

  // ボディ属性の上書き（キャッシュには影響させないため複製に適用）
  for (let i = 0; i < bodies.length; i++) bodies[i] = { ...bodies[i] };
  const props = project.bodyProps || {};
  for (const b of bodies) {
    const p = props[b.id];
    if (p) { if (p.name) b.name = p.name; if (p.color) b.color = p.color; b.hidden = !!p.hidden; b.material = p.material; if (p.component !== undefined) b.component = p.component; b.layup = p.layup || null; }
  }
  lastBodies = bodies;
  snapCache = newCache;
  lastSketches = sketches;
  return { bodies, sketches, errors };
}

// インポートは重いのでキャッシュ
const importShapes = new Map();
function importCache(f) {
  if (importShapes.has(f.dataKey)) return importShapes.get(f.dataKey);
  throw new Error("インポートデータが読み込まれていません");
}

async function loadImport(key, format, buffer) {
  if (importShapes.has(key)) return importShapes.get(key).solids?.length || 1;
  const blob = new Blob([buffer]);
  let shape;
  if (format === "step") shape = await R.importSTEP(blob);
  else if (format === "stl") shape = await R.importSTL(blob);
  else throw new Error("未対応の形式");
  importShapes.set(key, shape);
  return shape.solids ? shape.solids.length : 1;
}

function meshBody(b, quality) {
  const meta = { id: b.id, name: b.name, color: parseColor(b.color), hidden: !!b.hidden, src: b.src, material: b.material, component: b.component || null, layup: b.layup || null };
  const c = meshCache.get(b.shape);
  if (c && c.quality === quality) {
    if (sentMeshKeys.has(c.key)) return { ...meta, meshKey: c.key, reuse: true };
    return { ...meta, meshKey: c.key, ...cloneArrays(c.data) };
  }
  const data = meshData(b, quality);
  const key = ++meshSeq;
  meshCache.set(b.shape, { key, quality, data });
  return { ...meta, meshKey: key, ...cloneArrays(data) };
}
function cloneArrays(d) {
  return { vertices: d.vertices.slice(), normals: d.normals.slice(), triangles: d.triangles.slice(), lines: d.lines.slice(), faceGroups: d.faceGroups, edgeGroups: d.edgeGroups };
}
function meshData(b, quality) {
  // 曲面がカクカクしないよう角度の許容を小さめに（大きいモデルでも数十万三角形程度）
  const tol = quality === "fine" ? 0.05 : 0.2;
  const m = b.shape.mesh({ tolerance: tol, angularTolerance: 0.15 });
  const e = b.shape.meshEdges({ tolerance: tol, angularTolerance: 0.15 });
  return {
    vertices: new Float32Array(m.vertices), normals: new Float32Array(m.normals),
    triangles: new Uint32Array(m.triangles), faceGroups: m.faceGroups,
    lines: new Float32Array(e.lines), edgeGroups: e.edgeGroups,
  };
}

function bodiesFor(ids) {
  const list = ids && ids.length ? lastBodies.filter((b) => ids.includes(b.id)) : lastBodies.filter((b) => !b.hidden);
  return list;
}

// 演算で入力が消費されることがあるため、常に複製を渡す
function compoundOf(list) {
  if (list.length === 1) return list[0].shape.clone();
  return R.makeCompound(list.map((b) => b.shape.clone()));
}

// 投影（図面）: 可視線・隠れ線を SVG パスで返す
function projectView(ids, view) {
  const list = bodiesFor(ids);
  if (!list.length) return { visible: [], hidden: [] };
  const shape = compoundOf(list);
  // 第三角法: dir は「見る人の方向」（形状から視点へ向かう向き）
  const CAMS = {
    front: [[0, -1, 0], [1, 0, 0]],
    top: [[0, 0, 1], [1, 0, 0]],
    right: [[1, 0, 0], [0, 1, 0]],
    left: [[-1, 0, 0], [0, -1, 0]],
    back: [[0, 1, 0], [-1, 0, 0]],
    bottom: [[0, 0, -1], [1, 0, 0]],
    iso: [[1, -1, 1], [1, 1, 0]],
  };
  const [dir, xAxis] = CAMS[view] || CAMS.front;
  const cam = new R.ProjectionCamera([0, 0, 0], dir, xAxis);
  const { visible, hidden } = R.drawProjection(shape, cam);
  const flat = (p) => (Array.isArray(p) ? p.flat(Infinity) : [p]);
  const out = { visible: flat(visible.toSVGPaths()), hidden: flat(hidden.toSVGPaths()) };
  return out;
}

// 面スケッチの基準面を、今の形の中から探し直す（法線が同じ平面のうち、元の位置に一番近いもの）
function followFace(frame, ref, bodies) {
  try {
    const b = bodies.find((x) => x.id === ref.body);
    if (!b) return frame;
    const n = frame.normal, dot = (a, c) => a[0] * c[0] + a[1] * c[1] + a[2] * c[2];
    const d0 = dot(frame.origin, n);
    const p = ref.point || frame.origin;
    let best = null;
    for (const face of b.shape.faces) {
      if (face.geomType !== "PLANE") continue;
      const c = face.center; const cp = [c.x, c.y, c.z];
      const fn = face.normalAt(c); const nn = [fn.x, fn.y, fn.z];
      if (dot(nn, n) < 0.9999) continue;
      const d = dot(cp, n);
      // 元の点をこの面の高さに移した位置が、面の範囲（外接箱）に入っているか
      const q = [0, 1, 2].map((i) => p[i] + n[i] * (d - dot(p, n)));
      const [lo, hi] = face.boundingBox.bounds;
      const inside = [0, 1, 2].every((i) => q[i] >= lo[i] - 0.5 && q[i] <= hi[i] + 0.5);
      const score = Math.abs(d - d0) + (inside ? 0 : 1e6);
      if (!best || score < best.score) best = { score, d };
    }
    if (!best || best.score >= 1e6 || Math.abs(best.d - d0) < 1e-9) return frame;
    return { ...frame, origin: frame.origin.map((v, i) => v + n[i] * (best.d - d0)) };
  } catch { return frame; }
}

// 言葉の操作用: ボディの辺を種類で選ぶ（縦の辺・上の辺・下の辺・水平・すべて）
function edgesByKind(shape, kind) {
  const [lo, hi] = shape.boundingBox.bounds;
  const tol = Math.max(1e-3, (hi[2] - lo[2]) * 1e-4);
  // 円柱の継ぎ目（見えない線）は除く: 円の辺と同じ軸・半径の上にある直線
  const circles = [];
  for (const e of shape.edges) if (e.geomType === "CIRCLE") { const A = e.pointAt(0), B = e.pointAt(0.33), C = e.pointAt(0.66); const cc = circumCenter([A.x, A.y, A.z], [B.x, B.y, B.z], [C.x, C.y, C.z]); if (cc) { const n = cross3(V.sub([B.x, B.y, B.z], [A.x, A.y, A.z]), V.sub([C.x, C.y, C.z], [A.x, A.y, A.z])); const nl = Math.hypot(...n) || 1; circles.push({ c: cc, n: n.map((x) => x / nl), r: Math.hypot(A.x - cc[0], A.y - cc[1], A.z - cc[2]) }); } }
  const isSeam = (p, d) => circles.some((c) => { if (Math.abs(Math.abs(V.dot2(d, c.n)) - 1) > 1e-4) return false; const w = V.sub(p, c.c); const off = V.sub(w, V.mul(c.n, V.dot2(w, c.n))); return Math.abs(Math.hypot(...off) - c.r) < Math.max(1e-3, c.r * 1e-4); });
  const out = [];
  for (const e of shape.edges) {
    const p0 = e.pointAt(0), p1 = e.pointAt(1), m = e.pointAt(0.5);
    let d = [p1.x - p0.x, p1.y - p0.y, p1.z - p0.z]; const L = Math.hypot(...d);
    const line = e.geomType === "LINE";
    d = L > 1e-9 ? d.map((x) => x / L) : [0, 0, 0];
    if (line && isSeam([m.x, m.y, m.z], d)) continue;
    const vertical = line && Math.abs(d[2]) > 0.999;
    const horizontal = !vertical && Math.abs(p0.z - p1.z) < tol && Math.abs(m.z - p0.z) < tol;
    const top = horizontal && Math.abs(m.z - hi[2]) < tol, bottom = horizontal && Math.abs(m.z - lo[2]) < tol;
    if ({ vertical, top, bottom, horizontal, all: true }[kind || "all"]) out.push({ e, m, d: line ? d : null });
  }
  return out;
}
// 言葉の操作用: ボディの辺を種類で選ぶ（縦の辺・上の辺・下の辺・水平・すべて）
function edgesQuery(a) {
  const b = lastBodies.find((x) => x.id === a.bodyId);
  if (!b) throw new Error("ボディがありません");
  return edgesByKind(b.shape, a.kind).map(({ m, d }) => [m.x, m.y, m.z, ...(d || [])].map((v) => +v.toFixed(5)));
}

// 穴の配置用: 面の座標系・基準 (0,0)・吸着点（角・辺の中点・円の中心・面の中心）
function faceSnapInfo(a) {
  const b = lastBodies.find((x) => x.id === a.bodyId);
  if (!b) throw new Error("ボディがありません");
  const n0 = a.normal; const nL = Math.hypot(...n0) || 1; const n = n0.map((x) => x / nL);
  const cands = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  let u = cands.map((c) => [c, Math.abs(V.dot2(c, n))]).sort((p, q) => p[1] - q[1])[0][0];
  u = V.sub(u, V.mul(n, V.dot2(u, n))); const uL = Math.hypot(...u); u = u.map((x) => x / uL);
  const v = cross3(n, u);
  const to2 = (q) => [V.dot2(q, u), V.dot2(q, v)];
  const faces = b.shape.faces; const k = nearestIndex(faces, a.point, diag(b.shape) * 0.25 + 1);
  if (k < 0) throw new Error("面が見つかりません");
  const face = faces[k];
  const h = V.dot2(a.point, n);
  const pts = [], segs = [];
  let mu = Infinity, mv = Infinity, Mu = -Infinity, Mv = -Infinity;
  for (const e of face.edges) {
    const t = e.geomType;
    const P = (s) => { const q = e.pointAt(s); return to2([q.x, q.y, q.z]); };
    const s0 = P(0), s1 = P(1);
    for (let i = 0; i <= 16; i++) { const q = P(i / 16); mu = Math.min(mu, q[0]); mv = Math.min(mv, q[1]); Mu = Math.max(Mu, q[0]); Mv = Math.max(Mv, q[1]); if (i) segs.push([P((i - 1) / 16), q]); }
    if (t === "LINE") { pts.push({ p: s0, k: "角" }, { p: s1, k: "角" }, { p: P(0.5), k: "中点" }); }
    else if (t === "CIRCLE") {
      const A = e.pointAt(0), B = e.pointAt(0.33), C = e.pointAt(0.66);
      const cc = circumCenter([A.x, A.y, A.z], [B.x, B.y, B.z], [C.x, C.y, C.z]);
      if (cc) pts.push({ p: to2(cc), k: "円の中心" });
      if (Math.hypot(s0[0] - s1[0], s0[1] - s1[1]) > 1e-6) pts.push({ p: s0, k: "端点" }, { p: s1, k: "端点" });
    } else pts.push({ p: s0, k: "端点" }, { p: s1, k: "端点" });
  }
  pts.push({ p: [(mu + Mu) / 2, (mv + Mv) / 2], k: "面の中心" });
  // 基準 (0,0)
  let corner = [0, 0], refs = null;
  const ref = a.ref || "corner";
  if (ref === "corner") corner = [mu, mv];
  else if (ref === "circle" && a.ref1) {
    const edges = b.shape.edges; const kk = nearestIndex(edges, a.ref1.slice(0, 3), diag(b.shape) * 0.25 + 1);
    const e = kk >= 0 ? edges[kk] : null;
    if (e && e.geomType === "CIRCLE") { const A = e.pointAt(0), B = e.pointAt(0.33), C = e.pointAt(0.66); const cc = circumCenter([A.x, A.y, A.z], [B.x, B.y, B.z], [C.x, C.y, C.z]); if (cc) corner = to2(cc); }
  } else if (ref === "edges" && a.ref1 && a.ref2) {
    refs = [];
    for (const r of [a.ref1, a.ref2]) {
      const edges = b.shape.edges; const kk = nearestIndex(edges, r.slice(0, 3), diag(b.shape) * 0.25 + 1);
      if (kk < 0) continue;
      const e = edges[kk]; const s0 = e.pointAt(0), s1 = e.pointAt(1);
      const Q = to2([s0.x, s0.y, s0.z]), Q2 = to2([s1.x, s1.y, s1.z]);
      let D = [Q2[0] - Q[0], Q2[1] - Q[1]]; const DL = Math.hypot(...D); if (DL < 1e-9) continue; D = D.map((x) => x / DL);
      let N = [-D[1], D[0]]; const P2 = to2(a.point);
      if ((P2[0] - Q[0]) * N[0] + (P2[1] - Q[1]) * N[1] < 0) N = N.map((x) => -x);
      refs.push({ Q, N });
    }
  }
  return { u, v, n, h, corner, refs, pts, segs, box: [mu, mv, Mu, Mv] };
}

// 投影（Fusion の P）: ボディのエッジや面の外形をスケッチ平面に写して、スケッチの図形にする
function projectToSketch(bodyId, point, kind, frame) {
  const b = lastBodies.find((x) => x.id === bodyId);
  if (!b) throw new Error("ボディがありません");
  let edges;
  if (kind === "edge") { const all = b.shape.edges; const k = nearestIndex(all, point, diag(b.shape) * 0.25 + 1); if (k < 0) throw new Error("エッジが見つかりません"); edges = [all[k]]; }
  else { const faces = b.shape.faces; const k = nearestIndex(faces, point, diag(b.shape) * 0.25 + 1); if (k < 0) throw new Error("面が見つかりません"); edges = faces[k].edges; }
  const o = frame.origin, X = frame.xDir, Y = frame.yDir, N = frame.normal;
  const to2 = (p) => { const d = [p.x - o[0], p.y - o[1], p.z - o[2]]; return [+(d[0] * X[0] + d[1] * X[1] + d[2] * X[2]).toFixed(6), +(d[0] * Y[0] + d[1] * Y[1] + d[2] * Y[2]).toFixed(6)]; };
  const out = [];
  const near = (a, c) => Math.hypot(a[0] - c[0], a[1] - c[1]) < 1e-6;
  for (const e of edges) {
    const t = e.geomType;
    if (t === "LINE") {
      const a = to2(e.pointAt(0)), c = to2(e.pointAt(1));
      if (!near(a, c)) out.push({ type: "line", x1: a[0], y1: a[1], x2: c[0], y2: c[1] });
      continue;
    }
    if (t === "CIRCLE") {
      // 円が平面と平行なら円・円弧のまま、斜めなら折れ線
      const p0 = e.pointAt(0), p1 = e.pointAt(0.25), p2 = e.pointAt(0.5);
      const cc = circumCenter([p0.x, p0.y, p0.z], [p1.x, p1.y, p1.z], [p2.x, p2.y, p2.z]);
      const cn = cc && cross3(V.sub([p1.x, p1.y, p1.z], [p0.x, p0.y, p0.z]), V.sub([p2.x, p2.y, p2.z], [p0.x, p0.y, p0.z]));
      const par = cn && Math.abs(Math.abs(V.dot2(cn, N)) / (Math.hypot(...cn) || 1) - 1) < 1e-6;
      if (par) {
        const s = to2(e.pointAt(0)), en = to2(e.pointAt(1)), c2 = to2({ x: cc[0], y: cc[1], z: cc[2] });
        const r = Math.hypot(s[0] - c2[0], s[1] - c2[1]);
        if (near(s, en)) out.push({ type: "circle", cx: c2[0], cy: c2[1], d: +(2 * r).toFixed(6) });
        else { const m = to2(e.pointAt(0.5)); out.push({ type: "arc", x1: s[0], y1: s[1], x2: en[0], y2: en[1], xm: m[0], ym: m[1] }); }
        continue;
      }
    }
    const n = 24; let prev = to2(e.pointAt(0));
    for (let i = 1; i <= n; i++) { const q = to2(e.pointAt(i / n)); if (!near(prev, q)) out.push({ type: "line", x1: prev[0], y1: prev[1], x2: q[0], y2: q[1] }); prev = q; }
  }
  return out;
}

function facePlaneAt(bodyId, point) {
  const b = lastBodies.find((x) => x.id === bodyId);
  if (!b) throw new Error("ボディがありません");
  const faces = b.shape.faces;
  const k = nearestIndex(faces, point, 2);
  if (k < 0) throw new Error("面が見つかりません");
  const face = faces[k];
  if (face.geomType !== "PLANE") throw new Error("平面ではありません（平らな面を選んでください）");
  const n = face.normalAt(point);
  const normal = [n.x, n.y, n.z];
  // 面内の X 方向：ワールド軸に近いものを採用
  const cands = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  const dot = (a, c) => a[0] * c[0] + a[1] * c[1] + a[2] * c[2];
  let xd = cands.map((c) => [c, Math.abs(dot(c, normal))]).sort((a, b2) => a[1] - b2[1])[0][0];
  const d = dot(xd, normal);
  xd = V.sub(xd, V.mul(normal, d));
  const L = Math.hypot(...xd);
  xd = V.mul(xd, 1 / L);
  // 原点はワールド原点を面に投影した点（座標がモデルと揃う）
  const dd = dot(point, normal);
  const origin = V.mul(normal, dd).map((v) => +v.toFixed(6));
  return { origin, xDir: xd, normal, faceIndex: k };
}

// 平面の外形を DXF 用に: 面の境界エッジを面内 2D 座標に変換（直線・円弧・円・曲線）
function faceOutline(bodyId, point) {
  const fp = facePlaneAt(bodyId, point);
  const b = lastBodies.find((x) => x.id === bodyId);
  const face = b.shape.faces[fp.faceIndex];
  const n = fp.normal, xd = fp.xDir;
  const yd = [n[1] * xd[2] - n[2] * xd[1], n[2] * xd[0] - n[0] * xd[2], n[0] * xd[1] - n[1] * xd[0]];
  const to2 = (v) => [v.x * xd[0] + v.y * xd[1] + v.z * xd[2], v.x * yd[0] + v.y * yd[1] + v.z * yd[2]];
  const prims = [];
  for (const e of face.edges) {
    const t = e.geomType;
    if (t === "LINE") { prims.push({ t: "line", a: to2(e.startPoint), b: to2(e.endPoint) }); continue; }
    if (t === "CIRCLE") {
      const p0 = to2(e.pointAt(0)), p1 = to2(e.pointAt(1 / 3)), p2 = to2(e.pointAt(2 / 3)), pe = to2(e.pointAt(1));
      const c = circle3(p0, p1, p2);
      if (c) {
        const full = Math.hypot(p0[0] - pe[0], p0[1] - pe[1]) < 1e-6;
        const ang = (p) => Math.atan2(p[1] - c[1], p[0] - c[0]);
        if (full) { prims.push({ t: "arc", c, r: c[2], s: 0, d: Math.PI * 2 }); continue; }
        const s0 = ang(p0), sm = ang(to2(e.pointAt(0.5))), s1 = ang(pe);
        const n2 = (x) => { while (x < 0) x += 2 * Math.PI; while (x >= 2 * Math.PI) x -= 2 * Math.PI; return x; };
        const ccw = n2(sm - s0) < n2(s1 - s0);
        prims.push({ t: "arc", c: [c[0], c[1]], r: c[2], s: s0, d: ccw ? n2(s1 - s0) : -n2(s0 - s1) });
        continue;
      }
    }
    const pts = [];
    for (let i = 0; i <= 48; i++) pts.push(to2(e.pointAt(i / 48)));
    prims.push({ t: "poly", pts });
  }
  return { prims };
}

function circle3(a, b, m) {
  const d = 2 * (a[0] * (b[1] - m[1]) + b[0] * (m[1] - a[1]) + m[0] * (a[1] - b[1]));
  if (Math.abs(d) < 1e-12) return null;
  const a2 = a[0] * a[0] + a[1] * a[1], b2 = b[0] * b[0] + b[1] * b[1], m2 = m[0] * m[0] + m[1] * m[1];
  const ux = (a2 * (b[1] - m[1]) + b2 * (m[1] - a[1]) + m2 * (a[1] - b[1])) / d;
  const uy = (a2 * (m[0] - b[0]) + b2 * (a[0] - m[0]) + m2 * (b[0] - a[0])) / d;
  return [ux, uy, Math.hypot(a[0] - ux, a[1] - uy)];
}

function measure(ids, density) {
  const list = bodiesFor(ids);
  const res = [];
  let total = { volume: 0, area: 0, mass: 0 };
  for (const b of list) {
    let vol = 0, area = 0, com = null;
    try { const p = R.measureShapeVolumeProperties(b.shape); vol = p.volume; com = p.centerOfMass; } catch { /* */ }
    try { area = R.measureArea(b.shape); } catch { /* */ }
    const bb = b.shape.boundingBox;
    const d = (b.material && b.material.density) || density || 1;
    const mass = vol * d / 1e6; // g/cm3 * mm3 -> kg
    res.push({ id: b.id, name: b.name, volume: vol, area, mass, bounds: bb.bounds, com });
    total.volume += vol; total.area += area; total.mass += mass;
  }
  return { list: res, total };
}

function exportShapes(ids, format, opts = {}) {
  const list = bodiesFor(ids);
  if (!list.length) throw new Error("書き出すボディがありません");
  if (format === "step") {
    return R.exportSTEP(list.map((b) => ({ shape: b.shape, name: b.name, color: parseColor(b.color) })), { unit: opts.unit || "MM", modelUnit: "MM" });
  }
  if (format === "stl") {
    const shape = compoundOf(list);
    return shape.blobSTL({ binary: true, tolerance: opts.tolerance || 0.05, angularTolerance: 0.2 });
  }
  if (format === "brep") {
    const shape = compoundOf(list);
    return new Blob([shape.serialize()], { type: "text/plain" });
  }
  throw new Error("未対応の形式: " + format);
}

// ---------------------------------------------------------------- messages
self.onmessage = async (ev) => {
  const { id, cmd, args } = ev.data;
  try {
    if (cmd === "init") { await init(args.wasm); self.postMessage({ id, ok: true, result: "ok" }); return; }
    await ready;
    let result, transfer = [];
    switch (cmd) {
      case "ping": result = "ok"; break;
      case "hangTest": { const t = Date.now(); while (Date.now() - t < args.ms) { /* 応答なしの再現（テスト用） */ } result = "ok"; break; }
      case "crashTest": setTimeout(() => { throw new Error("crash test"); }); result = "ok"; break; // 復旧テスト用
      case "build": {
        const t0 = performance.now();
        const { bodies, sketches, errors } = buildProject(args.project, args.upto);
        const meshes = [];
        const nowKeys = new Set();
        for (const b of bodies) {
          try {
            const m = meshBody(b, args.quality);
            meshes.push(m);
            nowKeys.add(m.meshKey);
            if (!m.reuse) transfer.push(m.vertices.buffer, m.normals.buffer, m.triangles.buffer, m.lines.buffer);
          } catch (e) { errors.push({ featureId: b.src, message: "メッシュ化失敗: " + e.message }); }
        }
        sentMeshKeys = nowKeys;
        const sk = {};
        for (const [k, s] of Object.entries(sketches)) sk[k] = { frame: s.frame, loops: s.loops };
        result = { meshes, sketches: sk, errors, ms: performance.now() - t0, reused: lastBuildInfo.reused, total: lastBuildInfo.total, joints: jointInfo, holes: holeInfo };
        break;
      }
      case "loadImport": result = await loadImport(args.key, args.format, args.buffer); break;
      case "project": result = projectView(args.ids, args.view); break;
      case "facePlane": result = facePlaneAt(args.bodyId, args.point); break;
      case "faceSnap": result = faceSnapInfo(args); break;
      case "edgesQuery": result = edgesQuery(args); break;
      case "projectToSketch": result = projectToSketch(args.bodyId, args.point, args.kind, args.frame); break;
      case "faceOutline": result = faceOutline(args.bodyId, args.point); break;
      case "interference": result = interference(args.ids); break;
      case "measure": result = measure(args.ids, args.density); break;
      case "export": {
        const blob = exportShapes(args.ids, args.format, args.opts);
        result = await blob.arrayBuffer();
        transfer.push(result);
        break;
      }
      default: throw new Error("unknown cmd " + cmd);
    }
    self.postMessage({ id, ok: true, result }, transfer);
  } catch (e) {
    self.postMessage({ id, ok: false, error: String(e && e.message ? e.message : e) });
  }
};
