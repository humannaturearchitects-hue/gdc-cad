// 図面・パネル加工用の形状解析（ワーカー内で使う）
//  holesOf: 穴（円筒の凹面）の位置・径・深さ・貫通・ざぐり
//  panelFlat: 板状の部品を平らな 2D（外形・穴・彫り）に展開
//  verifyStep: 書き出した STEP を読み戻して体積を比べる

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => { const L = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / L, a[1] / L, a[2] / L]; };
const vec = (v) => [v.x, v.y, v.z];

// 3D の 3 点を通る円: 中心・半径・法線
function circle3D(p0, p1, p2) {
  const a = sub(p1, p0), b = sub(p2, p0);
  const n = cross(a, b);
  const n2 = dot(n, n);
  if (n2 < 1e-18) return null;
  const t1 = cross(n, a), t2 = cross(b, n);
  const aa = dot(a, a), bb = dot(b, b);
  const c = [0, 1, 2].map((k) => p0[k] + (bb * t1[k] + aa * t2[k]) / (2 * n2));
  return { c, r: Math.hypot(...sub(p0, c)), n: norm(n) };
}

function bodyExtent(shape, axis) {
  const bb = shape.boundingBox.bounds;
  // 軸方向の厚さ（軸が座標軸に近いとき正確）
  let lo = Infinity, hi = -Infinity;
  for (const x of [bb[0][0], bb[1][0]]) for (const y of [bb[0][1], bb[1][1]]) for (const z of [bb[0][2], bb[1][2]]) {
    const d = dot([x, y, z], axis); lo = Math.min(lo, d); hi = Math.max(hi, d);
  }
  return [lo, hi];
}

// 穴: 円筒面のうち内向き（材料が外側）のもの。同じ軸の円筒はまとめて ざぐり／段付き として扱う
export function holesOf(bodies) {
  const out = [];
  for (const b of bodies) {
    const cyl = [];
    let faces = [];
    try { faces = b.shape.faces; } catch { continue; }
    const cones = [];
    for (const f of faces) {
      if (f.geomType === "CONE") {
        // 皿もみ: 円の辺 2 つ（大きい円と、穴とつながる小さい円）
        const cs = [];
        try { for (const e of f.edges) if (e.geomType === "CIRCLE") { const c = circle3D(vec(e.pointAt(0)), vec(e.pointAt(1 / 3)), vec(e.pointAt(2 / 3))); if (c) cs.push(c); } } catch { /* */ }
        if (cs.length >= 2) { cs.sort((a, b2) => a.r - b2.r); cones.push({ small: cs[0], big: cs[cs.length - 1] }); }
        continue;
      }
      if (f.geomType !== "CYLINDRE") continue;
      // 円の辺から軸と半径を求める
      let circ = null; const pts = [];
      for (const e of f.edges) {
        if (e.geomType === "CIRCLE") {
          const c = circle3D(vec(e.pointAt(0)), vec(e.pointAt(1 / 3)), vec(e.pointAt(2 / 3)));
          if (c && !circ) circ = c;
        }
        for (const t of [0, 0.5, 1]) pts.push(vec(e.pointAt(t)));
      }
      if (!circ) continue;
      const axis = circ.n;
      // 凹（穴）か凸（丸棒・ボス）か: 面の法線が軸に向かうなら穴
      let concave = false;
      try {
        const uv = f.UVBounds;
        const p = vec(f.pointOnSurface((uv.uMin + uv.uMax) / 2, (uv.vMin + uv.vMax) / 2));
        const n = vec(f.normalAt(p));
        const rel = sub(p, circ.c); const along = dot(rel, axis);
        const radial = sub(rel, axis.map((k) => k * along));
        concave = dot(n, radial) < 0;
      } catch { continue; }
      if (!concave) continue;
      const ts = pts.map((p) => dot(sub(p, circ.c), axis));
      cyl.push({ c: circ.c, r: circ.r, axis, t0: Math.min(...ts), t1: Math.max(...ts) });
    }
    // 同じ軸・同じ半径の面（半円 2 枚など）をまとめる
    const merged = [];
    for (const c of cyl) {
      // 同じ直線上でも離れている穴（両側の木口から掘った下穴など）は別の穴
      const span = (q) => { const s0 = dot(sub(c.c, q.c), q.axis); const sg = dot(c.axis, q.axis) > 0 ? 1 : -1; return [s0 + sg * c.t0, s0 + sg * c.t1]; };
      const m = merged.find((q) => {
        if (!(Math.abs(Math.abs(dot(q.axis, c.axis)) - 1) < 1e-6 && Math.abs(q.r - c.r) < 1e-6 && lineDist(q, c.c) < 1e-4)) return false;
        const [a0, a1] = span(q);
        return Math.min(a0, a1) <= q.t1 + 1e-3 && Math.max(a0, a1) >= q.t0 - 1e-3;
      });
      if (m) { const [a0, a1] = span(m); m.t0 = Math.min(m.t0, a0, a1); m.t1 = Math.max(m.t1, a0, a1); }
      else merged.push({ ...c });
    }
    // 同じ軸の別の径 → ざぐり（大きい方）として小さい穴にまとめる
    const used = new Set();
    merged.sort((a, b2) => a.r - b2.r);
    for (let i = 0; i < merged.length; i++) {
      if (used.has(i)) continue;
      const h = merged[i];
      const p0 = h.c.map((v, k) => v + h.axis[k] * h.t0), p1 = h.c.map((v, k) => v + h.axis[k] * h.t1);
      const [lo, hi] = bodyExtent(b.shape, h.axis);
      const thk = hi - lo;
      let cb = null;
      for (let j = i + 1; j < merged.length; j++) {
        const q = merged[j];
        if (used.has(j)) continue;
        if (q.r <= h.r + 1e-6) continue; // 同じ径（同じ直線上の別の穴）はざぐりではない
        // ざぐりは穴とつながっている（離れた所の太い穴は別の穴）
        const qs = dot(sub(q.c, h.c), h.axis), qsg = dot(q.axis, h.axis) > 0 ? 1 : -1;
        const q0 = Math.min(qs + qsg * q.t0, qs + qsg * q.t1), q1 = Math.max(qs + qsg * q.t0, qs + qsg * q.t1);
        if (q0 > h.t1 + 1e-3 || q1 < h.t0 - 1e-3) continue;
        if (Math.abs(Math.abs(dot(q.axis, h.axis)) - 1) < 1e-6 && lineDist(h, q.c) < 1e-4) { used.add(j); cb = { dia: round(q.r * 2), depth: round(q.t1 - q.t0) }; break; }
      }
      let cs = null;
      if (!cb) for (const k of cones) {
        if (Math.abs(k.small.r - h.r) > 1e-3 || lineDist(h, k.small.c) > 1e-3 || lineDist(h, k.big.c) > 1e-3) continue;
        const ts = dot(sub(k.small.c, h.c), h.axis);
        if (Math.abs(ts - h.t0) > 1e-3 && Math.abs(ts - h.t1) > 1e-3) continue;
        cs = { dia: round(k.big.r * 2), depth: round(Math.abs(dot(sub(k.big.c, k.small.c), h.axis))) };
        break;
      }
      const depth = h.t1 - h.t0 + (cb ? cb.depth : 0) + (cs ? cs.depth : 0);
      out.push({
        bodyId: b.id, dia: round(h.r * 2), axis: h.axis.map((v) => round(v, 6)),
        p0: p0.map((v) => round(v, 4)), p1: p1.map((v) => round(v, 4)),
        depth: round(depth), through: Math.abs(depth - thk) < 1e-3 || depth >= thk - 1e-3, cbore: cb, ...(cs ? { csink: cs } : {}),
      });
    }
  }
  return out;
}

function lineDist(h, p) {
  const rel = sub(p, h.c); const along = dot(rel, h.axis);
  return Math.hypot(...sub(rel, h.axis.map((k) => k * along)));
}
const round = (v, d = 3) => +(+v).toFixed(d);

// ---------------------------------------------------------------- 板の展開
// 2D 座標系 (xd, yd) 上の図形（直線・円弧・曲線）
function edgePrims(edges, to2) {
  const prims = [];
  for (const e of edges) {
    const t = e.geomType;
    if (t === "LINE") { prims.push({ t: "line", a: to2(e.startPoint), b: to2(e.endPoint) }); continue; }
    if (t === "CIRCLE") {
      const p0 = to2(e.pointAt(0)), p1 = to2(e.pointAt(1 / 3)), p2 = to2(e.pointAt(2 / 3)), pe = to2(e.pointAt(1));
      const c = circle2(p0, p1, p2);
      if (c) {
        const full = Math.hypot(p0[0] - pe[0], p0[1] - pe[1]) < 1e-6;
        if (full) { prims.push({ t: "arc", c: [c[0], c[1]], r: c[2], s: 0, d: Math.PI * 2 }); continue; }
        const ang = (p) => Math.atan2(p[1] - c[1], p[0] - c[0]);
        const n2 = (x) => { while (x < 0) x += 2 * Math.PI; while (x >= 2 * Math.PI) x -= 2 * Math.PI; return x; };
        const s0 = ang(p0), sm = ang(to2(e.pointAt(0.5))), s1 = ang(pe);
        const ccw = n2(sm - s0) < n2(s1 - s0);
        prims.push({ t: "arc", c: [c[0], c[1]], r: c[2], s: s0, d: ccw ? n2(s1 - s0) : -n2(s0 - s1) });
        continue;
      }
    }
    const pts = [];
    for (let i = 0; i <= 48; i++) pts.push(to2(e.pointAt(i / 48)));
    prims.push({ t: "poly", pts });
  }
  return prims;
}
function circle2(a, b, m) {
  const d = 2 * (a[0] * (b[1] - m[1]) + b[0] * (m[1] - a[1]) + m[0] * (a[1] - b[1]));
  if (Math.abs(d) < 1e-12) return null;
  const a2 = a[0] * a[0] + a[1] * a[1], b2 = b[0] * b[0] + b[1] * b[1], m2 = m[0] * m[0] + m[1] * m[1];
  const ux = (a2 * (b[1] - m[1]) + b2 * (m[1] - a[1]) + m2 * (a[1] - b[1])) / d;
  const uy = (a2 * (m[0] - b[0]) + b2 * (a[0] - m[0]) + m2 * (b[0] - a[0])) / d;
  return [ux, uy, Math.hypot(a[0] - ux, a[1] - uy)];
}
function bbox2(prims) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  const add = (p) => { x0 = Math.min(x0, p[0]); y0 = Math.min(y0, p[1]); x1 = Math.max(x1, p[0]); y1 = Math.max(y1, p[1]); };
  for (const p of prims) {
    if (p.t === "line") { add(p.a); add(p.b); }
    else if (p.t === "poly") p.pts.forEach(add);
    else for (let k = 0; k <= 32; k++) { const t = p.s + (p.d * k) / 32; add([p.c[0] + p.r * Math.cos(t), p.c[1] + p.r * Math.sin(t)]); }
  }
  return [x0, y0, x1, y1];
}
const sameBox = (a, b, tol = 0.02) => a.every((v, k) => Math.abs(v - b[k]) < tol);

function faceArea(R, f) { try { return R.measureArea(f); } catch { return 0; } }

// 板状の部品を、いちばん広い平面を表にして 2D に展開する
export function panelFlat(R, body) {
  const faces = body.shape.faces;
  const planes = [];
  for (const f of faces) {
    if (f.geomType !== "PLANE") continue;
    const c = vec(f.center);
    const n = vec(f.normalAt(f.center));
    planes.push({ f, n, c, area: faceArea(R, f) });
  }
  if (!planes.length) throw new Error("平らな面がありません（板として展開できません）");
  // 法線ごとの面積合計が最大の向き = 板の表
  let best = null;
  for (const p of planes) {
    const tot = planes.filter((q) => Math.abs(dot(q.n, p.n)) > 1 - 1e-6).reduce((s, q) => s + q.area, 0);
    if (!best || tot > best.tot + 1e-6) best = { n: p.n, tot };
  }
  // 彫りが多い側を「表」にする（CNC は表から加工）
  const a = flatAlong(R, body, planes, best.n);
  const cnt = (r, side) => r.engrave.filter((e) => e.kind === "pocket" && e.side === side).length;
  if (cnt(a, "裏") > cnt(a, "表")) return flatAlong(R, body, planes, best.n.map((v) => -v));
  return a;
}

function flatAlong(R, body, planes, n) {
  // 表 = その向きで一番外側（高い）の面
  const lvl = (p) => dot(p.c, n);
  const tops = planes.filter((p) => dot(p.n, n) > 1 - 1e-6);
  const bots = planes.filter((p) => dot(p.n, n) < -1 + 1e-6);
  const [lo, hi] = extentAlong(body.shape, n);
  const top = tops.filter((p) => Math.abs(lvl(p) - hi) < 1e-4).sort((a, b) => b.area - a.area)[0] || tops.sort((a, b) => b.area - a.area)[0];
  const bot = bots.filter((p) => Math.abs(lvl(p) - lo) < 1e-4).sort((a, b) => b.area - a.area)[0];
  const thk = hi - lo;
  // 面内の X 方向: 外形の一番長い直線辺の向き（長方形の板は軸に沿う）
  let xd = null, bestL = 0;
  for (const e of top.f.clone().outerWire().edges) {
    if (e.geomType !== "LINE") continue;
    const d = sub(vec(e.endPoint), vec(e.startPoint)); const L = Math.hypot(...d);
    if (L > bestL + 1e-6) { bestL = L; xd = norm(d); }
  }
  if (!xd) { const cands = [[1, 0, 0], [0, 1, 0], [0, 0, 1]].sort((a, b) => Math.abs(dot(a, n)) - Math.abs(dot(b, n))); xd = norm(sub(cands[0], n.map((k) => k * dot(cands[0], n)))); }
  // 正の向きにそろえる（ワールド軸に近い方向を +）
  const big = xd.map(Math.abs).indexOf(Math.max(...xd.map(Math.abs))); if (xd[big] < 0) xd = xd.map((v) => -v);
  const yd = cross(n, xd);
  const to2raw = (v) => [v.x * xd[0] + v.y * xd[1] + v.z * xd[2], v.x * yd[0] + v.y * yd[1] + v.z * yd[2]];

  const outerTop = edgePrims(top.f.clone().outerWire().edges, to2raw);
  const outerBot = bot ? edgePrims(bot.f.clone().outerWire().edges, to2raw) : null;
  const bTop = bbox2(outerTop), bBot = outerBot ? bbox2(outerBot) : bTop;
  // 切り出し外形 = 大きい方（裏の外形のほうが大きいときは段欠き等）
  const areaOf = (b) => (b[2] - b[0]) * (b[3] - b[1]);
  const useBot = outerBot && areaOf(bBot) > areaOf(bTop) + 1e-3;
  const outer = useBot ? outerBot : outerTop;
  const ob = bbox2(outer);
  const shift = (prims) => prims.map((p) => tr(p, -ob[0], -ob[1]));
  const res = {
    id: body.id, name: body.name, thk: round(thk), w: round(ob[2] - ob[0]), h: round(ob[3] - ob[1]),
    outer: shift(outer), holes: [], engrave: [], notes: [],
  };
  if (outerBot && !sameBox(bTop, bBot)) res.engrave.push({ prims: shift(useBot ? outerTop : outerBot), depth: null, side: useBot ? "表" : "裏", kind: "step" });
  const innerOf = (pl) => (pl ? pl.f.clone().innerWires().map((w) => { const pr = edgePrims(w.edges, to2raw); return { prims: pr, box: bbox2(pr) }; }) : []);
  const inTop = innerOf(top), inBot = innerOf(bot);
  const matched = new Set();
  // 平面の高さ（表からの深さを求めるため）
  const depthAt = (box, fromTop) => {
    let d = null;
    for (const p of planes) {
      if (p === top || p === bot) continue;
      if (Math.abs(Math.abs(dot(p.n, n)) - 1) > 1e-6) continue;
      const c2 = to2raw({ x: p.c[0], y: p.c[1], z: p.c[2] });
      if (c2[0] < box[0] - 1e-6 || c2[0] > box[2] + 1e-6 || c2[1] < box[1] - 1e-6 || c2[1] > box[3] + 1e-6) continue;
      const dd = fromTop ? hi - lvl(p) : lvl(p) - lo;
      if (dd > 1e-6 && dd < thk - 1e-6) d = d === null ? dd : Math.max(d, dd);
    }
    return d === null ? null : round(d);
  };
  // 途中の段（ざぐりの底など）にある穴の形: その段から反対側まで抜けている
  const midWires = (sign) => planes.filter((p) => p !== top && p !== bot && dot(p.n, n) * sign > 1 - 1e-6)
    .flatMap((p) => { try { return p.f.clone().innerWires().map((w) => bbox2(edgePrims(w.edges, to2raw))); } catch { return []; } });
  const midUp = midWires(1), midDown = midWires(-1);
  for (const w of inTop) {
    const k = inBot.findIndex((q, i) => !matched.has(i) && sameBox(q.box, w.box));
    if (k >= 0) { matched.add(k); res.holes.push({ prims: shift(w.prims) }); }
    else if (midDown.some((b2) => sameBox(b2, w.box))) res.holes.push({ prims: shift(w.prims), stepped: true });
    else res.engrave.push({ prims: shift(w.prims), depth: depthAt(w.box, true), side: "表", kind: "pocket" });
  }
  inBot.forEach((w, i) => {
    if (matched.has(i)) return;
    if (midUp.some((b2) => sameBox(b2, w.box))) res.holes.push({ prims: shift(w.prims), stepped: true });
    else res.engrave.push({ prims: shift(w.prims), depth: depthAt(w.box, false), side: "裏", kind: "pocket" });
  });
  // 表面以外にある穴（側面＝木口からの穴など）: 平面の CNC 加工とは別に、側面加工として位置を返す
  const others = holesOf([body]).filter((h) => Math.abs(Math.abs(dot(h.axis, n)) - 1) > 1e-6);
  const toFlat = (p) => { const q = to2raw({ x: p[0], y: p[1], z: p[2] }); return [q[0] - ob[0], q[1] - ob[1]]; };
  const W = ob[2] - ob[0], H = ob[3] - ob[1];
  const edgeDist = (q) => Math.min(Math.abs(q[0]), Math.abs(q[1]), Math.abs(W - q[0]), Math.abs(H - q[1]));
  res.edgeHoles = [];
  for (const h of others) {
    const a = toFlat(h.p0), b = toFlat(h.p1);
    // 入口 = 外形（木口）に近い方の端
    const [entry, inner, pe] = edgeDist(a) <= edgeDist(b) ? [a, b, h.p0] : [b, a, h.p1];
    let d = [inner[0] - entry[0], inner[1] - entry[1]];
    const L = Math.hypot(d[0], d[1]);
    if (L < 1e-9) continue; // 表面に垂直でない・面内に向かない穴
    d = [d[0] / L, d[1] / L];
    res.edgeHoles.push({
      x: round(entry[0]), y: round(entry[1]), dir: [round(d[0], 6), round(d[1], 6)],
      z: round(hi - dot(pe, n)), dia: h.dia, depth: h.depth, through: h.through, cbore: h.cbore || null,
    });
  }
  if (res.edgeHoles.length) res.notes.push(`側面（木口）の穴 ${res.edgeHoles.length} 個（側面加工一覧を参照）`);
  // 図面で 3D と対応させるための座標系（平らな図の (0,0) = 表の面の上の点）
  res.frame = { xd, yd, n, off: [ob[0], ob[1]], hi, lo };
  return res;
}

function extentAlong(shape, n) {
  // 頂点から正確に（境界箱は回転した板で過大になる）
  let lo = Infinity, hi = -Infinity;
  for (const e of shape.edges) for (const t of [0, 0.25, 0.5, 0.75, 1]) { const d = dot(vec(e.pointAt(t)), n); lo = Math.min(lo, d); hi = Math.max(hi, d); }
  return [lo, hi];
}

function tr(p, dx, dy) {
  const T = (q) => [q[0] + dx, q[1] + dy];
  if (p.t === "line") return { t: "line", a: T(p.a), b: T(p.b) };
  if (p.t === "poly") return { t: "poly", pts: p.pts.map(T) };
  return { ...p, c: T(p.c) };
}

// STEP 読み戻し確認: 書き出したデータを形状として読み込み、体積を比べる
export async function verifyStep(R, buffer, bodies) {
  const shape = await R.importSTEP(new Blob([buffer]));
  let vol = 0;
  try { vol = R.measureShapeVolumeProperties(shape).volume; } catch { /* */ }
  let expect = 0;
  for (const b of bodies) { try { expect += R.measureShapeVolumeProperties(b.shape).volume; } catch { /* */ } }
  const bb = shape.boundingBox.bounds;
  return { volume: vol, expected: expect, bounds: bb, ok: Math.abs(vol - expect) <= Math.max(1e-6 * Math.abs(expect), 1e-3) };
}
