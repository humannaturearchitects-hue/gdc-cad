import * as THREE from "three";
import { Viewer } from "./viewer.js";
import { Sketcher } from "./sketcher.js";
import { CommandDialog, esc } from "./commands.js";
import { CommandLine } from "./commandline.js";
import { parseDXF } from "./dxfimport.js";
import { DrawingWorkspace } from "./drawing.js";
import { startKernel, requestBuild, call, kernelHooks, kernelReady, restartKernel } from "./kernel.js";
import { store, newProject, newId, FEATURE_LABEL, loadAutosave } from "./store.js";
import { ICON } from "./icons.js";
import { makeEvaluator, evaluateParams } from "./shared/expr.js";
import { findLoops, sketchPlaneFrame, resolveEntity } from "./shared/sketchgeom.js";
import { solveSketch } from "./shared/solver.js";

// 拘束付きスケッチは表示前に解く（パラメータ変更を反映）
export function solvedEntities(f, num) {
  const ents = f.entities || [];
  if (!f.constraints || !f.constraints.length) return ents;
  try { const r = solveSketch(ents, f.constraints, num); return r.ok ? r.entities : ents; } catch { return ents; }
}
import { download, exportOBJ, exportGLB, sheetToDXF, primsBBox, transformPrims, warmFont } from "./exporters.js";
import { sampleProject } from "./sample.js";
import { openLayupPanel, openTakeoff, computeLayup } from "./layup.js";

const MATERIALS = [
  ["", "未設定 (1.00)", 1.0], ["PETフォーム", "PETフォーム (0.10)", 0.10], ["FRP(ガラス)", "FRP ガラス (1.80)", 1.8],
  ["FRPサンドイッチ", "FRPサンドイッチ平均 (0.25)", 0.25], ["合板", "合板 (0.55)", 0.55], ["杉", "杉 (0.38)", 0.38],
  ["アルミ", "アルミ (2.70)", 2.7], ["鋼", "鋼 (7.85)", 7.85], ["ステンレス", "ステンレス (7.93)", 7.93],
  ["ABS", "ABS (1.05)", 1.05], ["アクリル", "アクリル (1.19)", 1.19], ["ゴム", "ゴム (1.20)", 1.2],
];

class App {
  constructor() {
    this.overlay = document.getElementById("overlay");
    this.viewer = new Viewer(document.getElementById("view3d"), this.overlay, document.getElementById("viewcube"));
    this.sketcher = new Sketcher(this);
    this.dialog = new CommandDialog(this);
    this.cmdline = new CommandLine(this);
    this.MATERIALS = MATERIALS;
    this.drawing = new DrawingWorkspace(this);
    this.tab = "solid";
    this.mode = "idle"; // idle | sketch | pickPlane | measure
    this.selection = [];
    this.meshes = [];
    this.sketchData = {};
    this.errors = [];
    this.loadedImports = new Set();
    this.importBuffers = new Map();
    this.buildTabs();
    this.buildMenus();
    this.bindViewport();
    this.bindKeys();
    this.bindNav();
    store.on(() => this.onProjectChange());
    // ファイルを画面にドラッグ＆ドロップ: STEP / STL / DXF（スケッチ）/ 手順ファイル（.txt）/ .kcad
    window.addEventListener("dragover", (e) => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) e.preventDefault(); });
    window.addEventListener("drop", (e) => {
      const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (!f) return;
      e.preventDefault();
      const ext = f.name.split(".").pop().toLowerCase();
      if (ext === "kcad") return this.openDoc && this.openDoc(f);
      if (["step", "stp", "stl", "dxf", "txt", "gdc"].includes(ext)) return this.importFile(f);
      this.toast("この形式は読み込めません（STEP・STL・DXF・手順ファイル .txt・.kcad）", true);
    });
  }

  async start() {
    this.busy(true, "CADエンジンを起動中…");
    try { await startKernel(); }
    catch (e) {
      document.getElementById("busy-msg").textContent = e.message + "（Google Chrome または Microsoft Edge の最新版で開いてください）";
      document.querySelector("#busy .spin").style.display = "none";
      return;
    }
    this.busy(false);
    kernelHooks.onRestart = () => { this.loadedImports.clear(); this.toast("CADエンジンを再起動しました。作業は保たれています"); this.rebuild(); };
    registerOffline();
    const saved = loadAutosave();
    if (saved && saved.features && saved.features.length) {
      store.replace(saved);
      this.toast("前回の作業を復元しました");
    } else {
      store.replace(newProject());
    }
    this.viewer.home();
  }

  // ------------------------------------------------------------ UI helpers
  toast(msg, err = false) {
    const t = document.getElementById("toast");
    t.textContent = msg; t.className = "show" + (err ? " err" : "");
    clearTimeout(this.tt); this.tt = setTimeout(() => (t.className = ""), err ? 4500 : 2200);
  }
  status(msg) { document.getElementById("status-hint").textContent = msg; }
  statusCoord(msg) { document.getElementById("status-coord").textContent = msg; }
  busyAction(label, fn) {
    let b = document.getElementById("busy-act");
    if (!label) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement("button"); b.id = "busy-act"; b.className = "busy-act"; document.getElementById("busy").appendChild(b); }
    b.textContent = label; b.onclick = fn;
  }
  busy(on, msg) { document.getElementById("busy").classList.toggle("hidden", !on); if (msg) document.getElementById("busy-msg").textContent = msg; }

  // ------------------------------------------------------------ toolbar
  buildTabs() {
    const tabs = document.getElementById("tabs");
    tabs.innerHTML = "";
    const list = this.mode === "sketch" ? [["sketch", "スケッチ"], ["inspect", "検査"]] : [["solid", "ソリッド"], ["inspect", "検査"], ["io", "挿入・書き出し"]];
    if (!list.find(([k]) => k === this.tab)) this.tab = list[0][0];
    for (const [k, n] of list) {
      const b = document.createElement("button");
      b.className = "tab" + (k === this.tab ? " active" : "") + (k === "sketch" ? " sketch" : "");
      b.textContent = n;
      b.onclick = () => { this.tab = k; this.buildTabs(); };
      tabs.appendChild(b);
    }
    this.refreshTools();
  }

  toolDefs() {
    if (this.tab === "sketch") {
      return [
        ["作成", [["line", "線", "L"], ["rect", "2点長方形", "R"], ["rectc", "中心長方形"], ["circle", "円", "C"], ["arc", "3点円弧", "A"], ["polygon", "多角形"], ["point", "点", "."], ["project", "投影", "P"]]],
        ["拘束", [["c_hv", "水平/垂直"], ["c_par", "平行"], ["c_perp", "直交"], ["c_eq", "等長"], ["c_fix", "固定"], ["c_dim", "寸法", "D"], ["explode", "線に分解"]]],
        ["修正", [["select", "選択", "S"], ["sfillet", "フィレット", "F"], ["offset", "オフセット", "O"], ["trim", "トリム", "T"], ["smirror", "ミラー"], ["construction", "補助線 切替", "X"], ["trash", "削除", "Del"]]],
        ["立体", [["extrude", "押し出し", "E"], ["revolve", "回転"]]],
        ["", [["finish", "スケッチを終了"]]],
      ];
    }
    if (this.tab === "inspect") return [["検査", [["measure", "計測"], ["section", "断面表示"], ["props", "物理プロパティ"], ["interference", "干渉チェック"], ["takeoff", "材料集計"]]], ["パラメータ", [["params", "パラメータ"]]]];
    if (this.tab === "io") return [["挿入", [["import", "インポート"]]], ["書き出し", [["export", "3D 書き出し"], ["dxf", "DXF 書き出し"], ["drawing", "図面を作成"]]]];
    return [
      ["作成", [["component", "新規コンポーネント"], ["sketch", "スケッチ作成"], ["extrude", "押し出し", "E"], ["revolve", "回転"], ["loft", "ロフト"], ["hole", "穴", "H"], ["box", "直方体"], ["cylinder", "円柱"], ["sphere", "球"]]],
      ["修正", [["presspull", "プレス/プル", "Q"], ["fillet", "フィレット", "F"], ["chamfer", "面取り"], ["shell", "シェル"], ["split", "分割"], ["move", "移動/コピー", "M"], ["mirror", "ミラー"], ["pattern", "矩形パターン"], ["cpattern", "円形パターン"], ["combine", "結合"]]],
      ["構築", [["plane", "構築平面"]]],
      ["言葉", [["cmdline", "AI に頼む", "/"], ["voice", "話す"]]],
      ["アセンブリ", [["joint", "ジョイント", "J"], ["align", "位置合わせ"], ["interference", "干渉チェック"]]],
      ["パラメータ", [["params", "パラメータ"]]],
      ["検査", [["measure", "計測"], ["section", "断面表示"]]],
      ["挿入", [["import", "インポート"]]],
    ];
  }

  refreshTools() {
    const el = document.getElementById("tools");
    el.innerHTML = "";
    for (const [glabel, items] of this.toolDefs()) {
      const g = document.createElement("div"); g.className = "tgroup";
      const it = document.createElement("div"); it.className = "items";
      for (const [id, label, key] of items) {
        const b = document.createElement("button");
        b.className = "tool" + (id === "finish" ? " finish" : "");
        if (this.mode === "sketch" && (this.sketcher.tool === id || (this.sketcher.tool === "dim" && id === "c_dim"))) b.classList.add("active");
        if (this.mode === "measure" && id === "measure") b.classList.add("active");
        b.innerHTML = (ICON[id] || ICON.sketch) + `<span>${label}</span>`;
        b.title = label + (key ? ` (${key})` : "");
        b.onclick = () => this.runTool(id);
        it.appendChild(b);
      }
      g.appendChild(it);
      const l = document.createElement("div"); l.className = "glabel"; l.textContent = glabel; g.appendChild(l);
      el.appendChild(g);
    }
  }

  runTool(id) {
    if (this.mode === "sketch") {
      if (["line", "rect", "rectc", "circle", "arc", "polygon", "point", "project", "select", "sfillet", "offset", "trim"].includes(id)) return this.sketcher.setTool(id);
      if (id === "smirror") return this.sketcher.mirrorSelected();
      if (id === "c_dim") return this.sketcher.startDim();
      if (id.startsWith("c_") || id === "explode") return this.sketcher.applyConstraintTool(id);
      if (id === "construction") return this.sketcher.selected.size ? this.sketcher.toggleConstruction() : this.toast("線を選択してから実行してください");
      if (id === "trash") return this.sketcher.selected.size ? this.sketcher.deleteSelected() : this.toast("削除する線を選択してください");
      if (id === "finish") return this.finishSketch();
      // Fusion と同じく、スケッチ中に立体の操作を選んだらスケッチを自動で終了してから始める
      this.finishSketch();
    }
    if (this.mode === "measure" && id !== "measure") this.endMeasure();
    switch (id) {
      case "sketch": return this.beginSketchCreate();
      case "component": return this.newComponent(store.project.activeComponent || null, this.selection.filter((x) => x.kind === "body").map((x) => x.bodyId));
      case "extrude": case "revolve": case "box": case "cylinder": case "sphere": case "fillet": case "chamfer":
      case "shell": case "move": case "mirror": case "pattern": case "combine":
      case "hole": case "cpattern": case "presspull": case "split": case "loft": case "align": case "joint": case "plane":
        if (this.mode === "pickPlane") this.cancelPickPlane();
        // Fusion と同じく、先に選んだもの（プロファイル・面・エッジ・ボディ）をそのまま使う
        this.preselect = this.selection.slice();
        try { return this.dialog.open(id); } finally { this.preselect = null; }
      case "params": return this.openParams();
      case "cmdline": return this.cmdline.open();
      // 押したその場で聞き始める（iPhone の Safari は、ボタンを押した直後でないとマイクを使わせない）
      case "voice": { this.cmdline.open(); document.getElementById("vc-talk")?.click(); return; }
      case "interference": return this.checkInterference();
      case "section": return this.openSection();
      case "takeoff": return openTakeoff(this);
      case "measure": return this.mode === "measure" ? this.endMeasure() : this.beginMeasure();
      case "props": return this.openProps();
      case "import": return this.importFile();
      case "export": return this.openExport3D();
      case "dxf": return this.openExportDXF();
      case "drawing": return this.setWorkspace("drawing");
    }
  }

  // ------------------------------------------------------------ file menu
  buildMenus() {
    const m = document.getElementById("menu-file");
    const pop = m.querySelector(".menu-pop");
    const items = [
      ["新規", "Ctrl+N", () => this.newDoc()],
      ["開く…", "Ctrl+O", () => this.openDoc()],
      ["保存（.kcad をダウンロード）", "Ctrl+S", () => this.saveDoc()],
      ["名前の変更…", "", () => this.renameDoc()],
      "-",
      ["インポート（STEP / STL / DXF）…", "", () => this.importFile()],
      ["手順ファイルを実行（.txt）…", "", async () => { const f = await this.pickFile(".txt,.gdc"); if (f) this.cmdline.runFile(f); }],
      ["3D 書き出し（STEP / STL / OBJ / GLB）…", "", () => this.openExport3D()],
      ["DXF 書き出し（スケッチ / 面）…", "", () => this.openExportDXF()],
      ["図面を作成（PDF / DXF）", "", () => this.setWorkspace("drawing")],
      "-",
      ["サンプルを開く", "", () => { if (this.confirmDiscard()) { store.replace(sampleProject()); this.viewer.home(); setTimeout(() => this.viewer.fit(), 400); } }],
      ["操作ガイド", "F1", () => this.openHelp()],
      ["このソフトについて", "", () => this.openAbout()],
    ];
    for (const it of items) {
      if (it === "-") { const s = document.createElement("div"); s.className = "sep"; pop.appendChild(s); continue; }
      const b = document.createElement("button");
      b.innerHTML = `<span>${it[0]}</span><span class="kbd">${it[1]}</span>`;
      b.onclick = () => { m.classList.remove("open"); it[2](); };
      pop.appendChild(b);
    }
    m.querySelector(".menu-btn").onclick = (e) => { e.stopPropagation(); m.classList.toggle("open"); };
    document.addEventListener("click", () => m.classList.remove("open"));
    const br = document.getElementById("browser");
    document.getElementById("btn-browser").onclick = (e) => { e.stopPropagation(); br.classList.toggle("open"); };
    document.getElementById("viewport").addEventListener("pointerdown", () => br.classList.remove("open"));
    document.getElementById("btn-undo").onclick = () => this.undo();
    document.getElementById("btn-redo").onclick = () => this.redo();
    document.querySelectorAll(".ws").forEach((b) => (b.onclick = () => this.setWorkspace(b.dataset.ws)));
  }

  confirmDiscard() {
    if (!store.dirty || !store.project.features.length) return true;
    return confirm("保存していない変更があります。破棄してよろしいですか？\n（作業内容はブラウザにも自動保存されています）");
  }
  newDoc() { if (!this.confirmDiscard()) return; this.exitModes(); store.replace(newProject()); this.viewer.home(); }
  renameDoc() { const n = prompt("ドキュメント名", store.project.name); if (n) store.commit((p) => { p.name = n; }); }

  saveDoc() {
    const p = store.project;
    const data = JSON.stringify(p);
    download(new Blob([data], { type: "application/json" }), `${p.name || "無題"}.kcad`);
    store.dirty = false;
    this.toast("保存しました（ダウンロードフォルダ）");
  }

  pickFile(accept) {
    return new Promise((res) => {
      const inp = document.getElementById("file-input");
      inp.value = ""; inp.accept = IS_IOS ? "" : accept;
      inp.onchange = () => res(inp.files[0] || null);
      inp.click();
    });
  }

  async openDoc(given) {
    if (!this.confirmDiscard()) return;
    const f = given instanceof File ? given : await this.pickFile(".kcad,.json");
    if (!f) return;
    try {
      const p = JSON.parse(await f.text());
      if (p.format !== "kobocad") throw new Error("GDC GOOD DESIGN CAD のファイルではありません");
      this.exitModes();
      store.replace(p);
      setTimeout(() => this.viewer.fit(), 300);
    } catch (e) { this.toast("開けませんでした: " + e.message, true); }
  }

  // DXF をスケッチとして読み込む（平らな面を選んでいればその面に、なければ XY 平面に）
  async importDXF(file) {
    let parsed;
    try { parsed = parseDXF(await file.text()); } catch (e) { return this.toast("DXF を読めませんでした: " + e.message, true); }
    if (!parsed.entities.length) return this.toast("DXF に読み込める線（線・円・円弧・ポリライン・点）がありませんでした", true);
    let plane = { type: "std", name: "XY", offset: "0" };
    const face = this.selection.find((s) => s.kind === "face");
    if (face) {
      try { const fp = await call("facePlane", { bodyId: face.bodyId, point: face.point }); plane = { type: "face", origin: fp.origin.map((v) => +v.toFixed(6)), xDir: fp.xDir, normal: fp.normal, offset: "0", ref: { body: face.bodyId, point: face.point.map((v) => +v.toFixed(4)) } }; } catch { /* XY に */ }
    }
    const id = newId();
    const ents = parsed.entities.map((e) => ({ ...e, id: newId("e") }));
    store.commit((p) => {
      const at = p.rollback ?? p.features.length;
      p.features.splice(at, 0, { id, type: "sketch", name: file.name.replace(/\.[^.]+$/, "") || store.nameFor("sketch"), plane, entities: ents, ...(p.activeComponent ? { component: p.activeComponent } : {}) });
      if (p.rollback != null) p.rollback = at + 1;
    });
    const sk = Object.entries(parsed.skipped).map(([k, n]) => `${k}×${n}`).join("、");
    this.toast(`DXF を${plane.type === "face" ? "選んだ面" : " XY 平面"}のスケッチとして読み込みました（${ents.length} 個の図形${parsed.scale !== 1 ? `、単位を mm に換算 ×${parsed.scale}` : ""}）${sk ? `。読めなかったもの: ${sk}` : ""}。押し出し（E）で立体にできます`);
    setTimeout(() => this.viewer.fit(), 400);
  }

  async importFile(given) {
    const f = given || await this.pickFile(".step,.stp,.stl,.dxf,.txt");
    if (!f) return;
    const ext = f.name.split(".").pop().toLowerCase();
    if (ext === "txt" || ext === "gdc") return this.cmdline.runFile(f);
    if (ext === "dxf") return this.importDXF(f);
    const format = ext === "stl" ? "stl" : "step";
    const buf = await f.arrayBuffer();
    this.busy(true, "インポート中…");
    try {
      const key = "imp_" + (await hashBuf(buf));
      this.importBuffers.set(key, buf);
      const n = await call("loadImport", { key, format, buffer: buf.slice(0) });
      this.loadedImports.add(key);
      const text = format === "step" ? new TextDecoder().decode(buf) : "";
      const names = format === "step" ? stepSolidNames(text, n) : [];
      const tree = format === "step" ? stepAssemblyTree(text, n) : null;
      const fid = newId();
      store.commit((p) => {
        if ((p.name === "無題" || !p.name) && !p.features.length) p.name = f.name.replace(/\.[^.]+$/, "");
        // STEP のアセンブリ構成をコンポーネント階層として取り込む
        let bodyComp = null;
        const base = p.activeComponent || null;
        if (tree && tree.nodes.length) {
          p.components = p.components || [];
          const idOf = (k) => `C_${fid}_${k}`;
          for (const nd of tree.nodes) p.components.push({ id: idOf(nd.key), name: nd.name || "アセンブリ", parent: nd.parent != null ? idOf(nd.parent) : base });
          bodyComp = tree.leafParent.map((k) => (k != null ? idOf(k) : base));
        }
        p.features.push({ id: fid, type: "import", component: base, bodyComp, name: f.name, fileName: f.name.replace(/\.[^.]+$/, ""), format, dataKey: key, data: b64(buf), names });
      });
      this.toast(`${f.name} を読み込みました（${n} ボディ）`);
      setTimeout(() => this.viewer.fit(), 500);
    } catch (e) { this.toast("インポート失敗: " + e.message, true); }
    finally { this.busy(false); }
  }

  async ensureImports(project) {
    for (const f of project.features) {
      if (f.type !== "import" || this.loadedImports.has(f.dataKey)) continue;
      const buf = this.importBuffers.get(f.dataKey) || unb64(f.data);
      await call("loadImport", { key: f.dataKey, format: f.format, buffer: buf });
      this.loadedImports.add(f.dataKey);
    }
  }

  // ------------------------------------------------------------ rebuild
  onProjectChange() {
    document.getElementById("doc-title").textContent = store.project.name + (store.dirty ? " *" : "");
    if (this.mode === "sketch") {
      if (!store.feature(this.sketcher.featureId)) { this.exitModes(); }
      else { this.sketcher.redraw(); this.renderTimeline(); return; }
    }
    this.rebuild();
  }

  async rebuild(opts = {}) {
    let project = store.project;
    if (opts.draft) {
      project = JSON.parse(JSON.stringify(project));
      if (opts.editId) { const i = project.features.findIndex((f) => f.id === opts.editId); project.features[i] = opts.draft; }
      else { const at = project.rollback ?? project.features.length; project.features.splice(at, 0, opts.draft); if (project.rollback != null) project.rollback = at + 1; }
    }
    let upto = project.rollback ?? null;
    if (opts.uptoBefore) { upto = project.features.findIndex((f) => f.id === opts.uptoBefore); }
    this.buildsRunning = (this.buildsRunning || 0) + 1;
    const t0 = Date.now();
    const busyTimer = setTimeout(() => { if (this.buildsRunning) this.busy(true, kernelReady() ? "計算中…" : "CADエンジンを起動中…"); }, 250);
    // 長くかかるときは経過時間と「再起動」ボタンを出す（止まったままにしない）
    const slowTimer = setInterval(() => {
      if (!this.buildsRunning) return;
      const sec = Math.round((Date.now() - t0) / 1000);
      if (sec < 8) return;
      this.busy(true, (kernelReady() ? "計算に時間がかかっています" : "CADエンジンを起動中") + `（${sec} 秒）`);
      this.busyAction(kernelReady() ? "中止して再起動" : null, () => { this.busyAction(null); restartKernel(); });
    }, 1000);
    try {
      await this.ensureImports(project);
      const r = await requestBuild({ project, upto, quality: "normal" });
      const wasEmpty = !this.meshes.length;
      // 使い回しのメッシュは手元の配列で補う
      this.meshStore = this.meshStore || new Map();
      const keys = new Set();
      for (const m of r.meshes) {
        keys.add(m.meshKey);
        if (m.reuse) Object.assign(m, this.meshStore.get(m.meshKey));
        else this.meshStore.set(m.meshKey, { vertices: m.vertices, normals: m.normals, triangles: m.triangles, lines: m.lines, faceGroups: m.faceGroups, edgeGroups: m.edgeGroups });
      }
      for (const k of [...this.meshStore.keys()]) if (!keys.has(k)) this.meshStore.delete(k);
      this.lastBuild = { ms: r.ms, reused: r.reused, total: r.total, meshes: r.meshes.length, newMeshes: r.meshes.filter((m) => !m.reuse).length };
      this.meshes = r.meshes;
      this.jointInfo = r.joints || {};
      this.holeInfo = r.holes || {};
      const hc = this.compHiddenSet();
      for (const m of this.meshes) if (m.component && hc.has(m.component)) m.hidden = true;
      this.sketchData = r.sketches;
      this.sketchFrames = this.sketchFrames || {};
      for (const [k, v] of Object.entries(r.sketches || {})) this.sketchFrames[k] = v.frame;
      this.errors = r.errors;
      this.viewer.pickExclude = opts.draft && !opts.editId && (opts.draft.operation === "new" || !opts.draft.operation) ? opts.draft.id : null;
      this.viewer.setBodies(r.meshes);
      // 形が変わったので、前の形を指したままのカーソル下の強調表示（残像）を消す
      this.viewer.clearHighlight("hover");
      // 移動の矢印で一時的に動かした見た目を元に戻す（計算し直した形を正しく表示）
      if (!this.mvDrag) for (const b of this.viewer.bodies.values()) for (const m of [b.mesh, b.edges]) { if (m.position.lengthSq() || m.quaternion.w !== 1) { m.position.set(0, 0, 0); m.quaternion.identity(); } }
      if (wasEmpty && r.meshes.length && !opts.draft && this.mode === "idle") this.viewer.fit();
      else if (r.meshes.length && this.mode !== "sketch") {
        // 形が大きくなって画面からはみ出したら引いて表示（Fusion で見失わないのと同じ感覚に）
        const bx = this.viewer.sceneBox();
        const prev = this.lastSceneBox;
        if (!prev || bx.min.x < prev.min.x - 1 || bx.min.y < prev.min.y - 1 || bx.min.z < prev.min.z - 1 || bx.max.x > prev.max.x + 1 || bx.max.y > prev.max.y + 1 || bx.max.z > prev.max.z + 1) {
          const c = [bx.min, bx.max];
          this.viewer.ensureVisible([0, 1, 2, 3, 4, 5, 6, 7].map((k) => [c[k & 1].x, c[(k >> 1) & 1].y, c[(k >> 2) & 1].z]));
        }
        this.lastSceneBox = bx.clone();
      }
      document.getElementById("welcome").classList.toggle("hidden", store.project.features.length > 0 || this.mode !== "idle");
      this.updateSketchDisplay(project);
      this.updateCPlanes(project);
      this.renderBrowser();
      this.renderTimeline();
      this.reapplyHighlights();
      if (r.errors.length && !opts.draft) this.status("⚠ " + r.errors.map((e) => `${store.feature(e.featureId)?.name || ""}: ${e.message}`).join(" / "));
      else if (this.mode === "idle") this.status("準備完了");
      return r.errors;
    } catch (e) {
      if (!e.superseded) { console.error(e); this.toast("計算エラー: " + e.message, true); }
      return null;
    } finally {
      clearTimeout(busyTimer); clearInterval(slowTimer);
      this.buildsRunning = Math.max(0, this.buildsRunning - 1);
      if (!this.buildsRunning) { this.busy(false); this.busyAction(null); }
    }
  }

  // スケッチの平面（面に描いたものは、計算エンジンが面を追いかけた結果を使う）
  frameOf(f, num) {
    const fr = sketchPlaneFrame(f.plane, num);
    const w = this.sketchFrames && this.sketchFrames[f.id];
    if (f.plane && f.plane.type === "cplane") {
      if (w) return w;
      const pf = this.sketchFrames && this.sketchFrames[f.plane.ref];
      if (pf) return { ...pf, origin: pf.origin.map((v, i) => v + pf.normal[i] * (+f.plane.offset || 0)) };
      return fr;
    }
    return f.plane && f.plane.type === "face" && w ? { ...fr, origin: w.origin } : fr;
  }

  sketchLoops(id) {
    const f = store.feature(id);
    if (!f) return null;
    try { const num = makeEvaluator(store.project.params || []); return findLoops(solvedEntities(f, num), num); } catch { return null; }
  }

  updateSketchDisplay(project = store.project) {
    const num = makeEvaluator(project.params || []);
    const needProfiles = this.dialog.isOpen && this.dialog.selKinds().includes("profile");
    const consumed = usedSketches(project.features);
    const list = [];
    const upto = project.rollback ?? project.features.length;
    project.features.forEach((f, idx) => {
      if (f.type !== "sketch" || idx >= upto) return;
      if (this.mode === "sketch" && f.id === this.sketcher.featureId) return;
      let frame;
      try { frame = this.frameOf(f, num); } catch { return; }
      const visible = f.visible ?? !consumed.has(f.id);
      const show = needProfiles ? true : visible;
      let loops = null;
      const ents = solvedEntities(f, num);
      try { loops = findLoops(ents, num); } catch { /* */ }
      list.push({ id: f.id, frame, entities: ents, loops, visible: show, num });
    });
    this.viewer.setSketches(list, { profiles: needProfiles || this.mode === "idle" });
  }

  // 構築平面の表示（クリックしてスケッチ・押し出しの対象などに使える）
  updateCPlanes(project = store.project) {
    const upto = project.rollback ?? project.features.length;
    const list = [];
    project.features.forEach((f, i) => {
      if (f.type !== "plane" || f.suppressed || i >= upto) return;
      const fr = this.sketchFrames && this.sketchFrames[f.id];
      if (fr) list.push({ id: f.id, name: f.name, frame: fr, visible: f.visible !== false });
    });
    this.viewer.setCPlanes(list);
  }

  bodyList() {
    return this.meshes.map((m) => ({ id: m.id, name: m.name, color: m.color, hidden: m.hidden, material: m.material }));
  }

  // ------------------------------------------------------------ components（アセンブリ階層）
  comps() { return store.project.components || []; }
  comp(id) { return this.comps().find((c) => c.id === id); }
  compChildren(id) { return this.comps().filter((c) => (c.parent || null) === (id || null)); }
  compDescendants(id) { const out = [id]; for (let i = 0; i < out.length; i++) for (const c of this.compChildren(out[i])) out.push(c.id); return out; }
  compBodies(id) { const set = new Set(this.compDescendants(id)); return this.meshes.filter((m) => set.has(m.component)).map((m) => m.id); }
  compHiddenSet() {
    const hidden = new Set();
    for (const c of this.comps()) { let x = c; while (x) { if (x.hidden) { hidden.add(c.id); break; } x = this.comp(x.parent); } }
    return hidden;
  }
  compPath(id) { const out = []; let x = this.comp(id); while (x) { out.unshift(x.name); x = this.comp(x.parent); } return out.join(" / "); }

  newComponent(parent = store.project.activeComponent || null, bodies = []) {
    const n = this.comps().length + 1;
    const name = prompt("コンポーネント名", `コンポーネント${n}`);
    if (!name) return;
    const id = newId("C");
    store.commit((p) => {
      p.components = p.components || [];
      p.components.push({ id, name, parent: parent || null });
      p.activeComponent = id;
      p.bodyProps = p.bodyProps || {};
      for (const b of bodies) p.bodyProps[b] = { ...(p.bodyProps[b] || {}), component: id };
    });
    this.toast(`「${name}」を作成し、アクティブにしました（新しいボディはここに入ります）`);
  }
  setActiveComponent(id) { store.commit((p) => { p.activeComponent = id || null; }); }
  moveBodiesToComponent(bodyIds, compId) {
    store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const b of bodyIds) p.bodyProps[b] = { ...(p.bodyProps[b] || {}), component: compId || null }; });
  }
  moveComponent(id, parent) {
    if (id === parent || this.compDescendants(id).includes(parent)) return this.toast("自分の中には移動できません", true);
    store.commit((p) => { const c = p.components.find((x) => x.id === id); c.parent = parent || null; });
  }
  deleteComponent(id) {
    const c = this.comp(id);
    if (!confirm(`コンポーネント「${c.name}」を削除しますか？\n中のボディとサブコンポーネントは1つ上の階層に移ります（形状は消えません）。`)) return;
    store.commit((p) => {
      for (const x of p.components) if (x.parent === id) x.parent = c.parent || null;
      for (const m of this.meshes) if (m.component === id) { p.bodyProps = p.bodyProps || {}; p.bodyProps[m.id] = { ...(p.bodyProps[m.id] || {}), component: c.parent || null }; }
      for (const f of p.features) if (f.component === id) f.component = c.parent || null;
      p.components = p.components.filter((x) => x.id !== id);
      if (p.activeComponent === id) p.activeComponent = c.parent || null;
    });
  }
  pickComponent(title, onPick, excludeId) {
    const opts = [`<option value="">（ルート：${esc(store.project.name)}）</option>`];
    const walk = (parent, depth) => { for (const c of this.compChildren(parent)) { if (c.id === excludeId) continue; opts.push(`<option value="${c.id}">${"　".repeat(depth + 1)}${esc(c.name)}</option>`); walk(c.id, depth + 1); } };
    walk(null, 0);
    this.panel(title, `<label>移動先</label><select id="cmp-sel">${opts.join("")}</select>`, () => onPick(document.getElementById("cmp-sel").value || null), { okLabel: "移動" });
  }

  componentMenu(ev, id) {
    const c = this.comp(id);
    const bodies = this.compBodies(id);
    this.menu(ev, [
      [store.project.activeComponent === id ? "（アクティブ中）" : "アクティブにする", () => this.setActiveComponent(id)],
      ["名前の変更", () => { const n = prompt("コンポーネント名", c.name); if (n) store.commit((p) => { p.components.find((x) => x.id === id).name = n; }); }],
      ["サブコンポーネントを追加", () => this.newComponent(id)],
      [c.hidden ? "表示" : "非表示", () => store.commit((p) => { const x = p.components.find((y) => y.id === id); x.hidden = !x.hidden; })],
      ["このコンポーネントだけ表示", () => store.commit((p) => {
        const keep = new Set(this.compDescendants(id));
        let x = c; while (x) { keep.add(x.id); x = this.comp(x.parent); }
        for (const k of p.components) k.hidden = !keep.has(k.id) && !this.compDescendants(k.id).some((d) => keep.has(d));
        p.bodyProps = p.bodyProps || {};
        for (const m of this.meshes) p.bodyProps[m.id] = { ...(p.bodyProps[m.id] || {}), hidden: !keep.has(m.component) };
      })],
      ["すべて表示", () => store.commit((p) => { for (const k of p.components || []) k.hidden = false; for (const m of this.meshes) if (p.bodyProps?.[m.id]) p.bodyProps[m.id].hidden = false; })],
      ["積層（サンドイッチパネル）を設定（中の全ボディ）", () => openLayupPanel(this, bodies)],
      ["ジョイントで動かす（ヒンジ・スライド）", () => { this.preselect = bodies.map((b) => ({ kind: "body", bodyId: b })); this.dialog.open("joint"); this.preselect = null; }],
      ["移動 / コピー（中身ごと）", () => { this.preselect = bodies.map((b) => ({ kind: "body", bodyId: b })); this.dialog.open("move"); this.preselect = null; }],
      ["別のコンポーネントの中へ移す", () => this.pickComponent("コンポーネントの移動", (to) => this.moveComponent(id, to), id)],
      [`STEP で書き出し（${bodies.length} ボディ）`, () => this.export3D("step", bodies, c.name)],
      ["STL で書き出し", () => this.export3D("stl", bodies, c.name)],
      ["このコンポーネントの図面", () => { store.project.drawing = { ...(store.project.drawing || {}), mode: "comp" }; this.setWorkspace("drawing"); }],
      ["削除（中身は残す）", () => this.deleteComponent(id)],
    ]);
  }

  // ------------------------------------------------------------ browser tree
  renderBrowser() {
    const el = document.getElementById("browser");
    const p = store.project;
    const evp = evaluateParams(p.params || []);
    const errIds = new Set(this.errors.map((e) => e.featureId));
    const active = p.activeComponent || null;
    const hiddenComps = this.compHiddenSet();
    this.collapsed = this.collapsed || new Set();
    const html = [];
    const bodyRow = (m) => {
      const sel = this.selection.some((s) => s.kind === "body" && s.bodyId === m.id);
      return `<div class="tree-node ${sel ? "selected" : ""}" data-body="${m.id}" draggable="true"><span class="tw"></span><span class="eye ${m.hidden ? "off" : ""}" data-eye="${m.id}">👁</span><span class="swatch" data-color="${m.id}" style="background:${m.color}"></span><span class="nm" title="${esc(m.name)}">${esc(m.name)}</span></div>`;
    };
    const compIds = new Set(this.comps().map((c) => c.id));
    const sketchesAll = p.features.filter((f) => f.type === "sketch");
    const consumedSk = usedSketches(p.features);
    const sketchRow = (sk) => {
      const vis = sk.visible ?? !consumedSk.has(sk.id);
      return `<div class="tree-node" data-sketch="${sk.id}"><span class="tw"></span><span class="eye ${vis ? "" : "off"}" data-skeye="${sk.id}">👁</span><span class="skicon">✎</span><span class="nm ${errIds.has(sk.id) ? "err" : ""}">${esc(sk.name)}</span></div>`;
    };
    const compRows = (parent) => {
      for (const c of this.compChildren(parent)) {
        const open = !this.collapsed.has(c.id);
        const nb = this.compBodies(c.id).length;
        html.push(`<div class="tree-node comp ${hiddenComps.has(c.id) ? "dim" : ""}" data-comp="${c.id}"><span class="tw" data-tw="${c.id}">${open ? "▾" : "▸"}</span><span class="radio ${active === c.id ? "on" : ""}" data-activate="${c.id}" title="アクティブにする（新しいボディの入れ先）"></span><span class="eye ${c.hidden ? "off" : ""}" data-ceye="${c.id}">👁</span><span class="cicon">▣</span><span class="nm" title="${esc(this.compPath(c.id))}">${esc(c.name)} <span class="cnt" title="ボディの数">${nb ? `(${nb})` : "(空)"}</span></span></div>`);
        if (open) {
          html.push(`<div class="tree-children">`);
          compRows(c.id);
          for (const m of this.meshes) if (m.component === c.id) html.push(bodyRow(m));
          for (const sk of sketchesAll.filter((f) => f.component === c.id)) html.push(sketchRow(sk));
          html.push(`</div>`);
        }
      }
    };
    html.push(`<div class="tree-node root" data-comp=""><span class="tw">▾</span><span class="radio ${active ? "" : "on"}" data-activate="" title="アクティブにする"></span><span class="nm"><b>${esc(p.name)}</b></span></div><div class="tree-children">`);
    html.push(`<div class="tree-node" data-act="planes"><span class="tw"></span><span class="eye ${this.planesOn ? "" : "off"}">👁</span><span class="nm">原点（XY / XZ / YZ 平面）</span></div>`);
    compRows(null);
    const loose = this.meshes.filter((m) => !m.component || !compIds.has(m.component));
    if (loose.length) {
      html.push(`<div class="tree-node"><span class="tw">▾</span><span class="nm"><b>ボディ</b> (${loose.length})</span></div><div class="tree-children">`);
      for (const m of loose) html.push(bodyRow(m));
      html.push(`</div>`);
    }
    const sketches = sketchesAll.filter((f) => !f.component || !compIds.has(f.component));
    if (sketches.length) {
      html.push(`<div class="tree-node"><span class="tw">▾</span><span class="nm"><b>スケッチ</b> (${sketches.length})</span></div><div class="tree-children">`);
      for (const sk of sketches) html.push(sketchRow(sk));
      html.push(`</div>`);
    }
    const cps = p.features.filter((f) => f.type === "plane");
    if (cps.length) {
      html.push(`<div class="tree-node"><span class="tw">▾</span><span class="nm"><b>構築</b> (${cps.length})</span></div><div class="tree-children">`);
      for (const f of cps) html.push(`<div class="tree-node" data-cplane="${f.id}"><span class="tw"></span><span class="eye ${f.visible === false ? "off" : ""}" data-cpeye="${f.id}">👁</span><span class="skicon">▱</span><span class="nm ${errIds.has(f.id) ? "err" : ""}">${esc(f.name)}</span></div>`);
      html.push(`</div>`);
    }
    html.push(`<div class="tree-node" data-act="params"><span class="tw">▾</span><span class="nm"><b>パラメータ</b> (${evp.length})</span></div><div class="tree-children">`);
    for (const q of evp) html.push(`<div class="tree-node" data-act="params"><span class="tw"></span><span class="nm">${esc(q.name)} = ${q.error ? "<span class='err'>エラー</span>" : +q.value.toFixed(4)}</span></div>`);
    html.push(`</div></div>`);
    if (!this.comps().length && this.meshes.length) html.push(`<div class="tree-tip">ヒント: 「新規コンポーネント」で部品をグループ分け（アセンブリ階層）できます。ボディはドラッグで移動できます。</div>`);
    el.innerHTML = html.join("");
    el.querySelectorAll("[data-eye]").forEach((e) => e.addEventListener("click", (ev) => { ev.stopPropagation(); this.toggleBody(e.dataset.eye); }));
    el.querySelectorAll("[data-ceye]").forEach((e) => e.addEventListener("click", (ev) => { ev.stopPropagation(); const id = e.dataset.ceye; store.commit((pp) => { const c = pp.components.find((x) => x.id === id); c.hidden = !c.hidden; }); }));
    el.querySelectorAll("[data-activate]").forEach((e) => e.addEventListener("click", (ev) => { ev.stopPropagation(); this.setActiveComponent(e.dataset.activate || null); }));
    el.querySelectorAll("[data-tw]").forEach((e) => e.addEventListener("click", (ev) => { ev.stopPropagation(); const id = e.dataset.tw; this.collapsed.has(id) ? this.collapsed.delete(id) : this.collapsed.add(id); this.renderBrowser(); }));
    el.querySelectorAll("[data-cpeye]").forEach((e) => e.addEventListener("click", (ev) => { ev.stopPropagation(); const id = e.dataset.cpeye; store.commit((pp) => { const f = pp.features.find((x) => x.id === id); f.visible = f.visible === false; }); }));
    el.querySelectorAll("[data-cplane]").forEach((e) => e.addEventListener("dblclick", () => this.dialog.open("plane", e.dataset.cplane)));
    el.querySelectorAll("[data-skeye]").forEach((e) => e.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const id = e.dataset.skeye;
      const f = store.feature(id);
      const vis = f.visible ?? !consumed.has(id);
      store.commit((pp) => { pp.features.find((x) => x.id === id).visible = !vis; });
    }));
    el.querySelectorAll("[data-color]").forEach((e) => e.addEventListener("click", (ev) => { ev.stopPropagation(); this.pickColor(e.dataset.color); }));
    el.querySelectorAll("[data-body]").forEach((e) => {
      e.addEventListener("click", (ev) => {
        const id = e.dataset.body;
        if (ev.shiftKey || ev.ctrlKey || ev.metaKey) { const k = this.selection.findIndex((s) => s.kind === "body" && s.bodyId === id); if (k >= 0) this.selection.splice(k, 1); else this.selection.push({ kind: "body", bodyId: id }); }
        else this.selection = [{ kind: "body", bodyId: id }];
        this.reapplyHighlights(); this.renderBrowser();
      });
      e.addEventListener("dblclick", () => this.renameBody(e.dataset.body));
      e.addEventListener("contextmenu", (ev) => { ev.preventDefault(); if (!this.selection.some((s) => s.bodyId === e.dataset.body)) this.selection = [{ kind: "body", bodyId: e.dataset.body }]; this.reapplyHighlights(); this.bodyMenu(ev, e.dataset.body); });
      e.addEventListener("dragstart", (ev) => {
        const sel = this.selection.filter((s) => s.kind === "body").map((s) => s.bodyId);
        const ids = sel.includes(e.dataset.body) ? sel : [e.dataset.body];
        ev.dataTransfer.setData("text/plain", JSON.stringify({ bodies: ids }));
      });
    });
    el.querySelectorAll("[data-comp]").forEach((e) => {
      const id = e.dataset.comp || null;
      if (id) {
        e.setAttribute("draggable", "true");
        e.addEventListener("dragstart", (ev) => ev.dataTransfer.setData("text/plain", JSON.stringify({ comp: id })));
        e.addEventListener("contextmenu", (ev) => { ev.preventDefault(); this.componentMenu(ev, id); });
        e.addEventListener("dblclick", () => this.setActiveComponent(id));
      }
      e.addEventListener("dragover", (ev) => { ev.preventDefault(); e.classList.add("drop"); });
      e.addEventListener("dragleave", () => e.classList.remove("drop"));
      e.addEventListener("drop", (ev) => {
        ev.preventDefault(); e.classList.remove("drop");
        try {
          const d = JSON.parse(ev.dataTransfer.getData("text/plain"));
          if (d.bodies) this.moveBodiesToComponent(d.bodies, id);
          if (d.comp) this.moveComponent(d.comp, id);
        } catch { /* */ }
      });
    });
    el.querySelectorAll("[data-sketch]").forEach((e) => {
      e.addEventListener("dblclick", () => this.editFeature(e.dataset.sketch));
      e.addEventListener("contextmenu", (ev) => { ev.preventDefault(); this.featureMenu(ev, e.dataset.sketch); });
    });
    el.querySelectorAll("[data-act=params]").forEach((e) => e.addEventListener("dblclick", () => this.openParams()));
    const pl = el.querySelector("[data-act=planes] .eye");
    pl.addEventListener("click", () => { this.planesOn = !this.planesOn; this.viewer.showPlanes(this.planesOn); this.renderBrowser(); });
  }

  setBodyProp(id, patch) {
    store.commit((p) => { p.bodyProps = p.bodyProps || {}; p.bodyProps[id] = { ...(p.bodyProps[id] || {}), ...patch }; });
  }
  toggleBody(id) { const m = this.meshes.find((x) => x.id === id); this.setBodyProp(id, { hidden: !m.hidden }); }
  renameBody(id) { const m = this.meshes.find((x) => x.id === id); const n = prompt("ボディ名", m.name); if (n) this.setBodyProp(id, { name: n }); }
  pickColor(id) {
    const inp = document.createElement("input"); inp.type = "color";
    inp.value = this.meshes.find((x) => x.id === id)?.color || "#9aa3ad";
    inp.style.cssText = "position:fixed;left:-100px";
    document.body.appendChild(inp);
    inp.addEventListener("change", () => { this.setBodyProp(id, { color: inp.value }); inp.remove(); });
    inp.click();
  }

  // ------------------------------------------------------------ timeline
  renderTimeline() {
    const el = document.getElementById("timeline");
    const p = store.project;
    const errIds = new Set(this.errors.map((e) => e.featureId));
    const rb = p.rollback ?? p.features.length;
    const html = [`<div class="tl-ctrl"><button data-tl="first" title="先頭へ">⏮</button><button data-tl="prev" title="1つ戻る">◀</button><button data-tl="next" title="1つ進む">▶</button><button data-tl="last" title="最後へ">⏭</button></div><div class="tl-items">`];
    p.features.forEach((f, i) => {
      if (i === rb) html.push(`<div class="tl-marker" title="ここまでの履歴を表示中"></div>`);
      const cls = ["tl-item", f.suppressed ? "suppressed" : "", i >= rb ? "rolled" : "", errIds.has(f.id) ? "error" : "", this.sketcher.active && this.sketcher.featureId === f.id ? "sel" : ""].join(" ");
      const ic = f.type === "import" ? ICON.import : ICON[f.type] || ICON.sketch;
      const err = this.errors.find((e) => e.featureId === f.id);
      html.push(`<div class="${cls}" data-f="${f.id}" title="${esc(f.name)}${err ? "\n⚠ " + esc(err.message) : ""}\nダブルクリックで編集 / 右クリックでメニュー">${ic}</div>`);
    });
    if (rb >= p.features.length) html.push(`<div class="tl-marker" title="最新"></div>`);
    html.push(`</div>`);
    if (!p.features.length) html.push(`<span class="tl-hint">タイムライン: 作成した操作の履歴がここに並びます。ダブルクリックで後から寸法を変更できます。</span>`);
    el.innerHTML = html.join("");
    el.querySelectorAll("[data-f]").forEach((d) => {
      d.addEventListener("dblclick", () => this.editFeature(d.dataset.f));
      d.addEventListener("contextmenu", (ev) => { ev.preventDefault(); this.featureMenu(ev, d.dataset.f); });
    });
    el.querySelectorAll("[data-tl]").forEach((b) => b.addEventListener("click", () => {
      const n = p.features.length; let r = p.rollback ?? n;
      r = { first: 0, prev: Math.max(0, r - 1), next: Math.min(n, r + 1), last: n }[b.dataset.tl];
      store.commit((pp) => { pp.rollback = r >= n ? null : r; });
    }));
  }

  featureMenu(ev, id) {
    const f = store.feature(id);
    const idx = store.project.features.indexOf(f);
    this.menu(ev, [
      ["編集", () => this.editFeature(id)],
      ["名前の変更", () => { const n = prompt("名前", f.name); if (n) store.commit((p) => { p.features[idx].name = n; }); }],
      [f.suppressed ? "抑制を解除" : "抑制（一時的に無効化）", () => store.commit((p) => { p.features[idx].suppressed = !f.suppressed; })],
      ["ここまで戻る（この前に挿入）", () => store.commit((p) => { p.rollback = idx; })],
      ...(f.type === "sketch" ? [["スケッチ平面を変更（オフセット）", () => this.sketchOffset(id)], ["スケッチを DXF 書き出し", () => this.exportSketchDXF(id)]] : []),
      ["削除", () => {
        const deps = store.project.features.filter((x) => x.sketch === id);
        if (deps.length && !confirm(`このスケッチは ${deps.map((d) => d.name).join(", ")} で使われています。削除しますか？`)) return;
        store.commit((p) => { p.features.splice(idx, 1); if (p.rollback != null && p.rollback > idx) p.rollback--; });
      }],
    ]);
  }

  sketchOffset(id) {
    const f = store.feature(id);
    const v = prompt("平面からのオフセット距離（法線方向, mm / 式も可）", f.plane?.offset ?? "0");
    if (v === null) return;
    store.commit((p) => { const s = p.features.find((x) => x.id === id); s.plane = { ...(s.plane || { type: "std", name: "XY" }), offset: v }; });
  }

  editFeature(id) {
    const f = store.feature(id);
    if (!f) return;
    if (f.type === "sketch") return this.enterSketch(id);
    if (f.type === "import") return this.toast("インポートは編集できません（右クリックで抑制/削除）");
    this.dialog.open(f.type, id);
  }

  menu(ev, items) {
    const m = document.getElementById("ctxmenu");
    m.innerHTML = "";
    for (const [label, fn] of items) {
      const b = document.createElement("button"); b.textContent = label;
      b.onclick = () => { m.classList.add("hidden"); fn(); };
      m.appendChild(b);
    }
    m.classList.remove("hidden");
    const w = 200, h = items.length * 30;
    m.style.left = Math.min(ev.clientX, innerWidth - w) + "px";
    m.style.top = Math.min(ev.clientY, innerHeight - h - 10) + "px";
    const close = () => { m.classList.add("hidden"); document.removeEventListener("mousedown", onDown); };
    const onDown = (e) => { if (!m.contains(e.target)) close(); };
    setTimeout(() => document.addEventListener("mousedown", onDown), 0);
  }

  bodyMenu(ev, id) {
    const m = this.meshes.find((x) => x.id === id);
    this.menu(ev, [
      ["名前の変更", () => this.renameBody(id)],
      ["色の変更", () => this.pickColor(id)],
      ["材料（密度）の設定", () => this.setMaterial(id)],
      ["積層（サンドイッチパネル）設定…", () => { const ids = this.selection.filter((x) => x.kind === "body").map((x) => x.bodyId); openLayupPanel(this, ids.includes(id) ? ids : [id]); }],
      [m.hidden ? "表示" : "非表示", () => this.toggleBody(id)],
      ["コンポーネントへ移動…", () => { const ids = this.selection.filter((s) => s.kind === "body").map((s) => s.bodyId); const list = ids.includes(id) ? ids : [id]; this.pickComponent(`${list.length} 個のボディを移動`, (to) => this.moveBodiesToComponent(list, to)); }],
      ["選択ボディから新規コンポーネント", () => { const ids = this.selection.filter((s) => s.kind === "body").map((s) => s.bodyId); this.newComponent(store.project.activeComponent || null, ids.includes(id) ? ids : [id]); }],
      ["このボディだけ表示", () => store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const b of this.meshes) p.bodyProps[b.id] = { ...(p.bodyProps[b.id] || {}), hidden: b.id !== id }; })],
      ["すべて表示", () => store.commit((p) => { for (const b of this.meshes) if (p.bodyProps?.[b.id]) p.bodyProps[b.id].hidden = false; })],
      ["STEP で書き出し", () => this.export3D("step", [id], m.name)],
      ["STL で書き出し", () => this.export3D("stl", [id], m.name)],
      ["削除", () => { const ids = this.selection.filter((s) => s.kind === "body").map((s) => s.bodyId); this.removeBodies(ids.includes(id) ? ids : [id]); }],
      ["この部品の図面", () => { this.selection = []; store.project.drawing = { ...(store.project.drawing || {}), mode: "each" }; this.setWorkspace("drawing"); }],
    ]);
  }

  // ボディの削除（Fusion の Delete と同じく「削除」の手順をタイムラインに追加 → 元に戻せる）
  removeBodies(ids) {
    if (!ids.length) return;
    store.commit((p) => {
      const at = p.rollback ?? p.features.length;
      p.features.splice(at, 0, { id: newId(), type: "remove", name: store.nameFor("remove"), bodies: ids });
      if (p.rollback != null) p.rollback = at + 1;
    });
    this.selection = [];
    this.toast(`${ids.length} 個のボディを削除しました（タイムラインに残ります。Ctrl+Z で元に戻せます）`);
  }

  setMaterial(id) {
    const cur = this.meshes.find((x) => x.id === id)?.material?.name || "";
    this.panel("材料の設定", `
      <label>材料</label><select id="mat-sel">${MATERIALS.map(([k, l]) => `<option value="${k}" ${k === cur ? "selected" : ""}>${l}</option>`).join("")}</select>
      <label>密度 g/cm³</label><input type="text" id="mat-d" value="${this.meshes.find((x) => x.id === id)?.material?.density ?? ""}" placeholder="材料から自動"/>`,
    () => {
      const k = document.getElementById("mat-sel").value;
      const d = parseFloat(document.getElementById("mat-d").value) || MATERIALS.find((m) => m[0] === k)[2];
      this.setBodyProp(id, { material: { name: k, density: d } });
    });
  }

  // ------------------------------------------------------------ generic panel
  panel(title, bodyHtml, onOk, { okLabel = "OK", wide = false, noCancel = false, foot = "", cls = "" } = {}) {
    if (this.dialog.isOpen) this.dialog.close();
    const el = document.getElementById("dialog");
    el.style.width = wide ? "460px" : "";
    el.className = cls;
    el.innerHTML = `<div class="dlg-head"><span>${title}</span><button class="x">×</button></div><div class="dlg-body">${bodyHtml}</div><div class="dlg-foot">${foot}${noCancel ? "" : '<button class="btn" data-c>キャンセル</button>'}<button class="btn ${foot ? "" : "primary"}" data-o>${okLabel}</button></div>`;
    el.classList.remove("hidden");
    const close = () => { el.classList.add("hidden"); el.classList.remove(...(cls ? cls.split(" ") : [])); el.style.width = ""; this.panelOpen = false; };
    this.panelOpen = true;
    el.querySelector(".x").onclick = close;
    const c = el.querySelector("[data-c]"); if (c) c.onclick = close;
    el.querySelector("[data-o]").onclick = async () => { const r = onOk ? await onOk() : true; if (r !== false) close(); };
    el.querySelectorAll("input,select,textarea").forEach((i) => i.addEventListener("keydown", (e) => e.stopPropagation()));
    return el;
  }

  // ------------------------------------------------------------ parameters
  openParams() {
    const params = JSON.parse(JSON.stringify(store.project.params || []));
    const render = () => {
      const ev = evaluateParams(params);
      return `<div class="full"><table class="grid"><tr><th>名前</th><th>式 / 値</th><th class="num">値</th><th>コメント</th><th></th></tr>
        ${ev.map((p, i) => `<tr><td><input data-i="${i}" data-k="name" value="${esc(p.name)}"/></td><td><input data-i="${i}" data-k="expr" value="${esc(p.expr)}"/></td><td class="num ${p.error ? "err" : ""}" title="${esc(p.error || "")}">${p.error ? "エラー" : +p.value.toFixed(4)}</td><td><input data-i="${i}" data-k="comment" value="${esc(p.comment || "")}"/></td><td><button class="btn" data-del="${i}" style="padding:0 6px">×</button></td></tr>`).join("")}
      </table></div>
      <div class="full"><button class="btn" id="p-add">＋ パラメータを追加</button></div>
      <div class="dlg-note">寸法欄には数値のほか、パラメータ名や式（例: 幅/2 - 厚さ）を入力できます。値を変えると全体が自動で更新されます。</div>`;
    };
    const el = this.panel("パラメータ", render(), () => {
      const names = params.map((p) => p.name.trim());
      if (names.some((n) => !/^[A-Za-z_぀-ヿ㐀-鿿][A-Za-z0-9_぀-ヿ㐀-鿿]*$/.test(n))) { this.toast("名前は文字で始めてください（記号・空白不可）", true); return false; }
      if (new Set(names).size !== names.length) { this.toast("同じ名前が重複しています", true); return false; }
      store.commit((p) => { p.params = params.map((q) => ({ name: q.name.trim(), expr: q.expr, comment: q.comment })); });
    }, { wide: true });
    const bind = () => {
      el.querySelectorAll("[data-k]").forEach((i) => {
        i.addEventListener("change", () => { params[+i.dataset.i][i.dataset.k] = i.value; el.querySelector(".dlg-body").innerHTML = render(); bind(); });
        i.addEventListener("keydown", (e) => e.stopPropagation());
      });
      el.querySelectorAll("[data-del]").forEach((b) => (b.onclick = () => { params.splice(+b.dataset.del, 1); el.querySelector(".dlg-body").innerHTML = render(); bind(); }));
      el.querySelector("#p-add").onclick = () => {
        let k = params.length + 1; while (params.some((p) => p.name === `P${k}`)) k++;
        params.push({ name: `P${k}`, expr: "100", comment: "" });
        el.querySelector(".dlg-body").innerHTML = render(); bind();
      };
    };
    bind();
  }

  // ------------------------------------------------------------ properties
  async openProps() {
    const ids = this.selection.filter((s) => s.bodyId).map((s) => s.bodyId);
    const r = await call("measure", { ids: [...new Set(ids)] });
    // 積層を設定したボディは、表皮・樹脂・コアから重量を計算
    r.total.mass = 0;
    for (const b of r.list) { const m = this.meshes.find((x) => x.id === b.id); if (m && m.layup) b.mass = computeLayup(m.layup, b).weight; r.total.mass += b.mass; }
    const f = (v, d = 1) => (+v).toLocaleString("ja-JP", { maximumFractionDigits: d });
    const rows = r.list.map((b) => `<tr><td>${esc(b.name)}</td><td class="num">${f(b.volume / 1e6, 3)}</td><td class="num">${f(b.area / 1e6, 3)}</td><td class="num">${f(b.mass, 2)}</td><td class="num">${f(b.bounds[1][0] - b.bounds[0][0])}×${f(b.bounds[1][1] - b.bounds[0][1])}×${f(b.bounds[1][2] - b.bounds[0][2])}</td></tr>`).join("");
    this.panel("物理プロパティ", `<div class="full" style="max-height:50vh;overflow:auto"><table class="grid"><tr><th>ボディ</th><th class="num">体積 L</th><th class="num">表面積 m²</th><th class="num">質量 kg</th><th class="num">外形 mm</th></tr>${rows}
      <tr><td><b>合計</b></td><td class="num"><b>${f(r.total.volume / 1e6, 3)}</b></td><td class="num"><b>${f(r.total.area / 1e6, 3)}</b></td><td class="num"><b>${f(r.total.mass, 2)}</b></td><td></td></tr></table></div>
      <div class="dlg-note">${ids.length ? "選択中のボディ" : "表示中の全ボディ"}。質量はボディの材料（右クリック →「材料（密度）の設定」）から計算します。積層を設定したボディは表皮・樹脂・コアから計算します。</div>`, null, { wide: true, noCancel: true, okLabel: "閉じる" });
  }

  openSection() {
    const box = this.viewer.sceneBox();
    const sec = this.section || { axis: "X", pos: 0, flip: false };
    const range = (ax) => { const k = { X: "x", Y: "y", Z: "z" }[ax]; return [box.min[k], box.max[k]]; };
    const mid = (ax) => { const [a, b] = range(ax); return (a + b) / 2; };
    if (!this.section) sec.pos = mid(sec.axis);
    this.section = sec;
    const el = this.panel("断面表示", `
      <label>切る方向</label><select id="sec-ax"><option value="X">X（幅方向で切る）</option><option value="Y">Y（奥行方向で切る）</option><option value="Z">Z（高さ方向で切る）</option></select>
      <label>位置</label><input type="range" id="sec-pos" step="any"/>
      <label></label><input type="text" id="sec-val"/>
      <label>反対側を表示</label><input type="checkbox" id="sec-flip"/>
      <div class="dlg-note">モデルを平面で切って中を確認します（表示だけで、形状は変わりません）。</div>`,
    () => { this.viewer.setSection(null); this.section = null; }, { okLabel: "断面表示を終了", noCancel: true });
    const ax = el.querySelector("#sec-ax"), pos = el.querySelector("#sec-pos"), val = el.querySelector("#sec-val"), flip = el.querySelector("#sec-flip");
    const sync = () => {
      const [a, b] = range(sec.axis);
      pos.min = a; pos.max = b; pos.value = sec.pos; val.value = (+sec.pos).toFixed(1);
      ax.value = sec.axis; flip.checked = sec.flip;
      this.viewer.setSection(sec);
    };
    ax.onchange = () => { sec.axis = ax.value; sec.pos = mid(sec.axis); sync(); };
    pos.oninput = () => { sec.pos = +pos.value; val.value = (+sec.pos).toFixed(1); this.viewer.setSection(sec); };
    val.onchange = () => { const v = parseFloat(val.value); if (isFinite(v)) { sec.pos = v; sync(); } };
    flip.onchange = () => { sec.flip = flip.checked; sync(); };
    el.querySelector(".x").onclick = () => { this.viewer.setSection(null); this.section = null; el.classList.add("hidden"); this.panelOpen = false; };
    sync();
  }

  // ---- ジョイント: 画面上で動かしてみる（再計算なしのアニメーション）
  animateJoint(d) {
    const ax = this.jointInfo[d.id];
    if (!ax) return this.toast("軸と動かす部品を選ぶと動かせます", true);
    const num = makeEvaluator(store.project.params || []);
    let v0, lo, hi;
    try { v0 = num(d.value); lo = num(d.min); hi = num(d.max); } catch (e) { return this.toast(e.message, true); }
    const objs = (d.bodies || []).map((id) => this.viewer.bodies.get(id)).filter(Boolean).flatMap((b) => [b.mesh, b.edges]);
    const p = new THREE.Vector3(...ax.p), dir = new THREE.Vector3(...ax.d).normalize();
    const T = performance.now(), dur = 2600;
    cancelAnimationFrame(this.animId);
    const step = () => {
      const t = ((performance.now() - T) % dur) / dur;
      const u = 0.5 - 0.5 * Math.cos(t * Math.PI * 2);
      const v = lo + (hi - lo) * u;
      const dv = v - v0;
      const m = new THREE.Matrix4();
      if (d.kind === "slider") m.makeTranslation(dir.x * dv, dir.y * dv, dir.z * dv);
      else m.makeTranslation(p.x, p.y, p.z).multiply(new THREE.Matrix4().makeRotationAxis(dir, (dv * Math.PI) / 180)).multiply(new THREE.Matrix4().makeTranslation(-p.x, -p.y, -p.z));
      for (const o of objs) { o.matrixAutoUpdate = false; o.matrix.copy(m); o.matrixWorldNeedsUpdate = true; }
      this.viewer.dirty = true;
      this.status(`動作確認中: ${d.kind === "slider" ? "移動" : "角度"} ${v.toFixed(1)}${d.kind === "slider" ? " mm" : "°"}（どこかをクリックで停止）`);
      if (performance.now() - T < dur * 2) this.animId = requestAnimationFrame(step);
      else stop();
    };
    const stop = () => {
      cancelAnimationFrame(this.animId);
      for (const o of objs) { o.matrix.identity(); o.matrixAutoUpdate = true; o.updateMatrix(); }
      this.viewer.dirty = true;
      this.status("準備完了");
      window.removeEventListener("pointerdown", stop, true);
    };
    window.addEventListener("pointerdown", stop, true);
    step();
  }

  // ---- ジョイント: 可動範囲を何点かに分けて干渉を調べる
  async jointSweepCheck(d) {
    const num = makeEvaluator(store.project.params || []);
    let lo, hi; try { lo = num(d.min); hi = num(d.max); } catch (e) { return this.toast(e.message, true); }
    const steps = 9, hits = [];
    const moving = new Set(d.bodies || []);
    for (let k = 0; k < steps; k++) {
      const v = lo + ((hi - lo) * k) / (steps - 1);
      this.busy(true, `干渉チェック中… ${k + 1}/${steps}`);
      await this.rebuild({ draft: { ...d, value: String(+v.toFixed(4)) }, editId: this.dialog.active?.editId });
      const list = await call("interference", { ids: [] });
      const rel = list.filter((x) => moving.has(x.a) !== moving.has(x.b));
      if (rel.length) hits.push({ v, rel });
    }
    this.busy(false);
    this.dialog.preview();
    const unit = d.kind === "slider" ? " mm" : "°";
    if (!hits.length) return this.toast(`可動範囲 ${lo}〜${hi}${unit} で干渉はありません ✓`);
    const lines = hits.map((h) => `${h.v.toFixed(1)}${unit}: ${h.rel.map((x) => `${x.an} × ${x.bn}`).join("、")}`);
    alert(`干渉する位置があります:\n\n${lines.join("\n")}`);
  }

  async checkInterference() {
    const ids = [...new Set(this.selection.filter((s) => s.bodyId).map((s) => s.bodyId))];
    this.busy(true, "干渉を調べています…");
    let list;
    try { list = await call("interference", { ids: ids.length > 1 ? ids : [] }); } catch (e) { this.toast(e.message, true); return; } finally { this.busy(false); }
    this.viewer.clearHighlight("sel");
    for (const x of list) { this.viewer.highlight({ kind: "body", bodyId: x.a }, "sel", 0xd23b3b); this.viewer.highlight({ kind: "body", bodyId: x.b }, "sel", 0xd23b3b); }
    const rows = list.map((x) => `<tr><td>${esc(x.an)}</td><td>${esc(x.bn)}</td><td class="num">${(x.volume / 1000).toFixed(2)}</td></tr>`).join("");
    this.panel("干渉チェック", list.length
      ? `<div class="full" style="max-height:45vh;overflow:auto"><table class="grid"><tr><th>部品 A</th><th>部品 B</th><th class="num">重なり cm³</th></tr>${rows}</table></div><div class="dlg-note">重なっている部品を赤く表示しています。</div>`
      : `<div class="full">重なっている部品はありません ✓</div>`, () => this.viewer.clearHighlight("sel"), { noCancel: true, okLabel: "閉じる", wide: true });
  }

  // ------------------------------------------------------------ measure
  beginMeasure() {
    this.exitModes();
    this.mode = "measure";
    this.mpts = [];
    this.status("計測: 2点をクリックしてください（頂点・エッジ・面）。Esc で終了。");
    this.refreshTools();
  }
  endMeasure() {
    this.mode = "idle";
    this.clearMeasure();
    this.status("準備完了");
    this.refreshTools();
  }
  clearMeasure() {
    if (this.mline) { this.viewer.helperGroup.remove(this.mline); this.mline = null; }
    if (this.mlabel) { this.mlabel.remove(); this.mlabel = null; }
    this.viewer.dirty = true;
  }
  snapVertex(ev, hit) {
    // 画面上で近い頂点（エッジの端点）にスナップ
    const r = this.viewer.canvas.getBoundingClientRect();
    const mx = ev.clientX - r.left, my = ev.clientY - r.top;
    let best = null, bd = 12;
    for (const m of this.meshes) {
      if (m.hidden) continue;
      for (const g of m.edgeGroups) {
        for (const k of [g.start, g.start + g.count - 1]) {
          const p = [m.lines[k * 3], m.lines[k * 3 + 1], m.lines[k * 3 + 2]];
          const [sx, sy] = this.viewer.toScreen(p);
          const d = Math.hypot(sx - mx, sy - my);
          if (d < bd) { bd = d; best = p; }
        }
      }
    }
    return best || (hit && hit.point);
  }
  measureClick(ev) {
    const hit = this.viewer.pick(ev, ["edge", "face"]);
    const p = this.snapVertex(ev, hit);
    if (!p) return;
    if (this.mpts.length >= 2) { this.mpts = []; this.clearMeasure(); }
    this.mpts.push(p);
    if (this.mpts.length === 2) {
      const [a, b] = this.mpts;
      const d = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
      const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...a), new THREE.Vector3(...b)]);
      this.mline = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xd23b3b, depthTest: false }));
      this.mline.renderOrder = 50;
      this.viewer.helperGroup.add(this.mline);
      const lab = document.createElement("div"); lab.className = "measure-label";
      const f = (v) => (+v.toFixed(3)).toString();
      lab.textContent = `距離 ${f(d)} mm（ΔX ${f(b[0] - a[0])} ΔY ${f(b[1] - a[1])} ΔZ ${f(b[2] - a[2])}）`;
      this.overlay.appendChild(lab);
      this.mlabel = lab; this.mmid = a.map((v, i) => (v + b[i]) / 2);
      this.positionMeasure();
      this.status(lab.textContent + "　— 次の2点をクリックで再計測");
    } else this.status(`1点目: (${p.map((v) => +v.toFixed(2)).join(", ")}) — 2点目をクリック`);
    this.viewer.dirty = true;
  }
  positionMeasure() {
    if (!this.mlabel) return;
    const [x, y] = this.viewer.toScreen(this.mmid);
    this.mlabel.style.left = x + "px"; this.mlabel.style.top = y + "px";
  }

  // ------------------------------------------------------------ sketch
  beginSketchCreate() {
    this.exitModes();
    document.getElementById("welcome").classList.add("hidden");
    this.mode = "pickPlane";
    this.viewer.cplaneFirst = true;
    this.viewer.showPlanes(true);
    this.showPlaneBar(true);
    this.status("スケッチ平面を選択: 原点平面（XY/XZ/YZ）またはボディの平らな面をクリック。Esc でキャンセル。");
  }
  // 基準平面をボタンでも選べるように（モデルに隠れていても・スマホでも一発で）
  showPlaneBar(on) {
    let bar = document.getElementById("planebar");
    if (!on) { if (bar) bar.remove(); return; }
    if (!bar) {
      bar = document.createElement("div"); bar.id = "planebar";
      bar.innerHTML = `<span class="pb-t">スケッチする平面:</span>` + [["XY", "床・水平"], ["XZ", "正面"], ["YZ", "側面"]].map(([k, l]) => `<button data-pl="${k}">${k}<span class="pb-l">（${l}）</span></button>`).join("") + `<span class="pb-or">または ボディの平らな面をクリック</span><button data-pl="">キャンセル</button>`;
      document.getElementById("viewport").appendChild(bar);
      bar.querySelectorAll("[data-pl]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); const k = b.dataset.pl; if (!k) return this.cancelPickPlane(); this.createSketchOn({ kind: "plane", name: k }); }));
    }
  }
  cancelPickPlane() { this.viewer.cplaneFirst = false; this.showPlaneBar(false); this.viewer.showPlanes(this.planesOn); this.viewer.clearHighlight("hover"); this.mode = "idle"; this.status("準備完了"); }

  async createSketchOn(hit) {
    let plane;
    if (hit.kind === "plane" && hit.frame) plane = { type: "cplane", ref: hit.name, offset: "0" };
    else if (hit.kind === "plane") plane = { type: "std", name: hit.name, offset: "0" };
    else {
      try {
        const fp = await call("facePlane", { bodyId: hit.bodyId, point: hit.point });
        plane = { type: "face", origin: fp.origin.map((v) => +v.toFixed(6)), xDir: fp.xDir, normal: fp.normal, offset: "0", ref: { body: hit.bodyId, point: hit.point.map((v) => +v.toFixed(4)) } };
      } catch (e) {
        if (hit.behindPlane) return this.createSketchOn(hit.behindPlane);
        this.toast("曲面にはスケッチを作れません。平らな面か、オレンジ色の基準平面をクリックしてください", true);
        return;
      }
    }
    this.cancelPickPlane();
    const id = newId();
    // 再計算はスケッチ画面に入ってから裏で行う（ここでは画面を止めない）
    store.commit((p) => {
      const at = p.rollback ?? p.features.length;
      p.features.splice(at, 0, { id, type: "sketch", name: store.nameFor("sketch"), plane, entities: [], ...(p.activeComponent ? { component: p.activeComponent } : {}) });
      if (p.rollback != null) p.rollback = at + 1;
    }, { silent: true });
    this.enterSketch(id);
  }

  async enterSketch(id) {
    this.exitModes();
    document.getElementById("welcome").classList.add("hidden");
    this.mode = "sketch";
    this.tab = "sketch";
    this.buildTabs();
    // すぐにスケッチ画面へ。スケッチより後の履歴を隠す再計算は裏で行う
    this.sketcher.start(id);
    this.renderTimeline();
    this.renderBrowser();
    this.rebuild({ uptoBefore: id });
  }

  finishSketch() {
    if (this.mode !== "sketch") return;
    const id = this.sketcher.featureId;
    this.sketcher.stop();
    this.mode = "idle";
    this.tab = "solid";
    this.buildTabs();
    this.status("準備完了");
    store.emit();
    const loops = this.sketchLoops(id);
    if (loops && loops.length) this.status(`スケッチを終了しました（閉じた輪郭 ${loops.length} 個）。「押し出し」で立体にできます。`);
    void id;
  }

  showSketchSelection() {
    const sk = this.sketcher;
    if (!sk.selected.size || sk.selected.size > 1) { if (this.panelOpen) document.getElementById("dialog").classList.add("hidden"); this.panelOpen = false; return; }
    const i = [...sk.selected][0];
    const e = sk.feature.entities[i];
    const keys = { line: [["x1", "始点 X"], ["y1", "始点 Y"], ["x2", "終点 X"], ["y2", "終点 Y"]], rect: [["x", "角 X"], ["y", "角 Y"], ["w", "幅"], ["h", "高さ"]], circle: [["cx", "中心 X"], ["cy", "中心 Y"], ["d", "直径"]], arc: [["x1", "始点 X"], ["y1", "始点 Y"], ["x2", "終点 X"], ["y2", "終点 Y"], ["xm", "通過点 X"], ["ym", "通過点 Y"]], point: [["x", "X"], ["y", "Y"]] }[e.type];
    const names = { line: "線", rect: "長方形", circle: "円", arc: "円弧", point: "点" };
    const el = this.panel(`${names[e.type]}の寸法`, keys.map(([k, l]) => `<label>${l}</label><input type="text" data-k="${k}" value="${esc(e[k])}"/>`).join("") +
      `<label>補助線</label><input type="checkbox" id="e-cons" ${e.construction ? "checked" : ""}/><div class="dlg-note">数値・パラメータ名・式が使えます。</div>`, () => {
      const patch = {};
      const num = makeEvaluator(store.project.params || []);
      for (const inp of el.querySelectorAll("[data-k]")) {
        const v = inp.value.trim();
        try { num(v); } catch (err) { this.toast(err.message, true); return false; }
        patch[inp.dataset.k] = /^-?\d+(\.\d+)?$/.test(v) ? parseFloat(v) : v;
      }
      patch.construction = el.querySelector("#e-cons").checked;
      sk.updateEntity(i, patch);
    }, { okLabel: "適用" });
  }

  exitModes() {
    if (this.mode === "sketch") { this.sketcher.stop(); this.tab = "solid"; }
    if (this.mode === "pickPlane") this.cancelPickPlane();
    if (this.mode === "measure") this.clearMeasure();
    if (this.dialog.isOpen) this.dialog.close(false);
    this.mode = "idle";
    this.buildTabs();
  }

  // ------------------------------------------------------------ command hooks
  onCommandStart(dlg) {
    void dlg;
    this.viewer.clearHighlight();
    this.updateSketchDisplay();
    // 平面を選ぶ欄があるときは原点の基準平面も表示して選べるように
    this.viewer.showPlanes(this.planesOn || this.dialog.selKinds().includes("plane"));
    this.status("ビューで対象を選択してください。値を変えるとプレビューが更新されます。Enter で OK、Esc でキャンセル。");
  }
  onCommandEnd() {
    this.clearMoveGizmo();
    this.clearHolePlacer(true);
    this.clearHoleDims();
    this.clearExtrudeHandle();
    this.viewer.showPlanes(this.planesOn);
    this.viewer.clearHighlight();
    this.selection = [];
    this.updateSketchDisplay();
    this.status("準備完了");
  }
  // スケッチを真上から見ていると押し出しが見えないので、立体が分かる向きに回す
  tiltForSketch(sketchId) {
    const f = store.feature(sketchId);
    if (!f) return;
    let fr;
    try { fr = this.frameOf(f, makeEvaluator(store.project.params || [])); } catch { return; }
    const v = this.viewer;
    const dir = v.camera.position.clone().sub(v.controls.target).normalize();
    const dn = dir.x * fr.normal[0] + dir.y * fr.normal[1] + dir.z * fr.normal[2];
    if (Math.abs(dn) > 0.9) {
      // 今見ている側のまま斜めに傾ける。なるべく上から見下ろす向きに（下から見上げると分かりにくい）
      const sg = Math.sign(dn) || 1;
      const n = fr.normal.map((c) => c * sg), x = fr.xDir, y = fr.yDir;
      let t = [0, 1, 2].map((i) => n[i] * 0.8 + x[i] * 0.45 - y[i] * 0.55);
      if (t[2] < -0.05) t = [0, 1, 2].map((i) => n[i] * 0.8 + x[i] * 0.45 + y[i] * 0.55);
      if (t[2] < -0.05 && Math.abs(n[2]) < 0.9) t[2] = 0.5;
      v.setView(t, [0, 0, 1]);
    }
  }

  highlightDraft(d) {
    this.viewer.clearHighlight("sel");
    this.clearHoleDims();
    this.updateExtrudeHandle(d);
    this.updateHolePlacer(d);
    this.updateMoveGizmo(d);
    if (d.type === "hole" && d.placement === "coords" && this.holeInfo && this.holeInfo[d.id]) this.drawHoleDims(this.holeInfo[d.id]);
    if (d.type === "hole" && d.placement === "coords" && d.face && d.body) { const g = this.viewer.faceGroupAt(d.body, d.face.slice(0, 3)); if (g) this.viewer.highlight({ kind: "face", bodyId: d.body, group: g }, "sel", 0x7fb2f0); }
    if (d.type === "extrude") {
      for (const it of d.items || []) {
        if (it.sketch) this.viewer.highlight({ kind: "profile", sketch: it.sketch, loop: it.loop }, "sel");
        else if (it.face) { const g = this.viewer.faceGroupAt(it.face.body, it.face.point); if (g) this.viewer.highlight({ kind: "face", bodyId: it.face.body, group: g }, "sel"); }
      }
      if (d.extent === "to" && d.to && d.toBody) { const g = this.viewer.faceGroupAt(d.toBody, d.to.slice(0, 3)); if (g) this.viewer.highlight({ kind: "face", bodyId: d.toBody, group: g }, "sel", 0x2e9e5b); }
      return;
    }
    if (d.profiles && d.sketch) for (const l of d.profiles) this.viewer.highlight({ kind: "profile", sketch: d.sketch, loop: l }, "sel");
  }

  // 押し出しの矢印と数値ボックス（Fusion と同じく、矢印をドラッグして距離を変え、数値はその場で入力）
  updateExtrudeHandle(d) {
    const h = this.exHandle;
    if (!d || d.type !== "extrude" || !(d.items || []).length || (d.extent && d.extent !== "dist") || !this.dialog.isOpen) { this.clearExtrudeHandle(); return; }
    // 1 つ目のプロファイル（面）の中心と向き
    const it = d.items[0];
    let base, n;
    if (it.face) { base = it.face.point; n = it.face.normal; }
    else {
      const f = store.feature(it.sketch); if (!f) return this.clearExtrudeHandle();
      const num = makeEvaluator(store.project.params || []);
      const fr = this.frameOf(f, num); const loops = this.sketchLoops(it.sketch) || []; const l = loops[it.loop];
      if (!l) return this.clearExtrudeHandle();
      const c = [(l.bbox.min[0] + l.bbox.max[0]) / 2, (l.bbox.min[1] + l.bbox.max[1]) / 2];
      base = [0, 1, 2].map((i) => fr.origin[i] + fr.xDir[i] * c[0] + fr.yDir[i] * c[1]); n = fr.normal;
    }
    const num = makeEvaluator(store.project.params || []);
    let dist = 0, so = 0; try { dist = num(d.distance); } catch { /* */ } try { so = d.start === "offset" ? num(d.startOffset) : 0; } catch { /* */ }
    const dir = d.direction || "one";
    const end = so + (dir === "reverse" ? -dist : dir === "symmetric" ? dist / 2 : dist);
    if (!h) {
      const grp = new THREE.Group();
      const mat = new THREE.MeshBasicMaterial({ color: 0x2f6fd0, depthTest: false });
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1, 10), mat); shaft.position.y = 0.5;
      const cone = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.4, 16), mat); cone.position.y = 1.2;
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffffff, depthTest: false }));
      for (const m of [shaft, cone, ball]) { m.renderOrder = 70; grp.add(m); }
      this.viewer.helperGroup.add(grp);
      const box = document.createElement("div"); box.className = "xbox";
      box.innerHTML = `<input type="text" inputmode="decimal" title="距離（Enter で OK）"/><span>mm</span>`;
      const inp = box.querySelector("input");
      inp.addEventListener("input", () => { const di = document.querySelector('#dialog input[data-k="distance"]'); if (di) { di.value = inp.value; di.dispatchEvent(new Event("input")); } });
      inp.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") this.dialog.ok(); if (e.key === "Escape") this.dialog.close(); });
      inp.addEventListener("focus", () => inp.select());
      this.overlay.appendChild(box);
      this.exHandle = { grp, box, inp };
    }
    const H = this.exHandle;
    Object.assign(H, { base, n, so, dir, end });
    if (document.activeElement !== H.inp) H.inp.value = d.distance;
    this.positionExtrudeHandle();
  }
  clearExtrudeHandle() {
    const h = this.exHandle; if (!h) return;
    this.viewer.helperGroup.remove(h.grp); h.grp.traverse((o) => o.geometry && o.geometry.dispose()); h.box.remove();
    this.exHandle = null; this.viewer.dirty = true;
  }
  positionExtrudeHandle() {
    const h = this.exHandle; if (!h) return;
    const wpp = this.viewer.worldPerPixel(), L = wpp * 60;
    const tip = h.base.map((v, i) => v + h.n[i] * h.end);
    const sg = h.end < 0 ? -1 : 1; // 矢印は押し出す向きへ
    h.grp.position.set(...tip);
    h.grp.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(...h.n.map((x) => x * sg)));
    h.grp.scale.setScalar(L);
    const [x, y] = this.viewer.toScreen(tip.map((v, i) => v + h.n[i] * sg * L * 1.5));
    // ダイアログに隠れるなら矢印の反対側に置く
    const dl = document.getElementById("dialog"), vr = this.viewer.canvas.getBoundingClientRect();
    let bx = x + 14; const bw = h.box.offsetWidth || 110;
    if (dl && !dl.classList.contains("hidden")) { const dr = dl.getBoundingClientRect(); const L = dr.left - vr.left, T = dr.top - vr.top, B = dr.bottom - vr.top; if (bx + bw > L && y > T - 20 && y < B + 20) bx = Math.min(x - 14 - bw, L - bw - 8); }
    h.box.style.left = Math.max(4, bx) + "px"; h.box.style.top = y - 12 + "px";
    h.tipScreen = this.viewer.toScreen(tip); h.headScreen = this.viewer.toScreen(tip.map((v, i) => v + h.n[i] * sg * L * 1.4));
    this.viewer.dirty = true;
  }
  // ------------------------------------------------------------ 移動の矢印（Fusion の移動マニピュレータ）
  // 選んだボディの中心に X（赤）・Y（緑）・Z（青）の矢印と回転リング。ドラッグで動かし、数値はダイアログで正確に
  moveTargets(d) { return (d.bodies || []).map((id) => (d.copy ? `B_${d.id}_${id}` : id)); }
  updateMoveGizmo(d) {
    if (!d || d.type !== "move" || !(d.bodies || []).length || !this.dialog.isOpen) { this.clearMoveGizmo(); return; }
    if (this.mvDrag) return; // ドラッグ中は動かさない
    const box = new THREE.Box3();
    for (const id of this.moveTargets(d)) { const b = this.viewer.bodies.get(id); if (b && b.mesh.visible) box.expandByObject(b.mesh); }
    if (box.isEmpty()) { this.clearMoveGizmo(); return; }
    const c = box.getCenter(new THREE.Vector3());
    if (!this.mvGizmo) {
      const grp = new THREE.Group(); const parts = [];
      const AX = [["X", 0xd23b3b, [1, 0, 0]], ["Y", 0x2e9e5b, [0, 1, 0]], ["Z", 0x2f6fd0, [0, 0, 1]]];
      for (const [name, col, dir] of AX) {
        const g = new THREE.Group(); const mat = new THREE.MeshBasicMaterial({ color: col, depthTest: false, transparent: true });
        const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1, 8), mat); sh.position.y = 0.5;
        const co = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.26, 16), mat); co.position.y = 1.08;
        for (const m of [sh, co]) { m.renderOrder = 80; g.add(m); }
        g.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(...dir));
        grp.add(g); parts.push({ kind: "axis", name, dir, obj: g, mat });
      }
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xe8a23a, depthTest: false, transparent: true });
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.02, 8, 64), ringMat); ring.renderOrder = 80; grp.add(ring);
      parts.push({ kind: "ring", obj: ring, mat: ringMat });
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffffff, depthTest: false, transparent: true })); ball.renderOrder = 81; grp.add(ball);
      this.viewer.helperGroup.add(grp);
      const lab = document.createElement("div"); lab.className = "hcur"; lab.style.display = "none"; this.overlay.appendChild(lab);
      this.mvGizmo = { grp, parts, lab };
    }
    const G = this.mvGizmo;
    const first = !G.center;
    G.center = [c.x, c.y, c.z];
    // 矢印がダイアログに隠れるときは、ビューを左へずらす
    if (first) {
      const dl = document.getElementById("dialog"), v = this.viewer;
      if (dl && !dl.classList.contains("hidden")) {
        const dr = dl.getBoundingClientRect(), cr = v.canvas.getBoundingClientRect();
        const [sx] = v.toScreen(G.center), limit = dr.left - cr.left - 240;
        if (sx > limit && limit > 120) {
          const right = new THREE.Vector3().setFromMatrixColumn(v.camera.matrixWorld, 0);
          const dv = right.multiplyScalar((sx - limit) * v.worldPerPixel());
          v.controls.target.add(dv); v.camera.position.add(dv); v.controls.update(); v.dirty = true;
        }
      }
    }
    const ax = { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }[d.rotAxis || "Z"];
    G.parts.find((p) => p.kind === "ring").obj.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(...ax));
    G.rotAxis = ax;
    this.positionMoveGizmo();
  }
  clearMoveGizmo() {
    const G = this.mvGizmo; if (!G) return;
    this.viewer.helperGroup.remove(G.grp); G.grp.traverse((o) => o.geometry && o.geometry.dispose()); G.lab.remove();
    this.mvGizmo = null; this.viewer.dirty = true;
  }
  positionMoveGizmo() {
    const G = this.mvGizmo; if (!G || !G.center) return;
    const s = this.viewer.worldPerPixel() * 75;
    const off = this.mvDrag ? this.mvDrag.offset : [0, 0, 0];
    G.grp.position.set(G.center[0] + off[0], G.center[1] + off[1], G.center[2] + off[2]);
    G.grp.scale.setScalar(s);
    G.grp.updateMatrixWorld(true);
    // 画面上の位置（つかめるか判定用）
    const P = (v) => this.viewer.toScreen(v);
    const o = [G.grp.position.x, G.grp.position.y, G.grp.position.z];
    G.scr = { o: P(o) };
    for (const p of G.parts) if (p.kind === "axis") { p.a = P(o.map((v, i) => v + p.dir[i] * s * 0.25)); p.b = P(o.map((v, i) => v + p.dir[i] * s * 1.2)); }
    const ring = G.parts.find((p) => p.kind === "ring"); const ax = G.rotAxis || [0, 0, 1];
    const u = new THREE.Vector3(...(Math.abs(ax[2]) > 0.9 ? [1, 0, 0] : [0, 0, 1])).cross(new THREE.Vector3(...ax)).normalize(), w = new THREE.Vector3(...ax).cross(u);
    ring.pts = []; for (let k = 0; k < 48; k++) { const t = k / 48 * Math.PI * 2; ring.pts.push(P(o.map((v, i) => v + (u.getComponent(i) * Math.cos(t) + w.getComponent(i) * Math.sin(t)) * s * 0.75))); }
    this.viewer.dirty = true;
  }
  hitMoveGizmo(e) {
    const G = this.mvGizmo; if (!G || !G.scr) return null;
    const r = this.viewer.canvas.getBoundingClientRect(); const p = [e.clientX - r.left, e.clientY - r.top];
    const segD = (a, b) => { const ab = [b[0] - a[0], b[1] - a[1]], L2 = ab[0] * ab[0] + ab[1] * ab[1] || 1; const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * ab[0] + (p[1] - a[1]) * ab[1]) / L2)); return Math.hypot(p[0] - a[0] - ab[0] * t, p[1] - a[1] - ab[1] * t); };
    const tol = e.pointerType === "touch" ? 22 : 10;
    let best = null, bd = tol;
    for (const q of G.parts) {
      if (q.kind === "axis") { const d = segD(q.a, q.b); if (d < bd) { bd = d; best = q; } }
      else { for (let k = 0; k < q.pts.length; k++) { const d = segD(q.pts[k], q.pts[(k + 1) % q.pts.length]); if (d < bd) { bd = d; best = q; } } }
    }
    return best;
  }
  // 視線と軸の最近点（軸方向の位置）
  axisParam(e, origin, dir) {
    const v = this.viewer; v.raycaster.setFromCamera(v.ndc(e), v.camera);
    const o = v.raycaster.ray.origin, dd = v.raycaster.ray.direction;
    const w = [o.x - origin[0], o.y - origin[1], o.z - origin[2]], d = [dd.x, dd.y, dd.z];
    const dn = d[0] * dir[0] + d[1] * dir[1] + d[2] * dir[2], wn = w[0] * dir[0] + w[1] * dir[1] + w[2] * dir[2], wd = w[0] * d[0] + w[1] * d[1] + w[2] * d[2];
    const den = 1 - dn * dn; if (den < 1e-6) return null;
    return (wn - wd * dn) / den;
  }
  ringAngle(e, origin, axis) {
    const v = this.viewer; v.raycaster.setFromCamera(v.ndc(e), v.camera);
    const pl = new THREE.Plane().setFromNormalAndCoplanarPoint(new THREE.Vector3(...axis), new THREE.Vector3(...origin));
    const q = new THREE.Vector3(); if (!v.raycaster.ray.intersectPlane(pl, q)) return null;
    const u = new THREE.Vector3(...(Math.abs(axis[2]) > 0.9 ? [1, 0, 0] : [0, 0, 1])).cross(new THREE.Vector3(...axis)).normalize(), w = new THREE.Vector3(...axis).cross(u);
    const rel = q.sub(new THREE.Vector3(...origin));
    return Math.atan2(rel.dot(w), rel.dot(u)) * 180 / Math.PI;
  }
  startMoveDrag(e, part) {
    const d = this.dialog.active.draft, G = this.mvGizmo;
    const num = makeEvaluator(store.project.params || []);
    const T0 = (d.translate || ["0", "0", "0"]).map((x) => { try { return num(x); } catch { return 0; } });
    let a0 = 0; try { a0 = num(d.angle || "0"); } catch { /* */ }
    const D = { part, T0, a0, offset: [0, 0, 0], rot: 0, origin: [...G.center] };
    if (part.kind === "axis") D.t0 = this.axisParam(e, D.origin, part.dir);
    else {
      D.r0 = this.ringAngle(e, D.origin, G.rotAxis);
      // 回転の中心: まだ回していなければ、選んだボディの中心（移動前の位置）に
      if (!a0) { d.center = D.origin.map((v, i) => String(+(v - T0[i]).toFixed(3))); }
    }
    this.mvDrag = D;
  }
  dragMove(e) {
    const D = this.mvDrag, G = this.mvGizmo; if (!D || !G) return;
    const raw = this.viewer.worldPerPixel() * 6, p10 = Math.pow(10, Math.floor(Math.log10(raw)));
    let step = [1, 2, 5, 10].map((m) => m * p10).find((s) => s >= raw) || raw; if (e.shiftKey) step /= 10;
    const f = (x) => (+x.toFixed(3)).toString();
    if (D.part.kind === "axis") {
      const t = this.axisParam(e, D.origin, D.part.dir); if (t === null || D.t0 === null) return;
      const dt = Math.round((t - D.t0) / step) * step;
      D.offset = D.part.dir.map((x) => x * dt);
      D.text = `${D.part.name} ${dt >= 0 ? "+" : ""}${f(dt)} mm（移動 ${f(D.T0[{ X: 0, Y: 1, Z: 2 }[D.part.name]] + dt)}）`;
      D.value = dt;
      // 見た目だけ先に動かす（離したときに計算し直す）
      for (const id of this.moveTargets(this.dialog.active.draft)) { const b = this.viewer.bodies.get(id); if (b) { b.mesh.position.set(...D.offset); b.edges.position.set(...D.offset); } }
    } else {
      const a = this.ringAngle(e, D.origin, G.rotAxis); if (a === null || D.r0 === null) return;
      let da = a - D.r0; while (da > 180) da -= 360; while (da < -180) da += 360;
      const st = e.shiftKey ? 1 : 5; da = Math.round(da / st) * st;
      D.rot = da; D.value = da;
      D.text = `回転 ${da >= 0 ? "+" : ""}${da}°（合計 ${f(D.a0 + da)}°）`;
      const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(...G.rotAxis), da * Math.PI / 180);
      const o = new THREE.Vector3(...D.origin);
      for (const id of this.moveTargets(this.dialog.active.draft)) {
        const b = this.viewer.bodies.get(id); if (!b) continue;
        for (const m of [b.mesh, b.edges]) { m.quaternion.copy(q); m.position.copy(o.clone().sub(o.clone().applyQuaternion(q))); }
      }
    }
    G.lab.style.display = ""; G.lab.innerHTML = `<b>${D.text}</b>`;
    const [x, y] = this.viewer.toScreen(this.mvGizmo.center.map((v, i) => v + D.offset[i])); G.lab.style.left = x + 24 + "px"; G.lab.style.top = y + 24 + "px";
    this.positionMoveGizmo();
  }
  endMoveDrag() {
    const D = this.mvDrag; if (!D) return;
    this.mvDrag = null;
    const d = this.dialog.active && this.dialog.active.draft; if (!d) return;
    const f = (x) => String(+x.toFixed(3));
    if (D.part.kind === "axis") { const i = { X: 0, Y: 1, Z: 2 }[D.part.name]; const t = [...(d.translate || ["0", "0", "0"])]; t[i] = f(D.T0[i] + (D.value || 0)); d.translate = t; }
    else d.angle = f(D.a0 + (D.rot || 0));
    if (this.mvGizmo) this.mvGizmo.lab.style.display = "none";
    this.dialog.touched = true;
    this.dialog.render(); this.dialog.preview();
  }

  // 矢印をつかんでいるか（画面上で矢印の線分から 14px 以内）
  hitExtrudeHandle(e) {
    const h = this.exHandle; if (!h || !h.tipScreen) return false;
    const r = this.viewer.canvas.getBoundingClientRect();
    const p = [e.clientX - r.left, e.clientY - r.top], a = h.tipScreen, b = h.headScreen;
    const ab = [b[0] - a[0], b[1] - a[1]], L2 = ab[0] * ab[0] + ab[1] * ab[1] || 1;
    const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * ab[0] + (p[1] - a[1]) * ab[1]) / L2));
    return Math.hypot(p[0] - a[0] - ab[0] * t, p[1] - a[1] - ab[1] * t) < (e.pointerType === "touch" ? 26 : 14);
  }
  dragExtrudeHandle(e) {
    const h = this.exHandle; if (!h) return;
    const v = this.viewer; v.raycaster.setFromCamera(v.ndc(e), v.camera);
    const o = v.raycaster.ray.origin, dd = v.raycaster.ray.direction;
    const w = [o.x - h.base[0], o.y - h.base[1], o.z - h.base[2]], n = h.n, d = [dd.x, dd.y, dd.z];
    const dn = d[0] * n[0] + d[1] * n[1] + d[2] * n[2], wn = w[0] * n[0] + w[1] * n[1] + w[2] * n[2], wd = w[0] * d[0] + w[1] * d[1] + w[2] * d[2];
    const den = 1 - dn * dn; if (den < 1e-6) return; // 矢印が視線と平行
    const t = (wn - wd * dn) / den - h.so;
    let val = h.dir === "reverse" ? -t : h.dir === "symmetric" ? 2 * t : t;
    // 画面の大きさに合った刻み（Shift で細かく）
    const raw = v.worldPerPixel() * 4, p10 = Math.pow(10, Math.floor(Math.log10(raw)));
    let step = [1, 2, 5, 10].map((m) => m * p10).find((s) => s >= raw) || raw;
    if (e.shiftKey) step /= 10;
    val = Math.round(val / step) * step;
    const txt = String(+val.toFixed(4));
    const di = document.querySelector('#dialog input[data-k="distance"]');
    if (di && di.value !== txt) { di.value = txt; di.dispatchEvent(new Event("input")); h.inp.value = txt; }
  }

  // ------------------------------------------------------------ 穴の配置（カーソルに穴が付いてきて、角・中点・中心に吸着、座標を表示）
  holePlacing() {
    const a = this.dialog.active;
    return !!(a && a.type === "hole" && (a.draft.placement || "single") === "coords" && a.draft.face && this.hp && this.hp.info && !["face", "ref1", "ref2"].includes(a.activeSel));
  }
  async updateHolePlacer(d) {
    if (!d || d.type !== "hole" || (d.placement || "single") !== "coords" || !d.face || !d.body || !this.dialog.isOpen) { this.clearHolePlacer(true); return; }
    const key = JSON.stringify([d.body, d.face, d.ref, d.ref1, d.ref2]);
    if (this.hp && this.hp.key === key) return;
    this.hp = { key, info: null };
    try {
      const info = await call("faceSnap", { bodyId: d.body, point: d.face.slice(0, 3), normal: d.face.slice(3, 6), ref: d.ref || "corner", ref1: d.ref1, ref2: d.ref2 });
      if (this.hp && this.hp.key === key) {
        this.hp.info = info;
        // 面を正面から見て、ダイアログに隠れないよう左側に収める（座標が見たままになる）
        const faceKey = JSON.stringify([d.body, d.face]);
        if (this.hpLookedAt !== faceKey) { this.hpLookedAt = faceKey; this.lookAtFace(info); }
        this.status("穴の位置: 面の上でクリック（角・辺の中点・中心に吸着）。置いた穴はドラッグで移動。数値は右の表で正確に"); }
    } catch (e) { this.hp = null; }
  }
  lookAtFace(I) {
    const v = this.viewer, [mu, mv, Mu, Mv] = I.box;
    const P = (a, b) => new THREE.Vector3(...[0, 1, 2].map((i) => I.u[i] * a + I.v[i] * b + I.n[i] * I.h));
    v.setView(I.n, I.v, false);
    const box = new THREE.Box3(); for (const [a, b] of [[mu, mv], [Mu, mv], [Mu, Mv], [mu, Mv]]) box.expandByPoint(P(a, b));
    box.expandByScalar(Math.max(Mu - mu, Mv - mv) * 0.08);
    v.fit(box);
    // ダイアログに隠れない左側の範囲に、面がちょうど収まる大きさで
    const dl = document.getElementById("dialog");
    const cw = v.canvas.clientWidth, ch = v.canvas.clientHeight;
    let w = 0; if (dl && !dl.classList.contains("hidden")) { const dw = dl.getBoundingClientRect().width; if (dw < cw * 0.7) w = dw + 20; }
    const bw = (Mu - mu) * 1.15 + 1, bh = (Mv - mv) * 1.15 + 1;
    const wpp = Math.max(bw / Math.max(100, cw - w - 40), bh / Math.max(100, ch - 90));
    v.camera.zoom = (v.camera.top - v.camera.bottom) / (wpp * ch); v.camera.updateProjectionMatrix();
    const c = P((mu + Mu) / 2, (mv + Mv) / 2);
    const back = v.camera.position.clone().sub(v.controls.target);
    const du = new THREE.Vector3(...I.u).multiplyScalar(wpp * w / 2);
    v.controls.target.copy(c).add(du); v.camera.position.copy(v.controls.target).add(back); v.controls.update();
    v.dirty = true;
  }
  clearHolePlacer(all) {
    if (this.hpGroup) { this.viewer.helperGroup.remove(this.hpGroup); this.hpGroup.traverse((o) => o.geometry && o.geometry.dispose()); this.hpGroup = null; this.viewer.dirty = true; }
    if (this.hpLabel) { this.hpLabel.remove(); this.hpLabel = null; }
    if (all) this.hp = null;
  }
  hpRowFromC(C) {
    const I = this.hp.info;
    if (I.refs && I.refs.length === 2) return I.refs.map((r) => (C[0] - r.Q[0]) * r.N[0] + (C[1] - r.Q[1]) * r.N[1]);
    return [C[0] - I.corner[0], C[1] - I.corner[1]];
  }
  hpCFromRow(row) {
    const I = this.hp.info;
    if (I.refs && I.refs.length === 2) {
      const [a, c] = I.refs; const det = a.N[0] * c.N[1] - a.N[1] * c.N[0]; if (Math.abs(det) < 1e-9) return null;
      const r1 = row[0] + a.N[0] * a.Q[0] + a.N[1] * a.Q[1], r2 = row[1] + c.N[0] * c.Q[0] + c.N[1] * c.Q[1];
      return [(r1 * c.N[1] - a.N[1] * r2) / det, (a.N[0] * r2 - r1 * c.N[0]) / det];
    }
    return [I.corner[0] + row[0], I.corner[1] + row[1]];
  }
  hp3(C) { const I = this.hp.info; return [0, 1, 2].map((i) => I.u[i] * C[0] + I.v[i] * C[1] + I.n[i] * I.h); }
  hpCursor(e) {
    const I = this.hp.info, v = this.viewer;
    v.raycaster.setFromCamera(v.ndc(e), v.camera);
    const pl = new THREE.Plane(new THREE.Vector3(...I.n), -I.h);
    const p = new THREE.Vector3(); if (!v.raycaster.ray.intersectPlane(pl, p)) return null;
    return [p.x * I.u[0] + p.y * I.u[1] + p.z * I.u[2], p.x * I.v[0] + p.y * I.v[1] + p.z * I.v[2]];
  }
  // 吸着: 点（角・中点・中心・ほかの穴・基準）→ 縦横のそろい（ガイド線）→ 刻み
  hpSnap(C, skipRow, fine) {
    const I = this.hp.info, wpp = this.viewer.worldPerPixel();
    const num = makeEvaluator(store.project.params || []);
    const d = this.dialog.active.draft;
    const cands = [...I.pts, { p: I.corner, k: I.refs ? "辺の交点" : "基準 (0,0)" }];
    (d.pos || []).forEach((r, i) => { if (i === skipRow) return; try { const c = this.hpCFromRow([num(r[0]), num(r[1])]); if (c) cands.push({ p: c, k: `穴 ${i + 1}` }); } catch { /* */ } });
    if (!fine) {
      let best = null, bd = wpp * 12;
      for (const c of cands) { const dd = Math.hypot(c.p[0] - C[0], c.p[1] - C[1]); if (dd < bd) { bd = dd; best = c; } }
      if (best) return { C: [...best.p], kind: best.k, guides: [] };
    }
    const out = [...C]; const guides = []; let su = false, sv = false;
    if (!fine) {
      let bu = wpp * 7, bv = wpp * 7, gu = null, gv = null;
      for (const c of cands) { const du = Math.abs(c.p[0] - C[0]), dv = Math.abs(c.p[1] - C[1]); if (du < bu) { bu = du; gu = c; } if (dv < bv) { bv = dv; gv = c; } }
      if (gu) { out[0] = gu.p[0]; su = true; guides.push({ axis: 0, at: gu.p, k: gu.k }); }
      if (gv) { out[1] = gv.p[1]; sv = true; guides.push({ axis: 1, at: gv.p, k: gv.k }); }
    }
    // 残りは画面の大きさに合った刻み（基準からの座標で）。Shift で細かく
    const raw = wpp * 3.5, p10 = Math.pow(10, Math.floor(Math.log10(raw)));
    let step = [1, 2, 5, 10].map((m) => m * p10).find((s) => s >= raw) || raw; if (fine) step /= 10;
    if (!I.refs) {
      if (!su) out[0] = I.corner[0] + Math.round((out[0] - I.corner[0]) / step) * step;
      if (!sv) out[1] = I.corner[1] + Math.round((out[1] - I.corner[1]) / step) * step;
    }
    return { C: out, kind: guides.length ? guides.map((g) => `${g.k}に${g.axis === 0 ? "縦" : "横"}をそろえる`).join("・") : "", guides };
  }
  hpDraw(snap) {
    const I = this.hp.info;
    this.clearHolePlacer(false);
    const grp = new THREE.Group(); const C3 = this.hp3(snap.C);
    const num = makeEvaluator(store.project.params || []);
    let r = 5; try { r = num(this.dialog.active.draft.d) / 2; } catch { /* */ }
    const ring = []; for (let i = 0; i <= 48; i++) { const t = i / 48 * Math.PI * 2; ring.push(new THREE.Vector3(...this.hp3([snap.C[0] + r * Math.cos(t), snap.C[1] + r * Math.sin(t)]))); }
    const col = snap.kind ? 0xe8732a : 0x2f6fd0;
    const add = (pts, mat) => { const l = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat); l.renderOrder = 65; if (mat.isLineDashedMaterial) l.computeLineDistances(); grp.add(l); };
    add(ring, new THREE.LineBasicMaterial({ color: col, depthTest: false, transparent: true }));
    const wpp = this.viewer.worldPerPixel(), s = wpp * 8;
    add([new THREE.Vector3(...this.hp3([snap.C[0] - s, snap.C[1]])), new THREE.Vector3(...this.hp3([snap.C[0] + s, snap.C[1]]))], new THREE.LineBasicMaterial({ color: col, depthTest: false, transparent: true }));
    add([new THREE.Vector3(...this.hp3([snap.C[0], snap.C[1] - s])), new THREE.Vector3(...this.hp3([snap.C[0], snap.C[1] + s]))], new THREE.LineBasicMaterial({ color: col, depthTest: false, transparent: true }));
    // ガイド線（縦・横のそろい）
    const [mu, mv, Mu, Mv] = I.box; const ext = (Mu - mu + Mv - mv) * 0.15 + wpp * 30;
    for (const g of snap.guides) {
      const a = g.axis === 0 ? [g.at[0], Math.min(mv, snap.C[1], g.at[1]) - ext] : [Math.min(mu, snap.C[0], g.at[0]) - ext, g.at[1]];
      const b = g.axis === 0 ? [g.at[0], Math.max(Mv, snap.C[1], g.at[1]) + ext] : [Math.max(Mu, snap.C[0], g.at[0]) + ext, g.at[1]];
      add([new THREE.Vector3(...this.hp3(a)), new THREE.Vector3(...this.hp3(b))], new THREE.LineDashedMaterial({ color: 0xe8732a, dashSize: wpp * 6, gapSize: wpp * 4, depthTest: false, transparent: true }));
    }
    this.viewer.helperGroup.add(grp); this.hpGroup = grp; this.viewer.dirty = true;
    const row = this.hpRowFromC(snap.C);
    const f = (x) => (+x.toFixed(2)).toString();
    const lab = document.createElement("div"); lab.className = "hcur";
    lab.innerHTML = `${I.refs ? "辺1" : "X"} <b>${f(row[0])}</b>　${I.refs ? "辺2" : "Y"} <b>${f(row[1])}</b>${snap.kind ? `<span>${esc(snap.kind)}</span>` : ""}`;
    const [x, y] = this.viewer.toScreen(C3); lab.style.left = x + 16 + "px"; lab.style.top = y + 14 + "px";
    this.overlay.appendChild(lab); this.hpLabel = lab;
    return row;
  }
  hpMove(e) {
    if (!this.holePlacing()) { if (this.hpGroup) this.clearHolePlacer(false); return; }
    const C = this.hpCursor(e); if (!C) return;
    const I = this.hp.info, [mu, mv, Mu, Mv] = I.box, m = (Mu - mu + Mv - mv) * 0.1;
    if (C[0] < mu - m || C[0] > Mu + m || C[1] < mv - m || C[1] > Mv + m) { this.clearHolePlacer(false); return; }
    const snap = this.hpSnap(C, this.hpDragRow ?? -1, e.shiftKey);
    const row = this.hpDraw(snap);
    if (this.hpDragRow !== undefined && this.hpDragRow !== null) this.hpSetRow(this.hpDragRow, row, false);
    return row;
  }
  hpSetRow(i, row, render = true) {
    const d = this.dialog.active.draft;
    const rows = (d.pos || []).map((r) => [...r]);
    const txt = row.map((x) => String(+x.toFixed(3)));
    if (i >= rows.length) rows.push(txt); else rows[i] = txt;
    d.pos = rows.filter((r) => r[0] !== "" || r[1] !== "");
    if (render) this.dialog.render();
    else { const ins = document.querySelectorAll(`#dialog [data-pt="${i}"]`); if (ins.length === 2) { ins[0].value = txt[0]; ins[1].value = txt[1]; } }
    this.dialog.preview();
  }
  hpClick(e) {
    const row = this.hpMove(e); if (!row) return false;
    const d = this.dialog.active.draft;
    // クリックするたびに穴を 1 つ追加（空の行があればそこへ）
    const rows = d.pos || []; const empty = rows.findIndex((r) => r[0] === "" && r[1] === "");
    const i = empty >= 0 ? empty : rows.length;
    this.hpSetRow(i, row);
    return true;
  }
  // 置いた穴の中心の近く（画面で 12px 以内）なら、その穴をドラッグで動かす
  hpRowAt(e) {
    if (!this.holePlacing()) return -1;
    const d = this.dialog.active.draft, num = makeEvaluator(store.project.params || []);
    const r = this.viewer.canvas.getBoundingClientRect(); const px = [e.clientX - r.left, e.clientY - r.top];
    let best = -1, bd = e.pointerType === "touch" ? 24 : 12;
    (d.pos || []).forEach((row, i) => { try { const c = this.hpCFromRow([num(row[0]), num(row[1])]); const s = this.viewer.toScreen(this.hp3(c)); const dd = Math.hypot(s[0] - px[0], s[1] - px[1]); if (dd < bd) { bd = dd; best = i; } } catch { /* */ } });
    return best;
  }

  // 穴の寸法線（基準から穴の中心までの X・Y）を画面に表示
  drawHoleDims(info) {
    const grp = new THREE.Group(); grp.renderOrder = 60;
    const mat = new THREE.LineBasicMaterial({ color: 0x2f6fd0, depthTest: false, transparent: true });
    const seg = (a, b, m = mat) => { const l = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...a), new THREE.Vector3(...b)]), m); l.renderOrder = 60; grp.add(l); };
    const wpp = this.viewer.worldPerPixel();
    const cross = (c, s, m) => { for (const ax of [info.u, info.v]) seg(c.map((x, i) => x - ax[i] * s), c.map((x, i) => x + ax[i] * s), m); };
    this.holeDimLabels = [];
    const lab = (at, text, cls, row, col) => {
      const el = document.createElement("div"); el.className = "hdim" + (cls ? " " + cls : ""); el.textContent = text;
      if (row !== undefined) { el.dataset.row = row; el.dataset.col = col; el.title = "クリックで数値を変更"; el.addEventListener("click", (e) => { e.stopPropagation(); const inp = document.querySelector(`#dialog [data-pt="${row}"][data-c="${col}"]`); if (inp) inp.focus(); }); }
      this.overlay.appendChild(el); this.holeDimLabels.push({ el, at });
    };
    if (info.corner) { cross(info.corner, wpp * 10, new THREE.LineBasicMaterial({ color: 0xd07a20, depthTest: false, transparent: true })); lab(info.corner.map((x, i) => x - info.u[i] * wpp * 18 - info.v[i] * wpp * 12), info.ref === "origin" ? "原点 (0,0)" : "基準 (0,0)", "corner"); }
    for (const c of info.centers) cross(c, wpp * 6);
    const fmt = (v) => (+(+v).toFixed(3)).toString();
    for (const d of info.dims) {
      if (Math.hypot(d.a[0] - d.b[0], d.a[1] - d.b[1], d.a[2] - d.b[2]) < 1e-9) { lab(d.b, fmt(d.value), "", d.row, d.col); continue; }
      seg(d.a, d.b);
      lab(d.a.map((x, i) => (x + d.b[i]) / 2), (d.col === 0 ? (info.ref === "edges" ? "辺1 " : "X ") : (info.ref === "edges" ? "辺2 " : "Y ")) + fmt(d.value), "", d.row, d.col);
    }
    this.viewer.helperGroup.add(grp); this.holeDimGroup = grp;
    this.positionHoleDims(); this.viewer.dirty = true;
  }
  clearHoleDims() {
    if (this.holeDimGroup) { this.viewer.helperGroup.remove(this.holeDimGroup); this.holeDimGroup.traverse((o) => o.geometry && o.geometry.dispose()); this.holeDimGroup = null; }
    for (const l of this.holeDimLabels || []) l.el.remove();
    this.holeDimLabels = [];
  }
  positionHoleDims() {
    for (const l of this.holeDimLabels || []) { const [x, y] = this.viewer.toScreen(l.at); l.el.style.left = x + "px"; l.el.style.top = y + "px"; }
  }
  focusHoleDim(row, col) {
    for (const l of this.holeDimLabels || []) l.el.classList.toggle("on", l.el.dataset.row === String(row) && l.el.dataset.col === String(col));
  }

  // 平面のピック結果 → 平面の座標系（原点平面・構築平面）
  planeFrame(hit) {
    if (!hit || hit.kind !== "plane") return null;
    if (hit.frame) return hit.frame;
    return sketchPlaneFrame({ type: "std", name: hit.name });
  }

  reapplyHighlights() {
    this.viewer.clearHighlight("sel");
    if (this.dialog.isOpen) {
      const d = this.dialog.active.draft;
      this.highlightDraft(d);
      return;
    }
    for (const s of this.selection) {
      if (s.kind === "edge" || s.kind === "face") {
        // メッシュ再生成後はグループを点から探し直す
        const m = this.meshes.find((x) => x.id === s.bodyId);
        if (!m) continue;
        this.viewer.highlight(s, "sel");
      } else this.viewer.highlight(s, "sel");
    }
  }

  // ------------------------------------------------------------ viewport events
  bindViewport() {
    const c = this.viewer.canvas;
    let down = null;
    // タッチ: 長押し = 右クリックメニュー、ダブルタップ = ボディ選択、2本指以上はビュー操作のみ
    let longTimer = 0, longFired = false, touches = 0, lastTap = { t: 0, x: 0, y: 0 };
    c.addEventListener("pointerdown", (e) => {
      if (e.pointerType === "touch") {
        touches++;
        if (touches > 1) { clearTimeout(longTimer); down = null; return; }
        longFired = false;
        const ev = { clientX: e.clientX, clientY: e.clientY, button: 2, shiftKey: false, ctrlKey: false };
        longTimer = setTimeout(() => { if (down && touches === 1) { longFired = true; down = null; this.onViewContext(ev); } }, 550);
      }
      down = { x: e.clientX, y: e.clientY, b: e.button, touch: e.pointerType === "touch" };
      if (this.mode === "sketch" && e.button === 0 && e.pointerType !== "touch") this.sketcher.onDown(e);
    });
    const endTouch = (e) => { if (e.pointerType === "touch") { touches = Math.max(0, touches - 1); clearTimeout(longTimer); } };
    c.addEventListener("pointercancel", (e) => { endTouch(e); down = null; });
    c.addEventListener("pointermove", (e) => {
      if (down && down.touch && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 10) clearTimeout(longTimer);
    });
    c.addEventListener("pointerup", (e) => {
      endTouch(e);
      if (!down || longFired) { down = null; return; }
      const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y) > (down.touch ? 10 : 4);
      const btn = down.b, touch = down.touch; down = null;
      if (this.mode === "sketch" && btn === 0 && !touch) { this.sketcher.onUp(e, moved); return; }
      if (moved) return;
      if (touch) {
        const now = performance.now();
        const dbl = now - lastTap.t < 320 && Math.hypot(e.clientX - lastTap.x, e.clientY - lastTap.y) < 24;
        lastTap = { t: dbl ? 0 : now, x: e.clientX, y: e.clientY };
        if (dbl && this.mode === "idle" && !this.dialog.isOpen) {
          const hit = this.viewer.pick(e, ["body"]);
          if (hit) { this.selection = [{ kind: "body", bodyId: hit.bodyId }]; this.reapplyHighlights(); this.renderBrowser(); }
          return;
        }
      }
      if (btn === 0) this.onViewClick(e);
      if (btn === 2) this.onViewContext(e);
    });
    c.addEventListener("contextmenu", (e) => e.preventDefault());
    c.addEventListener("dblclick", (e) => {
      if (this.mode !== "idle" || this.dialog.isOpen) return;
      const hit = this.viewer.pick(e, ["body"]);
      if (hit) { this.selection = [{ kind: "body", bodyId: hit.bodyId }]; this.reapplyHighlights(); this.renderBrowser(); }
    });
    let raf = 0;
    c.addEventListener("pointermove", (e) => {
      if (raf) return;
      raf = requestAnimationFrame(() => { raf = 0; this.onViewMove(e); });
    });
    this.viewer.onRender = () => { if (this.mode === "sketch") this.sketcher.positionLabels(); this.positionMeasure(); this.positionHoleDims(); };
    this.viewer.onBeforeRender = () => { this.positionExtrudeHandle(); if (!this.mvDrag) this.positionMoveGizmo(); };
    // 移動の矢印・回転リングのドラッグ
    const vpMv = document.getElementById("viewport");
    vpMv.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || !this.mvGizmo) return;
      const part = this.hitMoveGizmo(e); if (!part) return;
      e.stopImmediatePropagation(); e.preventDefault();
      this.viewer.controls.enabled = false; this.startMoveDrag(e, part);
      try { c.setPointerCapture(e.pointerId); } catch { /* */ }
    }, { capture: true });
    vpMv.addEventListener("pointermove", (e) => {
      if (this.mvDrag) { e.stopImmediatePropagation(); this.dragMove(e); return; }
      if (this.mvGizmo && !e.buttons) { const h = this.hitMoveGizmo(e); for (const p of this.mvGizmo.parts) p.mat.opacity = p === h ? 1 : 0.8; c.style.cursor = h ? "grab" : ""; this.viewer.dirty = true; }
    }, { capture: true });
    const endMv = (e) => { if (!this.mvDrag) return; e.stopImmediatePropagation(); this.viewer.controls.enabled = true; try { c.releasePointerCapture(e.pointerId); } catch { /* */ } this.endMoveDrag(); };
    vpMv.addEventListener("pointerup", endMv, { capture: true });
    vpMv.addEventListener("pointercancel", endMv, { capture: true });
    // 穴の配置: 置いた穴のドラッグ・カーソルに付いてくる表示（寸法ラベルの上からでもつかめるようビュー全体で受ける）
    const vpEl = document.getElementById("viewport");
    vpEl.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const i = this.hpRowAt(e); if (i < 0) return;
      e.stopImmediatePropagation(); e.preventDefault();
      this.hpDragRow = i; this.hpDragMoved = false; this.viewer.controls.enabled = false;
      try { c.setPointerCapture(e.pointerId); } catch { /* */ }
    }, { capture: true });
    vpEl.addEventListener("pointermove", (e) => {
      if (this.hpDragRow !== undefined && this.hpDragRow !== null) { e.stopImmediatePropagation(); this.hpDragMoved = true; this.hpMove(e); return; }
      if (this.hp && !e.buttons) { this.hpMove(e); c.style.cursor = this.hpRowAt(e) >= 0 ? "move" : this.holePlacing() ? "crosshair" : ""; }
    }, { capture: true });
    const endHp = (e) => { if (this.hpDragRow === undefined || this.hpDragRow === null) return; e.stopImmediatePropagation(); this.hpDragRow = null; this.viewer.controls.enabled = true; this.dialog.render(); try { c.releasePointerCapture(e.pointerId); } catch { /* */ } };
    vpEl.addEventListener("pointerup", endHp, { capture: true });
    vpEl.addEventListener("pointercancel", endHp, { capture: true });
    c.addEventListener("pointerleave", () => { if (this.mode === "sketch") this.sketcher.clearSmart(); if (this.hpGroup && (this.hpDragRow === undefined || this.hpDragRow === null)) this.clearHolePlacer(false); });
    // 押し出しの矢印のドラッグ（視点の回転より先に受け取る）
    let exDrag = false;
    c.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || !this.exHandle || !this.hitExtrudeHandle(e)) return;
      e.stopImmediatePropagation(); e.preventDefault();
      exDrag = true; this.viewer.controls.enabled = false;
      try { c.setPointerCapture(e.pointerId); } catch { /* */ }
    }, { capture: true });
    c.addEventListener("pointermove", (e) => { if (exDrag) { e.stopImmediatePropagation(); this.dragExtrudeHandle(e); } else if (this.exHandle) c.style.cursor = this.hitExtrudeHandle(e) ? "grab" : ""; }, { capture: true });
    const endEx = (e) => { if (!exDrag) return; exDrag = false; this.viewer.controls.enabled = true; e.stopImmediatePropagation(); try { c.releasePointerCapture(e.pointerId); } catch { /* */ } };
    c.addEventListener("pointerup", endEx, { capture: true });
    c.addEventListener("pointercancel", endEx, { capture: true });
  }

  currentKinds() {
    if (this.mode === "pickPlane") return ["plane", "face"];
    if (this.mode === "measure") return ["edge", "face"];
    if (this.dialog.isOpen) return this.dialog.selKinds();
    return ["edge", "face", "profile"];
  }

  onViewMove(e) {
    if (this.mode === "sketch") { if (!e.buttons || (e.buttons & 1)) this.sketcher.onMove(e); return; }
    if (e.buttons) return;
    const kinds = this.currentKinds();
    this.viewer.clearHighlight("hover");
    if (!kinds.length) return;
    const hit = this.viewer.pick(e, kinds);
    if (hit) this.viewer.highlight(hit, "hover");
    if (this.mode === "pickPlane") this.status(hit ? (hit.kind === "plane" ? `${PLANE_LABEL[hit.name] || hit.name} にスケッチ（クリック）` : `${this.meshes.find((m) => m.id === hit.bodyId)?.name || "ボディ"} の面にスケッチ（クリック）`) : "スケッチ平面を選択: 基準平面（XY/XZ/YZ）またはボディの平らな面をクリック。Esc でキャンセル。");
  }

  onViewClick(e) {
    document.getElementById("ctxmenu").classList.add("hidden");
    if (this.mode === "sketch") return this.sketcher.onClick(e);
    if (this.mode === "measure") return this.measureClick(e);
    const kinds = this.currentKinds();
    const hit = kinds.length ? this.viewer.pick(e, kinds) : null;
    if (this.mode === "pickPlane") { if (hit) this.createSketchOn(hit); return; }
    if (this.holePlacing()) { this.hpClick(e); return; }
    if (this.dialog.isOpen) { if (hit) this.dialog.onPick(hit); return; }
    // 通常選択
    if (!e.shiftKey && !e.ctrlKey) this.selection = [];
    if (hit) {
      const k = this.selection.findIndex((s) => s.kind === hit.kind && (hit.kind === "profile" ? s.sketch === hit.sketch && s.loop === hit.loop : s.bodyId === hit.bodyId && s.group === hit.group));
      if (k >= 0) this.selection.splice(k, 1); else this.selection.push(hit);
    }
    this.reapplyHighlights();
    this.renderBrowser();
    const s = this.selection;
    if (s.length) this.status(`${s.length} 個選択中（${[...new Set(s.map((x) => ({ edge: "エッジ", face: "面", body: "ボディ", profile: "プロファイル" }[x.kind])))].join("・")}）— ${s.some((x) => x.kind === "profile" || x.kind === "face") ? "E で押し出し、" : ""}右クリックでメニュー、Shift で追加選択`);
  }

  onViewContext(e) {
    if (this.mode === "sketch") {
      return this.menu(e, [["スケッチを終了", () => this.finishSketch()], ["線", () => this.sketcher.setTool("line")], ["長方形", () => this.sketcher.setTool("rect")], ["円", () => this.sketcher.setTool("circle")], ["選択", () => this.sketcher.setTool("select")]]);
    }
    if (this.dialog.isOpen) return this.menu(e, [["OK", () => this.dialog.ok()], ["キャンセル", () => this.dialog.close()]]);
    const hit = this.viewer.pick(e, ["edge", "face"]);
    if (hit && !this.selection.some((s) => s.group === hit.group && s.bodyId === hit.bodyId)) { this.selection = [hit]; this.reapplyHighlights(); }
    const s = this.selection;
    const items = [];
    if (s.some((x) => x.kind === "edge")) items.push(["フィレット", () => { this.preselect = s; this.dialog.open("fillet"); this.preselect = null; }], ["面取り", () => { this.preselect = s; this.dialog.open("chamfer"); this.preselect = null; }]);
    const face = s.find((x) => x.kind === "face");
    if (face) {
      items.push(["この面にスケッチを作成", () => this.createSketchOn(face)]);
      items.push(["この面を DXF 書き出し（加工用外形）", () => this.exportFaceDXF(face)]);
    }
    const bid = s[0]?.bodyId;
    if (bid) {
      items.push(["ボディ: 移動/コピー", () => { this.preselect = s; this.dialog.open("move"); this.preselect = null; }]);
      items.push(["ボディ: その他…", () => this.bodyMenu(e, bid)]);
    }
    items.push(["スケッチを作成", () => this.beginSketchCreate()], ["押し出し", () => this.dialog.open("extrude")], ["全体表示", () => this.viewer.fit()]);
    this.menu(e, items);
  }

  bindNav() {
    document.querySelectorAll("#navbar [data-nav]").forEach((b) => b.addEventListener("click", () => {
      const k = b.dataset.nav;
      if (k === "home") this.viewer.home();
      if (k === "fit") this.viewer.fit();
      if (k === "grid") { this.viewer.setGrid(!this.viewer.showGrid); b.classList.toggle("on", this.viewer.showGrid); }
      if (k === "edges") { this.viewer.setEdges(!this.viewer.showEdges); b.classList.toggle("on", this.viewer.showEdges); }
    }));
    document.querySelector("[data-nav=grid]").classList.add("on");
    document.querySelector("[data-nav=edges]").classList.add("on");
  }

  bindKeys() {
    window.addEventListener("keydown", (e) => {
      const typing = ["INPUT", "TEXTAREA", "SELECT"].includes(e.target.tagName);
      const ctrl = e.ctrlKey || e.metaKey;
      if (ctrl && e.key.toLowerCase() === "s") { e.preventDefault(); return this.saveDoc(); }
      if (ctrl && e.key.toLowerCase() === "o") { e.preventDefault(); return this.openDoc(); }
      if (ctrl && e.key.toLowerCase() === "n") { e.preventDefault(); return this.newDoc(); }
      if (typing) return;
      if (ctrl && e.key.toLowerCase() === "z") { e.preventDefault(); return this.undo(); }
      if (ctrl && (e.key.toLowerCase() === "y" || (e.shiftKey && e.key.toLowerCase() === "z"))) { e.preventDefault(); return this.redo(); }
      if (this.sketcher.onKey(e)) { e.preventDefault(); return; }
      if (e.key === "Escape") {
        if (this.dialog.isOpen) return this.dialog.close();
        if (this.panelOpen) { document.getElementById("dialog").classList.add("hidden"); this.panelOpen = false; return; }
        if (this.mode === "pickPlane") return this.cancelPickPlane();
        if (this.mode === "measure") return this.endMeasure();
        this.selection = []; this.reapplyHighlights(); this.renderBrowser();
        return;
      }
      if (e.key === "Enter" && this.dialog.isOpen) return this.dialog.ok();
      if (e.key === "F1") { e.preventDefault(); return this.openHelp(); }
      if (ctrl) return;
      const k = e.key.toLowerCase();
      if ((e.key === "Delete" || e.key === "Backspace") && this.mode === "idle" && !this.dialog.isOpen && this.selection.length) {
        const ids = [...new Set(this.selection.filter((s) => s.kind === "body").map((s) => s.bodyId))];
        if (ids.length) { e.preventDefault(); return this.removeBodies(ids); }
        return this.toast("ボディを消すときは、ボディをダブルクリック（またはツリーで選択）してから Delete");
      }
      if (k === "i" && this.mode === "idle" && !this.dialog.isOpen) return this.runTool("measure");
      if (e.key === "/" && this.mode === "idle" && !this.dialog.isOpen) { e.preventDefault(); return this.cmdline.open(); }
      if (this.mode === "sketch") { if (k === "e" && !e.shiftKey && !e.altKey) this.runTool("extrude"); return; }
      if (k === "e") this.runTool("extrude");
      else if (k === "f" && this.selection.some((s) => s.kind === "edge")) { this.preselect = this.selection; this.dialog.open("fillet"); this.preselect = null; }
      else if (k === "f") this.viewer.fit();
      else if (k === "m") { this.preselect = this.selection; this.dialog.open("move"); this.preselect = null; }
      else if (k === "s" && !this.dialog.isOpen) this.beginSketchCreate();
      else if (k === "h" && !e.shiftKey) this.runTool("hole");
      else if (k === "q") this.runTool("presspull");
      else if (k === "j") this.runTool("joint");
    });
  }

  undo() { if (this.mode === "sketch") { store.undo(); return; } if (this.dialog.isOpen) this.dialog.close(false); store.undo(); }
  redo() { store.redo(); }

  setWorkspace(ws) {
    document.querySelectorAll(".ws").forEach((b) => b.classList.toggle("active", b.dataset.ws === ws));
    if (ws === "drawing") {
      if (!this.meshes.length) { this.toast("先に 3D モデルを作成してください", true); document.querySelector(".ws[data-ws=design]").classList.add("active"); document.querySelector(".ws[data-ws=drawing]").classList.remove("active"); return; }
      this.exitModes();
      document.getElementById("topbar").querySelector(".tb-tools").classList.add("hidden");
      document.getElementById("tabs").classList.add("hidden");
      this.drawing.open();
    } else {
      document.getElementById("topbar").querySelector(".tb-tools").classList.remove("hidden");
      document.getElementById("tabs").classList.remove("hidden");
      this.drawing.close();
    }
  }

  // ------------------------------------------------------------ exports
  openExport3D() {
    const ids = [...new Set(this.selection.filter((s) => s.bodyId).map((s) => s.bodyId))];
    this.panel("3D 書き出し", `
      <label>形式</label><select id="x-fmt">
        <option value="step">STEP (.step) — CAD間の受け渡し（推奨）</option>
        <option value="stl">STL (.stl) — 3Dプリンタ</option>
        <option value="obj">OBJ (.obj) — CG/ビジュアライズ</option>
        <option value="glb">glTF バイナリ (.glb) — Web/AR</option>
        <option value="brep">BREP (.brep) — OpenCascade/FreeCAD</option>
      </select>
      <label>対象</label><select id="x-ids"><option value="all">表示中の全ボディ</option>${ids.length ? `<option value="sel" selected>選択中のボディ (${ids.length})</option>` : ""}</select>
      <div class="dlg-note">STEP にはボディ名と色が含まれます（Fusion・SolidWorks・FreeCAD 等で開けます）。</div>`,
    async () => {
      const fmt = document.getElementById("x-fmt").value;
      const which = document.getElementById("x-ids").value === "sel" ? ids : [];
      await this.export3D(fmt, which);
    }, { okLabel: "書き出し" });
  }

  async export3D(fmt, ids = [], name) {
    const base = (name || store.project.name || "model").replace(/[\\/:*?"<>|]/g, "_");
    this.busy(true, "書き出し中…");
    try {
      if (fmt === "obj") download(await exportOBJ(this.viewer), `${base}.obj`, "text/plain");
      else if (fmt === "glb") download(await exportGLB(this.viewer), `${base}.glb`, "model/gltf-binary");
      else {
        let buf = await call("export", { ids, format: fmt });
        if (fmt === "step") buf = stepUnicode(buf);
        download(new Blob([buf]), `${base}.${fmt}`);
      }
      this.toast("書き出しました");
    } catch (e) { this.toast("書き出し失敗: " + e.message, true); }
    finally { this.busy(false); }
  }

  openExportDXF() {
    const sketches = store.project.features.filter((f) => f.type === "sketch");
    const face = this.selection.find((s) => s.kind === "face");
    this.panel("DXF 書き出し", `
      <label>対象</label><select id="d-src">
        ${face ? `<option value="face">選択中の面の外形（CNC・レーザー加工用）</option>` : ""}
        ${sketches.map((s) => `<option value="${s.id}">スケッチ: ${esc(s.name)}</option>`).join("")}
        <option value="drawing">図面（三面図）→ 図面ワークスペースへ</option>
      </select>
      <div class="dlg-note">面の外形: ボディの平らな面を選択してから実行すると、その面の輪郭（穴を含む）を原寸 1:1 で書き出します。</div>`,
    () => {
      const v = document.getElementById("d-src").value;
      if (v === "face") return this.exportFaceDXF(face);
      if (v === "drawing") return this.setWorkspace("drawing");
      return this.exportSketchDXF(v);
    }, { okLabel: "書き出し" });
  }

  exportSketchDXF(id) {
    const f = store.feature(id);
    const num = makeEvaluator(store.project.params || []);
    const out = [], cons = [];
    for (const raw of f.entities) {
      const e = resolveEntity(raw, num);
      const list = raw.construction ? cons : out;
      if (e.type === "line") list.push({ t: "line", a: [e.x1, e.y1], b: [e.x2, e.y2] });
      if (e.type === "rect") { const p = [[e.x, e.y], [e.x + e.w, e.y], [e.x + e.w, e.y + e.h], [e.x, e.y + e.h]]; for (let k = 0; k < 4; k++) list.push({ t: "line", a: p[k], b: p[(k + 1) % 4] }); }
      if (e.type === "circle") list.push({ t: "arc", c: [e.cx, e.cy], r: Math.abs(e.d) / 2, s: 0, d: Math.PI * 2 });
      if (e.type === "arc") {
        const pts = [[e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym]];
        const c = arc3(pts[0], pts[1], pts[2]);
        if (c) list.push({ t: "arc", c: [c.cx, c.cy], r: c.r, s: c.t0, d: c.sweep });
      }
    }
    const dxf = sheetToDXF({ w: 0, h: 0, layers: { SKETCH: { prims: out }, CONSTRUCTION: { prims: cons } }, texts: [] });
    download(dxf, `${f.name}.dxf`, "application/dxf");
    this.toast("DXF を書き出しました（原寸 1:1, mm）");
  }

  async exportFaceDXF(face) {
    try {
      const r = await call("faceOutline", { bodyId: face.bodyId, point: face.point });
      const bb = primsBBox(r.prims);
      const prims = transformPrims(r.prims, 1, -bb.min[0], -bb.min[1]); // 左下を原点 (0,0) に
      const body = this.meshes.find((m) => m.id === face.bodyId);
      const dxf = sheetToDXF({ w: 0, h: 0, layers: { OUTLINE: { prims } }, texts: [] });
      download(dxf, `${body?.name || "face"}_外形.dxf`, "application/dxf");
      this.toast("面の外形を DXF で書き出しました（原寸 1:1, mm）");
    } catch (e) { this.toast(e.message, true); }
  }

  openAbout() {
    this.panel("このソフトについて", `<div class="full" style="font-size:12px;line-height:1.7">
      <b>GDC GOOD DESIGN CAD</b> バージョン 0.14.0<br>ブラウザで動くパラメトリック 3D CAD（無料・オフライン動作）<br><br>
      形状エンジン: OpenCascade Technology（LGPL-2.1, Open CASCADE Exception）/ replicad（MIT）<br>
      表示: three.js（MIT）/ PDF: jsPDF・svg2pdf.js（MIT）/ フォント: Noto Sans JP（SIL OFL 1.1）<br>
      各ライセンスの全文は同梱の「THIRD_PARTY_LICENSES.txt」をご覧ください。<br>
      作成したデータは外部に送信されません。</div>`, null, { noCancel: true, okLabel: "閉じる" });
  }

  // ------------------------------------------------------------ help
  openHelp() {
    this.panel("操作ガイド", `<div class="full" style="font-size:12px;line-height:1.7">
      <b>マウス</b><br>左ドラッグ: 回転 / 右・中ドラッグ: 移動 / ホイール: ズーム / 左クリック: 選択（Shift で追加）/ ダブルクリック: ボディ選択 / 右クリック: メニュー<br>
      <b>基本の流れ</b><br>① スケッチ作成（S）→ 平面か面をクリック → 線(L)・長方形(R)・円(C) を描く（数値を打って Enter で寸法指定）→ スケッチを終了<br>
      ② 押し出し（E）→ プロファイルをクリック → 距離を入力 → OK<br>
      ③ 寸法の変更: 下のタイムラインのアイコンをダブルクリック。パラメータ（f(x)）を使うと複数の寸法を一括変更できます。<br>
      <b>アセンブリ（コンポーネント）</b><br>「新規コンポーネント」で部品のグループを作成。○ をクリックしたコンポーネントがアクティブになり、新しいボディはその中に入ります。ボディはツリー上でドラッグして移動、右クリックで移動・書き出し・図面・削除。STEP のアセンブリ構成も階層のまま読み込みます。<br>
      <b>拘束（スケッチ）</b><br>線を選択して「拘束」のボタン（水平/垂直・平行・直交・等長・固定・寸法 D）。長さラベルに値や式を入れると駆動寸法になり、パラメータで形が変わります。<br>
      <b>図面の書き込み</b><br>図面画面の「書き込み」で寸法・注記・部品番号を追加。<br>
      <b>積層・材料集計</b><br>ボディを右クリック →「積層（サンドイッチパネル）設定」、検査 →「材料集計」。<br>
      <b>スケッチのコツ</b><br>クリック→クリック、または押したままドラッグで描けます。線が交差・はみ出していても、囲まれた部分は自動でプロファイルになります（青く塗られた部分）。スケッチ中の視点移動は右ドラッグ、回転は右上のキューブ。<br>
      <b>ショートカット</b><br>Ctrl+Z 元に戻す / Ctrl+Y やり直し / Ctrl+S 保存 / S スケッチ / E 押し出し / H 穴 / Q プレス/プル / F 全体表示（エッジ選択中はフィレット）/ M 移動 / Esc キャンセル<br>スケッチ中: L 線 / R 長方形 / C 円 / A 円弧 / P 多角形 / F フィレット / O オフセット / T トリム / S 選択<br>
      <b>書き出し</b><br>3D: STEP・STL・OBJ・GLB・BREP / 2D: DXF（スケッチ・面の外形・図面）・PDF・SVG
      </div>`, null, { wide: true, noCancel: true, okLabel: "閉じる" });
  }
}

function arc3(a, b, m) {
  const ax = a[0], ay = a[1], bx = b[0], by = b[1], mx = m[0], my = m[1];
  const d = 2 * (ax * (my - by) + mx * (by - ay) + bx * (ay - my));
  if (Math.abs(d) < 1e-12) return null;
  const ux = ((ax * ax + ay * ay) * (my - by) + (mx * mx + my * my) * (by - ay) + (bx * bx + by * by) * (ay - my)) / d;
  const uy = ((ax * ax + ay * ay) * (bx - mx) + (mx * mx + my * my) * (ax - bx) + (bx * bx + by * by) * (mx - ax)) / d;
  const r = Math.hypot(ax - ux, ay - uy);
  const t0 = Math.atan2(ay - uy, ax - ux), tm = Math.atan2(my - uy, mx - ux), t1 = Math.atan2(by - uy, bx - ux);
  const n2 = (t) => { while (t < 0) t += 2 * Math.PI; return t; };
  const ccw = n2(tm - t0) < n2(t1 - t0);
  return { cx: ux, cy: uy, r, t0, sweep: ccw ? n2(t1 - t0) : -n2(t0 - t1) };
}

async function hashBuf(buf) {
  const h = await crypto.subtle.digest("SHA-1", buf);
  return [...new Uint8Array(h)].slice(0, 10).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function b64(buf) {
  const u = new Uint8Array(buf); let s = "";
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
}
function unb64(s) { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; }

// STEP の日本語名を ISO 10303-21 の \X2\ 形式に変換（他CADでの文字化け防止）
function stepUnicode(buf) {
  const t = new TextDecoder().decode(buf);
  return t.replace(/[^\x00-\x7f]+/g, (run) => "\\X2\\" + [...run].map((c) => {
    const cp = c.codePointAt(0);
    if (cp > 0xffff) { const h = Math.floor((cp - 0x10000) / 0x400) + 0xd800, l = ((cp - 0x10000) % 0x400) + 0xdc00; return h.toString(16).toUpperCase() + l.toString(16).toUpperCase(); }
    return cp.toString(16).toUpperCase().padStart(4, "0");
  }).join("") + "\\X0\\");
}

// STEP のアセンブリ構成（親子関係）: 末端部品ごとに親アセンブリを返す
function stepAssemblyTree(text, n) {
  const ents = new Map(); const order = [];
  const re = /#(\d+)\s*=\s*([A-Z_0-9]+)\s*\(([\s\S]*?)\)\s*;\s*(?=#\d+\s*=|ENDSEC)/g;
  let m;
  while ((m = re.exec(text))) { ents.set(+m[1], { type: m[2], args: m[3] }); if (m[2] === "NEXT_ASSEMBLY_USAGE_OCCURRENCE") order.push(+m[1]); }
  if (!order.length) return null;
  const refs = (a) => [...a.matchAll(/#(\d+)/g)].map((x) => +x[1]);
  const dec = (s) => fixMojibake(s.replace(/\\X2\\([0-9A-F]+)\\X0\\/g, (_, h) => h.match(/.{4}/g).map((c) => String.fromCharCode(parseInt(c, 16))).join("")));
  const nameOf = (pd) => {
    const a = ents.get(pd); if (!a) return ""; const f = ents.get(refs(a.args)[0]); if (!f) return ""; const pr = ents.get(refs(f.args)[0]); if (!pr) return "";
    const nm = pr.args.match(/^\s*'((?:[^']|'')*)'/); return nm ? dec(nm[1]) : "";
  };
  const rel = order.map((id) => { const r = refs(ents.get(id).args); return { parent: r[0], child: r[1] }; });
  const parents = new Set(rel.map((r) => r.parent));
  const parentOf = new Map(); for (const r of rel) if (!parentOf.has(r.child)) parentOf.set(r.child, r.parent);
  const leaves = rel.filter((r) => !parents.has(r.child));
  if (leaves.length !== n) return null;
  const nodes = [...parents].map((pd) => ({ key: pd, name: nameOf(pd), parent: parentOf.has(pd) ? parentOf.get(pd) : null }));
  return { nodes, leafParent: leaves.map((r) => r.parent) };
}

// UTF-8 のバイト列が Latin-1 として二重に符号化された文字列を復元
function fixMojibake(s) {
  if (!s || ![...s].every((c) => c.charCodeAt(0) < 256) || !/[\u0080-\u00ff]/.test(s)) return s;
  try { return new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from([...s].map((c) => c.charCodeAt(0)))); } catch { return s; }
}

// STEP 内の部品名: アセンブリ構成（NEXT_ASSEMBLY_USAGE_OCCURRENCE）の順に末端部品の PRODUCT 名を拾う
export function stepSolidNames(text, n) {
  const dec = (s) => s
    .replace(/\\X2\\([0-9A-F]+)\\X0\\/g, (_, h) => h.match(/.{4}/g).map((c) => String.fromCharCode(parseInt(c, 16))).join(""))
    .replace(/\\X\\([0-9A-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
  const ents = new Map();
  const order = [];
  const re = /#(\d+)\s*=\s*([A-Z_0-9]+)\s*\(([\s\S]*?)\)\s*;\s*(?=#\d+\s*=|ENDSEC)/g;
  let m;
  while ((m = re.exec(text))) { ents.set(+m[1], { type: m[2], args: m[3] }); if (m[2] === "NEXT_ASSEMBLY_USAGE_OCCURRENCE") order.push(+m[1]); }
  const refs = (args) => [...args.matchAll(/#(\d+)/g)].map((x) => +x[1]);
  const productName = (pdId) => {
    const pd = ents.get(pdId); if (!pd) return null;
    const pdf = ents.get(refs(pd.args)[0]); if (!pdf) return null;
    const prod = ents.get(refs(pdf.args)[0]); if (!prod) return null;
    const nm = prod.args.match(/^\s*'((?:[^']|'')*)'/);
    return nm ? fixMojibake(dec(nm[1].replace(/''/g, "'"))) : null;
  };
  const parents = new Set(order.map((id) => refs(ents.get(id).args)[0]));
  const leaf = order.map((id) => refs(ents.get(id).args)[1]).filter((pd) => !parents.has(pd));
  let names = leaf.map(productName);
  if (!order.length) {
    const prods = [...text.matchAll(/PRODUCT\('((?:[^']|'')*)'/g)].map((x) => fixMojibake(dec(x[1])));
    if (prods.length === n) names = prods;
  }
  if (names.length !== n) {
    const breps = [...text.matchAll(/MANIFOLD_SOLID_BREP\('([^']*)'/g)].map((x) => dec(x[1]));
    names = breps.length === n && breps.some(Boolean) ? breps : [];
  }
  return names.map((x) => x || "");
}

// 押し出し・回転に使われたスケッチ（Fusion と同じく、使ったスケッチは自動で非表示に）
function usedSketches(features) {
  const out = new Set();
  for (const f of features) {
    if ((f.type !== "extrude" && f.type !== "revolve") || f.suppressed) continue;
    if (f.sketch) out.add(f.sketch);
    for (const it of f.items || []) if (it.sketch) out.add(it.sketch);
  }
  return out;
}
const PLANE_LABEL = { XY: "XY 平面（水平・床の向き）", XZ: "XZ 平面（正面の向き）", YZ: "YZ 平面（側面の向き）" };
export const IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);

// オフライン対応（https で配信している場合のみ。単一HTML版では何もしない）
function registerOffline() {
  if (!("serviceWorker" in navigator) || !/^https?:$/.test(location.protocol)) return;
  if (location.protocol === "http:" && !["localhost", "127.0.0.1"].includes(location.hostname)) return;
  navigator.serviceWorker.register("sw.js").then(() => warmFont()).catch(() => {});
}

const app = new App();
window.__app = app;
document.getElementById("boot-msg")?.remove();
window.__store = store;
window.__kcall = call;
window.__cmd = (t) => app.cmdline.runText(t);
app.start();
