// 音声入力: 話した言葉を文字にして、コマンドとして実行する
// ブラウザの音声認識（Web Speech API）を使う。端末の中だけで認識できるときはそれを使い、
// できないとき（音声が Google / Apple のサーバーに送られる）は、利用者の同意があるときだけ使う。

// ---- 漢数字 → 数字（「六百」→600、「千二百五十」→1250、「三十五」→35、「二〇」→20）
const KD = { 〇: 0, 零: 0, 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
function kanjiToNum(s) {
  if (!/[十百千万]/.test(s)) return +[...s].map((c) => KD[c]).join(""); // 二〇 → 20
  let total = 0, sec = 0, cur = 0;
  for (const c of s) {
    if (c in KD) cur = KD[c];
    else if (c === "十" || c === "百" || c === "千") { sec += (cur || 1) * { 十: 10, 百: 100, 千: 1000 }[c]; cur = 0; }
    else if (c === "万") { total += (sec + cur || 1) * 10000; sec = 0; cur = 0; }
  }
  return total + sec + cur;
}
function kanjiNumbers(s) {
  return s.replace(/[〇零一二三四五六七八九十百千万]+/g, (m, i, all) => {
    const next = all.slice(i + m.length);
    // 数でない言葉（四隅・一つ・一通り・一時・一番・六角形・行頭の四角 など）はそのまま
    if (/^(隅|つ|通|時|番|方|緒|部|般|応|旦|気|斉|体|角形|切|度目|列目)/.test(next)) return m;
    if (/^角/.test(next) && /(^|\n)\s*$/.test(all.slice(0, i))) return m;
    if (m === "万" || m === "千" && !/^\s*[\d.]/.test(next) && /[一-龥]$/.test(all.slice(0, i))) return m;
    return String(kanjiToNum(m));
  });
}

// 聞き間違えやすい言葉（同じ読みの別の漢字など）→ このソフトの言葉
const FIX = [
  [/熱さ|暑さ|あつさ|厚み/g, "厚さ"], [/奥行き|おくゆき|奥ゆき/g, "奥行"], [/(^|\s)はば/g, "$1幅"], [/高さ|たかさ/g, "高さ"],
  [/直系|直経|ちょっけい/g, "直径"], [/半経|はんけい/g, "半径"], [/(^|\s)(?:あな|孔)/g, "$1穴"],
  [/推し出し|おしだし|押出し|押し出して|押しだし/g, "押し出し"], [/(^|\s)いた(?=\s|\d|$)/g, "$1板"],
  [/ふぃれっと|フィレ(?!ット)/g, "フィレット"], [/めんとり|面とり/g, "面取り"], [/えんちゅう|円中|円柱/g, "円柱"],
  [/上目ん|情面|城面|うわめん/g, "上面"], [/ゆか板|床いた|ゆかいた/g, "床板"], [/いどう|異動/g, "移動"],
  [/スケール|縮尺/g, "スケール"], [/すべて|全て/g, "すべて"], [/取り消し|とりけし|元にもどす|もとに戻す/g, "元に戻す"],
];

// 話し言葉 → コマンドの書き方に整える
export function speechToCommand(text) {
  let s = String(text || "").normalize("NFKC");
  // 言いよどみ
  s = s.replace(/(?:^|\s|、)(?:えー+と?|えっと|あのー?|えー|うーん|まあ)(?=\s|、|$)/g, " ");
  // 文の区切り → 行の区切り（「。」「次に」「それから」）
  s = s.replace(/。|(?:^|\s)(?:次に|それから|続けて|そして)(?=\s|$)/g, "\n");
  for (const [a, b] of FIX) s = s.replace(a, b);
  s = kanjiNumbers(s);
  s = s.replace(/(\d)\s*(?:てん|点|ポイント)\s*(\d)/g, "$1.$2"); // 30点5 → 30.5
  // 単位: センチ・メートル → mm（3センチ → 30、1.2メートル → 1200）
  const unit = (m, n, k) => String(+(+n * k).toFixed(6));
  s = s.replace(/(\d+(?:\.\d+)?)\s*(?:センチメートル|センチ|cm)/gi, (m, n) => unit(m, n, 10))
    .replace(/(\d+(?:\.\d+)?)\s*(?:ミリメートル|ミリ|mm)/gi, "$1")
    .replace(/(\d+(?:\.\d+)?)\s*(?:メートル|m)(?![a-z])/gi, (m, n) => unit(m, n, 1000));
  s = s.replace(/ミリメートル|ミリ|mm/gi, "")
    .replace(/(?:ファイ|パイ|φ)\s*/g, "Ø")
    .replace(/アール\s*(?=\d)/g, "R").replace(/シー\s*(?=\d)/g, "C")
    .replace(/マイナス\s*/g, "-");
  for (let i = 0; i < 2; i++) s = s.replace(/(\d)\s*(?:かける|掛ける|×|バイ|x|X)\s*(\d)/g, "$1x$2");
  s = s.replace(/[、，,]\s*(?=\D)|[、，]/g, " ").replace(/[ \t]+/g, " ");
  // 数だけが続くところを座標の組に（移動・コピー・板・円柱・球は X,Y,Z の 3 つずつ、ほかは X,Y の 2 つずつ）
  return s.split("\n").map((line) => {
    line = line.trim(); if (!line) return "";
    const toks = line.split(" ");
    const by3 = /^(移動|コピー|複製|板|直方体|箱|円柱|球)/.test(line);
    const out = [];
    for (let i = 0; i < toks.length;) {
      if (/^-?\d+(\.\d+)?$/.test(toks[i])) {
        let j = i; while (j < toks.length && /^-?\d+(\.\d+)?$/.test(toks[j])) j++;
        const run = toks.slice(i, j);
        const n = run.length >= 2 ? (by3 && run.length % 3 === 0 ? 3 : 2) : 1;
        if (n > 1 && run.length % n === 0) for (let k = 0; k < run.length; k += n) out.push(run.slice(k, k + n).join(","));
        else out.push(...run);
        i = j;
      } else out.push(toks[i++]);
    }
    return out.join(" ");
  }).filter(Boolean).join("\n");
}

// このソフトでよく使う言葉（聞き取りの候補を選ぶ・Chrome の認識に「この言葉が出やすい」と伝える）
export const VOCAB = ["板", "幅", "奥行", "厚さ", "高さ", "直径", "半径", "穴", "上面", "下面", "位置", "押し出し", "切り取り", "結合", "フィレット", "面取り",
  "縦の辺", "上の辺", "移動", "コピー", "削除", "スケール", "倍", "分の", "円柱", "球", "長方形", "円", "スケッチ", "床板", "壁", "天井", "名前", "材料",
  "ミラー", "パターン", "回転", "シェル", "元に戻す", "書き出し", "図面"];

// 聞き取った文の「コマンドらしさ」（候補が複数あるとき、いちばんそれらしいものを選ぶ）
export function commandScore(text) {
  const s = speechToCommand(text);
  let sc = 0;
  for (const w of VOCAB) if (s.includes(w)) sc += 2;
  sc += (s.match(/\d+(?:\.\d+)?/g) || []).length;
  sc -= (s.match(/[ぁ-ん]{4,}/g) || []).length; // ひらがなが長く続く＝聞き間違いの可能性
  return sc;
}

const SR = typeof window !== "undefined" ? (window.SpeechRecognition || window.webkitSpeechRecognition) : null;

export class Voice {
  constructor() { this.rec = null; this.listening = false; this.local = false; }
  get supported() { return !!SR; }
  // 端末の中で認識できるかを確かめる手段があるか（新しい Chrome だけ。Safari には無い）
  get canCheckLocal() { return !!(SR && typeof SR.available === "function"); }
  // 端末の中だけで日本語を認識できるか（新しい Chrome など）
  async checkLocal() {
    try {
      if (this.canCheckLocal) {
        const wait = (p, ms) => Promise.race([p, new Promise((r) => setTimeout(() => r("timeout"), ms))]);
        const st = await wait(SR.available({ langs: ["ja-JP"], processLocally: true }), 3000);
        if (st === "available") return (this.local = true);
        if (st === "downloadable" && typeof SR.install === "function") { const ok = await wait(SR.install({ langs: ["ja-JP"], processLocally: true }), 60000); if (ok === "timeout") return (this.local = false); return (this.local = !!ok); }
      }
    } catch { /* 使えない */ }
    return (this.local = false);
  }
  // 話している間は聞き続け、少し黙ったら（silenceMs）自動で終わる。もう一度押しても終わる
  start({ onInterim, onFinal, onEnd, onError, silenceMs = 2200, maxMs = 45000 }) {
    if (!SR) { onError && onError("このブラウザは音声入力に対応していません"); return; }
    if (this.listening) return;
    const r = new SR();
    r.lang = "ja-JP"; r.interimResults = true; r.continuous = true; r.maxAlternatives = 5;
    if (this.local && "processLocally" in r) r.processLocally = true;
    // Chrome: よく使う言葉を伝えて聞き取りやすくする（対応しているときだけ）
    try { if ("phrases" in r && window.SpeechRecognitionPhrase) r.phrases = VOCAB.map((w) => new window.SpeechRecognitionPhrase(w, 3)); } catch { /* 未対応 */ }
    let text = "", heard = false, silence = null, ended = false;
    const kick = () => { clearTimeout(silence); silence = setTimeout(() => this.stop(), heard ? silenceMs : 8000); };
    const hardStop = setTimeout(() => this.stop(), maxMs);
    r.onresult = (ev) => {
      // 毎回、結果の全体から文を組み立て直す（iPhone では最後まで「確定」にならないことがある、
      // また同じ文が伸びながら何度も届くことがあるので、前の文で始まるものは置き換える）
      const segs = [];
      for (let i = 0; i < ev.results.length; i++) {
        const res = ev.results[i];
        let best = res[0].transcript;
        if (res.isFinal && res.length > 1) {
          let bs = commandScore(best);
          for (let k = 1; k < res.length; k++) { const t = res[k].transcript, sc = commandScore(t); if (sc > bs + 1) { best = t; bs = sc; } }
        }
        best = best.trim(); if (!best) continue;
        const last = segs[segs.length - 1];
        if (last && best.startsWith(last)) segs[segs.length - 1] = best;
        else if (!(last && last.startsWith(best))) segs.push(best);
      }
      text = segs.join(" ");
      heard = heard || !!text; kick();
      onInterim && onInterim(text);
    };
    r.onerror = (e) => {
      if (e.error === "aborted") return;
      if (e.error === "no-speech" && text.trim()) return;
      const m = { "not-allowed": "マイクの使用が許可されていません（iPhone は 設定 → Safari → マイク、パソコンはアドレス欄の 🔒 から許可してください）", "service-not-allowed": "音声入力が使えません（iPhone は 設定 → 一般 → キーボード →「音声入力」をオンにしてください）", "no-speech": "声が聞き取れませんでした。もう一度ボタンを押して話してください", "network": "音声認識のサーバーにつながりません（インターネット接続を確認してください）", "audio-capture": "マイクが見つかりません" }[e.error] || "音声入力のエラー: " + e.error;
      onError && onError(m);
    };
    r.onend = () => {
      if (ended) return; ended = true;
      clearTimeout(silence); clearTimeout(hardStop);
      this.listening = false; this.rec = null;
      if (text.trim()) onFinal && onFinal(text.trim());
      onEnd && onEnd();
    };
    this.rec = r; this.listening = true;
    try { r.start(); kick(); } catch (e) { this.listening = false; this.rec = null; clearTimeout(hardStop); onError && onError(e.message); }
  }
  stop() { if (this.rec) try { this.rec.stop(); } catch { /* */ } }
}
