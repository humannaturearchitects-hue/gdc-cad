// 音声入力: 話した言葉を文字にして、コマンドとして実行する
// ブラウザの音声認識（Web Speech API）を使う。端末の中だけで認識できるときはそれを使い、
// できないとき（音声が Google / Apple のサーバーに送られる）は、利用者の同意があるときだけ使う。

// 話し言葉 → コマンドの書き方に整える
export function speechToCommand(text) {
  let s = String(text || "").normalize("NFKC");
  // 文の区切り → 行の区切り（「。」「次に」「それから」）
  s = s.replace(/。|(?:^|\s)(?:次に|それから|続けて|そして)(?=\s|$)/g, "\n");
  s = s.replace(/ミリメートル|ミリ|mm/gi, "")
    .replace(/(?:ファイ|パイ|φ)\s*/g, "Ø")
    .replace(/アール\s*(?=\d)/g, "R").replace(/シー\s*(?=\d)/g, "C")
    .replace(/マイナス\s*/g, "-");
  for (let i = 0; i < 2; i++) s = s.replace(/(\d)\s*(?:かける|掛ける|×|バイ|x|X)\s*(\d)/g, "$1x$2");
  s = s.replace(/(\d)\s*(?:てん|点)\s*(\d)/g, "$1.$2"); // 30点5 → 30.5
  s = s.replace(/[、，]/g, " ").replace(/[ \t]+/g, " ");
  // 数だけが続くところを座標の組に（移動・コピー・板・円柱・球は X,Y,Z の 3 つずつ、ほかは X,Y の 2 つずつ）
  return s.split("\n").map((line) => {
    line = line.trim(); if (!line) return "";
    const toks = line.split(" ");
    const by3 = /^(移動|コピー|複製|板|直方体|箱|円柱|球)/.test(line);
    const out = [];
    for (let i = 0; i < toks.length;) {
      if (/^-?\d+(\.\d+)?$/.test(toks[i])) {
        let j = i; while (j < toks.length && /^-?\d+(\.\d+)?$/.test(toks[j])) j++;
        const run = toks.slice(i, j);
        const n = run.length >= 2 ? (by3 && run.length % 3 === 0 ? 3 : 2) : 1;
        if (n > 1 && run.length % n === 0) for (let k = 0; k < run.length; k += n) out.push(run.slice(k, k + n).join(","));
        else out.push(...run);
        i = j;
      } else out.push(toks[i++]);
    }
    return out.join(" ");
  }).filter(Boolean).join("\n");
}

const SR = typeof window !== "undefined" ? (window.SpeechRecognition || window.webkitSpeechRecognition) : null;

export class Voice {
  constructor() { this.rec = null; this.listening = false; this.local = false; }
  get supported() { return !!SR; }
  // 端末の中だけで日本語を認識できるか（新しい Chrome など）
  async checkLocal() {
    try {
      if (SR && typeof SR.available === "function") {
        const wait = (p, ms) => Promise.race([p, new Promise((r) => setTimeout(() => r("timeout"), ms))]);
        const st = await wait(SR.available({ langs: ["ja-JP"], processLocally: true }), 3000);
        if (st === "available") return (this.local = true);
        if (st === "downloadable" && typeof SR.install === "function") { const ok = await wait(SR.install({ langs: ["ja-JP"], processLocally: true }), 60000); if (ok === "timeout") return (this.local = false); return (this.local = !!ok); }
      }
    } catch { /* 使えない */ }
    return (this.local = false);
  }
  start({ onInterim, onFinal, onEnd, onError }) {
    if (!SR) { onError && onError("このブラウザは音声入力に対応していません"); return; }
    if (this.listening) return;
    const r = new SR();
    r.lang = "ja-JP"; r.interimResults = true; r.continuous = false; r.maxAlternatives = 1;
    if (this.local && "processLocally" in r) r.processLocally = true;
    let finalText = "";
    r.onresult = (ev) => {
      let interim = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const t = ev.results[i][0].transcript;
        if (ev.results[i].isFinal) finalText += t; else interim += t;
      }
      onInterim && onInterim(finalText + interim);
    };
    r.onerror = (e) => { const m = { "not-allowed": "マイクの使用が許可されていません（ブラウザのアドレス欄の 🔒 からマイクを許可してください）", "no-speech": "声が聞き取れませんでした。もう一度ボタンを押して話してください", "network": "音声認識のサーバーにつながりません（インターネット接続を確認してください）", "audio-capture": "マイクが見つかりません" }[e.error] || "音声入力のエラー: " + e.error; onError && onError(m); };
    r.onend = () => { this.listening = false; this.rec = null; if (finalText.trim()) onFinal && onFinal(finalText); onEnd && onEnd(); };
    this.rec = r; this.listening = true;
    try { r.start(); } catch (e) { this.listening = false; onError && onError(e.message); }
  }
  stop() { if (this.rec) try { this.rec.stop(); } catch { /* */ } }
}
