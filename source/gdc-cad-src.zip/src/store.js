// プロジェクト（設計データ）と元に戻す/やり直し
export const FEATURE_LABEL = {
  sketch: "スケッチ", extrude: "押し出し", revolve: "回転", box: "直方体", cylinder: "円柱", sphere: "球",
  fillet: "フィレット", chamfer: "面取り", shell: "シェル", move: "移動/コピー", mirror: "ミラー",
  pattern: "矩形パターン", combine: "結合", import: "インポート",
  hole: "穴", cpattern: "円形パターン", presspull: "プレス/プル", split: "ボディを分割", loft: "ロフト", align: "位置合わせ", joint: "ジョイント", plane: "構築平面", remove: "ボディの削除", scale: "尺度",
};

export function newProject() {
  return {
    format: "kobocad", version: 1,
    name: "無題",
    units: "mm",
    params: [],
    features: [],
    bodyProps: {},
    rollback: null,
    drawing: null,
  };
}

let counter = 1;
export function newId(prefix = "F") {
  return `${prefix}${Date.now().toString(36)}${(counter++).toString(36)}`;
}

export const store = {
  project: newProject(),
  undoStack: [],
  redoStack: [],
  listeners: new Set(),
  dirty: false,
  fileName: null,

  snapshot() { return JSON.stringify(this.project); },
  commit(mutator, { silent = false } = {}) {
    this.undoStack.push(this.snapshot());
    if (this.undoStack.length > 200) this.undoStack.shift();
    this.redoStack = [];
    mutator(this.project);
    this.dirty = true;
    if (!silent) this.emit();
  },
  replace(project) {
    this.project = project;
    this.undoStack = [];
    this.redoStack = [];
    this.dirty = false;
    this.emit();
  },
  undo() {
    if (!this.undoStack.length) return;
    this.redoStack.push(this.snapshot());
    this.project = JSON.parse(this.undoStack.pop());
    this.emit();
  },
  redo() {
    if (!this.redoStack.length) return;
    this.undoStack.push(this.snapshot());
    this.project = JSON.parse(this.redoStack.pop());
    this.emit();
  },
  on(fn) { this.listeners.add(fn); },
  // 再計算せずに保存だけ（図面の書き込みなど）
  touch() { this.dirty = true; autosave(this.project); },
  emit() { for (const fn of this.listeners) fn(this.project); autosave(this.project); },
  feature(id) { return this.project.features.find((f) => f.id === id); },
  nameFor(type) {
    const base = FEATURE_LABEL[type] || type;
    const n = this.project.features.filter((f) => f.type === type).length + 1;
    return `${base}${n}`;
  },
};

let saveTimer = null;
function autosave(project) {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      const s = JSON.stringify(project);
      if (s.length < 4_000_000) localStorage.setItem("kobocad.autosave", s);
    } catch { /* 容量オーバー等は無視 */ }
  }, 800);
}

export function loadAutosave() {
  try {
    const s = localStorage.getItem("kobocad.autosave");
    return s ? JSON.parse(s) : null;
  } catch { return null; }
}
