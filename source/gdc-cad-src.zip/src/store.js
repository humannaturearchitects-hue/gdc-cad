// プロジェクト（設計データ）と元に戻す/やり直し、自動保存（端末の保管庫 = library.js）
import { library, ConflictError } from "./library.js";
export const FEATURE_LABEL = {
  sketch: "スケッチ", extrude: "押し出し", revolve: "回転", box: "直方体", cylinder: "円柱", sphere: "球",
  fillet: "フィレット", chamfer: "面取り", shell: "シェル", move: "移動/コピー", mirror: "ミラー",
  pattern: "矩形パターン", combine: "結合", import: "インポート",
  hole: "穴", cpattern: "円形パターン", presspull: "プレス/プル", split: "ボディを分割", loft: "ロフト", align: "位置合わせ", joint: "ジョイント", plane: "構築平面", remove: "ボディの削除", scale: "尺度",
};

export function newProject() {
  return {
    format: "kobocad", version: 1,
    name: "無題",
    units: "mm",
    params: [],
    features: [],
    bodyProps: {},
    rollback: null,
    drawing: null,
  };
}

let counter = 1;
export function newId(prefix = "F") {
  return `${prefix}${Date.now().toString(36)}${(counter++).toString(36)}`;
}

export const store = {
  project: newProject(),
  undoStack: [],
  redoStack: [],
  listeners: new Set(),
  dirty: false,
  fileName: null,

  docId: null,          // 保管庫の中のこのファイルの id
  docSaved: false,      // 保管庫に一度でも保存したか
  saveState: "saved",   // "saved" | "pending" | "saving" | "error" | "conflict"（別のタブが先に保存した）
  saveError: "",
  docRev: 0,            // このタブが知っている保管庫の保存番号（違っていたら別のタブが保存している）
  conflict: null,       // 別のタブとぶつかったときの相手の情報（解決するまで自動保存を止める）
  quiet: false,         // true の間は emit しても自動保存しない（別のタブの内容を取り込むときなど）
  thumbProvider: null,  // () => サムネイル画像（dataURL）
  blobs: {},            // 取り込んだ STEP/STL など大きなデータ（元に戻す用の写しには入れない）
  // 元に戻す用の写し。取り込んだファイルの中身は blobs に分けて、毎回コピーしない（スマホでも重くならない）
  snapshot() {
    return JSON.stringify(this.project, (k, v) => {
      if (v && typeof v === "object" && v.type === "import" && typeof v.data === "string" && v.data.length > 2000 && v.dataKey) { this.blobs[v.dataKey] = v.data; return { ...v, data: "@blob" }; }
      return v;
    });
  },
  fromSnapshot(s) { const p = JSON.parse(s); for (const f of p.features || []) if (f.type === "import" && f.data === "@blob" && this.blobs[f.dataKey]) f.data = this.blobs[f.dataKey]; return p; },
  commit(mutator, { silent = false } = {}) {
    this.undoStack.push(this.snapshot());
    if (this.undoStack.length > 200) this.undoStack.shift();
    this.redoStack = [];
    mutator(this.project);
    this.dirty = true;
    if (!silent) this.emit();
  },
  // 別のファイルに切り替える（docId: 保管庫の id。省略すると新しいファイルとして保管庫に入る）
  replace(project, docId = null) {
    this.project = sanitizeProject(project);
    this.undoStack = [];
    this.redoStack = [];
    this.blobs = {};
    this.docId = docId || library.newId();
    this.docSaved = !!docId;
    this.docRev = docId ? (library.revOf(docId) ?? 0) : 0;
    this.conflict = null;
    this.dirty = false;
    if (this.saveState === "conflict" || this.saveState === "error") this.setSave("saved");
    resetHistoryTimer(this);
    try { localStorage.setItem("gdc-last-doc", this.docId); sessionStorage.setItem("gdc-tab-doc", this.docId); } catch { /* */ }
    // 閉じる直前の控えから戻したファイルは、すぐ保管庫へ保存し直す
    const rescued = docId && library.rescued.delete(docId);
    this.emit();
    if (rescued) { this.dirty = true; autosave(); }
  },
  // 別のタブで保存された内容を取り込む（元に戻すで、このタブの前の状態に戻せる）
  adopt(project, rev) {
    this.undoStack.push(this.snapshot());
    this.redoStack = [];
    this.project = sanitizeProject(project);
    this.docRev = rev; this.conflict = null;
    this.quiet = true;
    try { this.emit(); } finally { this.quiet = false; }
    this.setSave("saved");
  },
  // すぐに保存する（ファイルを切り替える前など）
  async flush() { clearTimeout(saveTimer); return saveNow(); },
  saveListeners: new Set(),
  setSave(st, err = "") { this.saveState = st; this.saveError = err; for (const fn of this.saveListeners) fn(st, err); },
  undo() {
    if (!this.undoStack.length) return;
    this.redoStack.push(this.snapshot());
    this.project = this.fromSnapshot(this.undoStack.pop());
    this.emit();
  },
  redo() {
    if (!this.redoStack.length) return;
    this.undoStack.push(this.snapshot());
    this.project = this.fromSnapshot(this.redoStack.pop());
    this.emit();
  },
  on(fn) { this.listeners.add(fn); },
  // 再計算せずに保存だけ（図面の書き込みなど）
  touch() { this.dirty = true; autosave(); },
  emit() { for (const fn of this.listeners) fn(this.project); if (!this.quiet) autosave(); },
  feature(id) { return this.project.features.find((f) => f.id === id); },
  nameFor(type) {
    const base = FEATURE_LABEL[type] || type;
    const n = this.project.features.filter((f) => f.type === type).length + 1;
    return `${base}${n}`;
  },
};

// 壊れた・古いデータでも開けるように、最低限の形を整える
export function sanitizeProject(p) {
  const base = newProject();
  if (!p || typeof p !== "object" || Array.isArray(p)) return base;
  const out = { ...base, ...p };
  out.format = "kobocad";
  if (typeof out.name !== "string") out.name = String(out.name ?? "無題");
  out.features = Array.isArray(p.features) ? p.features.filter((f) => f && typeof f === "object" && typeof f.type === "string") : [];
  for (const f of out.features) if (!f.id) f.id = newId();
  out.params = Array.isArray(p.params) ? p.params.filter((x) => x && typeof x === "object") : [];
  if (!out.bodyProps || typeof out.bodyProps !== "object" || Array.isArray(out.bodyProps)) out.bodyProps = {};
  if (out.rollback != null && !(Number.isInteger(out.rollback) && out.rollback >= 0 && out.rollback <= out.features.length)) out.rollback = null;
  return out;
}

// 版の履歴: 開いたあと最初に保存するとき「開いたときの状態」を、その後は 30 分ごとに今の状態を残す
export const HISTORY_EVERY = 30 * 60 * 1000;
let opened = null, lastSnapAt = 0;
function resetHistoryTimer(st) {
  opened = st.docSaved ? { id: st.docId, snap: st.snapshot(), blobs: { ...st.blobs }, t: library.times[st.docId] || Date.now() } : null;
  lastSnapAt = Date.now();
}
function historyAfterSave(id, project) {
  try {
    if (opened && opened.id === id) {
      const o = opened; opened = null; lastSnapAt = Date.now();
      const p = JSON.parse(o.snap); for (const f of p.features || []) if (f.type === "import" && f.data === "@blob" && o.blobs[f.dataKey]) f.data = o.blobs[f.dataKey];
      library.addVersion(id, p, { t: o.t }).catch(() => {});
    } else if (Date.now() - lastSnapAt >= HISTORY_EVERY) {
      lastSnapAt = Date.now();
      library.addVersion(id, project).catch(() => {});
    }
  } catch { /* 履歴の失敗で保存を止めない */ }
}

let saveTimer = null, lastThumb = 0, lastThumbId = null, saving = null;
function autosave() {
  // 何もない新しいファイルは保管庫に入れない（一覧が空のファイルで埋まらないように）
  if (!store.project.features.length && !store.docSaved) return;
  if (store.conflict) return; // 別のタブとぶつかっている間は上書きしない（利用者が選ぶまで待つ）
  clearTimeout(saveTimer);
  store.setSave("pending");
  saveTimer = setTimeout(saveNow, 700);
}
async function saveNow({ force = false } = {}) {
  if (!store.docId) return;
  if (!store.project.features.length && !store.docSaved) return;
  if (store.conflict && !force) return;
  if (saving) await saving.catch(() => {});
  const id = store.docId, project = store.project;
  let thumb;
  if (store.thumbProvider && (Date.now() - lastThumb > 8000 || lastThumbId !== id)) { try { thumb = store.thumbProvider(); lastThumb = Date.now(); lastThumbId = id; } catch { /* */ } }
  store.setSave("saving");
  saving = library.save(id, project, { thumb, expectRev: force ? undefined : store.docRev }).then((m) => {
    if (store.docId === id) { store.docSaved = true; store.docRev = m.rev; store.conflict = null; }
    library.clearRescue(id);
    try { if (localStorage.getItem("kobocad.autosave")) localStorage.removeItem("kobocad.autosave"); } catch { /* */ }
    store.setSave("saved");
    for (const fn of store.savedListeners) { try { fn(id, m); } catch { /* */ } }
    historyAfterSave(id, project);
  }).catch((e) => {
    if (e instanceof ConflictError) {
      if (store.docId === id) store.conflict = { meta: e.meta };
      store.setSave("conflict", e.message);
      return;
    }
    // 保管庫が使えないとき（プライベートブラウズ等）は、小さければ従来の場所へ
    try { const s = JSON.stringify(project); if (s.length < 4_000_000) localStorage.setItem("kobocad.autosave", s); } catch { /* */ }
    store.setSave("error", e.message || String(e));
  });
  return saving;
}
store.savedListeners = new Set(); // 保存できたとき (id, meta)
// 別のタブとぶつかったとき、このタブの内容で上書きする
store.forceSave = async () => { clearTimeout(saveTimer); store.conflict = null; return saveNow({ force: true }); };
// 閉じる・別のアプリに切り替える直前: 保存待ちの内容をすぐ保存し、間に合わない分は控えに書く
function onLeave() {
  if (!store.docId || (!store.project.features.length && !store.docSaved)) return;
  if (store.saveState === "pending" || store.saveState === "saving" || store.saveState === "error") {
    library.writeRescue(store.docId, store.project, store.docRev);
    if (!store.conflict) { clearTimeout(saveTimer); saveNow().catch(() => {}); }
  }
}
if (typeof window !== "undefined") {
  window.addEventListener("pagehide", onLeave);
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") onLeave(); });
  // 保存できていない（容量不足・別のタブとぶつかった）まま閉じようとしたら、ブラウザの確認を出す
  window.addEventListener("beforeunload", (e) => {
    onLeave();
    if (store.saveState === "error" || store.saveState === "conflict") { e.preventDefault(); e.returnValue = ""; }
  });
}

export function loadAutosave() {
  try {
    const s = localStorage.getItem("kobocad.autosave");
    return s ? JSON.parse(s) : null;
  } catch { return null; }
}
