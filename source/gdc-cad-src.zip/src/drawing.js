// 図面ワークスペース: 3D から三面図＋等角図を作成し DXF / PDF / SVG に書き出す
import { call } from "./kernel.js";
import { parseSvgPath, primsBBox, transformPrims, sheetToSVG, sheetToDXF, sheetsToPDF, download } from "./exporters.js";
import { store } from "./store.js";
import { esc } from "./commands.js";
import { layupSpec } from "./layup.js";

const SIZES = { A4: [297, 210], A3: [420, 297], A2: [594, 420], A1: [841, 594], A0: [1189, 841] };
const SCALES = [10, 5, 2, 1, 1 / 2, 1 / 2.5, 1 / 5, 1 / 10, 1 / 20, 1 / 25, 1 / 50, 1 / 100, 1 / 200];
const scaleLabel = (s) => (s >= 1 ? `${s}:1` : `1:${+(1 / s).toFixed(1)}`);
const VIEW_NAMES = { front: "正面図", top: "平面図", right: "右側面図", iso: "等角図" };

export function defaultDrawingSettings() {
  return {
    size: "A3", scale: "auto", mode: "all",
    views: { front: true, top: true, right: true, iso: true },
    hidden: true, dims: true, holes: true, bom: "auto",
    title: store.project.name || "", number: "", author: "", material: "", note: "", company: "",
    date: new Date().toISOString().slice(0, 10),
  };
}

export class DrawingWorkspace {
  constructor(app) {
    this.app = app;
    this.el = document.getElementById("drawing-ws");
    this.page = 0;
    this.cache = new Map();
  }

  get settings() {
    if (!store.project.drawing) store.project.drawing = defaultDrawingSettings();
    return store.project.drawing;
  }

  async open() {
    this.el.classList.remove("hidden");
    this.cache.clear();
    this.renderSide();
    await this.refresh();
  }
  close() { this.el.classList.add("hidden"); }

  renderSide() {
    const s = this.settings;
    const bodies = this.app.bodyList().filter((b) => !b.hidden);
    this.el.innerHTML = `
      <div class="dw-side">
        <h3>シート</h3>
        <div class="row"><label>用紙</label><select data-s="size">${Object.keys(SIZES).map((k) => `<option ${s.size === k ? "selected" : ""}>${k}</option>`).join("")}</select></div>
        <div class="row"><label>尺度</label><select data-s="scale"><option value="auto">自動</option>${SCALES.map((v) => `<option value="${v}" ${String(s.scale) === String(v) ? "selected" : ""}>${scaleLabel(v)}</option>`).join("")}</select></div>
        <div class="row"><label>対象</label><select data-s="mode"><option value="all" ${s.mode === "all" ? "selected" : ""}>表示中の全体（1枚）</option><option value="each" ${s.mode === "each" ? "selected" : ""}>部品（ボディ）ごと（${bodies.length}枚）</option>${this.compPages().length ? `<option value="comp" ${s.mode === "comp" ? "selected" : ""}>コンポーネントごと（${this.compPages().length}枚）</option>` : ""}</select></div>
        <h3>ビュー</h3>
        <div class="checks">${Object.entries(VIEW_NAMES).map(([k, n]) => `<label><input type="checkbox" data-v="${k}" ${s.views[k] ? "checked" : ""}/>${n}</label>`).join("")}</div>
        <div class="checks" style="margin-top:6px"><label><input type="checkbox" data-c="hidden" ${s.hidden ? "checked" : ""}/>隠れ線</label><label><input type="checkbox" data-c="dims" ${s.dims ? "checked" : ""}/>外形寸法</label><label><input type="checkbox" data-c="holes" ${s.holes !== false ? "checked" : ""}/>穴径（Ø）</label></div>
        <div class="row" style="margin-top:6px"><label>部品表</label><select data-s="bom"><option value="auto" ${(s.bom || "auto") === "auto" ? "selected" : ""}>自動（多い時は別ページ）</option><option value="sheet" ${s.bom === "sheet" ? "selected" : ""}>図面の中に入れる</option><option value="page" ${s.bom === "page" ? "selected" : ""}>別ページ</option><option value="none" ${s.bom === "none" ? "selected" : ""}>なし</option></select></div>
        <h3>表題欄</h3>
        ${[["title", "図名"], ["number", "図番"], ["material", "材質"], ["author", "作成者"], ["date", "日付"], ["company", "会社名"], ["note", "備考"]].map(([k, n]) => `<div class="row"><label>${n}</label><input type="text" data-t="${k}" value="${esc(s[k] || "")}" ${s.mode === "each" && k === "title" ? 'placeholder="部品名を自動"' : ""}/></div>`).join("")}
        <h3>書き込み（クリックで図面に追加）</h3>
        <div class="btns ann-tools">
          <button class="btn" data-ann="dim">寸法</button>
          <button class="btn" data-ann="note">注記</button>
          <button class="btn" data-ann="balloon">部品番号（自動）</button>
          <button class="btn" data-ann="del">消す</button>
        </div>
        <p class="dlg-note" id="ann-hint">寸法: 2 点をクリック → 3 回目のクリックで寸法線の位置。点は線の端・円の中心に吸着します。</p>
        <h3>書き出し</h3>
        <div class="btns">
          <button class="btn primary" data-x="pdf">PDF（全ページ）</button>
          <button class="btn" data-x="dxf">DXF（このページ）</button>
          <button class="btn" data-x="dxfall">DXF（全ページ）</button>
          <button class="btn" data-x="svg">SVG（このページ）</button>
        </div>
        <p class="dlg-note" style="margin-top:10px">投影法: 第三角法 / 単位: mm。DXF は R12 形式（AutoCAD・Jw_cad 等で読込可）。線は画層 OUTLINE・HIDDEN・DIM・BORDER に分かれます。</p>
      </div>
      <div class="dw-main"><div><div class="dw-pages"></div><div class="dw-sheet"></div></div></div>`;
    const upd = () => { store.dirty = true; this.cache.clear(); this.refresh(); };
    this.el.querySelectorAll("[data-s]").forEach((i) => i.addEventListener("change", () => { s[i.dataset.s] = i.value; this.page = 0; if (i.dataset.s === "mode") this.renderSide(); upd(); }));
    this.el.querySelectorAll("[data-v]").forEach((i) => i.addEventListener("change", () => { s.views[i.dataset.v] = i.checked; upd(); }));
    this.el.querySelectorAll("[data-c]").forEach((i) => i.addEventListener("change", () => { s[i.dataset.c] = i.checked; upd(); }));
    this.el.querySelectorAll("[data-t]").forEach((i) => i.addEventListener("change", () => { s[i.dataset.t] = i.value; this.refresh(); }));
    this.el.querySelectorAll("[data-x]").forEach((b) => b.addEventListener("click", () => this.export(b.dataset.x)));
    this.el.querySelectorAll("[data-ann]").forEach((b) => b.addEventListener("click", () => this.setAnnTool(b.dataset.ann)));
    this.annTool = null; this.annPts = [];
  }

  compPages() {
    const visible = new Set(this.app.bodyList().filter((b) => !b.hidden).map((b) => b.id));
    const out = [];
    const walk = (parent) => {
      for (const c of this.app.compChildren(parent)) {
        const ids = this.app.compBodies(c.id).filter((id) => visible.has(id));
        if (ids.length) out.push({ ids, title: c.name });
        walk(c.id);
      }
    };
    walk(null);
    return out;
  }

  pages() {
    const s = this.settings;
    const bodies = this.app.bodyList().filter((b) => !b.hidden);
    if (s.mode === "each") return bodies.map((b) => ({ ids: [b.id], title: b.name }));
    let pages = s.mode === "comp" ? this.compPages() : [];
    if (!pages.length) pages = [{ ids: bodies.map((b) => b.id), title: s.title || store.project.name }];
    // 部品表: 部品が多いときは別ページ
    const out = [];
    for (const pg of pages) {
      const rows = this.bomRows(pg.ids);
      const mode = s.bom || "auto";
      const onSheet = rows.length > 1 && (mode === "sheet" || (mode === "auto" && rows.length <= 12));
      out.push({ ...pg, bomRows: onSheet ? rows : null });
      if (rows.length > 1 && (mode === "page" || (mode === "auto" && rows.length > 12))) {
        const per = 34;
        for (let k = 0; k < rows.length; k += per) out.push({ ids: pg.ids, title: `${pg.title} 部品表${rows.length > per ? ` (${k / per + 1})` : ""}`, bomOnly: rows.slice(k, k + per), bomStart: k });
      }
    }
    return out;
  }

  // 部品表の行: 同じ名前・同じ外形の部品はまとめて数量に
  bomRows(ids) {
    const map = new Map();
    for (const id of ids) {
      const m = this.app.meshes.find((x) => x.id === id);
      if (!m) continue;
      const v = m.vertices; const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
      for (let i = 0; i < v.length; i += 3) for (let k = 0; k < 3; k++) { if (v[i + k] < mn[k]) mn[k] = v[i + k]; if (v[i + k] > mx[k]) mx[k] = v[i + k]; }
      const dims = mx.map((x, k) => Math.round((x - mn[k]) * 10) / 10).sort((a, b) => b - a);
      const name = m.name.replace(/(_\d+(-\d+)?|\((コピー|ミラー)\))+$/, "");
      const key = bomKey(m);
      if (map.has(key)) map.get(key).qty++;
      else map.set(key, { name, qty: 1, material: m.layup ? layupSpec(m.layup) : (m.material?.name || ""), dims: dims.join(" × ") });
    }
    return [...map.values()];
  }

  async refresh() {
    const pages = this.pages();
    const pg = this.el.querySelector(".dw-pages");
    if (pages.length > 1) {
      pg.innerHTML = pages.map((p, i) => `<button data-p="${i}" class="${i === this.page ? "on" : ""}">${i + 1}. ${esc(p.title)}</button>`).join("");
      pg.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => { this.page = +b.dataset.p; this.refresh(); }));
    } else pg.innerHTML = "";
    const holder = this.el.querySelector(".dw-sheet");
    if (!pages.length) { holder.innerHTML = `<div style="padding:40px">表示中のボディがありません</div>`; return; }
    this.page = Math.min(this.page, pages.length - 1);
    this.app.busy(true, "図面を作成中…");
    try {
      const sheet = await this.buildSheet(pages[this.page], this.page, pages.length);
      const svg = sheetToSVG(sheet);
      holder.innerHTML = svg;
      const el = holder.firstElementChild;
      this.sheet = sheet; this.pageKey = pageKeyOf(pages[this.page]);
      el.style.cursor = this.annTool ? "crosshair" : "default";
      el.addEventListener("click", (ev) => this.onSheetClick(ev, el));
      const avail = this.el.querySelector(".dw-main").clientWidth - 60;
      const px = Math.min(avail, 1400);
      el.setAttribute("width", px); el.setAttribute("height", px * sheet.h / sheet.w);
    } catch (e) {
      holder.innerHTML = `<div style="padding:40px;color:#c33">図面の作成に失敗しました: ${esc(e.message)}</div>`;
    } finally { this.app.busy(false); }
  }

  async projections(ids, view) {
    const key = ids.join(",") + "|" + view;
    if (this.cache.has(key)) return this.cache.get(key);
    const r = await call("project", { ids, view });
    const out = {
      visible: r.visible.flatMap(parseSvgPath),
      hidden: r.hidden.flatMap(parseSvgPath),
    };
    this.cache.set(key, out);
    return out;
  }

  async buildSheet(page, index, total) {
    if (page.bomOnly) return this.buildBomSheet(page, index, total);
    const s = this.settings;
    const [W, H] = SIZES[s.size];
    const M = 10;
    const tbW = 180, tbH = 36;
    const sheet = {
      w: W, h: H, texts: [], fills: [],
      layers: {
        BORDER: { prims: [], width: 0.5 },
        OUTLINE: { prims: [], width: 0.35 },
        HIDDEN: { prims: [], width: 0.2, dash: "2 1", color: "#333" },
        DIM: { prims: [], width: 0.18, color: "#1a5fb4" },
      },
    };
    const rect = (L, x, y, w, h) => { L.push({ t: "line", a: [x, y], b: [x + w, y] }, { t: "line", a: [x + w, y], b: [x + w, y + h] }, { t: "line", a: [x + w, y + h], b: [x, y + h] }, { t: "line", a: [x, y + h], b: [x, y] }); };
    rect(sheet.layers.BORDER.prims, M, M, W - 2 * M, H - 2 * M);

    // ビュー投影
    const want = Object.keys(VIEW_NAMES).filter((k) => s.views[k]);
    const proj = {};
    for (const v of want) proj[v] = await this.projections(page.ids, v);
    const bb = {};
    for (const v of want) {
      const all = s.hidden ? [...proj[v].visible, ...proj[v].hidden] : proj[v].visible;
      bb[v] = primsBBox(all.length ? all : proj[v].visible);
    }
    const size = (v) => (bb[v] ? [bb[v].max[0] - bb[v].min[0], bb[v].max[1] - bb[v].min[1]] : [0, 0]);
    // 第三角法の配置: 平面図は正面図の上、右側面図は正面図の右
    const gap = 22;
    const fw = size("front")[0], fh = size("front")[1];
    const tw = s.views.top ? size("top")[0] : 0, th = s.views.top ? size("top")[1] : 0;
    const rw = s.views.right ? size("right")[0] : 0;
    const iw = s.views.iso ? size("iso")[0] : 0, ih = s.views.iso ? size("iso")[1] : 0;
    const bomW = 180;
    const areaW = W - 2 * M - 20 - (page.bomRows ? bomW + 10 : 0), areaH = H - 2 * M - tbH - 16;
    const needW = (sc) => Math.max(fw, tw) * sc + (s.views.right ? gap + rw * sc : 0) + (s.views.iso ? gap + iw * sc * 0.6 : 0);
    const needH = (sc) => fh * sc + (s.views.top ? gap + th * sc : 0);
    let scale = s.scale === "auto" ? null : +s.scale;
    if (!scale) {
      scale = SCALES[SCALES.length - 1];
      for (const sc of SCALES) if (needW(sc) <= areaW && needH(sc) <= areaH && (!s.views.iso || ih * sc * 0.6 <= areaH)) { scale = sc; break; }
    }
    const usedW = needW(scale), usedH = needH(scale);
    const x0 = M + 10 + Math.max(0, (areaW - usedW) / 2);
    const y0 = M + tbH + 8 + Math.max(0, (areaH - usedH) / 2);
    const place = {};
    place.front = [x0, y0];
    if (s.views.top) place.top = [x0, y0 + fh * scale + gap];
    if (s.views.right) place.right = [x0 + Math.max(fw, tw) * scale + gap, y0];
    if (s.views.iso) place.iso = [x0 + Math.max(fw, tw) * scale + (s.views.right ? gap + rw * scale : 0) + gap, y0 + Math.max(0, usedH - ih * scale * 0.6)];
    if (!s.views.front) { place.top = [x0, y0]; }

    sheet.views = {};
    for (const v of want) {
      const sc = v === "iso" ? scale * 0.6 : scale;
      const [px, py] = place[v];
      const ox = px - bb[v].min[0] * sc, oy = py - bb[v].min[1] * sc;
      sheet.layers.OUTLINE.prims.push(...transformPrims(proj[v].visible, sc, ox, oy));
      {
        const [vw2, vh2] = size(v);
        const snaps = [];
        for (const p of proj[v].visible) {
          if (p.t === "line") snaps.push(p.a, p.b);
          else if (p.t === "arc") snaps.push(p.c, [p.c[0] + p.r * Math.cos(p.s), p.c[1] + p.r * Math.sin(p.s)], [p.c[0] + p.r * Math.cos(p.s + p.d), p.c[1] + p.r * Math.sin(p.s + p.d)]);
          else if (p.t === "poly") snaps.push(p.pts[0], p.pts[p.pts.length - 1]);
        }
        sheet.views[v] = { sc, ox, oy, rect: [px, py, px + vw2 * sc, py + vh2 * sc], snaps };
      }
      if (s.hidden && v !== "iso") sheet.layers.HIDDEN.prims.push(...transformPrims(dropCovered(proj[v].hidden, proj[v].visible), sc, ox, oy));
      const [vw, vh] = size(v);
      sheet.texts.push({ x: px + (vw * sc) / 2, y: py - (s.dims && v !== "iso" ? 14 : 6), text: VIEW_NAMES[v] + (v === "iso" ? "（参考）" : ""), size: 3.5, anchor: "middle" });
      if (s.dims && v !== "iso") {
        const D = sheet.layers.DIM.prims;
        // 幅（下側）
        if (v !== "top" || !s.views.front) hDim(sheet, D, px, px + vw * sc, py, py - 7, vw);
        // 高さ（左側）
        if (v === "front" || v === "top") vDim(sheet, D, py, py + vh * sc, px, px - 7, vh);
        if (v === "right" && !s.views.front) vDim(sheet, D, py, py + vh * sc, px, px - 7, vh);
      }
    }

    // 穴径（Ø）: 同じ径の円はまとめて「n×Ø」
    if (s.holes !== false) {
      for (const v of want.filter((x) => x !== "iso")) {
        const sc = scale;
        const [px, py] = place[v];
        const ox = px - bb[v].min[0] * sc, oy = py - bb[v].min[1] * sc;
        // 円は半円 2 つ等に分かれて出てくるので、同じ中心・半径の弧をまとめて一周なら円とみなす
        const arcs = new Map();
        for (const p of proj[v].visible) {
          if (p.t !== "arc") continue;
          const key = `${p.c[0].toFixed(3)},${p.c[1].toFixed(3)},${p.r.toFixed(3)}`;
          const a = arcs.get(key) || { c: p.c, r: p.r, sweep: 0 };
          a.sweep += Math.abs(p.d);
          arcs.set(key, a);
        }
        const circles = [...arcs.values()].filter((a) => a.sweep >= 2 * Math.PI - 1e-3);
        const groups = new Map();
        for (const c of circles) {
          const dia = Math.round(c.r * 2 * 10) / 10;
          const key = String(dia);
          const g = groups.get(key) || { dia, list: [] };
          if (!g.list.some((q) => Math.hypot(q.c[0] - c.c[0], q.c[1] - c.c[1]) < 1e-3)) g.list.push(c);
          groups.set(key, g);
        }
        // 外形寸法と同じ大きさの円（丸棒の外形など）は除く
        const [vw, vh] = size(v);
        for (const g of groups.values()) {
          if (g.dia >= Math.max(vw, vh) - 0.1) continue;
          const c = g.list[0];
          const cx = ox + c.c[0] * sc, cy = oy + c.c[1] * sc, r = c.r * sc;
          const lx = cx + r * 0.7071, ly = cy + r * 0.7071;
          sheet.layers.DIM.prims.push({ t: "line", a: [lx, ly], b: [lx + 4, ly + 4] }, { t: "line", a: [lx + 4, ly + 4], b: [lx + 4 + 14, ly + 4] });
          sheet.texts.push({ x: lx + 5, y: ly + 4.8, text: `${g.list.length > 1 ? g.list.length + "×" : ""}Ø${g.dia}`, size: 2.5, color: "#1a5fb4", layer: "DIM" });
        }
      }
    }

    // 手書きの寸法・注記・部品番号
    this.drawAnnotations(sheet, page);

    // 部品表（図面内）
    if (page.bomRows) drawBomTable(sheet, page.bomRows, W - M - bomW, M + tbH + 4, bomW, 0, false);

    // 表題欄
    const tx = W - M - tbW, ty = M;
    const B = sheet.layers.BORDER.prims;
    rect(B, tx, ty, tbW, tbH);
    const rows = [0, 12, 24, 36];
    for (const r of rows.slice(1, 3)) B.push({ t: "line", a: [tx, ty + r], b: [tx + tbW, ty + r] });
    const cols = [0, 30, 100, 125, 180];
    for (const c of [30, 100]) B.push({ t: "line", a: [tx + c, ty], b: [tx + c, ty + 24] });
    B.push({ t: "line", a: [tx + 125, ty], b: [tx + 125, ty + tbH] });
    const cell = (ci, ri, label, value, big) => {
      const x = tx + cols[ci] + 1.5, y = ty + rows[ri];
      sheet.texts.push({ x, y: y + 9.2, text: label, size: 2 });
      sheet.texts.push({ x: x + 1, y: y + 2.8, text: value || "", size: big ? 4.2 : 3.2 });
    };
    const title = s.mode === "each" || s.mode === "comp" ? page.title : (s.title || page.title || "");
    cell(0, 2, "図名", "");
    sheet.texts.push({ x: tx + 32, y: ty + 27.5, text: title, size: 5 });
    cell(3, 2, "図番", s.number + (total > 1 ? `-${index + 1}` : ""));
    cell(0, 1, "材質", s.material);
    cell(1, 1, "", "");
    sheet.texts.push({ x: tx + 32, y: ty + 20.2, text: "備考", size: 2 });
    sheet.texts.push({ x: tx + 33, y: ty + 14.8, text: s.note || "", size: 3 });
    cell(2, 1, "尺度", scaleLabel(scale));
    cell(3, 1, "投影法", "第三角法");
    cell(0, 0, "作成者", s.author);
    cell(1, 0, "会社名", s.company);
    cell(2, 0, "日付", s.date);
    cell(3, 0, "単位 / シート", `mm   ${index + 1}/${total}`);
    // 第三角法記号
    thirdAngleSymbol(sheet, tx + 160, ty + 17.5);
    sheet.scale = scale;
    return sheet;
  }

  // ---------------------------------------------------------------- 書き込み
  annList(page) {
    const s = this.settings;
    s.annotations = s.annotations || {};
    const k = pageKeyOf(page);
    return (s.annotations[k] = s.annotations[k] || []);
  }

  setAnnTool(t) {
    this.annTool = this.annTool === t ? null : t;
    this.annPts = [];
    this.el.querySelectorAll("[data-ann]").forEach((b) => b.classList.toggle("primary", b.dataset.ann === this.annTool));
    const hints = {
      dim: "寸法: 2 点をクリック → 3 回目のクリックで寸法線の位置（上下に置くと横寸法、左右に置くと縦寸法）。",
      note: "注記: 文字を置きたい場所をクリック。",
      del: "消す: 消したい寸法・注記・部品番号の近くをクリック。",
    };
    if (t === "balloon") { this.annTool = null; this.autoBalloons(); return; }
    const h = this.el.querySelector("#ann-hint"); if (h) h.textContent = hints[this.annTool] || "ボタンを選んでから図面をクリックします。";
    const svg = this.el.querySelector(".dw-sheet svg"); if (svg) svg.style.cursor = this.annTool ? "crosshair" : "default";
  }

  sheetPoint(ev, svg) {
    const r = svg.getBoundingClientRect();
    return [((ev.clientX - r.left) / r.width) * this.sheet.w, this.sheet.h - ((ev.clientY - r.top) / r.height) * this.sheet.h];
  }

  viewAt(p) {
    let best = null, bd = Infinity;
    for (const [v, info] of Object.entries(this.sheet.views || {})) {
      if (v === "iso") continue;
      const [x0, y0, x1, y1] = info.rect;
      const dx = Math.max(x0 - p[0], 0, p[0] - x1), dy = Math.max(y0 - p[1], 0, p[1] - y1);
      const d = Math.hypot(dx, dy);
      if (d < bd) { bd = d; best = v; }
    }
    return bd < 25 ? best : null;
  }

  // シート上の点 → そのビューのモデル座標（端点・円の中心に吸着）
  toModel(v, p) {
    const info = this.sheet.views[v];
    const m = [(p[0] - info.ox) / info.sc, (p[1] - info.oy) / info.sc];
    let best = null, bd = 4 / info.sc;
    for (const q of info.snaps) { const d = Math.hypot(q[0] - m[0], q[1] - m[1]); if (d < bd) { bd = d; best = q; } }
    return best ? [best[0], best[1]] : m;
  }

  onSheetClick(ev, svg) {
    if (!this.annTool || !this.sheet) return;
    const p = this.sheetPoint(ev, svg);
    const page = this.pages()[this.page];
    const list = this.annList(page);
    if (this.annTool === "note") {
      const text = prompt("注記の文字");
      if (text) { list.push({ t: "note", x: +p[0].toFixed(2), y: +p[1].toFixed(2), text }); this.changed(); }
      return;
    }
    if (this.annTool === "del") {
      let k = -1, bd = 8;
      list.forEach((a, i) => { const q = annAnchor(a, this.sheet); if (q) { const d = Math.hypot(q[0] - p[0], q[1] - p[1]); if (d < bd) { bd = d; k = i; } } });
      if (k >= 0) { list.splice(k, 1); this.changed(); } else this.app.toast("近くに消せる書き込みがありません");
      return;
    }
    if (this.annTool === "dim") {
      if (this.annPts.length < 2) {
        const v = this.annPts.length ? this.annPts[0].v : this.viewAt(p);
        if (!v) return this.app.toast("図（ビュー）の上をクリックしてください（等角図には寸法を入れられません）");
        this.annPts.push({ v, m: this.toModel(v, p) });
        this.app.toast(this.annPts.length === 1 ? "2 点目をクリック" : "寸法線を置く位置をクリック");
        return;
      }
      const [A, B] = this.annPts;
      const info = this.sheet.views[A.v];
      const a = [info.ox + A.m[0] * info.sc, info.oy + A.m[1] * info.sc], b = [info.ox + B.m[0] * info.sc, info.oy + B.m[1] * info.sc];
      const inX = p[0] >= Math.min(a[0], b[0]) && p[0] <= Math.max(a[0], b[0]);
      const inY = p[1] >= Math.min(a[1], b[1]) && p[1] <= Math.max(a[1], b[1]);
      const dir = Math.abs(a[0] - b[0]) < 1e-6 ? "v" : Math.abs(a[1] - b[1]) < 1e-6 ? "h" : inX && !inY ? "h" : !inX && inY ? "v" : "a";
      const off = dir === "h" ? (p[1] - info.oy) / info.sc : dir === "v" ? (p[0] - info.ox) / info.sc : signedOffset(A.m, B.m, [(p[0] - info.ox) / info.sc, (p[1] - info.oy) / info.sc]);
      list.push({ t: "dim", view: A.v, a: A.m.map((x) => +x.toFixed(4)), b: B.m.map((x) => +x.toFixed(4)), dir, off: +off.toFixed(4) });
      this.annPts = [];
      this.changed();
    }
  }

  changed() { store.touch(); this.refresh(); }

  autoBalloons() {
    const page = this.pages()[this.page];
    const rows = this.bomRows(page.ids);
    if (rows.length < 2) return this.app.toast("部品が 2 種類以上ある図面で使えます", true);
    const v = this.sheet.views.iso ? "iso" : this.sheet.views.front ? "front" : Object.keys(this.sheet.views)[0];
    const list = this.annList(page).filter((a) => a.t !== "balloon");
    const groups = this.bomGroups(page.ids);
    groups.forEach((ids, k) => {
      const m = this.app.meshes.find((x) => x.id === ids[0]);
      if (!m) return;
      const c = meshCenter(m);
      list.push({ t: "balloon", n: k + 1, view: v, at: project2D(v, c) });
    });
    this.settings.annotations[pageKeyOf(page)] = list;
    this.changed();
    this.app.toast(`部品番号を ${groups.length} 個配置しました（番号は部品表と同じ）`);
  }

  // 部品表の行ごとのボディ id
  bomGroups(ids) {
    const map = new Map();
    for (const id of ids) {
      const m = this.app.meshes.find((x) => x.id === id);
      if (!m) continue;
      const key = bomKey(m);
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(id);
    }
    return [...map.values()];
  }

  drawAnnotations(sheet, page) {
    const list = this.annList(page);
    const D = sheet.layers.DIM.prims;
    const placed = [];
    for (const a of list) {
      if (a.t === "note") { sheet.texts.push({ x: a.x, y: a.y, text: a.text, size: 3.2, layer: "TEXT" }); continue; }
      const info = sheet.views && sheet.views[a.view];
      if (!info) continue;
      const T = (m) => [info.ox + m[0] * info.sc, info.oy + m[1] * info.sc];
      if (a.t === "dim") {
        const A = T(a.a), B = T(a.b);
        linearDim(sheet, D, A, B, a.dir, a.dir === "h" ? info.oy + a.off * info.sc : a.dir === "v" ? info.ox + a.off * info.sc : a.off * info.sc,
          a.dir === "h" ? Math.abs(a.b[0] - a.a[0]) : a.dir === "v" ? Math.abs(a.b[1] - a.a[1]) : Math.hypot(a.b[0] - a.a[0], a.b[1] - a.a[1]));
      }
      if (a.t === "balloon") {
        const P = T(a.at);
        const [x0, y0, x1, y1] = info.rect, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
        let dx = P[0] - cx, dy = P[1] - cy; const L = Math.hypot(dx, dy) || 1; dx /= L; dy /= L;
        const R = Math.max(x1 - x0, y1 - y0) / 2 + 12;
        let bpos = [cx + dx * R, cy + dy * R];
        for (let k = 0; k < 20 && placed.some((q) => Math.hypot(q[0] - bpos[0], q[1] - bpos[1]) < 9.5); k++) bpos = [bpos[0] + (dy || 0.7) * 9.5, bpos[1] - (dx || 0.7) * 9.5];
        placed.push(bpos);
        const r = 4;
        const ux = P[0] - bpos[0], uy = P[1] - bpos[1], ul = Math.hypot(ux, uy) || 1;
        D.push({ t: "arc", c: bpos, r, s: 0, d: Math.PI * 2 }, { t: "line", a: [bpos[0] + (ux / ul) * r, bpos[1] + (uy / ul) * r], b: P });
        sheet.fills.push({ pts: [[P[0] - 0.6, P[1] - 0.6], [P[0] + 0.6, P[1] - 0.6], [P[0] + 0.6, P[1] + 0.6]], color: "#1a5fb4", layer: "DIM" });
        sheet.texts.push({ x: bpos[0], y: bpos[1] - 1.2, text: String(a.n), size: 3.4, anchor: "middle", color: "#1a5fb4", layer: "DIM" });
        a._pos = bpos;
      }
    }
  }

  buildBomSheet(page, index, total) {
    const s = this.settings;
    const [W, H] = SIZES[s.size];
    const M = 10, tbW = 180, tbH = 36;
    const sheet = { w: W, h: H, texts: [], fills: [], layers: { BORDER: { prims: [], width: 0.5 }, OUTLINE: { prims: [] }, HIDDEN: { prims: [] }, DIM: { prims: [] } } };
    const B = sheet.layers.BORDER.prims;
    const rect = (x, y, w, h) => B.push({ t: "line", a: [x, y], b: [x + w, y] }, { t: "line", a: [x + w, y], b: [x + w, y + h] }, { t: "line", a: [x + w, y + h], b: [x, y + h] }, { t: "line", a: [x, y + h], b: [x, y] });
    rect(M, M, W - 2 * M, H - 2 * M);
    drawBomTable(sheet, page.bomOnly, M + 15, 0, Math.min(W - 2 * M - 30, 260), page.bomStart || 0, true, H - M - 15);
    rect(W - M - tbW, M, tbW, tbH);
    sheet.texts.push({ x: W - M - tbW + 3, y: M + 24, text: page.title, size: 5 });
    sheet.texts.push({ x: W - M - tbW + 3, y: M + 6, text: `${s.date || ""}   ${index + 1}/${total}`, size: 3 });
    sheet.scale = 1;
    return sheet;
  }

  async allSheets() {
    const pages = this.pages();
    const out = [];
    for (let i = 0; i < pages.length; i++) {
      this.app.busy(true, `図面を作成中… ${i + 1}/${pages.length}`);
      out.push(await this.buildSheet(pages[i], i, pages.length));
    }
    this.app.busy(false);
    return out;
  }

  async export(kind) {
    const base = (store.project.name || "drawing").replace(/[\\/:*?"<>|]/g, "_");
    try {
      if (kind === "pdf") {
        const sheets = await this.allSheets();
        this.app.busy(true, "PDF を作成中…");
        const blob = await sheetsToPDF(sheets);
        download(blob, `${base}_図面.pdf`);
      } else if (kind === "dxf" || kind === "svg") {
        const pages = this.pages();
        const sh = await this.buildSheet(pages[this.page], this.page, pages.length);
        const nm = pages.length > 1 ? `${base}_${pages[this.page].title}` : `${base}_図面`;
        if (kind === "dxf") download(sheetToDXF(sh), `${nm}.dxf`, "application/dxf");
        else download(sheetToSVG(sh), `${nm}.svg`, "image/svg+xml");
      } else if (kind === "dxfall") {
        const pages = this.pages();
        const sheets = await this.allSheets();
        for (let i = 0; i < sheets.length; i++) {
          download(sheetToDXF(sheets[i]), `${base}_${String(i + 1).padStart(2, "0")}_${pages[i].title}.dxf`.replace(/[\\/:*?"<>|]/g, "_"), "application/dxf");
          await new Promise((r) => setTimeout(r, 250));
        }
      }
      this.app.toast("書き出しました");
    } catch (e) {
      this.app.toast("書き出しに失敗: " + e.message, true);
    } finally { this.app.busy(false); }
  }
}

// 可視線と重なっている隠れ線を除く（外形が破線に見えるのを防ぐ）
function dropCovered(hidden, visible) {
  const vis = visible.filter((p) => p.t === "line");
  const tol = 1e-3;
  const onSeg = (q, a, b) => {
    const dx = b[0] - a[0], dy = b[1] - a[1];
    const L2 = dx * dx + dy * dy || 1e-12;
    const t = ((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) / L2;
    if (t < -tol || t > 1 + tol) return false;
    return Math.hypot(q[0] - a[0] - t * dx, q[1] - a[1] - t * dy) < tol * Math.max(1, Math.sqrt(L2));
  };
  return hidden.filter((h) => {
    if (h.t !== "line") return true;
    return !vis.some((v) => onSeg(h.a, v.a, v.b) && onSeg(h.b, v.a, v.b));
  });
}

const pageKeyOf = (pg) => (pg ? `${pg.title}|${pg.ids.length}` : "");

function meshBBox(m) {
  const v = m.vertices; const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < v.length; i += 3) for (let k = 0; k < 3; k++) { if (v[i + k] < mn[k]) mn[k] = v[i + k]; if (v[i + k] > mx[k]) mx[k] = v[i + k]; }
  return [mn, mx];
}
function meshCenter(m) { const [mn, mx] = meshBBox(m); return mn.map((v, k) => (v + mx[k]) / 2); }
function bomKey(m) {
  const [mn, mx] = meshBBox(m);
  const dims = mx.map((x, k) => Math.round((x - mn[k]) * 10) / 10).sort((a, b) => b - a);
  return m.name.replace(/(_\d+(-\d+)?|\((コピー|ミラー)\))+$/, "") + "|" + dims.join("x");
}
// 3D 点 → 各ビューの 2D 座標（投影と同じ向き）
function project2D(v, p) {
  const CAMS = { front: [[0, -1, 0], [1, 0, 0]], top: [[0, 0, 1], [1, 0, 0]], right: [[1, 0, 0], [0, 1, 0]], iso: [[1, -1, 1], [1, 1, 0]] };
  const [d0, x0] = CAMS[v] || CAMS.front;
  const n = (a) => { const L = Math.hypot(...a); return a.map((c) => c / L); };
  const d = n(d0), x = n(x0);
  const y = n([d[1] * x[2] - d[2] * x[1], d[2] * x[0] - d[0] * x[2], d[0] * x[1] - d[1] * x[0]]);
  return [p[0] * x[0] + p[1] * x[1] + p[2] * x[2], p[0] * y[0] + p[1] * y[1] + p[2] * y[2]];
}
function signedOffset(a, b, p) {
  const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1;
  return ((p[0] - a[0]) * -dy + (p[1] - a[1]) * dx) / L;
}
function annAnchor(a, sheet) {
  if (a.t === "note") return [a.x, a.y];
  const info = sheet.views && sheet.views[a.view];
  if (!info) return null;
  if (a.t === "balloon") return a._pos || [info.ox + a.at[0] * info.sc, info.oy + a.at[1] * info.sc];
  const A = [info.ox + a.a[0] * info.sc, info.oy + a.a[1] * info.sc], B = [info.ox + a.b[0] * info.sc, info.oy + a.b[1] * info.sc];
  if (a.dir === "h") { const y = info.oy + a.off * info.sc; return [(A[0] + B[0]) / 2, y]; }
  if (a.dir === "v") { const x = info.ox + a.off * info.sc; return [x, (A[1] + B[1]) / 2]; }
  return [(A[0] + B[0]) / 2, (A[1] + B[1]) / 2];
}

// 寸法線（横 h・縦 v・平行 a）
function linearDim(sheet, D, A, B, dir, pos, value) {
  const txt = fmtDim(value);
  if (dir === "h") {
    const y = pos;
    for (const P of [A, B]) { const s = Math.sign(y - P[1]) || 1; D.push({ t: "line", a: [P[0], P[1] + s * 1], b: [P[0], y + s * 1.5] }); }
    const xa = Math.min(A[0], B[0]), xb = Math.max(A[0], B[0]);
    D.push({ t: "line", a: [xa, y], b: [xb, y] });
    arrow(sheet, [xa, y], [-1, 0]); arrow(sheet, [xb, y], [1, 0]);
    sheet.texts.push({ x: (xa + xb) / 2, y: y + 0.8, text: txt, size: 3, anchor: "middle", color: "#1a5fb4", layer: "DIM" });
  } else if (dir === "v") {
    const x = pos;
    for (const P of [A, B]) { const s = Math.sign(x - P[0]) || 1; D.push({ t: "line", a: [P[0] + s * 1, P[1]], b: [x + s * 1.5, P[1]] }); }
    const ya = Math.min(A[1], B[1]), yb = Math.max(A[1], B[1]);
    D.push({ t: "line", a: [x, ya], b: [x, yb] });
    arrow(sheet, [x, ya], [0, -1]); arrow(sheet, [x, yb], [0, 1]);
    sheet.texts.push({ x: x - 0.8, y: (ya + yb) / 2, text: txt, size: 3, anchor: "middle", rot: 90, color: "#1a5fb4", layer: "DIM" });
  } else {
    const dx = B[0] - A[0], dy = B[1] - A[1], L = Math.hypot(dx, dy) || 1;
    const n = [-dy / L, dx / L], u = [dx / L, dy / L];
    const A2 = [A[0] + n[0] * pos, A[1] + n[1] * pos], B2 = [B[0] + n[0] * pos, B[1] + n[1] * pos];
    const sg = Math.sign(pos) || 1;
    D.push({ t: "line", a: [A[0] + n[0] * sg, A[1] + n[1] * sg], b: [A2[0] + n[0] * sg * 1.5, A2[1] + n[1] * sg * 1.5] }, { t: "line", a: [B[0] + n[0] * sg, B[1] + n[1] * sg], b: [B2[0] + n[0] * sg * 1.5, B2[1] + n[1] * sg * 1.5] });
    D.push({ t: "line", a: A2, b: B2 });
    arrow(sheet, A2, [-u[0], -u[1]]); arrow(sheet, B2, u);
    let ang = Math.atan2(dy, dx) * 180 / Math.PI; if (ang > 90) ang -= 180; if (ang < -90) ang += 180;
    sheet.texts.push({ x: (A2[0] + B2[0]) / 2 + n[0] * 0.8, y: (A2[1] + B2[1]) / 2 + n[1] * 0.8, text: txt, size: 3, anchor: "middle", rot: ang, color: "#1a5fb4", layer: "DIM" });
  }
}

// 部品表の表（下端 y0 から上へ積む）
function drawBomTable(sheet, rows, x0, y0, w, start, fullPage, topY) {
  const B = sheet.layers.BORDER.prims;
  const rh = 6, cols = [0, 12, 82, 96, 126, w];
  const heads = ["No.", "部品名", "数量", "材質", "外形寸法 (mm)"];
  const n = rows.length;
  const h = (n + 1) * rh;
  const yb = fullPage ? topY - h : y0;
  const line = (a, b) => B.push({ t: "line", a, b });
  for (let k = 0; k <= n + 1; k++) line([x0, yb + k * rh], [x0 + w, yb + k * rh]);
  for (const c of cols) line([x0 + c, yb], [x0 + c, yb + h]);
  const rowY = (k) => yb + h - (k + 1) * rh + 1.8;
  heads.forEach((t, k) => sheet.texts.push({ x: x0 + cols[k] + 1.5, y: rowY(0), text: t, size: 2.6 }));
  rows.forEach((r, k) => {
    const y = rowY(k + 1);
    const cells = [String(start + k + 1), r.name, String(r.qty), r.material || "", r.dims];
    cells.forEach((t, c) => {
      const max = Math.floor((cols[c + 1] - cols[c] - 2) / 2.6 * (c === 1 ? 1 : 1.6));
      sheet.texts.push({ x: x0 + cols[c] + 1.5, y, text: t.length > max ? t.slice(0, max - 1) + "…" : t, size: 2.6 });
    });
  });
  sheet.texts.push({ x: x0, y: yb + h + 2, text: "部品表", size: 3.2 });
}

function fmtDim(v) { return (+v.toFixed(1)).toString(); }

function arrow(sheet, tip, dir) {
  const L = 2.5, Wd = 0.6;
  const n = [-dir[1], dir[0]];
  const b = [tip[0] - dir[0] * L, tip[1] - dir[1] * L];
  sheet.fills.push({ pts: [tip, [b[0] + n[0] * Wd, b[1] + n[1] * Wd], [b[0] - n[0] * Wd, b[1] - n[1] * Wd]], color: "#1a5fb4", layer: "DIM" });
}

function hDim(sheet, D, xa, xb, yBase, yDim, value) {
  D.push({ t: "line", a: [xa, yBase - 1], b: [xa, yDim - 1.5] }, { t: "line", a: [xb, yBase - 1], b: [xb, yDim - 1.5] });
  D.push({ t: "line", a: [xa, yDim], b: [xb, yDim] });
  arrow(sheet, [xa, yDim], [-1, 0]); arrow(sheet, [xb, yDim], [1, 0]);
  sheet.texts.push({ x: (xa + xb) / 2, y: yDim + 0.8, text: fmtDim(value), size: 3, anchor: "middle", color: "#1a5fb4", layer: "DIM" });
}

function vDim(sheet, D, ya, yb, xBase, xDim, value) {
  D.push({ t: "line", a: [xBase - 1, ya], b: [xDim - 1.5, ya] }, { t: "line", a: [xBase - 1, yb], b: [xDim - 1.5, yb] });
  D.push({ t: "line", a: [xDim, ya], b: [xDim, yb] });
  arrow(sheet, [xDim, ya], [0, -1]); arrow(sheet, [xDim, yb], [0, 1]);
  sheet.texts.push({ x: xDim - 0.8, y: (ya + yb) / 2, text: fmtDim(value), size: 3, anchor: "middle", rot: 90, color: "#1a5fb4", layer: "DIM" });
}

function thirdAngleSymbol(sheet, cx, cy) {
  const B = sheet.layers.BORDER.prims;
  // 円錐台: 左に正面（台形）、右に側面（同心円）
  B.push({ t: "line", a: [cx - 14, cy - 3], b: [cx - 14, cy + 3] }, { t: "line", a: [cx - 14, cy + 3], b: [cx - 6, cy + 5] }, { t: "line", a: [cx - 6, cy + 5], b: [cx - 6, cy - 5] }, { t: "line", a: [cx - 6, cy - 5], b: [cx - 14, cy - 3] });
  B.push({ t: "arc", c: [cx + 4, cy], r: 5, s: 0, d: Math.PI * 2 }, { t: "arc", c: [cx + 4, cy], r: 3, s: 0, d: Math.PI * 2 });
}
