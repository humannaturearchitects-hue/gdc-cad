// 書き出した STEP を形状エンジンで読み戻し、体積が元の形と一致するか確かめる
import { call } from "./kernel.js";

export async function checkStepExport(buf, ids) {
  try {
    const ab = await new Blob([buf]).arrayBuffer();
    const r = await call("verifyStep", { buffer: ab, ids }, [ab]);
    const pct = r.expected ? Math.abs(r.volume - r.expected) / r.expected * 100 : 0;
    window.__lastStepCheck = r;
    if (r.ok) return { ok: true, text: "読み戻して確認済み（体積が一致・単位 mm）" };
    return { ok: false, text: `注意: 読み戻した体積が ${pct.toFixed(2)}% 違います（元 ${r.expected.toFixed(1)} / 読み戻し ${r.volume.toFixed(1)} mm³）` };
  } catch (e) {
    return { ok: false, text: "読み戻し確認ができませんでした: " + e.message };
  }
}
