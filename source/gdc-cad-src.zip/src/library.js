// 設計データの保管庫（ブラウザの IndexedDB）
// ・いくつでも保存でき、1 件あたりの大きさの制限も実質なし（端末の空き容量の範囲）
// ・作業中は自動で上書き保存。一覧から開く・名前変更・複製・削除・ファイルに書き出す
// ・すべてを 1 つのバックアップファイルにまとめて書き出し／戻すことができる
// ・ファイルごとの「版の履歴」（hist）。取り込んだ STEP などの大きな中身は blob に 1 回だけ置き、版どうしで共有する
// ・保存の番号（rev）で、別のタブが先に保存していたら上書きしない（ConflictError）
const DB = "gdc-cad";
const STORES = ["meta", "data", "hist", "blob"];
let dbp = null;
function db() {
  if (!dbp) dbp = new Promise((res, rej) => {
    if (typeof indexedDB === "undefined") return rej(new Error("このブラウザでは端末内に保存できません（プライベートブラウズでは保存できないことがあります）"));
    // まれに Safari で開く処理が返ってこないことがある → 起動が止まらないよう時間切れにする
    let done = false;
    const timer = setTimeout(() => { if (!done) { done = true; dbp = null; rej(new Error("端末の保存場所が応答しません（ブラウザを開き直してください）")); } }, 8000);
    const ok = (d) => { if (done) { try { d.close(); } catch { /* */ } return; } done = true; clearTimeout(timer); res(d); };
    const ng = (e) => { if (done) return; done = true; clearTimeout(timer); dbp = null; rej(e); };
    // 入れ物が欠けていたら、版を上げて作り直す（中身は消さない）
    const open = (ver) => {
      let r;
      try { r = ver ? indexedDB.open(DB, ver) : indexedDB.open(DB); } catch (e) { return ng(e); }
      r.onupgradeneeded = () => {
        const d = r.result;
        if (!d.objectStoreNames.contains("meta")) d.createObjectStore("meta", { keyPath: "id" }); // 一覧用（名前・日付・大きさ・サムネイル・保存番号）
        if (!d.objectStoreNames.contains("data")) d.createObjectStore("data", { keyPath: "id" }); // 中身（JSON）
        if (!d.objectStoreNames.contains("hist")) d.createObjectStore("hist", { keyPath: "k", autoIncrement: true }).createIndex("doc", "doc"); // 版の履歴
        if (!d.objectStoreNames.contains("blob")) d.createObjectStore("blob", { keyPath: "id" }); // 版で共有する大きな取り込みデータ
      };
      r.onsuccess = () => {
        const d = r.result;
        if (STORES.some((n) => !d.objectStoreNames.contains(n))) { const v = d.version + 1; d.close(); return open(v); }
        d.onversionchange = () => { d.close(); dbp = null; };
        ok(d);
      };
      r.onerror = () => ng(r.error || new Error("保存場所を開けませんでした"));
      r.onblocked = () => ng(new Error("別のタブでこのソフトの古い版が開いています。ほかのタブを閉じてからもう一度開いてください"));
    };
    open(0); // 版は指定しない（今ある版で開き、足りなければ上げる）
  });
  return dbp;
}
const quotaMsg = "端末の空き容量が足りません";
export const isQuotaError = (e) => !!e && (e.name === "QuotaExceededError" || e.quota === true || String(e.message || "").includes(quotaMsg));
// fn(s, c) は store 名 → objectStore を受け取り、結果を返すリクエストを返してよい。c.abort(err) で取り消し、c.set(v) で結果
const tx = async (names, mode, fn) => {
  const d = await db();
  return new Promise((res, rej) => {
    let t;
    try { t = d.transaction(names, mode); } catch (e) { dbp = null; return rej(e); }
    const s = (n) => t.objectStore(n);
    let out, why = null;
    const ctl = { abort: (err) => { why = err; try { t.abort(); } catch { /* */ } }, set: (v) => { out = v; } };
    try { const r = fn(s, ctl); if (r) r.onsuccess = () => { out = r.result; }; } catch (e) { why = e; try { t.abort(); } catch { /* */ } }
    t.oncomplete = () => res(out);
    t.onabort = () => {
      const er = why || t.error;
      if (why && why.name !== "QuotaExceededError") return rej(why);
      if (er && er.name === "QuotaExceededError") { const e = new Error(quotaMsg + "（使わないファイルや古い版を削除するか、バックアップを書き出してから削除してください）"); e.quota = true; return rej(e); }
      rej(er || new Error("保存に失敗しました"));
    };
  });
};
const metaOf = (id, project, json, prev, extra = {}) => ({ id, name: project.name || "無題", created: prev?.created || Date.now(), updated: Date.now(), size: json.length, features: (project.features || []).length, thumb: prev?.thumb || "", rev: (prev?.rev || 0) + 1, ...extra });

// 別のタブ（画面）が先に保存していたときのエラー
export class ConflictError extends Error {
  constructor(meta) { super("このファイルは別のタブ（画面）で変更されています"); this.name = "ConflictError"; this.meta = meta; }
}

// 閉じる直前に保存が間に合わなかったときの控え（localStorage は同期で書けるので確実に残る）
const RESCUE = "gdc-rescue";
const readRescue = () => { try { const r = JSON.parse(localStorage.getItem(RESCUE) || "null"); return r && r.id && r.json ? r : null; } catch { return null; } };

// 取り込みデータ（大きな文字列）を版の中では参照に置き換える
const BIG = 20000, HB = "@hist-blob";
function splitBlobs(project) {
  const blobs = {};
  const json = JSON.stringify(project, (k, v) => {
    if (v && typeof v === "object" && v.type === "import" && typeof v.data === "string" && v.data.length > BIG && v.dataKey) { blobs[v.dataKey] = v.data; return { ...v, data: HB }; }
    return v;
  });
  return { json, blobs };
}

export const library = {
  revs: {},           // 読み込んだときの保存番号（id → rev）
  times: {},          // 読み込んだときの最終保存時刻
  rescued: new Set(), // 控えから戻したファイル（開いたらすぐ保存し直す）
  newId() { return "D" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); },
  // 一覧（中身は読まない）。壊れた項目は除く
  async list() { const all = await tx(["meta"], "readonly", (s) => s("meta").getAll()); return (all || []).filter((m) => m && typeof m === "object" && m.id).sort((a, b) => (b.updated || 0) - (a.updated || 0)); },
  async meta(id) { return (await tx(["meta"], "readonly", (s) => s("meta").get(id))) || null; },
  // project を保存（thumb を渡したときだけサムネイルを更新）。
  // expectRev を渡すと、保管庫の保存番号が違う（＝別のタブが保存した）ときは保存せず ConflictError
  async save(id, project, { thumb, expectRev } = {}) {
    const json = JSON.stringify(project);
    const m = await tx(["meta", "data"], "readwrite", (s, c) => {
      const g = s("meta").get(id);
      g.onsuccess = () => {
        const prev = g.result || null;
        if (expectRev !== undefined && expectRev !== null && (prev?.rev || 0) !== expectRev) return c.abort(new ConflictError(prev));
        const mm = metaOf(id, project, json, prev, thumb ? { thumb } : {});
        try { s("data").put({ id, json }); s("meta").put(mm); } catch (e) { return c.abort(e); }
        c.set(mm);
      };
    });
    this.revs[id] = m.rev;
    return m;
  },
  // 中身を読む（保存番号も覚える）。閉じる直前の控えの方が新しければそちらを返す
  async load(id) {
    const r = await tx(["data", "meta"], "readonly", (s, c) => {
      const o = {}; c.set(o);
      const a = s("data").get(id), b = s("meta").get(id);
      a.onsuccess = () => { o.v = a.result; }; b.onsuccess = () => { o.m = b.result; };
    });
    const v = r?.v, m = r?.m;
    const res = readRescue();
    if (res && res.id === id && (!m || ((res.t || 0) > (m.updated || 0) && (res.rev ?? 0) === (m.rev || 0)))) {
      try { const p = JSON.parse(res.json); this.revs[id] = m?.rev || 0; this.rescued.add(id); return p; } catch { /* 控えが壊れていれば使わない */ }
    }
    if (!v) return null;
    this.revs[id] = m?.rev || 0; this.times[id] = m?.updated || 0;
    try { return JSON.parse(v.json); } catch { throw new Error(`「${m?.name || "無題"}」の中身が壊れていて開けません（ファイル → 版の履歴 で前の版を開けることがあります）`); }
  },
  revOf(id) { return this.revs[id] ?? null; },
  // 閉じる直前: まだ保存していない内容を控えに書く（大きすぎるものは書けない）
  writeRescue(id, project, rev) {
    try { const json = JSON.stringify(project); if (json.length > 3_500_000) return false; localStorage.setItem(RESCUE, JSON.stringify({ id, t: Date.now(), rev: rev || 0, json })); return true; } catch { return false; }
  },
  clearRescue(id) { try { const r = readRescue(); if (r && (!id || r.id === id)) localStorage.removeItem(RESCUE); } catch { /* */ } },
  async remove(id) {
    await tx(["meta", "data"], "readwrite", (s) => { s("meta").delete(id); s("data").delete(id); });
    this.clearRescue(id);
    await this.removeHistory(id).catch(() => {});
  },
  async rename(id, name) { const p = await this.load(id); if (!p) return; p.name = name; await this.save(id, p); },
  async duplicate(id) { const p = await this.load(id), m = await this.meta(id); if (!p) return null; p.name = (p.name || "無題") + " のコピー"; const nid = this.newId(); await this.save(nid, p, { thumb: m?.thumb }); return nid; },
  // 同じ中身のファイルがすでに保管庫にあれば、その id（.kcad を何度開いても一覧が増えないように）
  async findSame(project) {
    const json = JSON.stringify(project);
    for (const m of await this.list()) {
      if (m.name !== (project.name || "無題") || m.size !== json.length) continue;
      const d = await tx(["data"], "readonly", (s) => s("data").get(m.id));
      if (d && d.json === json) return m.id;
    }
    return null;
  },
  // 端末の使用量と、ブラウザに「消さないで」と頼めているか
  async usage() {
    const est = navigator.storage?.estimate ? await navigator.storage.estimate().catch(() => null) : null;
    const persisted = navigator.storage?.persisted ? await navigator.storage.persisted().catch(() => false) : false;
    return { used: est?.usage ?? null, quota: est?.quota ?? null, persisted };
  },
  async persist() { try { return navigator.storage?.persist ? await navigator.storage.persist() : false; } catch { return false; } },
  // バックアップ（全件を 1 ファイルに）
  async backup() {
    const metas = await this.list(), out = [];
    for (const m of metas) { let p = null; try { p = await this.load(m.id); } catch { /* 壊れた 1 件で全体を止めない */ } if (p) out.push({ id: m.id, created: m.created, updated: m.updated, thumb: m.thumb, project: p }); }
    return JSON.stringify({ format: "gdc-backup", version: 1, created: Date.now(), projects: out });
  },
  // 戻す: 端末にあるものより新しいものだけ入れる。戻した件数を返す
  async restore(text) {
    let b;
    try { b = JSON.parse(text); } catch { throw new Error("ファイルが壊れているか、バックアップファイルではありません"); }
    if (!b || b.format !== "gdc-backup" || !Array.isArray(b.projects)) throw new Error("GDC GOOD DESIGN CAD のバックアップファイルではありません");
    let n = 0;
    for (const it of b.projects) {
      if (!it || !it.project || it.project.format !== "kobocad") continue;
      const id = it.id || this.newId(), cur = await this.meta(id);
      if (cur && cur.updated >= (it.updated || 0)) continue;
      const json = JSON.stringify(it.project);
      const m = { ...metaOf(id, it.project, json, cur, { thumb: it.thumb || "" }), created: it.created || Date.now(), updated: it.updated || Date.now() };
      await tx(["meta", "data"], "readwrite", (s) => { s("data").put({ id, json }); s("meta").put(m); });
      n++;
    }
    return n;
  },

  // ---------------------------------------------------------------- 版の履歴
  // 一覧（新しい順。中身は含めない）
  async history(doc) {
    const all = await tx(["hist"], "readonly", (s) => s("hist").index("doc").getAll(doc));
    return (all || []).map(({ json, ...h }) => ({ ...h, size: json?.length || 0 })).sort((a, b) => b.t - a.t || b.k - a.k);
  },
  async lastVersion(doc) { return (await this.history(doc))[0] || null; },
  // 版を 1 つ加える（kind: auto=自動 / named=名前付き / before=戻す前の状態）。直前の自動の版と同じ中身なら加えない
  async addVersion(doc, project, { kind = "auto", label = "", t = Date.now() } = {}) {
    const { json, blobs } = splitBlobs(project);
    if (kind === "auto") {
      const all = await tx(["hist"], "readonly", (s) => s("hist").index("doc").getAll(doc));
      const prev = (all || []).sort((a, b) => b.t - a.t || b.k - a.k)[0];
      if (prev && prev.json === json) return null;
    }
    const rec = { doc, t, kind, label, name: project.name || "無題", features: (project.features || []).length, json };
    const k = await tx(["hist", "blob"], "readwrite", (s) => {
      for (const [key, data] of Object.entries(blobs)) { const bid = doc + ":" + key; const g = s("blob").get(bid); g.onsuccess = () => { if (!g.result) s("blob").put({ id: bid, doc, data }); }; }
      return s("hist").add(rec);
    });
    await this.pruneHistory(doc).catch(() => {});
    return k;
  },
  async loadVersion(k) {
    const h = await tx(["hist"], "readonly", (s) => s("hist").get(k));
    if (!h) return null;
    const p = JSON.parse(h.json);
    for (const f of p.features || []) {
      if (f && f.type === "import" && f.data === HB) {
        const b = await tx(["blob"], "readonly", (s) => s("blob").get(h.doc + ":" + f.dataKey));
        if (!b) throw new Error("この版の取り込みデータが見つかりません");
        f.data = b.data;
      }
    }
    return p;
  },
  async removeVersion(k) { const h = await tx(["hist"], "readonly", (s) => s("hist").get(k)); await tx(["hist"], "readwrite", (s) => { s("hist").delete(k); }); if (h) await this.gcBlobs(h.doc); },
  async renameVersion(k, label) { await tx(["hist"], "readwrite", (s) => { const g = s("hist").get(k); g.onsuccess = () => { if (g.result) s("hist").put({ ...g.result, label, kind: g.result.kind === "auto" ? "named" : g.result.kind }); }; }); },
  async removeHistory(doc) {
    await tx(["hist", "blob"], "readwrite", (s) => {
      const q = s("hist").index("doc").getAllKeys(doc); q.onsuccess = () => { for (const k of q.result || []) s("hist").delete(k); };
      const b = s("blob").getAllKeys(); b.onsuccess = () => { for (const k of b.result || []) if (String(k).startsWith(doc + ":")) s("blob").delete(k); };
    });
  },
  // 自動の版を間引く: 新しい 20 個はそのまま、それより古いものは 1 日 1 個（30 日まで）。名前付きは残す。
  // 1 ファイルの自動の版が合計 30MB を超えたら古いものから消す
  async pruneHistory(doc, { maxRecent = 20, days = 30, maxBytes = 30_000_000 } = {}) {
    const hs = (await this.history(doc)).filter((h) => h.kind === "auto");
    const drop = [], seenDay = new Set(), now = Date.now();
    let bytes = 0;
    hs.forEach((h, i) => {
      const day = new Date(h.t).toDateString();
      let keep = i < maxRecent || (now - h.t < days * 864e5 && !seenDay.has(day));
      seenDay.add(day);
      if (keep && (bytes += h.size) > maxBytes && i > 0) keep = false;
      if (!keep) drop.push(h.k);
    });
    if (drop.length) { await tx(["hist"], "readwrite", (s) => { for (const k of drop) s("hist").delete(k); }); await this.gcBlobs(doc); }
    return drop.length;
  },
  // どの版からも使われていない取り込みデータを消す
  async gcBlobs(doc) {
    const all = await tx(["hist"], "readonly", (s) => s("hist").index("doc").getAll(doc));
    const used = new Set();
    for (const h of all || []) { try { for (const f of JSON.parse(h.json).features || []) if (f && f.data === HB) used.add(f.dataKey); } catch { /* */ } }
    await tx(["blob"], "readwrite", (s) => { const b = s("blob").getAllKeys(); b.onsuccess = () => { for (const k of b.result || []) { const ks = String(k); if (ks.startsWith(doc + ":") && !used.has(ks.slice(doc.length + 1))) s("blob").delete(k); } }; });
  },
  // 容量が足りないとき: すべてのファイルの自動の版を消す（名前付きは残す）。消した数を返す
  async purgeAutoVersions() {
    const all = await tx(["hist"], "readonly", (s) => s("hist").getAll());
    const ks = (all || []).filter((h) => h.kind === "auto").map((h) => h.k), docs = new Set((all || []).map((h) => h.doc));
    if (ks.length) await tx(["hist"], "readwrite", (s) => { for (const k of ks) s("hist").delete(k); });
    for (const d of docs) await this.gcBlobs(d).catch(() => {});
    return ks.length;
  },
};

export const fmtSize = (n) => n == null ? "?" : n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(0)} KB` : n < 1073741824 ? `${(n / 1048576).toFixed(1)} MB` : `${(n / 1073741824).toFixed(1)} GB`;
export const fmtDate = (t) => { if (!t) return ""; const d = new Date(t), now = new Date(); const hm = `${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`; return d.toDateString() === now.toDateString() ? `今日 ${hm}` : `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()} ${hm}`; };
