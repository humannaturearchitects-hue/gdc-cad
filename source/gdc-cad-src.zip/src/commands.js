// フィーチャ作成・編集ダイアログ
import { store, newId, FEATURE_LABEL } from "./store.js";
import { makeEvaluator } from "./shared/expr.js";

const OPS = [["new", "新規ボディ"], ["join", "結合"], ["cut", "切り取り"], ["intersect", "交差"]];
const AXES = [["X", "X軸"], ["Y", "Y軸"], ["Z", "Z軸"]];

export const DEFS = {
  extrude: {
    fields: (f) => {
      const ext = f.extent || "dist";
      return [
        { key: "items", label: "プロファイル", type: "sel", kinds: ["profile", "face"], multi: true, unit: "個（プロファイル・面）", note: "複数のスケッチの領域や、ボディの平らな面も選べます（もう一度クリックで解除）" },
        { key: "start", label: "開始", type: "select", options: [["profile", "プロファイル平面"], ["offset", "オフセット"]] },
        ...(f.start === "offset" ? [{ key: "startOffset", label: "開始オフセット", type: "expr" }] : []),
        { key: "direction", label: "方向", type: "select", options: ext === "to" ? [["one", "一方向"]] : [["one", "一方向"], ["reverse", "反対方向"], ["symmetric", "対称（中心）"], ["two", "二方向"]] },
        { key: "extent", label: "範囲", type: "select", options: [["dist", "距離"], ["to", "対象まで"], ["all", "全体"]] },
        ...(ext === "dist" ? [{ key: "distance", label: f.direction === "symmetric" ? "距離（全体）" : "距離", type: "expr" }] : []),
        ...(ext === "dist" && f.direction === "two" ? [{ key: "distance2", label: "距離（反対側）", type: "expr" }] : []),
        ...(ext === "to" ? [{ key: "to", label: "対象", type: "sel", kinds: ["face", "plane"], single: true, keepBody: true, note: "ここまで押し出す面・平面（斜めでも可）" }] : []),
        { key: "operation", label: "操作", type: "select", options: OPS },
        ...(f.operation === "join" || f.operation === "intersect" ? [{ key: "target", label: "対象ボディ", type: "body" }] : []),
        ...(f.operation === "cut" ? [{ key: "targets", label: "切り取るボディ", type: "bodies", note: "空欄なら重なる全ボディ" }] : []),
        ...(f.operation === "new" || !f.operation ? [{ key: "bodyName", label: "ボディ名", type: "text" }] : []),
      ];
    },
    init: () => ({ items: [], distance: "10", direction: "one", extent: "dist", start: "profile", startOffset: "0", operation: "new" }),
  },
  revolve: {
    fields: (f) => [
      { key: "profiles", label: "プロファイル", type: "sel", kinds: ["profile"], multi: true },
      { key: "axis", label: "回転軸", type: "select", options: [["v", "スケッチのY軸（縦）"], ["u", "スケッチのX軸（横）"]] },
      { key: "angle", label: "角度°", type: "expr" },
      { key: "operation", label: "操作", type: "select", options: OPS },
      ...(f.operation === "join" || f.operation === "intersect" ? [{ key: "target", label: "対象ボディ", type: "body" }] : []),
      ...(f.operation === "new" || !f.operation ? [{ key: "bodyName", label: "ボディ名", type: "text" }] : []),
    ],
    init: () => ({ profiles: [], axis: "v", angle: "360", operation: "new" }),
  },
  box: {
    fields: (f) => [
      { key: "position", label: "基準点 X,Y,Z", type: "vec3" },
      { key: "w", label: "幅 (X)", type: "expr" }, { key: "d", label: "奥行 (Y)", type: "expr" }, { key: "h", label: "高さ (Z)", type: "expr" },
      { key: "operation", label: "操作", type: "select", options: OPS },
      ...(f.operation === "join" || f.operation === "intersect" ? [{ key: "target", label: "対象ボディ", type: "body" }] : []),
      ...(f.operation === "new" ? [{ key: "bodyName", label: "ボディ名", type: "text" }] : []),
    ],
    init: () => ({ position: ["0", "0", "0"], w: "100", d: "100", h: "100", operation: "new" }),
  },
  cylinder: {
    fields: (f) => [
      { key: "position", label: "底面中心 X,Y,Z", type: "vec3" },
      { key: "axis", label: "軸方向", type: "select", options: AXES },
      { key: "d", label: "直径", type: "expr" }, { key: "h", label: "高さ", type: "expr" },
      { key: "operation", label: "操作", type: "select", options: OPS },
      ...(f.operation === "join" || f.operation === "intersect" ? [{ key: "target", label: "対象ボディ", type: "body" }] : []),
      ...(f.operation === "new" ? [{ key: "bodyName", label: "ボディ名", type: "text" }] : []),
    ],
    init: () => ({ position: ["0", "0", "0"], axis: "Z", d: "50", h: "100", operation: "new" }),
  },
  sphere: {
    fields: (f) => [
      { key: "position", label: "中心 X,Y,Z", type: "vec3" },
      { key: "d", label: "直径", type: "expr" },
      { key: "operation", label: "操作", type: "select", options: OPS },
      ...(f.operation === "join" || f.operation === "intersect" ? [{ key: "target", label: "対象ボディ", type: "body" }] : []),
      ...(f.operation === "new" ? [{ key: "bodyName", label: "ボディ名", type: "text" }] : []),
    ],
    init: () => ({ position: ["0", "0", "0"], d: "100", operation: "new" }),
  },
  fillet: {
    fields: () => [
      { key: "edges", label: "エッジ", type: "sel", kinds: ["edge"], multi: true },
      { key: "radius", label: "半径", type: "expr" },
    ],
    init: () => ({ edges: [], radius: "5" }),
  },
  chamfer: {
    fields: () => [
      { key: "edges", label: "エッジ", type: "sel", kinds: ["edge"], multi: true },
      { key: "radius", label: "距離", type: "expr" },
    ],
    init: () => ({ edges: [], radius: "3" }),
  },
  shell: {
    fields: () => [
      { key: "faces", label: "除去する面", type: "sel", kinds: ["face"], multi: true },
      { key: "thickness", label: "厚さ", type: "expr", note: "正: 内側 / 負: 外側" },
    ],
    init: () => ({ faces: [], thickness: "2" }),
  },
  move: {
    fields: () => [
      { key: "bodies", label: "ボディ", type: "bodies" },
      { key: "translate", label: "移動 X,Y,Z", type: "vec3" },
      { key: "rotAxis", label: "回転軸", type: "select", options: AXES },
      { key: "angle", label: "回転角°", type: "expr" },
      { key: "center", label: "回転中心", type: "vec3" },
      { key: "copy", label: "コピーを作成", type: "check" },
    ],
    init: () => ({ bodies: [], translate: ["0", "0", "0"], rotAxis: "Z", angle: "0", center: ["0", "0", "0"], copy: false }),
  },
  mirror: {
    fields: () => [
      { key: "bodies", label: "ボディ", type: "bodies" },
      { key: "plane", label: "対称面", type: "select", options: [["YZ", "YZ平面（X反転）"], ["XZ", "XZ平面（Y反転）"], ["XY", "XY平面（Z反転）"]] },
      { key: "offset", label: "面の位置", type: "expr" },
      { key: "join", label: "元と結合", type: "check" },
    ],
    init: () => ({ bodies: [], plane: "YZ", offset: "0", join: false }),
  },
  pattern: {
    fields: (f) => [
      { key: "bodies", label: "ボディ", type: "bodies" },
      { key: "dir", label: "方向1", type: "select", options: AXES },
      { key: "count", label: "数量1", type: "expr" }, { key: "spacing", label: "間隔1", type: "expr" },
      { key: "dir2", label: "方向2", type: "select", options: [["", "なし"], ...AXES] },
      ...(f.dir2 ? [{ key: "count2", label: "数量2", type: "expr" }, { key: "spacing2", label: "間隔2", type: "expr" }] : []),
      { key: "join", label: "1つのボディに結合", type: "check" },
    ],
    init: () => ({ bodies: [], dir: "X", count: "3", spacing: "100", dir2: "", count2: "2", spacing2: "100", join: false }),
  },
  hole: {
    fields: (f) => {
      const pl = f.placement || ((f.points || []).length ? "legacy" : "single");
      const ref = f.ref || "corner";
      return [
        { key: "placement", label: "配置", type: "select", options: [["coords", "座標で指定"], ["sketch", "スケッチの点から"], ...(pl === "single" ? [["single", "面＋基準エッジ（旧）"]] : []), ...(pl === "legacy" ? [["legacy", "クリックした位置（旧）"]] : [])] },
        ...(pl === "coords" ? [
          { key: "face", label: "面", type: "sel", kinds: ["face"], single: true, note: "穴をあける面をクリック（位置は下の数値で決めます）" },
          { key: "ref", label: "基準 (0, 0)", type: "select", options: [["corner", "面の左下の角"], ["origin", "原点"], ["edges", "2 本の辺"], ["circle", "丸い辺の中心（同心）"]] },
          ...(ref === "circle" ? [{ key: "ref1", label: "丸い辺", type: "sel", kinds: ["edge"], single: true, note: "穴・円柱の縁をクリック。位置 0, 0 でちょうど同心" }] : []),
          ...(ref === "edges" ? [
            { key: "ref1", label: "辺 1（X の基準）", type: "sel", kinds: ["edge"], single: true },
            { key: "ref2", label: "辺 2（Y の基準）", type: "sel", kinds: ["edge"], single: true },
          ] : []),
          { key: "pos", label: ref === "edges" ? "位置（辺1から, 辺2から）" : "位置 X, Y（mm）", type: "pts2d", note: "穴ごとに 1 行。式・パラメータも使えます。画面の寸法ラベルをクリックすると、その欄に移ります" },
        ] : pl === "single" ? [
          { key: "face", label: "面", type: "sel", kinds: ["face"], single: true },
          { key: "ref1", label: "基準エッジ 1", type: "sel", kinds: ["edge"], single: true },
          ...(f.ref1 ? [{ key: "off1", label: "辺 1 からの距離", type: "expr" }] : []),
          ...(f.ref1 ? [{ key: "ref2", label: "基準エッジ 2", type: "sel", kinds: ["edge"], single: true }] : []),
          ...(f.ref2 ? [{ key: "off2", label: "辺 2 からの距離", type: "expr" }] : []),
        ] : pl === "sketch" ? [
          { key: "sketchRef", label: "スケッチ", type: "sketch", note: "そのスケッチの「点」と円の中心すべてに穴をあけます" },
          { key: "useCircles", label: "円の中心も使う", type: "check" },
          { key: "flip", label: "向きを反転", type: "check" },
        ] : [
          { key: "points", label: "穴の位置", type: "sel", kinds: ["face"], multi: true, unit: "箇所" },
        ]),
        { key: "style", label: "種類", type: "select", options: [["simple", "シンプル"], ["cbore", "ざぐり"], ["csink", "皿もみ"]] },
        { key: "d", label: "穴径", type: "expr" },
        { key: "through", label: "貫通（全体）", type: "check" },
        ...(!f.through ? [{ key: "depth", label: "深さ", type: "expr" }] : []),
        ...(f.style === "cbore" ? [{ key: "cboreD", label: "ざぐり径", type: "expr" }, { key: "cboreDepth", label: "ざぐり深さ", type: "expr" }] : []),
        ...(f.style === "csink" ? [{ key: "csinkD", label: "皿径", type: "expr" }, { key: "csinkAngle", label: "皿角度°", type: "expr" }] : []),
      ];
    },
    init: () => ({ placement: "coords", face: null, ref: "corner", ref1: null, ref2: null, pos: [], off1: "0", off2: "0", sketchRef: "", useCircles: true, flip: false, points: [], style: "simple", d: "10", through: true, depth: "20", cboreD: "18", cboreDepth: "6", csinkD: "20", csinkAngle: "90" }),
  },
  plane: {
    fields: (f) => {
      const k = f.kind || "offset";
      return [
        { key: "kind", label: "種類", type: "select", options: [["offset", "オフセット平面"], ["angle", "角度の平面"], ["mid", "中間の平面"]] },
        ...(k === "offset" ? [
          { key: "base", label: "基準", type: "sel", kinds: ["face", "plane"], single: true, keepBody: true, note: "面か平面（XY/XZ/YZ・構築平面）をクリック" },
          { key: "distance", label: "距離", type: "expr", note: "マイナスで反対側" },
        ] : k === "mid" ? [
          { key: "base", label: "面 1", type: "sel", kinds: ["face", "plane"], single: true, keepBody: true },
          { key: "base2", label: "面 2", type: "sel", kinds: ["face", "plane"], single: true, keepBody: true, note: "2 つの面のちょうど真ん中に平面を作ります" },
        ] : [
          { key: "edge", label: "回転の軸", type: "sel", kinds: ["edge"], single: true, note: "直線のエッジ" },
          { key: "base", label: "基準の面", type: "sel", kinds: ["face", "plane"], single: true, keepBody: true, note: "角度 0° のときの面（軸を含む面）" },
          { key: "angle", label: "角度°", type: "expr" },
        ]),
      ];
    },
    init: () => ({ kind: "offset", base: null, base2: null, edge: null, distance: "100", angle: "45" }),
  },
  cpattern: {
    fields: () => [
      { key: "bodies", label: "ボディ", type: "bodies" },
      { key: "axis", label: "回転軸", type: "select", options: AXES },
      { key: "center", label: "軸の位置", type: "vec3" },
      { key: "count", label: "数量", type: "expr" },
      { key: "angle", label: "全体の角度°", type: "expr", note: "360 で一周に均等配置" },
      { key: "join", label: "1つのボディに結合", type: "check" },
    ],
    init: () => ({ bodies: [], axis: "Z", center: ["0", "0", "0"], count: "6", angle: "360", join: false }),
  },
  presspull: {
    fields: () => [
      { key: "face", label: "面", type: "sel", kinds: ["face"], single: true },
      { key: "distance", label: "距離", type: "expr", note: "＋で外へ押し出し（結合）、－で押し込み（切り取り）" },
      { key: "operation", label: "操作", type: "select", options: [["join", "ボディを変更"], ["new", "新規ボディとして作成"]] },
    ],
    init: () => ({ face: null, distance: "10", operation: "join" }),
  },
  split: {
    fields: (f) => [
      { key: "body", label: "分割するボディ", type: "body" },
      { key: "plane", label: "分割面", type: "select", options: [["XY", "XY 平面（高さ）"], ["XZ", "XZ 平面（奥行）"], ["YZ", "YZ 平面（幅）"], ["face", "選んだ平らな面"]] },
      ...(f.plane === "face" ? [{ key: "face", label: "面", type: "sel", kinds: ["face"], single: true, keepBody: true }] : [{ key: "offset", label: "平面の位置", type: "expr" }]),
    ],
    init: () => ({ body: "", plane: "YZ", offset: "0", face: null }),
  },
  loft: {
    fields: (f) => [
      { key: "sections", label: "断面", type: "sel", kinds: ["profile"], multi: true, unit: "断面", note: "別々のスケッチのプロファイルを順番にクリック（2つ以上）" },
      { key: "ruled", label: "直線でつなぐ", type: "check" },
      { key: "operation", label: "操作", type: "select", options: OPS },
      ...(f.operation === "join" || f.operation === "intersect" ? [{ key: "target", label: "対象ボディ", type: "body" }] : []),
      ...(f.operation === "new" ? [{ key: "bodyName", label: "ボディ名", type: "text" }] : []),
    ],
    init: () => ({ sections: [], ruled: false, operation: "new" }),
  },
  align: {
    fields: () => [
      { key: "from", label: "動かす面", type: "sel", kinds: ["face"], single: true, note: "動かしたい部品の面" },
      { key: "to", label: "合わせる面", type: "sel", kinds: ["face"], single: true, note: "相手の部品の面（向かい合わせにくっつけます）" },
      { key: "mode", label: "合わせ方", type: "select", options: [["center", "面の中心どうしを合わせる"], ["plane", "面の高さだけ合わせる"]] },
      { key: "flip", label: "同じ向きにする", type: "check" },
      { key: "offset", label: "すき間", type: "expr" },
    ],
    init: () => ({ from: null, to: null, mode: "center", flip: false, offset: "0" }),
  },
  joint: {
    fields: (f) => [
      { key: "kind", label: "種類", type: "select", options: [["revolute", "回転（ヒンジ）"], ["slider", "スライド"]] },
      { key: "bodies", label: "動かす部品", type: "bodies" },
      { key: "axis", label: "軸", type: "sel", kinds: ["edge"], single: true, note: f.kind === "slider" ? "動かす方向の直線エッジ" : "ヒンジの軸になる直線エッジ、またはピン（円）のエッジ。開く向きが逆なら角度の符号（＋／－）を逆に" },
      { key: "value", label: f.kind === "slider" ? "移動量 mm" : "角度°", type: "expr" },
      { key: "min", label: "可動範囲 最小", type: "expr" },
      { key: "max", label: "可動範囲 最大", type: "expr" },
    ],
    init: () => ({ kind: "revolute", bodies: [], axis: null, value: "0", min: "0", max: "90" }),
    actions: [
      ["▶ 動かしてみる", (app, d) => app.animateJoint(d)],
      ["可動範囲の干渉チェック", (app, d) => app.jointSweepCheck(d)],
    ],
  },
  combine: {
    fields: () => [
      { key: "target", label: "ターゲット", type: "body" },
      { key: "tools", label: "ツールボディ", type: "bodies" },
      { key: "op", label: "操作", type: "select", options: [["join", "結合"], ["cut", "切り取り"], ["intersect", "交差"]] },
      { key: "keepTools", label: "ツールを保持", type: "check" },
    ],
    init: () => ({ target: "", tools: [], op: "join", keepTools: false }),
  },
};

export class CommandDialog {
  constructor(app) {
    this.app = app;
    this.el = document.getElementById("dialog");
    this.active = null;
    makeDraggable(this.el);
  }

  get isOpen() { return !!this.active; }

  open(type, editId = null) {
    this.close(false);
    this.autoProfile = false;
    const def = DEFS[type];
    let draft;
    if (editId) draft = JSON.parse(JSON.stringify(store.feature(editId)));
    else {
      draft = { id: newId(), type, name: store.nameFor(type), ...def.init() };
      // 選択中のものを初期値に
      const pre = this.app.preselect;
      if (pre && pre.length) {
        if (["fillet", "chamfer"].includes(type)) { const es = pre.filter((s) => s.kind === "edge"); if (es.length) { draft.body = es[0].bodyId; draft.edges = es.map((e) => [...e.point, ...(e.dir || [])]); } }
        if (["move", "mirror", "pattern", "cpattern", "joint"].includes(type)) draft.bodies = [...new Set(pre.filter((s) => s.bodyId).map((s) => s.bodyId))];
      }
      if (type === "extrude" || type === "revolve") {
        const sk = [...store.project.features].reverse().find((f) => f.type === "sketch");
        if (sk) {
          draft.sketch = sk.id;
          const loops = this.app.sketchLoops(sk.id) || [];
          if (loops.length === 1) { draft.profiles = [0]; this.autoProfile = true; if (type === "extrude") draft.items = [{ sketch: sk.id, loop: 0 }]; }
          if (type === "extrude" && loops.length) {
            // 既定の距離: 形の大きさの約 2 割（見て分かる厚み）
            let D = 0;
            for (const l of loops) D = Math.max(D, l.bbox.max[0] - l.bbox.min[0], l.bbox.max[1] - l.bbox.min[1]);
            const raw = D * 0.2, p10 = Math.pow(10, Math.floor(Math.log10(raw || 1)));
            const nice = [1, 2, 5, 10].map((m) => m * p10).find((v) => v >= raw * 0.7) || 10;
            draft.distance = String(+nice.toFixed(6));
          }
          // Fusion と同じく、ボディの面に描いたスケッチはそのボディに「結合」が既定
          if (sk.plane && sk.plane.type === "face" && sk.plane.ref && this.app.meshes.some((m) => m.id === sk.plane.ref.body)) {
            draft.operation = type === "extrude" || type === "revolve" ? "join" : draft.operation;
            draft.target = sk.plane.ref.body;
          }
          this.app.tiltForSketch(sk.id);
        }
        // 先に選んであったプロファイル・面を使う
        const pp = (pre || []).filter((s) => s.kind === "profile" || s.kind === "face");
        if (type === "extrude" && pp.length) {
          this.autoProfile = false;
          draft.items = pp.map((h) => h.kind === "profile" ? { sketch: h.sketch, loop: h.loop } : { face: { body: h.bodyId, point: h.point.map((v) => +v.toFixed(5)), normal: (h.normal || [0, 0, 1]).map((v) => +v.toFixed(6)), group: h.group ? h.group.start : -1 } });
          const first = draft.items.find((x) => x.sketch);
          draft.sketch = first ? first.sketch : null;
          draft.profiles = first ? draft.items.filter((x) => x.sketch === first.sketch).map((x) => x.loop) : [];
          const face = pp.find((s) => s.kind === "face");
          if (face) { draft.operation = "join"; draft.target = face.bodyId; }
          else if (first) { const skf = store.feature(first.sketch); draft.operation = skf && skf.plane && skf.plane.type === "face" && skf.plane.ref ? "join" : "new"; if (draft.operation === "join") draft.target = skf.plane.ref.body; }
        }
      }
    }
    this.active = { type, draft, editId, activeSel: null };
    this.touched = !!editId;
    const firstSel = def.fields(draft).find((f) => ["sel", "bodies", "body"].includes(f.type));
    if (firstSel) this.active.activeSel = firstSel.key;
    this.render();
    this.app.onCommandStart(this);
    this.preview();
  }

  selKinds() {
    if (!this.active || !this.active.activeSel) return [];
    const f = DEFS[this.active.type].fields(this.active.draft).find((x) => x.key === this.active.activeSel);
    if (!f) return [];
    if (f.type === "sel") return f.kinds;
    return ["body"];
  }

  // ビューポートでのピック結果を受け取る
  onPick(hit) {
    if (!this.active || !hit) return false;
    this.touched = true;
    const d = this.active.draft;
    const key = this.active.activeSel;
    const field = DEFS[this.active.type].fields(d).find((x) => x.key === key);
    if (!field) return false;
    const fpt = () => [...hit.point.map((v) => +v.toFixed(5)), ...(hit.normal || [0, 0, 1]).map((v) => +v.toFixed(6))];
    if (field.type === "sel" && hit.kind === "profile" && key === "sections") {
      const arr = d.sections || [];
      const k = arr.findIndex((x) => x.sketch === hit.sketch);
      if (k >= 0 && arr[k].profile === hit.loop) arr.splice(k, 1);
      else if (k >= 0) arr[k] = { sketch: hit.sketch, profile: hit.loop };
      else arr.push({ sketch: hit.sketch, profile: hit.loop });
      d.sections = arr;
    } else if (field.type === "sel" && hit.kind === "edge" && field.single) {
      d[key] = [...hit.point.map((v) => +v.toFixed(5)), ...(hit.dir || [])];
      if (this.active.type === "plane") { const sels = DEFS.plane.fields(d).filter((x) => x.type === "sel"); const nxt = sels[sels.findIndex((x) => x.key === key) + 1]; if (nxt && !d[nxt.key]) this.active.activeSel = nxt.key; }
      // 穴: クリックした位置から辺までの今の距離を初期値に（あとで数値を打ち替える）
      if (this.active.type === "hole" && (key === "ref1" || key === "ref2") && d.face) {
        const P = d.face.slice(0, 3), n = d.face.slice(3, 6), Q = hit.point, D = hit.dir;
        if (D && D.length === 3) {
          const w = [0, 1, 2].map((i) => P[i] - Q[i]);
          const dd = w[0] * D[0] + w[1] * D[1] + w[2] * D[2], dn = w[0] * n[0] + w[1] * n[1] + w[2] * n[2];
          const r = [0, 1, 2].map((i) => w[i] - D[i] * dd - n[i] * dn);
          d[key === "ref1" ? "off1" : "off2"] = String(+Math.hypot(...r).toFixed(1));
        }
        const sels = DEFS.hole.fields(d).filter((x) => x.type === "sel");
        const nxt = sels[sels.findIndex((x) => x.key === key) + 1];
        if (nxt && !d[nxt.key]) this.active.activeSel = nxt.key;
      }
    } else if (field.type === "sel" && hit.kind === "face" && field.single) {
      d[key] = fpt();
      if (key === "to") d.toBody = hit.bodyId; else if (!field.keepBody) d.body = hit.bodyId;
      // 構築平面の基準面は、形を変えたときに面について行けるよう参照を残す
      d[key + "Ref"] = { body: hit.bodyId, point: hit.point.map((v) => +v.toFixed(4)) };
      // 穴（座標）: 面を選んだら、次は面の上で位置を置くモードへ
      if (this.active.type === "hole" && key === "face" && (d.placement || "single") === "coords" && (d.ref || "corner") !== "edges" && (d.ref !== "circle" || d.ref1)) this.active.activeSel = "pos";
      // 次の選択欄へ自動で進む
      const sels = DEFS[this.active.type].fields(d).filter((x) => x.type === "sel");
      const nxt = sels[sels.findIndex((x) => x.key === key) + 1];
      if (nxt && !d[nxt.key]) this.active.activeSel = nxt.key;
    } else if (field.type === "sel" && hit.kind === "face" && key === "points") {
      const arr = d.points || [];
      arr.push(fpt());
      d.points = arr;
      if (!d.body) d.body = hit.bodyId;
    } else if (field.type === "sel" && key === "items" && (hit.kind === "profile" || hit.kind === "face")) {
      // 押し出し: プロファイル（どのスケッチでも）と平らな面を混ぜて選べる
      const arr = d.items || [];
      const same = (x) => hit.kind === "profile" ? (x.sketch === hit.sketch && x.loop === hit.loop) : (x.face && x.face.body === hit.bodyId && hit.group && x.face.group === hit.group.start);
      const k = arr.findIndex(same);
      if (k >= 0 && this.autoProfile) { /* 自動で選んだものは最初のクリックで外さない */ }
      else if (k >= 0) arr.splice(k, 1);
      else arr.push(hit.kind === "profile" ? { sketch: hit.sketch, loop: hit.loop } : { face: { body: hit.bodyId, point: hit.point.map((v) => +v.toFixed(5)), normal: (hit.normal || [0, 0, 1]).map((v) => +v.toFixed(6)), group: hit.group ? hit.group.start : -1 } });
      this.autoProfile = false;
      d.items = arr;
      // 面を選んだら、結合先はその面のボディ（Fusion と同じ）。最初の 1 つ目の面のときは結合を既定に
      if (hit.kind === "face" && k < 0) { if (!this.active.editId && (!d.operation || d.operation === "new") && arr.length === 1) d.operation = "join"; if (!d.target) d.target = hit.bodyId; }
      const first = arr.find((x) => x.sketch);
      d.sketch = first ? first.sketch : null;
      d.profiles = first ? arr.filter((x) => x.sketch === first.sketch).map((x) => x.loop) : [];
    } else if (field.type === "sel" && hit.kind === "plane" && field.single) {
      // 基準平面（原点の XY/XZ/YZ）を対象に
      const fr = this.app.planeFrame(hit);
      if (fr) { d[key] = [...fr.origin, ...fr.normal]; delete d[key + "Ref"]; if (hit.frame) d[key + "Plane"] = hit.name; else delete d[key + "Plane"]; }
      const sels = DEFS[this.active.type].fields(d).filter((x) => x.type === "sel");
      const nxt = sels[sels.findIndex((x) => x.key === key) + 1];
      if (nxt && !d[nxt.key]) this.active.activeSel = nxt.key;
    } else if (field.type === "sel" && hit.kind === "profile") {
      if (d.sketch && d.sketch !== hit.sketch) { d.profiles = []; }
      d.sketch = hit.sketch;
      const arr = d.profiles || [];
      const k = arr.indexOf(hit.loop);
      // 自動で選んでおいたプロファイルを最初にクリックしたときは、外さずにそのまま（選んだつもりが解除される混乱を防ぐ）
      if (k >= 0 && this.autoProfile) { /* keep */ }
      else if (k >= 0) arr.splice(k, 1); else arr.push(hit.loop);
      this.autoProfile = false;
      d.profiles = arr;
    } else if (field.type === "sel" && hit.kind === "edge") {
      if (d.body && d.body !== hit.bodyId) { d.edges = []; }
      d.body = hit.bodyId;
      const arr = d.edges || [];
      const k = arr.findIndex((p) => dist3(p, hit.point) < 1e-3);
      if (k >= 0) arr.splice(k, 1); else arr.push([...hit.point.map((v) => +v.toFixed(5)), ...(hit.dir || [])]);
      d.edges = arr;
    } else if (field.type === "sel" && hit.kind === "face") {
      if (d.body && d.body !== hit.bodyId) { d.faces = []; }
      d.body = hit.bodyId;
      const arr = d.faces || [];
      arr.push(hit.point.map((v) => +v.toFixed(5)));
      d.faces = arr;
    } else if ((field.type === "bodies") && hit.bodyId) {
      const arr = d[key] || [];
      const k = arr.indexOf(hit.bodyId);
      if (k >= 0) arr.splice(k, 1); else arr.push(hit.bodyId);
      d[key] = arr;
    } else if (field.type === "body" && hit.bodyId) {
      d[key] = hit.bodyId;
    } else return false;
    this.render();
    this.preview();
    return true;
  }

  render() {
    const { type, draft } = this.active;
    const def = DEFS[type];
    const num = makeEvaluator(store.project.params || []);
    const fields = def.fields(draft);
    const bodies = this.app.bodyList();
    const html = [];
    html.push(`<div class="dlg-head"><span>${FEATURE_LABEL[type]}${this.active.editId ? "（編集）" : ""}</span><button class="x" data-act="cancel">×</button></div>`);
    html.push(`<div class="dlg-body">`);
    for (const f of fields) {
      const v = draft[f.key];
      html.push(`<label>${f.label}</label>`);
      if (f.type === "expr") {
        let bad = false; try { num(v); } catch { bad = true; }
        html.push(`<input type="text" data-k="${f.key}" value="${esc(v ?? "")}" class="${bad ? "err" : ""}" />`);
        if (f.note) html.push(`<div class="dlg-note">${f.note}</div>`);
      } else if (f.type === "text") {
        html.push(`<input type="text" data-k="${f.key}" value="${esc(v ?? "")}" placeholder="自動" />`);
      } else if (f.type === "select") {
        html.push(`<select data-k="${f.key}">${f.options.map(([ov, ol]) => `<option value="${ov}" ${String(v ?? "") === ov ? "selected" : ""}>${ol}</option>`).join("")}</select>`);
      } else if (f.type === "check") {
        html.push(`<input type="checkbox" data-k="${f.key}" ${v ? "checked" : ""} />`);
      } else if (f.type === "vec3") {
        const a = v || ["0", "0", "0"];
        html.push(`<div style="display:flex;gap:4px">${[0, 1, 2].map((i) => `<input type="text" data-k="${f.key}" data-i="${i}" value="${esc(a[i])}" />`).join("")}</div>`);
      } else if (f.type === "sel") {
        const n = f.single ? (v ? 1 : 0) : (v || []).length;
        const unit = f.unit || (f.kinds[0] === "profile" ? "個のプロファイル" : f.kinds[0] === "edge" ? "本のエッジ" : "枚の面");
        const label = f.single ? (n ? "選択済み ✓" : "クリックして選択") : (n ? n + unit : "選択してください");
        html.push(`<div class="selfield ${this.active.activeSel === f.key ? "active" : ""}" data-sel="${f.key}"><span class="cnt">${label}</span>${n ? `<button class="clr" data-clr="${f.key}">×</button>` : ""}</div>`);
        if (f.note) html.push(`<div class="dlg-note">${f.note}</div>`);
      } else if (f.type === "bodies") {
        const arr = v || [];
        html.push(`<div class="selfield ${this.active.activeSel === f.key ? "active" : ""}" data-sel="${f.key}"><span class="cnt">${arr.length ? arr.map((id) => esc(bodies.find((b) => b.id === id)?.name || id)).join(", ") : "ビューでボディを選択"}</span>${arr.length ? `<button class="clr" data-clr="${f.key}">×</button>` : ""}</div>`);
        if (f.note) html.push(`<div class="dlg-note">${f.note}</div>`);
      } else if (f.type === "pts2d") {
        const rows = Array.isArray(v) && v.length ? v : [["", ""]];
        const hdr = (draft.ref || "corner") === "edges" ? ["辺 1 から", "辺 2 から"] : ["X", "Y"];
        html.push(`<div class="pts2d full"><div class="pt-row pt-hdr"><span></span><span>${hdr[0]}</span><span>${hdr[1]}</span><span></span></div>${rows.map((r, ri) => `<div class="pt-row"><span class="pt-n">${ri + 1}</span><input type="text" data-pt="${ri}" data-c="0" value="${esc(r[0])}" /><input type="text" data-pt="${ri}" data-c="1" value="${esc(r[1])}" />${rows.length > 1 ? `<button class="pt-del" data-ptdel="${ri}" title="この穴を消す">×</button>` : ""}</div>`).join("")}<button class="btn pt-add" data-ptadd="1">＋ 穴を追加</button></div>`);
        if (f.note) html.push(`<div class="dlg-note">${f.note}</div>`);
      } else if (f.type === "sketch") {
        const sks = store.project.features.filter((x) => x.type === "sketch");
        if (!v && sks.length) { const last = [...sks].reverse().find((x) => (x.entities || []).some((e) => e.type === "point" || e.type === "circle")) || sks[sks.length - 1]; draft[f.key] = v || last.id; }
        const cur = draft[f.key];
        html.push(`<select data-k="${f.key}">${sks.map((x) => { const np = (x.entities || []).filter((e) => e.type === "point").length, nc = (x.entities || []).filter((e) => e.type === "circle").length; return `<option value="${x.id}" ${cur === x.id ? "selected" : ""}>${esc(x.name)}（点 ${np}・円 ${nc}）</option>`; }).join("")}</select>`);
        if (f.note) html.push(`<div class="dlg-note">${f.note}</div>`);
      } else if (f.type === "body") {
        html.push(`<select data-k="${f.key}"><option value="">（最後のボディ）</option>${bodies.map((b) => `<option value="${b.id}" ${v === b.id ? "selected" : ""}>${esc(b.name)}</option>`).join("")}</select>`);
      }
    }
    // まだ何も選んでいないうちは、赤いエラーではなく「次にすること」の案内として出す（Fusion と同じ）
    if (this.error) html.push(this.touched ? `<div class="dlg-err">⚠ ${esc(this.error)}</div>` : `<div class="dlg-hint">→ ${esc(this.error)}</div>`);
    const acts = def.actions || [];
    html.push(`</div><div class="dlg-foot">${acts.map(([l], i) => `<button class="btn" data-x="${i}" style="margin-right:auto">${l}</button>`).join("")}<button class="btn" data-act="cancel">キャンセル</button><button class="btn primary" data-act="ok">OK</button></div>`);
    this.el.innerHTML = html.join("");
    this.el.classList.remove("hidden");
    this.el.querySelectorAll("[data-pt]").forEach((inp) => {
      const ri = +inp.dataset.pt, ci = +inp.dataset.c;
      inp.addEventListener("input", () => {
        draft.pos = (draft.pos || []).map((r) => [...r]); if (!draft.pos[ri]) draft.pos[ri] = ["", ""]; draft.pos[ri][ci] = inp.value;
        let bad = false; try { num(inp.value); } catch { bad = true; } inp.classList.toggle("err", bad);
        this.preview();
      });
      inp.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") this.ok(); if (e.key === "Escape") this.close(); });
      inp.addEventListener("focus", () => { inp.select(); this.app.focusHoleDim && this.app.focusHoleDim(ri, ci); });
    });
    this.el.querySelectorAll("[data-ptadd]").forEach((b) => b.addEventListener("click", () => {
      const rows = (draft.pos || []).filter((r) => r[0] !== "" || r[1] !== "").map((r) => [...r]); const last = rows[rows.length - 1] || ["0", "0"];
      // 次の穴は前の穴の横（X + 50）に。数値を打ち替えて使う
      let nx = last[0]; try { nx = String(+(num(last[0]) + 50).toFixed(3)); } catch { /* */ }
      rows.push([nx, last[1]]); draft.pos = rows; this.render(); this.preview();
      const ins = this.el.querySelectorAll(`[data-pt="${rows.length - 1}"]`); if (ins[0]) ins[0].focus();
    }));
    this.el.querySelectorAll("[data-ptdel]").forEach((b) => b.addEventListener("click", () => { const rows = (draft.pos || []).filter((_, i) => i !== +b.dataset.ptdel); draft.pos = rows; this.render(); this.preview(); }));
    this.el.querySelectorAll("[data-k]").forEach((inp) => {
      const k = inp.dataset.k;
      const ev = inp.tagName === "SELECT" || inp.type === "checkbox" ? "change" : "input";
      inp.addEventListener(ev, () => {
        this.touched = true;
        if (inp.dataset.i !== undefined) { draft[k] = [...(draft[k] || ["0", "0", "0"])]; draft[k][+inp.dataset.i] = inp.value; }
        else if (inp.type === "checkbox") draft[k] = inp.checked;
        else draft[k] = inp.value;
        // 切り取りにしたら、材料の中へ向けて貫通を既定に（Fusion と同じく、面から外向きに削って何も起きない、を防ぐ）
        if (type === "extrude" && k === "operation" && inp.value === "cut" && !this.active.editId && !draft._cutDefaults) {
          draft._cutDefaults = true;
          draft.extent = "all";
          const sk = store.feature(draft.sketch);
          if ((draft.direction || "one") === "one") draft.direction = sk && sk.plane && sk.plane.type === "face" ? "reverse" : "symmetric";
        }
        // 距離をマイナスにしたら切り取りに（Fusion と同じ）
        if (type === "extrude" && k === "distance" && !this.active.editId && (draft.operation === "new" || draft.operation === "join")) {
          let v = NaN; try { v = num(inp.value); } catch { /* */ }
          if (v < 0) { draft.operation = "cut"; draft._autoCut = true; this.render(); this.preview(); const el = this.el.querySelector('[data-k="distance"]'); if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } return; }
        }
        if (inp.tagName === "SELECT" || inp.type === "checkbox") {
          // 欄の構成が変わったら、まだ選んでいない最初の選択欄へ
          const sels = DEFS[type].fields(draft).filter((x) => ["sel", "bodies", "body"].includes(x.type));
          const empty = (x) => { const v = draft[x.key]; return v === null || v === undefined || v === "" || (Array.isArray(v) && !v.length); };
          const cur = sels.find((x) => x.key === this.active.activeSel);
          const e = sels.find(empty);
          if (e) this.active.activeSel = e.key; else if (!cur && sels[0]) this.active.activeSel = sels[0].key;
          this.render(); this.app.onCommandStart(this);
        } else { let bad = false; if (DEFS[type].fields(draft).find((x) => x.key === k)?.type === "expr") { try { num(inp.value); } catch { bad = true; } } inp.classList.toggle("err", bad); }
        this.preview();
      });
      inp.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") this.ok(); if (e.key === "Escape") this.close(); });
    });
    this.el.querySelectorAll("[data-sel]").forEach((s) => s.addEventListener("click", () => { this.active.activeSel = s.dataset.sel; this.render(); this.app.onCommandStart(this); }));
    this.el.querySelectorAll("[data-clr]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); const fd = DEFS[type].fields(draft).find((x) => x.key === b.dataset.clr); draft[b.dataset.clr] = fd && fd.single ? null : []; this.render(); this.preview(); }));
    this.el.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", () => (b.dataset.act === "ok" ? this.ok() : this.close())));
    this.el.querySelectorAll("[data-x]").forEach((b) => b.addEventListener("click", () => (def.actions[+b.dataset.x][1])(this.app, draft)));
    this.app.highlightDraft(draft);
  }

  preview() {
    clearTimeout(this.pt);
    this.pt = setTimeout(async () => {
      if (!this.active) return;
      const err = await this.app.rebuild({ draft: this.active.draft, editId: this.active.editId });
      if (!this.active) return;
      const e = (err || []).find((x) => x.featureId === this.active.draft.id);
      const msg = e ? e.message : null;
      if (msg !== this.error) { this.error = msg; this.render(); }
    }, 120);
  }

  async ok() {
    if (!this.active || this.okBusy) return;
    const { draft, editId } = this.active;
    if (draft.type === "extrude") {
      if (!(draft.items || []).length) { this.app.toast("押し出すプロファイル（塗られた領域）か、平らな面をクリックしてください", true); return; }
      if (draft.extent === "to" && !draft.to) { this.app.toast("「対象まで」の面または平面を選んでください", true); return; }
    }
    if (draft.type === "revolve") {
      if (!draft.sketch) { this.app.toast("プロファイルを選択してください", true); return; }
      const loops = draft.sketch ? this.app.sketchLoops(draft.sketch) : null;
      if (draft.type === "revolve" && loops && !loops.length) { this.app.toast("このスケッチには閉じた形がありません。線の端どうしをつないで囲んでください（長方形・円ツールなら確実です）", true); return; }
    }
    if ((draft.type === "fillet" || draft.type === "chamfer") && !(draft.edges || []).length) { this.app.toast("エッジを選択してください", true); return; }
    // 新しいボディはアクティブなコンポーネントに入れる
    if (!editId && (draft.operation === "new" || ["move", "mirror", "pattern", "cpattern"].includes(draft.type)) && store.project.activeComponent) draft.component = store.project.activeComponent;
    if (draft.type === "hole") {
      const pl = draft.placement || "single";
      if ((pl === "single" || pl === "coords") && !draft.face) { this.app.toast("穴をあける面をクリックしてください", true); return; }
      if (pl === "coords" && !(draft.pos || []).some((r) => String(r[0]).trim() !== "" && String(r[1]).trim() !== "")) { this.app.toast("面の上をクリックして穴を置くか、X・Y を入力してください", true); return; }
      if (pl === "coords" && (draft.ref || "corner") === "edges" && !(draft.ref1 && draft.ref2)) { this.app.toast("基準の辺を 2 本クリックしてください", true); return; }
      if (pl === "coords" && draft.ref === "circle" && !draft.ref1) { this.app.toast("基準にする丸い辺をクリックしてください", true); return; }
      if (pl === "sketch" && !draft.sketchRef) { this.app.toast("スケッチを選んでください", true); return; }
      if (pl === "legacy" && !(draft.points || []).length) { this.app.toast("穴の位置をクリックしてください", true); return; }
    }
    const need = { presspull: ["face", "面"], align: ["to", "2つの面"], loft: ["sections", "断面"], joint: ["axis", "軸のエッジ"] }[draft.type];
    if (draft.type === "joint" && !(draft.bodies || []).length) { this.app.toast("動かす部品を選択してください", true); return; }
    if (need && !(Array.isArray(draft[need[0]]) ? draft[need[0]].length : draft[need[0]])) { this.app.toast(`${need[1]}を選択してください`, true); return; }
    if (draft.type === "split" && !draft.body) { this.app.toast("分割するボディを選んでください", true); return; }
    // 入力に問題があるときは OK にしない（Fusion で OK が押せないのと同じ）。最新の状態で確かめる
    clearTimeout(this.pt);
    this.okBusy = true;
    let chk;
    try { chk = await this.app.rebuild({ draft, editId }); } finally { this.okBusy = false; }
    if (!this.active || this.active.draft !== draft) return;
    const bad = (chk || []).find((x) => x.featureId === draft.id);
    if (bad) { this.touched = true; this.error = bad.message; this.render(); this.app.toast(bad.message, true); return; }
    store.commit((p) => {
      if (editId) { const i = p.features.findIndex((f) => f.id === editId); p.features[i] = draft; }
      else {
        const at = p.rollback ?? p.features.length;
        p.features.splice(at, 0, draft);
        if (p.rollback !== null && p.rollback !== undefined) p.rollback = at + 1;
      }
    });
    this.active = null;
    this.error = null;
    this.el.classList.add("hidden");
    this.app.onCommandEnd();
  }

  close(rebuild = true) {
    if (!this.active) return;
    this.active = null;
    this.error = null;
    this.el.classList.add("hidden");
    this.app.onCommandEnd();
    if (rebuild) this.app.rebuild();
  }
}

function dist3(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]); }
export function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

function makeDraggable(el) {
  let sx, sy, ox, oy, drag = false;
  el.addEventListener("mousedown", (e) => {
    if (!e.target.classList.contains("dlg-head") && !e.target.parentElement?.classList.contains("dlg-head")) return;
    if (e.target.tagName === "BUTTON") return;
    drag = true; sx = e.clientX; sy = e.clientY;
    const r = el.getBoundingClientRect(), pr = el.parentElement.getBoundingClientRect();
    ox = r.left - pr.left; oy = r.top - pr.top;
    e.preventDefault();
  });
  window.addEventListener("mousemove", (e) => {
    if (!drag) return;
    el.style.left = ox + e.clientX - sx + "px"; el.style.top = oy + e.clientY - sy + "px"; el.style.right = "auto";
  });
  window.addEventListener("mouseup", () => { drag = false; });
}
