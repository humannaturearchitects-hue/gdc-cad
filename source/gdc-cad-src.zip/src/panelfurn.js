// パネル家具づくりの道具
//  ・ビス接合: 板と板が突き当たっているところに、通し穴（＋皿もみ）と相手の木口の下穴を同じ位置にあける
//  ・板厚の一括変更: 厚さ 18 の板をまとめて 20 に（直方体・押し出しで作った板）
//  ・板厚・材料の一括変更の画面
import { store, newId } from "./store.js";
import { call } from "./kernel.js";
import { esc } from "./commands.js";
import { ICON } from "./icons.js";

// ツールバーのアイコン
{
  const S = (body) => `<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round">${body}</svg>`;
  ICON.screwjoint = ICON.screwjoint || S(`<rect x="4" y="4" width="6" height="24" stroke="#2f7de1"/><rect x="10" y="13" width="18" height="6" stroke="#6b737d"/><path d="M2 16h18" stroke="#e8732a" stroke-width="2.2"/><path d="M2 13v6" stroke="#e8732a" stroke-width="2.2"/>`);
  ICON.panelbatch = ICON.panelbatch || S(`<rect x="4" y="6" width="24" height="4" stroke="#2f7de1"/><rect x="4" y="14" width="24" height="4" stroke="#2f7de1"/><rect x="4" y="22" width="24" height="6" stroke="#e8732a"/>`);
}

const FACE_NAME = [["左面", "右面"], ["前面", "背面"], ["下面", "上面"]];
const AXN = "XYZ";
const n4 = (v) => +(+v).toFixed(4);
const num = (s) => (s == null ? null : parseFloat(String(s).replace(/[Øφ]/g, "")));

function kv(line, keys) {
  const m = line.match(new RegExp(`(?:${keys})\\s*[:=]?\\s*(?:Ø|φ)?\\s*(-?[0-9.]+)`));
  return m ? m[1] : null;
}

async function boundsMap(ids) {
  const r = await call("measure", { ids, density: 1 });
  return new Map(r.list.map((x) => [x.id, { min: x.bounds[0], max: x.bounds[1] }]));
}
const thinAxis = (b) => { const d = [0, 1, 2].map((k) => b.max[k] - b.min[k]); return d.indexOf(Math.min(...d)); };

// 2 つの箱が面で接しているか: { k: 接している面の向き(0=X,1=Y,2=Z), sideA: A の接している面が +側なら 1, lo, hi: 接している範囲 }
export function contactOf(a, b, tol = 0.5) {
  for (let k = 0; k < 3; k++) {
    let sideA = 0;
    if (Math.abs(a.max[k] - b.min[k]) < tol) sideA = 1;
    else if (Math.abs(a.min[k] - b.max[k]) < tol) sideA = -1;
    if (!sideA) continue;
    const lo = [0, 1, 2].map((i) => Math.max(a.min[i], b.min[i])), hi = [0, 1, 2].map((i) => Math.min(a.max[i], b.max[i]));
    if ([0, 1, 2].every((i) => i === k || hi[i] - lo[i] > 1)) return { k, sideA, lo, hi };
  }
  return null;
}

// 接合の計画（穴の位置）。A = ビスを通す板、B = 木口でビスを受ける板
export function jointPlan(A, B, { count = null, inset = 50 } = {}) {
  let c = contactOf(A.b, B.b);
  if (!c) return null;
  // 役割: 接している面が「板の表（いちばん薄い向き）」の方が A
  const ta = thinAxis(A.b), tb = thinAxis(B.b);
  let swapped = false;
  if (ta !== c.k && tb === c.k) { [A, B] = [B, A]; c = contactOf(A.b, B.b); swapped = true; }
  const [i, j] = [0, 1, 2].filter((x) => x !== c.k);
  const li = c.hi[i] - c.lo[i], lj = c.hi[j] - c.lo[j];
  const L = li >= lj ? i : j, S = L === i ? j : i;
  const len = c.hi[L] - c.lo[L];
  let e = Math.min(inset, len / 4);
  let n = count ? Math.max(1, Math.round(count)) : Math.max(2, Math.ceil((len - 2 * e) / 300) + 1);
  if (len < 60) { n = 1; }
  const along = n === 1 ? [c.lo[L] + len / 2] : Array.from({ length: n }, (_, q) => c.lo[L] + e + ((len - 2 * e) * q) / (n - 1));
  const mid = (c.lo[S] + c.hi[S]) / 2;
  const pts = along.map((t) => { const p = [0, 0, 0]; p[L] = t; p[S] = mid; p[c.k] = c.sideA > 0 ? A.b.max[c.k] : A.b.min[c.k]; return p; });
  return {
    A, B, swapped, k: c.k, pts,
    // A はビスを入れる外側の面（接している面の反対）、B は接している面（木口）。どちらも同じ向きの名前になる
    faceA: FACE_NAME[c.k][c.sideA > 0 ? 0 : 1],
    faceB: FACE_NAME[c.k][c.sideA > 0 ? 0 : 1],
    axes: [i, j],
    along: along.map((t) => n4(t - c.lo[L])), axisL: AXN[L],
  };
}

async function facePointOf(cl, name, body) { return cl.facePoint(name, body); }

function holeFeature(fp, body, pts, axes, { d, through, depth, csD }) {
  return {
    id: newId(), type: "hole", name: store.nameFor("hole"), placement: "coords", face: [...fp.p, ...fp.n], faceRef: { body: body.id, point: fp.p }, body: body.id,
    ref: "origin", pos: pts.map((p) => axes.map((a) => String(n4(p[a])))), axes: "global",
    style: csD ? "csink" : "simple", d: String(d), through, depth: String(depth || 10), cboreD: "18", cboreDepth: "6", csinkD: String(csD || 20), csinkAngle: "90", useCircles: true, flip: false, points: [],
  };
}

// 「ビス接合 側板 棚板 Ø4 皿径8 下穴Ø3 深さ30 個数3 端から50」
async function screwJoint(cl, line) {
  const app = cl.app;
  const L = line.replace(/^(ビス接合|ビス止め|ビス穴|接合穴)\s*/, "");
  const named = cl.bodiesIn(L, { fallbackSel: true });
  if (!named.length) throw new Error("書き方: ビス接合 側板 棚板 [Ø4] [皿径8] [下穴Ø3 深さ30] [個数3] [端から50]（突き当たっている 2 枚の板）");
  let rest = L; for (const m of named) rest = rest.split(m.name).join(" ");
  const d = num(kv(rest, "(?<!下穴|皿)(?:Ø|φ|穴径|ビス径|径)")) || 4;
  const csD = num(kv(rest, "皿径|皿")) || null;
  const pd = num(kv(rest, "下穴(?:径)?")) || Math.max(1, +(d * 0.7).toFixed(1));
  const depth = num(kv(rest, "深さ")) || 30;
  const count = num(kv(rest, "個数|本数")) || num((rest.match(/([0-9]+)\s*(?:本|個|か所|箇所|ヶ所)/) || [])[1]);
  const inset = num(kv(rest, "端から|端")) ?? 50;
  return doScrewJoint(cl, named, { d, csD, pd, depth, count, inset });
}

// named: 2 枚以上なら書いた板どうし、1 枚だけならそれに突き当たっている板すべて
export async function doScrewJoint(cl, named, { d = 4, csD = null, pd = 3, depth = 30, count = null, inset = 50 } = {}) {
  const app = cl.app;
  const others = app.meshes.filter((m) => !m.hidden);
  const bm = await boundsMap(others.map((m) => m.id));
  const W = (m) => ({ m, b: bm.get(m.id) });
  // 組み合わせ: 2 枚以上書いたら書いた板どうし、1 枚だけならそれに突き当たっている板すべて
  const pairs = [];
  if (named.length >= 2) { for (let x = 0; x < named.length; x++) for (let y = x + 1; y < named.length; y++) if (contactOf(bm.get(named[x].id), bm.get(named[y].id))) pairs.push([named[x], named[y]]); }
  else for (const o of others) if (o.id !== named[0].id && contactOf(bm.get(named[0].id), bm.get(o.id))) pairs.push([o, named[0]]);
  if (!pairs.length) throw new Error(`${named.map((m) => m.name).join("・")}: 突き当たっている板が見つかりません（板どうしが面で接している必要があります。すき間・重なりは「干渉チェック」で確認）`);
  const msgs = [];
  for (const [a, b] of pairs) {
    const plan = jointPlan(W(a), W(b), { count, inset });
    if (!plan) continue;
    const A = plan.A.m, B = plan.B.m;
    if (thinAxis(plan.B.b) === plan.k) { msgs.push(`${A.name}・${B.name}: 板の表どうしが重なっているので木口ではありません（スキップ）`); continue; }
    const fa = await facePointOf(cl, plan.faceA, A);
    const fb = await facePointOf(cl, plan.faceB, B);
    await cl.commitFeature(holeFeature(fa, A, plan.pts, plan.axes, { d, through: true, csD }));
    await cl.commitFeature(holeFeature(fb, B, plan.pts, plan.axes, { d: pd, through: false, depth }));
    msgs.push(`${A.name} → ${B.name} の木口に ${plan.pts.length} 本（${A.name}: Ø${d} 貫通${csD ? ` 皿Ø${csD}` : ""}、${B.name}: 下穴 Ø${pd} 深さ ${depth}、${plan.axisL} 方向の位置 ${plan.along.join(", ")}）`);
  }
  if (!msgs.length) throw new Error("接合できる組み合わせがありませんでした");
  return "ビス接合: " + msgs.join(" ／ ");
}

// 「板厚 18 を 20 に [ボディ名… | すべて]」「板厚 18→20」
async function changeThickness(cl, line) {
  const app = cl.app;
  const m = line.match(/板厚\s*([0-9.]+)\s*(?:mm)?\s*(?:を|→|->|から|⇒|>)\s*([0-9.]+)/);
  if (!m) throw new Error("書き方: 板厚 18 を 20 に（厚さ 18 の板をまとめて 20 に。ボディ名を書けばその板だけ）");
  const from = +m[1], to = +m[2];
  if (!(to > 0)) throw new Error("新しい厚さは 0 より大きくしてください");
  const rest = line.replace(m[0], " ");
  let bs = cl.bodiesIn(rest, { fallbackSel: false });
  if (!bs.length) bs = app.meshes.filter((x) => !x.hidden);
  return doChangeThickness(cl, bs, from, to);
}

export async function doChangeThickness(cl, bs, from, to) {
  const app = cl.app;
  const bm = await boundsMap(bs.map((b) => b.id));
  const params = store.project.params || [];
  const changes = [], skipped = [], paramChanges = new Set();
  const isNum = (e) => /^\s*[-+]?[0-9.]+\s*$/.test(String(e));
  for (const b of bs) {
    const bb = bm.get(b.id); if (!bb) continue;
    const ax = thinAxis(bb);
    const t = bb.max[ax] - bb.min[ax];
    if (Math.abs(t - from) > 0.05) continue;
    const f = store.feature(b.src);
    let key = null;
    if (f && f.type === "box") key = ["w", "d", "h"][ax];
    else if (f && f.type === "extrude") key = "distance";
    if (!key) { skipped.push(`${b.name}（${f ? f.name : "?"} は厚さを直接変えられない作り方）`); continue; }
    const ex = f[key];
    if (isNum(ex) && Math.abs(+ex - from) < 0.05) changes.push({ fid: f.id, key, name: b.name });
    else if (params.some((p) => p.name === String(ex).trim())) paramChanges.add(String(ex).trim());
    else skipped.push(`${b.name}（${f.name} の値が式「${ex}」）`);
  }
  if (!changes.length && !paramChanges.size) throw new Error(`厚さ ${from} の板が見つかりません${skipped.length ? "（変えられない板: " + skipped.join("、") + "）" : ""}`);
  store.commit((p) => {
    for (const c of changes) { const f = p.features.find((x) => x.id === c.fid); if (f) f[c.key] = String(to); }
    for (const n of paramChanges) { const q = (p.params || []).find((x) => x.name === n); if (q) q.expr = String(to); }
  });
  const errs = (await app.rebuild()) || [];
  if (errs.length) { store.undo(); await app.rebuild(); throw new Error("厚さを変えると形が作れなくなるので元に戻しました: " + errs.map((e) => e.message).join(" / ")); }
  return `板厚 ${from} → ${to}: ${changes.map((c) => c.name).join("・")}${paramChanges.size ? `${changes.length ? "、" : ""}パラメータ ${[...paramChanges].join("・")}` : ""}（${changes.length + paramChanges.size} か所）。板の位置はそのままなので、となりの板とのすき間・重なりを「干渉チェック」で確かめてください${skipped.length ? "。変えなかった板: " + skipped.join("、") : ""}`;
}

// コマンドの入口（commandline.js の run から呼ぶ）。担当しない行は undefined
export async function panelCommand(cl, line) {
  if (/^(ビス接合|ビス止め|ビス穴|接合穴)/.test(line)) return screwJoint(cl, line);
  if (/^板厚\s*[0-9.]/.test(line)) return changeThickness(cl, line);
  return undefined;
}

// ---------------------------------------------------------------- 画面

export function openScrewJoint(app) {
  const bodies = app.meshes.filter((m) => !m.hidden);
  if (bodies.length < 2) return app.toast("板が 2 枚以上必要です", true);
  const sel = [...new Set((app.selection || []).map((x) => x.bodyId).filter(Boolean))];
  const opt = (id) => bodies.map((b) => `<option value="${esc(b.id)}" ${b.id === id ? "selected" : ""}>${esc(b.name)}</option>`).join("");
  const keep = store.project.screwJoint || { d: 4, cs: 8, pd: 3, depth: 30, count: "", inset: 50 };
  const el = app.panel("ビス接合（板と板の穴をそろえてあける）", `
    <label>ビスを通す板</label><select id="sj-a">${opt(sel[0] || bodies[0].id)}</select>
    <label>木口で受ける板</label><select id="sj-b"><option value="">（突き当たっている板すべて）</option>${opt(sel[1] || "")}</select>
    <label>通し穴 Ø</label><input type="text" id="sj-d" value="${keep.d}" inputmode="decimal"/>
    <label>皿もみ Ø（空欄＝なし）</label><input type="text" id="sj-cs" value="${keep.cs}" inputmode="decimal"/>
    <label>下穴 Ø</label><input type="text" id="sj-pd" value="${keep.pd}" inputmode="decimal"/>
    <label>下穴の深さ</label><input type="text" id="sj-dep" value="${keep.depth}" inputmode="decimal"/>
    <label>本数（空欄＝自動）</label><input type="text" id="sj-n" value="${keep.count}" inputmode="numeric"/>
    <label>端からの距離</label><input type="text" id="sj-e" value="${keep.inset}" inputmode="decimal"/>
    <div class="full dlg-note">2 枚の板が突き当たっている所（例: 側板の内側に棚板の木口）を見つけて、側板には通し穴（＋皿もみ）、棚板の木口には同じ位置に下穴をあけます。穴の位置は両方の板で必ずそろいます。<br>「木口で受ける板」を空欄にすると、ビスを通す板に突き当たっている板すべてに入れます。</div>`, async () => {
    const v = (id) => el.querySelector(id).value.trim();
    const A = bodies.find((b) => b.id === v("#sj-a")), B = bodies.find((b) => b.id === v("#sj-b"));
    store.project.screwJoint = { d: v("#sj-d"), cs: v("#sj-cs"), pd: v("#sj-pd"), depth: v("#sj-dep"), count: v("#sj-n"), inset: v("#sj-e") };
    const N = (id, def) => { const x = parseFloat(v(id)); return isFinite(x) && x > 0 ? x : def; };
    if (B && B.id === A.id) { app.toast("違う板を 2 枚選んでください", true); return false; }
    try {
      const r = await doScrewJoint(app.cmdline, B ? [A, B] : [A], { d: N("#sj-d", 4), csD: N("#sj-cs", null), pd: N("#sj-pd", 3), depth: N("#sj-dep", 30), count: N("#sj-n", null), inset: parseFloat(v("#sj-e")) >= 0 ? parseFloat(v("#sj-e")) : 50 });
      app.toast(r);
    } catch (e) { app.toast(e.message, true); return false; }
  }, { okLabel: "穴をあける", wide: true });
  return el;
}

// 板厚・材料の一括変更: 今ある板を厚さ・材料ごとにまとめて表示し、まとめて変える
export async function openPanelBatch(app) {
  const bodies = app.meshes.filter((m) => !m.hidden);
  if (!bodies.length) return app.toast("表示中のボディがありません", true);
  const bm = await boundsMap(bodies.map((b) => b.id));
  const groups = new Map();
  for (const b of bodies) {
    const bb = bm.get(b.id); if (!bb) continue;
    const ax = thinAxis(bb); const t = +(bb.max[ax] - bb.min[ax]).toFixed(1);
    const mat = b.material?.name || "";
    const k = `${t}|${mat}`;
    if (!groups.has(k)) groups.set(k, { t, mat, list: [] });
    groups.get(k).list.push(b);
  }
  const G = [...groups.values()].sort((a, b) => a.t - b.t || a.mat.localeCompare(b.mat));
  const M = (app.MATERIALS || []).filter((m) => m[0]);
  const el = app.panel("板厚・材料をまとめて変更", `
    <div class="full"><table class="grid" id="pb-list"><tr><th class="num">厚さ</th><th>材料</th><th class="num">枚数</th><th>部品</th><th>新しい厚さ</th><th>新しい材料</th></tr>
    ${G.map((g, i) => `<tr><td class="num">${g.t}</td><td>${esc(g.mat || "—")}</td><td class="num">${g.list.length}</td><td style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(g.list.map((b) => b.name).join("、"))}">${esc(g.list.map((b) => b.name).join("、"))}</td>
      <td><input type="text" data-t="${i}" value="" placeholder="${g.t}" inputmode="decimal" style="width:64px"/></td>
      <td><select data-m="${i}"><option value="">（そのまま）</option>${M.map((m) => `<option value="${esc(m[0])}">${esc(m[0])}</option>`).join("")}</select></td></tr>`).join("")}
    </table></div>
    <div class="full dlg-note">変えたい行だけ入力してください。厚さは直方体・押し出しで作った板の厚さの数値（またはパラメータ）を書き換えます。板の位置は変わらないので、変えた後に「干渉チェック」ですき間・重なりを確かめてください。</div>`, async () => {
    const todo = G.map((g, i) => ({ g, t: el.querySelector(`[data-t="${i}"]`).value.trim(), m: el.querySelector(`[data-m="${i}"]`).value }));
    const msgs = [];
    try {
      const matJobs = todo.filter((x) => x.m);
      if (matJobs.length) {
        store.commit((p) => {
          p.bodyProps = p.bodyProps || {};
          for (const { g, m } of matJobs) { const M = (app.MATERIALS || []).find((q) => q[0] === m); for (const b of g.list) p.bodyProps[b.id] = { ...(p.bodyProps[b.id] || {}), material: { name: m, density: M ? M[2] : 1 } }; }
        });
        await app.rebuild();
        msgs.push(...matJobs.map(({ g, m }) => `厚さ ${g.t} の ${g.list.length} 枚を ${m} に`));
      }
      for (const { g, t } of todo) {
        if (!t || Math.abs(+t - g.t) < 0.01) continue;
        if (!(+t > 0)) throw new Error("厚さは 0 より大きい数字で入力してください");
        msgs.push(await doChangeThickness(app.cmdline, g.list, g.t, +t));
      }
    } catch (e) { app.toast(e.message, true); return false; }
    if (msgs.length) app.toast(msgs.join(" ／ "));
  }, { okLabel: "変更する", wide: true });
  return el;
}
