// 端末内 AI（WebGPU で動く小さな言語モデル）の作業場所。画面が固まらないように、別の糸（Worker）で動かす
// 画面側（localai.js）とは決まった短いメッセージだけでやり取りする（web-llm は画面側には読み込まない＝軽い）
import { MLCEngine, hasModelInCache, deleteModelAllInfoInCache } from "@mlc-ai/web-llm";

let engine = null, loadedId = null;
const post = (m) => self.postMessage(m);

self.onmessage = async (ev) => {
  const m = ev.data || {};
  try {
    if (m.type === "has") {
      post({ type: "has", id: m.id, has: await hasModelInCache(m.modelId, m.appConfig) });
    } else if (m.type === "load") {
      if (engine && loadedId === m.modelId) { post({ type: "loaded", id: m.id }); return; }
      if (engine) { try { await engine.unload(); } catch { /* */ } engine = null; loadedId = null; }
      const e = new MLCEngine({
        appConfig: m.appConfig,
        initProgressCallback: (p) => post({ type: "progress", id: m.id, progress: p.progress, text: p.text, timeElapsed: p.timeElapsed }),
      });
      await e.reload(m.modelId, m.chatOpts || {});
      engine = e; loadedId = m.modelId;
      post({ type: "loaded", id: m.id });
    } else if (m.type === "chat") {
      if (!engine) throw new Error("not-loaded");
      const r = await engine.chat.completions.create(m.request);
      post({ type: "result", id: m.id, content: r.choices[0]?.message?.content || "", usage: r.usage || null });
    } else if (m.type === "delete") {
      if (engine && loadedId === m.modelId) { try { await engine.unload(); } catch { /* */ } engine = null; loadedId = null; }
      await deleteModelAllInfoInCache(m.modelId, m.appConfig);
      post({ type: "deleted", id: m.id });
    } else if (m.type === "unload") {
      if (engine) { try { await engine.unload(); } catch { /* */ } }
      engine = null; loadedId = null;
      post({ type: "unloaded", id: m.id });
    }
  } catch (e) {
    post({ type: "error", id: m.id, name: e && e.name, message: String((e && e.message) || e) });
  }
};
