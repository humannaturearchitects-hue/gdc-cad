// スケッチ編集モード
import * as THREE from "three";
import { sketchObject, frameMatrix, entityPolyline, COARSE } from "./viewer.js";
import { sketchPlaneFrame, resolveEntity, findLoops, arcFrom3 } from "./shared/sketchgeom.js";
import { makeEvaluator } from "./shared/expr.js";
import { solveSketch, normalizeSketch, newEntityId } from "./shared/solver.js";
import { handles, moveHandle, applyWithLinks, filletCorner, nearestCorner, offsetEntity, trimAt, mirrorEntities, explodeRect } from "./sketchtools.js";
import { store } from "./store.js";
import { call as kernelCall } from "./kernel.js";

const fmt = (v) => (Math.abs(v) < 1e-9 ? "0" : (+v.toFixed(3)).toString());

export class Sketcher {
  constructor(app) {
    this.app = app;
    this.viewer = app.viewer;
    this.active = false;
    this.tool = "line";
    this.pts = [];
    this.selected = new Set();
    this.hover = -1;
    this.group = new THREE.Group();
    this.viewer.scene.add(this.group);
    this.labels = [];
    this.inbox = null;
  }

  get feature() { return store.feature(this.featureId); }
  get num() { return makeEvaluator(store.project.params || []); }

  start(featureId) {
    this.featureId = featureId;
    this.active = true;
    this.pts = [];
    this.selected.clear();
    {
      // 古いデータに id を付け、パラメータが変わっていれば拘束を解き直す
      const f0 = this.feature;
      const norm = normalizeSketch(f0.entities || [], f0.constraints || []);
      let ents = norm.entities;
      if (norm.constraints.length) { const r = solveSketch(ents, norm.constraints, this.num); if (r.ok) ents = r.entities; }
      f0.entities = ents; f0.constraints = norm.constraints;
    }
    const f = this.feature;
    this.frame = this.app.frameOf(f, this.num);
    const fr = this.frame;
    const up = fr.yDir;
    // スケッチ平面を正面から見て、既存の線があれば全体が入るように
    // 今見ている中心をスケッチ平面に写した点を中心に、平面を正面から見る（見ていた場所がそのまま画面に残る）
    { const t = this.viewer.controls.target.clone(), n = new THREE.Vector3(...fr.normal), o = new THREE.Vector3(...fr.origin);
      t.sub(n.clone().multiplyScalar(t.clone().sub(o).dot(n)));
      this.viewer.controls.target.copy(t); }
    this.viewer.setView(fr.normal, up, false);
    const box = new THREE.Box3();
    const num = this.num;
    for (const raw of f.entities) {
      let e; try { e = resolveEntity(raw, num); } catch { continue; }
      for (const q of entityPolyline(e)) box.expandByPoint(new THREE.Vector3(...[0, 1, 2].map((k) => fr.origin[k] + fr.xDir[k] * q[0] + fr.yDir[k] * q[1])));
    }
    if (!box.isEmpty()) { box.expandByScalar(box.getSize(new THREE.Vector3()).length() * 0.08 + 1); this.viewer.fit(box); }
    this.viewer.showPlanes(false);
    this.viewer.setTouchSketch(true);
    this.viewer.setSketchMouse(true);
    this.prevGrid = this.viewer.grid.visible;
    this.viewer.grid.visible = false;
    this.redraw();
    this.setTool(f.entities.length ? "select" : "line");
    this.viewer.onCameraChange = () => this.positionLabels();
  }

  stop() {
    this.clearSmart();
    this.active = false;
    this.cancelInput();
    this.clearLabels();
    this.group.clear();
    this.viewer.grid.visible = this.prevGrid;
    this.viewer.setTouchSketch(false);
    this.viewer.setSketchMouse(false);
    this.viewer.onCameraChange = null;
    this.viewer.dirty = true;
  }

  setTool(t) {
    this.clearSmart && this.clearSmart();
    this.tool = t;
    this.pts = [];
    this.cancelInput();
    if (t !== "select") this.selected.clear();
    this.redraw();
    for (const l of this.labels) l.el.style.pointerEvents = t === "select" ? "auto" : "none";
    this.app.status && 0;
    const hints = {
      select: "クリックで選択（Shift で追加）。点（端点・角・中心）はドラッグで動かせます。Delete で削除。寸法ラベル（青）をクリックで値を変更。",
      line: "クリックで点を指定。続けて連続線。数値を入力して Enter で長さ確定（Tab で角度）。Esc で終了。",
      rect: "1点目（角）→ 2点目（対角）。数値入力: 幅 Tab 高さ Enter。",
      rectc: "1点目（中心）→ 2点目（角）。数値入力: 幅 Tab 高さ Enter。",
      circle: "1点目（中心）→ 2点目（半径）。数値入力: 直径 Enter。",
      arc: "始点 → 終点 → 通過点 の3点で円弧。",
      polygon: "1点目（中心）→ 2点目（頂点）。数値入力: 外接円直径 Tab 辺数 Enter。",
      sfillet: "丸めたい角（2本の線が交わる点）をクリック → 半径を入力して Enter。",
      offset: "オフセットする線・円・長方形をクリック → 距離を入力（＋外側 / －内側）して Enter。",
      trim: "消したい部分をクリック（交点で区切られた区間が消えます）。",
      point: "クリックで点を置きます（穴の位置などに）。置いた後、選択して X・Y を数値で変更できます。",
      project: "ボディのエッジ（1 本）か面（外形すべて）をクリック → スケッチに写します（紫の線）。寸法の基準に使えます。",
      dim: "寸法: 図形をクリック → もう 1 つクリックで距離・角度、何もない所をクリックで長さ・直径。数値・式を入れて Enter。",
    };
    this.app.status(hints[t] || "");
    this.app.refreshTools();
  }

  // ------------------------------------------------ 座標・スナップ
  snapStep() {
    const wpp = this.viewer.worldPerPixel();
    const raw = wpp * 12;
    const p = Math.pow(10, Math.floor(Math.log10(raw)));
    for (const m of [1, 2, 5, 10]) if (p * m >= raw) return p * m;
    return p * 10;
  }

  keyPoints() {
    const out = [[0, 0]];
    const num = this.num;
    for (const raw of this.feature.entities) {
      let e; try { e = resolveEntity(raw, num); } catch { continue; }
      if (e.type === "line") out.push([e.x1, e.y1], [e.x2, e.y2], [(e.x1 + e.x2) / 2, (e.y1 + e.y2) / 2]);
      if (e.type === "rect") out.push([e.x, e.y], [e.x + e.w, e.y], [e.x + e.w, e.y + e.h], [e.x, e.y + e.h], [e.x + e.w / 2, e.y + e.h / 2]);
      if (e.type === "circle") out.push([e.cx, e.cy]);
      if (e.type === "point") out.push([e.x, e.y]);
      if (e.type === "arc") { out.push([e.x1, e.y1], [e.x2, e.y2]); const c = arcFrom3([e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym]); if (c) out.push([c.cx, c.cy]); }
    }
    return out;
  }

  // 吸着点（種類つき）: 原点・端点・角・中点・中心・点
  keyPointsK() {
    const out = [{ p: [0, 0], k: "原点" }];
    const num = this.num;
    for (const raw of this.feature.entities) {
      let e; try { e = resolveEntity(raw, num); } catch { continue; }
      if (e.type === "line") out.push({ p: [e.x1, e.y1], k: "端点" }, { p: [e.x2, e.y2], k: "端点" }, { p: [(e.x1 + e.x2) / 2, (e.y1 + e.y2) / 2], k: "中点" });
      if (e.type === "rect") out.push({ p: [e.x, e.y], k: "角" }, { p: [e.x + e.w, e.y], k: "角" }, { p: [e.x + e.w, e.y + e.h], k: "角" }, { p: [e.x, e.y + e.h], k: "角" }, { p: [e.x + e.w / 2, e.y + e.h / 2], k: "中心" }, { p: [e.x + e.w / 2, e.y], k: "中点" }, { p: [e.x + e.w / 2, e.y + e.h], k: "中点" }, { p: [e.x, e.y + e.h / 2], k: "中点" }, { p: [e.x + e.w, e.y + e.h / 2], k: "中点" });
      if (e.type === "circle") { const r = Math.abs(e.d) / 2; out.push({ p: [e.cx, e.cy], k: "中心" }, { p: [e.cx + r, e.cy], k: "四分点" }, { p: [e.cx - r, e.cy], k: "四分点" }, { p: [e.cx, e.cy + r], k: "四分点" }, { p: [e.cx, e.cy - r], k: "四分点" }); }
      if (e.type === "point") out.push({ p: [e.x, e.y], k: "点" });
      if (e.type === "arc") { out.push({ p: [e.x1, e.y1], k: "端点" }, { p: [e.x2, e.y2], k: "端点" }); const c = arcFrom3([e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym]); if (c) out.push({ p: [c.cx, c.cy], k: "中心" }); }
    }
    for (const p of this.pts) out.push({ p, k: "描き始め" });
    return out;
  }

  // カーソル位置の決定（Illustrator のスマートガイドと同じ考え方）:
  // 点に吸着 → 縦横がそろう点（ガイド線）→ 線の上 → 刻み。Alt で吸着なし
  pointFromEvent(ev, exclude) {
    const p = this.viewer.planePoint(ev, this.frame);
    if (!p) return null;
    const wpp = this.viewer.worldPerPixel();
    const same = (k) => exclude && Math.abs(k[0] - exclude[0]) < 1e-9 && Math.abs(k[1] - exclude[1]) < 1e-9;
    const keys = this.keyPointsK().filter((k) => !same(k.p));
    let best = null, bd = wpp * (COARSE ? 22 : 10);
    for (const k of keys) { const d = Math.hypot(k.p[0] - p[0], k.p[1] - p[1]); if (d < bd) { bd = d; best = k; } }
    if (best) return { p: [...best.p], snapped: true, kind: best.k, guides: [] };
    if (ev.altKey) return { p, snapped: false, guides: [] };
    // 縦・横のそろい
    const tol = wpp * (COARSE ? 12 : 7);
    let gx = null, gy = null, dx = tol, dy = tol;
    for (const k of keys) { const ax = Math.abs(k.p[0] - p[0]), ay = Math.abs(k.p[1] - p[1]); if (ax < dx) { dx = ax; gx = k; } if (ay < dy) { dy = ay; gy = k; } }
    // 線の上（端点・中点以外の位置）
    let on = null;
    if (!gx || !gy) {
      let od = wpp * (COARSE ? 12 : 6);
      for (const raw of this.feature.entities) {
        let e; try { e = resolveEntity(raw, this.num); } catch { continue; }
        const segs = e.type === "line" ? [[e.x1, e.y1, e.x2, e.y2]] : e.type === "rect" ? [[e.x, e.y, e.x + e.w, e.y], [e.x + e.w, e.y, e.x + e.w, e.y + e.h], [e.x + e.w, e.y + e.h, e.x, e.y + e.h], [e.x, e.y + e.h, e.x, e.y]] : [];
        for (const [x1, y1, x2, y2] of segs) {
          const ax = x2 - x1, ay = y2 - y1, L2 = ax * ax + ay * ay || 1; const t = Math.max(0, Math.min(1, ((p[0] - x1) * ax + (p[1] - y1) * ay) / L2));
          // 線の上でも、刻みの位置にそろえる（中途半端な数値にしない）
          const s0 = this.snapStep(); let q = [x1 + ax * t, y1 + ay * t];
          if (Math.abs(ay) < 1e-9) q[0] = Math.round(q[0] / s0) * s0; else if (Math.abs(ax) < 1e-9) q[1] = Math.round(q[1] / s0) * s0;
          const d = Math.hypot(x1 + ax * t - p[0], y1 + ay * t - p[1]); if (d < od) { od = d; on = q; }
        }
        if (e.type === "circle") { const r = Math.abs(e.d) / 2, dd = Math.hypot(p[0] - e.cx, p[1] - e.cy) || 1; const d = Math.abs(dd - r); if (d < od) { od = d; on = [e.cx + (p[0] - e.cx) / dd * r, e.cy + (p[1] - e.cy) / dd * r]; } }
      }
    }
    const s = this.snapStep();
    let q = [Math.round(p[0] / s) * s, Math.round(p[1] / s) * s];
    const guides = [];
    if (gx && gy) { q = [gx.p[0], gy.p[1]]; guides.push({ axis: 0, at: gx.p, k: gx.k }, { axis: 1, at: gy.p, k: gy.k }); }
    else if (on) return { p: on.map((v) => +v.toFixed(6)), snapped: true, kind: "線上", guides: [] };
    else {
      if (gx) { q[0] = gx.p[0]; guides.push({ axis: 0, at: gx.p, k: gx.k }); }
      if (gy) { q[1] = gy.p[1]; guides.push({ axis: 1, at: gy.p, k: gy.k }); }
    }
    // 線: 前の点と水平・垂直
    const last = this.pts[this.pts.length - 1];
    if (last && this.tool === "line" && !guides.length) {
      if (Math.abs(q[1] - last[1]) < wpp * 8) { q[1] = last[1]; guides.push({ axis: 1, at: last, k: "水平" }); }
      if (Math.abs(q[0] - last[0]) < wpp * 8) { q[0] = last[0]; guides.push({ axis: 0, at: last, k: "垂直" }); }
    }
    return { p: q, snapped: false, guides, kind: guides.length ? guides.map((g) => g.k === "水平" || g.k === "垂直" ? g.k : `${g.k}と${g.axis === 0 ? "縦" : "横"}`).join("・") : "" };
  }

  // スマートガイドの表示（吸着の印・ガイド線・座標）
  drawSmart(r) {
    this.clearSmart();
    if (!r || this.tool === "select" || this.tool === "project") return;
    const fr = this.frame, wpp = this.viewer.worldPerPixel();
    const grp = new THREE.Group(); grp.applyMatrix4(frameMatrix(fr));
    const add = (pts, mat) => { const l = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts.map((q) => new THREE.Vector3(q[0], q[1], 0))), mat); l.renderOrder = 45; if (mat.isLineDashedMaterial) l.computeLineDistances(); grp.add(l); };
    const L = wpp * 4000;
    for (const g of r.guides || []) {
      const a = g.axis === 0 ? [g.at[0], g.at[1] - L] : [g.at[0] - L, g.at[1]], b = g.axis === 0 ? [g.at[0], g.at[1] + L] : [g.at[0] + L, g.at[1]];
      add([a, b], new THREE.LineDashedMaterial({ color: 0xd8601a, dashSize: wpp * 9, gapSize: wpp * 5, depthTest: false }));
    }
    if (r.snapped) { const s = wpp * 5, c = r.p; add([[c[0] - s, c[1] - s], [c[0] + s, c[1] - s], [c[0] + s, c[1] + s], [c[0] - s, c[1] + s], [c[0] - s, c[1] - s]], new THREE.LineBasicMaterial({ color: 0xe8732a, depthTest: false })); }
    this.group.add(grp); this.smartObj = grp;
    const lab = document.createElement("div"); lab.className = "hcur";
    lab.innerHTML = `X <b>${fmt(r.p[0])}</b>　Y <b>${fmt(r.p[1])}</b>${r.kind ? `<span>${r.kind}</span>` : ""}`;
    const w = [0, 1, 2].map((i) => fr.origin[i] + fr.xDir[i] * r.p[0] + fr.yDir[i] * r.p[1]);
    const [x, y] = this.viewer.toScreen(w); lab.style.left = x + 16 + "px"; lab.style.top = y + 16 + "px";
    this.app.overlay.appendChild(lab); this.smartLabel = lab;
    this.viewer.dirty = true;
  }
  clearSmart() {
    if (this.smartObj) { this.group.remove(this.smartObj); this.smartObj.traverse((o) => o.geometry && o.geometry.dispose()); this.smartObj = null; }
    if (this.smartLabel) { this.smartLabel.remove(); this.smartLabel = null; }
  }

  // ------------------------------------------------ イベント
  // ドラッグで描く: 押した点 → 離した点 / 選択ツールでは点をドラッグして移動
  onDown(ev) {
    if (this.active && this.tool === "select") { this.startPointDrag(ev); return; }
    if (!this.active || ["sfillet", "offset", "trim"].includes(this.tool) || this.pts.length) { this.dragStart = null; return; }
    const r = this.pointFromEvent(ev);
    this.dragStart = r ? { p: r.p, x: ev.clientX, y: ev.clientY } : null;
    this.dragging = false;
  }

  onUp(ev, moved) {
    if (!this.active) return;
    if (this.ptDrag) { const d = this.ptDrag; this.ptDrag = null; if (d.moved) { this.finishPointDrag(d); return; } }
    if (this.dragging && this.dragStart) {
      const r = this.pointFromEvent(ev);
      this.dragging = false; this.dragStart = null;
      if (r) {
        const wasLine = this.tool === "line";
        this.addPoint(r.p);
        if (wasLine) { this.pts = []; this.chainStart = null; this.cancelInput(); this.drawPreview(); }
      }
      return;
    }
    this.dragStart = null;
    if (!moved) this.onClick(ev);
  }

  onMove(ev) {
    if (!this.active) return;
    const r = this.pointFromEvent(ev);
    if (!r) return;
    this.cursor = r.p;
    if ((ev.buttons & 1) && this.ptDrag) { this.updatePointDrag(ev); return; }
    if ((ev.buttons & 1) && this.dragStart && !this.dragging && Math.hypot(ev.clientX - this.dragStart.x, ev.clientY - this.dragStart.y) > 5) {
      this.dragging = true;
      this.pts = [this.dragStart.p];
      if (this.tool === "line") this.chainStart = this.dragStart.p;
    }
    this.app.statusCoord(`X ${fmt(r.p[0])}  Y ${fmt(r.p[1])}  (スナップ ${fmt(this.snapStep())})`);
    this.drawSmart(r);
    if (this.tool === "select") {
      const h = this.hitEntity(ev);
      if (h !== this.hover) { this.hover = h; this.redraw(); }
      return;
    }
    this.drawPreview();
  }

  // ---- 点のドラッグ（つながった線も追従）
  startPointDrag(ev) {
    this.ptDrag = null;
    const q = this.viewer.planePoint(ev, this.frame);
    if (!q) return;
    const tol = this.viewer.worldPerPixel() * (COARSE ? 20 : 9);
    const num = this.num;
    let best = null, bd = tol;
    this.feature.entities.forEach((raw, i) => {
      let e; try { e = resolveEntity(raw, num); } catch { return; }
      for (const h of handles(e)) { const d = Math.hypot(h.p[0] - q[0], h.p[1] - q[1]); if (d < bd) { bd = d; best = { i, h, e }; } }
    });
    if (best) this.ptDrag = { ...best, orig: JSON.parse(JSON.stringify(this.feature.entities)), moved: false, x: ev.clientX, y: ev.clientY };
  }
  updatePointDrag(ev) {
    const d = this.ptDrag;
    if (!d.moved && Math.hypot(ev.clientX - d.x, ev.clientY - d.y) < 4) return;
    d.moved = true;
    const r = this.pointFromEvent(ev, d.h.p);
    if (!r) return;
    const num = this.num;
    let ents;
    if (this.constraints.length && d.h.k) {
      const res = solveSketch(d.orig, this.constraints, num, { drag: { i: d.i, fx: d.h.k[0], fy: d.h.k[1], to: r.p }, maxIter: 30 });
      ents = res.entities;
    } else ents = applyWithLinks(d.orig, d.i, moveHandle(d.orig[d.i], d.e, d.h, r.p), num);
    this.feature.entities.splice(0, this.feature.entities.length, ...ents);
    this.redraw();
  }
  finishPointDrag(d) {
    const final = JSON.parse(JSON.stringify(this.feature.entities));
    this.feature.entities.splice(0, this.feature.entities.length, ...d.orig);
    store.commit((p) => { p.features.find((x) => x.id === this.featureId).entities = final; }, { silent: true });
    this.redraw();
  }

  // ---- 数値を 1 つ聞く（画面上部の小さな入力欄）
  askNumber(label, def, cb, rawCb) {
    this.cancelInput();
    const box = document.createElement("div");
    box.className = "inbox ask";
    box.innerHTML = `<span class="lbl">${label}</span><input value="${def}"/><button class="btn primary">OK</button>`;
    box.style.left = "50%"; box.style.top = "8px"; box.style.transform = "translateX(-50%)";
    this.app.overlay.appendChild(box);
    this.inbox = box;
    const inp = box.querySelector("input");
    const go = () => {
      let v; try { v = this.num(inp.value); } catch (e) { this.app.toast(e.message, true); return; }
      this.cancelInput();
      try { if (rawCb) rawCb(inp.value); else cb(v); } catch (e) { this.app.toast(e.message, true); }
    };
    inp.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") go(); if (e.key === "Escape") this.cancelInput(); });
    box.querySelector("button").onclick = go;
    setTimeout(() => { inp.focus(); inp.select(); }, 0);
  }

  get constraints() { return this.feature.constraints || []; }

  // 図形・拘束を確定（id を整え、拘束があれば解いてから保存）。矛盾したら元に戻す
  commitSketch(ents, cons = this.constraints, { fixIdx = null, fixFields = null, keepSel = false, quiet = false } = {}) {
    const norm = normalizeSketch(ents, cons);
    let out = norm.entities;
    if (norm.constraints.length) {
      const extra = fixIdx !== null && fixFields ? [{ type: "fix", a: out[fixIdx].id, at: Object.fromEntries(fixFields.map((k) => [k, +this.num(out[fixIdx][k])])) }] : [];
      const r = solveSketch(out, [...norm.constraints, ...extra], this.num);
      if (!r.ok) {
        if (!quiet) this.app.toast("拘束を満たせません（拘束が矛盾しているか、寸法が無理な値です）", true);
        return false;
      }
      out = r.entities;
    }
    store.commit((p) => { const f = p.features.find((x) => x.id === this.featureId); f.entities = out; f.constraints = norm.constraints; }, { silent: true });
    if (!keepSel) this.selected.clear();
    this.redraw();
    this.keepInView(out);
    return true;
  }

  // 描いた形が画面からはみ出したら、全体が見えるように引く
  keepInView(ents) {
    const fr = this.frame; if (!fr) return;
    const pts = [];
    const add = (u, v) => { u = +this.num(u); v = +this.num(v); if (isFinite(u) && isFinite(v)) pts.push([0, 1, 2].map((i) => fr.origin[i] + u * fr.xDir[i] + v * fr.yDir[i])); };
    try {
      for (const e of ents) {
        if (e.type === "line") { add(e.x1, e.y1); add(e.x2, e.y2); }
        else if (e.type === "rect") { const x = +this.num(e.x), y = +this.num(e.y); add(x, y); add(x + +this.num(e.w), y + +this.num(e.h)); }
        else if (e.type === "circle") { const r = +this.num(e.d) / 2, cx = +this.num(e.cx), cy = +this.num(e.cy); add(cx - r, cy - r); add(cx + r, cy + r); }
        else if (e.type === "arc") { add(e.x1, e.y1); add(e.x2, e.y2); add(e.xm, e.ym); }
      }
    } catch { return; }
    if (this.viewer.ensureVisible(pts)) this.redraw();
  }

  addConstraint(c) {
    const others = this.constraints.filter((x) => !(x.type === c.type && x.a === c.a && (x.b || null) === (c.b || null)));
    if (this.commitSketch(this.feature.entities, [...others, c], { keepSel: true })) this.app.toast("拘束を追加しました");
  }

  removeConstraint(k) {
    const cons = this.constraints.slice(); cons.splice(k, 1);
    this.commitSketch(this.feature.entities, cons, { keepSel: true });
  }

  setEntities(ents) { this.commitSketch(ents); }

  // ---- 拘束ボタン（選択中の図形に適用）
  applyConstraintTool(kind) {
    const sel = [...this.selected];
    const ents = this.feature.entities;
    const lines = sel.filter((i) => ents[i] && ents[i].type === "line");
    const num = this.num;
    const need = (n, what) => { this.app.toast(`${what}を ${n} 本選択してから押してください（選択ツールでクリック、Shift で追加）`, true); };
    if (kind === "explode") {
      const rects = sel.filter((i) => ents[i].type === "rect");
      if (!rects.length) return this.app.toast("長方形を選択してください", true);
      const out = [];
      ents.forEach((e, i) => { if (rects.includes(i)) out.push(...explodeRect(resolveEntity(e, num))); else out.push(e); });
      this.commitSketch(out);
      return this.app.toast("長方形を 4 本の線に分解しました（拘束を付けられます）");
    }
    if (sel.some((i) => ents[i].type === "rect") && kind !== "c_fix") return this.app.toast("長方形には拘束を付けられません。「線に分解」してから使ってください", true);
    if (kind === "c_hv") {
      if (!lines.length) return need(1, "線");
      const cons = this.constraints.slice();
      for (const i of lines) {
        const e = resolveEntity(ents[i], num);
        const t = Math.abs(e.x2 - e.x1) >= Math.abs(e.y2 - e.y1) ? "h" : "v";
        if (!cons.some((c) => c.a === ents[i].id && (c.type === "h" || c.type === "v"))) cons.push({ type: t, a: ents[i].id });
      }
      return this.commitSketch(ents, cons, { keepSel: true });
    }
    if (["c_par", "c_perp", "c_eq"].includes(kind)) {
      if (lines.length !== 2) return need(2, "線");
      return this.addConstraint({ type: { c_par: "par", c_perp: "perp", c_eq: "eq" }[kind], a: ents[lines[0]].id, b: ents[lines[1]].id });
    }
    if (kind === "c_fix") {
      if (!sel.length) return need(1, "図形");
      const cons = this.constraints.slice();
      for (const i of sel) {
        const e = resolveEntity(ents[i], num);
        const at = {};
        for (const k of ["x1", "y1", "x2", "y2", "xm", "ym", "cx", "cy"]) if (e[k] !== undefined && ents[i].type !== "rect") at[k] = e[k];
        cons.push({ type: "fix", a: ents[i].id, at });
      }
      return this.commitSketch(ents, cons, { keepSel: true });
    }
    if (kind === "c_dim") {
      const plsel = sel.filter((i) => ents[i] && (ents[i].type === "point" || ents[i].type === "circle"));
      if (lines.length === 1 && !plsel.length) {
        const e = resolveEntity(ents[lines[0]], num);
        return this.askValue("長さ", fmt(Math.hypot(e.x2 - e.x1, e.y2 - e.y1)), (v) => this.addConstraint({ type: "len", a: ents[lines[0]].id, value: v }));
      }
      if (lines.length === 2 && !plsel.length) {
        const a = resolveEntity(ents[lines[0]], num), b = resolveEntity(ents[lines[1]], num);
        const ax = a.x2 - a.x1, ay = a.y2 - a.y1, bx = b.x2 - b.x1, by = b.y2 - b.y1;
        const cr = (ax * by - ay * bx) / (Math.hypot(ax, ay) * Math.hypot(bx, by));
        if (Math.abs(cr) < 0.02) {
          const L = Math.hypot(ax, ay); const d = Math.abs(((b.x1 + b.x2) / 2 - a.x1) * ay - ((b.y1 + b.y2) / 2 - a.y1) * ax) / L;
          const cons = this.constraints.some((c) => c.type === "par" && [c.a, c.b].includes(ents[lines[0]].id) && [c.a, c.b].includes(ents[lines[1]].id)) ? [] : [{ type: "par", a: ents[lines[0]].id, b: ents[lines[1]].id }];
          return this.askValue("平行な線の間の距離", fmt(d), (v) => { this.commitSketch(ents, [...this.constraints, ...cons, { type: "dist", a: ents[lines[0]].id, b: ents[lines[1]].id, value: v }], { keepSel: true }); });
        }
        const ang = Math.abs(Math.atan2(ax * by - ay * bx, ax * bx + ay * by)) * 180 / Math.PI;
        return this.askValue("2 本の線の角度（°）", fmt(Math.min(ang, 180 - ang)), (v) => this.addConstraint({ type: "ang", a: ents[lines[0]].id, b: ents[lines[1]].id, value: v }));
      }
      const pls = sel.filter((i) => ents[i] && (ents[i].type === "point" || ents[i].type === "circle"));
      const ctr = (e) => e.type === "point" ? [e.x, e.y] : [e.cx, e.cy];
      if (pls.length === 1 && lines.length === 1) {
        const p = ctr(resolveEntity(ents[pls[0]], num)), l = resolveEntity(ents[lines[0]], num);
        const ax = l.x2 - l.x1, ay = l.y2 - l.y1, L = Math.hypot(ax, ay) || 1;
        const d = Math.abs((p[0] - l.x1) * ay - (p[1] - l.y1) * ax) / L;
        return this.askValue("点（円の中心）と線の距離", fmt(d), (v) => this.addConstraint({ type: "pldist", a: ents[pls[0]].id, b: ents[lines[0]].id, value: v }));
      }
      if (pls.length === 2 && !lines.length) {
        const p = ctr(resolveEntity(ents[pls[0]], num)), q = ctr(resolveEntity(ents[pls[1]], num));
        const dx = Math.abs(q[0] - p[0]), dy = Math.abs(q[1] - p[1]);
        const mode = dy < 1e-6 ? "h" : dx < 1e-6 ? "v" : "a";
        const lab = { h: "2 点の横の距離", v: "2 点の縦の距離", a: "2 点の距離" }[mode];
        return this.askValue(lab, fmt(mode === "h" ? dx : mode === "v" ? dy : Math.hypot(dx, dy)), (v) => this.addConstraint({ type: "ppdist", mode, a: ents[pls[0]].id, b: ents[pls[1]].id, value: v }));
      }
      return this.app.toast("寸法: 線 1 本（長さ）、線 2 本（距離・角度）、点（円）と線（距離）、点 2 つ（距離）を選んでから押してください", true);
    }
  }

  // 数値または式を聞く
  askValue(label, def, cb) {
    this.askNumber(label, def, () => {}, (raw) => cb(/^-?\d+(\.\d+)?$/.test(raw.trim()) ? parseFloat(raw) : raw.trim()));
  }

  mirrorSelected() {
    const sel = [...this.selected];
    if (!sel.length) return this.app.toast("ミラーする線を選択してから実行してください（選択ツールでクリック）");
    const ents = this.feature.entities;
    const last = sel[sel.length - 1];
    const num = this.num;
    const lastIsLine = ents[last] && ents[last].type === "line";
    this.app.panel("スケッチのミラー", `<label>対称軸</label><select id="mir-ax">
        ${lastIsLine && sel.length > 1 ? `<option value="line">最後に選んだ線（${sel.length - 1} 個をミラー）</option>` : ""}
        <option value="x">スケッチの X 軸（上下反転）</option><option value="y">スケッチの Y 軸（左右反転）</option></select>`, () => {
      const v = document.getElementById("mir-ax").value;
      let axis, idx = sel;
      if (v === "line") { const e = resolveEntity(ents[last], num); axis = { a: [e.x1, e.y1], b: [e.x2, e.y2] }; idx = sel.slice(0, -1); }
      else if (v === "x") axis = { a: [0, 0], b: [1, 0] };
      else axis = { a: [0, 0], b: [0, 1] };
      this.setEntities([...ents, ...mirrorEntities(ents, idx, axis, num)]);
    }, { okLabel: "ミラー" });
  }

  onClick(ev) {
    if (!this.active) return;
    if (["sfillet", "offset", "trim"].includes(this.tool)) return this.modifyClick(ev);
    if (this.tool === "project") return this.projectClick(ev);
    if (this.tool === "dim") return this.dimClick(ev);
    if (this.tool === "select") {
      const h = this.hitEntity(ev);
      if (!ev.shiftKey) this.selected.clear();
      if (h >= 0) { if (this.selected.has(h) && ev.shiftKey) this.selected.delete(h); else this.selected.add(h); }
      this.redraw();
      this.app.showSketchSelection();
      return;
    }
    const r = this.pointFromEvent(ev);
    if (!r) return;
    this.addPoint(r.p);
  }

  // 寸法ツール（Fusion の D）: 図形を 1 つクリック → 何もない所をクリックで長さ・直径、
  // もう 1 つクリックで 2 つの間の距離・角度。選んでから押した場合はすぐ寸法
  startDim() {
    if (this.selected.size) return this.applyConstraintTool("c_dim");
    this.dimFirst = null;
    this.setTool("dim");
  }
  dimClick(ev) {
    const h = this.hitEntity(ev);
    const single = (i) => {
      const e = this.feature.entities[i];
      this.dimFirst = null; this.selected = new Set([i]); this.redraw();
      if (e.type === "circle") return this.askValue("円の直径", fmt(Math.abs(this.num(e.d))), (v) => { const ents = this.feature.entities.map((x, k) => (k === i ? { ...x, d: v } : x)); this.commitSketch(ents, this.constraints, { keepSel: true }); });
      if (e.type === "point") return this.app.toast("点は、もう 1 つの図形（線や点）をクリックして距離を付けます", true);
      return this.applyConstraintTool("c_dim");
    };
    if (h < 0) { if (this.dimFirst !== null && this.dimFirst !== undefined) return single(this.dimFirst); return; }
    if (this.dimFirst === null || this.dimFirst === undefined) {
      this.dimFirst = h; this.selected = new Set([h]); this.redraw();
      this.app.status("寸法: もう 1 つの図形をクリック（距離・角度）か、何もない所をクリック（長さ・直径）");
      return;
    }
    if (h === this.dimFirst) return single(h);
    this.selected = new Set([this.dimFirst, h]); this.dimFirst = null; this.redraw();
    this.applyConstraintTool("c_dim");
  }

  // 投影: ボディのエッジ（1 本）または面（外形すべて）をクリック → スケッチに紫の線で写す
  async projectClick(ev) {
    const hit = this.viewer.pick(ev, ["edge", "face"]);
    if (!hit || !hit.bodyId) return this.app.toast("ボディのエッジか面をクリックしてください", true);
    let ents;
    try { ents = await kernelCall("projectToSketch", { bodyId: hit.bodyId, point: hit.point, kind: hit.kind, frame: this.frame }); }
    catch (e) { return this.app.toast("投影できませんでした: " + e.message, true); }
    if (!ents.length) return this.app.toast("この向きでは投影できません（スケッチ平面に垂直なエッジです）", true);
    const add = ents.map((e) => ({ ...e, proj: true }));
    this.commitSketch([...this.feature.entities, ...add]);
    this.app.toast(`${hit.kind === "edge" ? "エッジ" : "面の外形"}を投影しました（${add.length} 本）。寸法の基準やプロファイルに使えます`);
  }

  addPoint(p) {
    const t = this.tool;
    this.pts.push(p);
    if (t === "line" && this.pts.length >= 2) {
      const [a, b] = this.pts.slice(-2);
      if (Math.hypot(a[0] - b[0], a[1] - b[1]) > 1e-9) {
        // 水平・垂直に描いた線は自動で拘束（Fusion と同じ）
        const auto = Math.abs(a[1] - b[1]) < 1e-9 ? ["h"] : Math.abs(a[0] - b[0]) < 1e-9 ? ["v"] : [];
        this.addEntity({ type: "line", x1: a[0], y1: a[1], x2: b[0], y2: b[1] }, auto);
      }
      // 始点に戻ったら終了
      const first = this.chainStart;
      if (first && Math.hypot(first[0] - b[0], first[1] - b[1]) < 1e-9) { this.pts = []; this.chainStart = null; this.cancelInput(); this.drawPreview(); return; }
      this.pts = [b];
    } else if (t === "line" && this.pts.length === 1) {
      this.chainStart = p;
    } else if (t === "point") {
      this.addEntity({ type: "point", x: p[0], y: p[1] });
      this.pts = [];
    } else if ((t === "rect" || t === "rectc") && this.pts.length === 2) {
      const [a, b] = this.pts;
      if (t === "rect") this.addEntity({ type: "rect", x: a[0], y: a[1], w: b[0] - a[0], h: b[1] - a[1] });
      else this.addEntity({ type: "rect", x: 2 * a[0] - b[0], y: 2 * a[1] - b[1], w: 2 * (b[0] - a[0]), h: 2 * (b[1] - a[1]) });
      this.pts = [];
    } else if (t === "circle" && this.pts.length === 2) {
      const [a, b] = this.pts;
      const d = 2 * Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (d > 1e-9) this.addEntity({ type: "circle", cx: a[0], cy: a[1], d });
      this.pts = [];
    } else if (t === "arc" && this.pts.length === 3) {
      const [a, b, m] = this.pts;
      if (arcFrom3(a, b, m)) this.addEntity({ type: "arc", x1: a[0], y1: a[1], x2: b[0], y2: b[1], xm: m[0], ym: m[1] });
      this.pts = [];
    } else if (t === "polygon" && this.pts.length === 2) {
      const [a, b] = this.pts;
      this.addPolygon(a, Math.hypot(b[0] - a[0], b[1] - a[1]), this.polySides || 6, Math.atan2(b[1] - a[1], b[0] - a[0]));
      this.pts = [];
    }
    this.cancelInput();
    if (this.pts.length) this.openInput();
    this.drawPreview();
  }

  modifyClick(ev) {
    const q = this.viewer.planePoint(ev, this.frame);
    if (!q) return;
    const num = this.num;
    const ents = this.feature.entities;
    try {
      if (this.tool === "sfillet") {
        const P = nearestCorner(ents, q, this.viewer.worldPerPixel() * (COARSE ? 24 : 14), num);
        if (!P) return this.app.toast("角（2本の線が交わる点）の近くをクリックしてください");
        this.askNumber("角の半径", this.lastFillet ?? 10, (r) => { this.lastFillet = r; this.setEntities(filletCorner(this.feature.entities, P, r, num)); });
      } else if (this.tool === "offset") {
        const i = this.hitEntity(ev);
        if (i < 0) return this.app.toast("線・円・長方形をクリックしてください");
        this.askNumber("オフセット距離（＋外側／－内側）", this.lastOffset ?? 5, (d) => { this.lastOffset = d; this.setEntities([...this.feature.entities, ...offsetEntity(this.feature.entities, i, d, num)]); });
      } else if (this.tool === "trim") {
        const i = this.hitEntity(ev);
        if (i < 0) return;
        this.setEntities(trimAt(ents, i, q, num));
      }
    } catch (e) { this.app.toast(e.message, true); }
  }

  addPolygon(c, r, n, a0) {
    const pts = [];
    for (let i = 0; i < n; i++) { const t = a0 + (i / n) * Math.PI * 2; pts.push([+(c[0] + r * Math.cos(t)).toFixed(6), +(c[1] + r * Math.sin(t)).toFixed(6)]); }
    store.commit((p) => {
      const f = p.features.find((x) => x.id === this.featureId);
      for (let i = 0; i < n; i++) { const a = pts[i], b = pts[(i + 1) % n]; f.entities.push({ type: "line", x1: a[0], y1: a[1], x2: b[0], y2: b[1] }); }
    }, { silent: true });
    this.redraw();
  }

  onKey(ev) {
    if (!this.active) return false;
    if (ev.key === "Escape") {
      if (this.pts.length) { this.pts = []; this.chainStart = null; this.cancelInput(); this.drawPreview(); }
      else if (this.tool !== "select") this.setTool("select");
      else if (this.selected.size) { this.selected.clear(); this.redraw(); this.app.showSketchSelection(); }
      else this.app.status("スケッチを終わるときは「スケッチを終了」を押してください（Esc ではスケッチは終わりません）");
      return true;
    }
    if ((ev.key === "Delete" || ev.key === "Backspace") && this.tool === "select" && this.selected.size && !isTyping(ev)) {
      this.deleteSelected();
      return true;
    }
    if (isTyping(ev)) return false;
    const map = { l: "line", r: "rect", c: "circle", a: "arc", p: "project", s: "select", f: "sfillet", o: "offset", t: "trim", ".": "point" };
    if (ev.key.toLowerCase() === "d" && !ev.ctrlKey && !ev.metaKey) { this.startDim(); return true; }
    if (map[ev.key.toLowerCase()] && !ev.ctrlKey && !ev.metaKey) { this.setTool(map[ev.key.toLowerCase()]); return true; }
    if (ev.key.toLowerCase() === "x" && this.selected.size) { this.toggleConstruction(); return true; }
    // 数字を打ち始めたら入力欄へ
    if (/^[0-9.\-]$/.test(ev.key) && this.pts.length && this.inbox) {
      const inp = this.inbox.querySelector("input");
      inp.focus(); inp.value = ""; return false;
    }
    return false;
  }

  addEntity(e, autoCons = []) {
    for (const k of Object.keys(e)) if (typeof e[k] === "number") e[k] = +e[k].toFixed(6);
    e.id = newEntityId();
    const cons = [...this.constraints, ...autoCons.map((t) => ({ type: t, a: e.id }))];
    this.commitSketch([...this.feature.entities, e], cons, { keepSel: true, quiet: true }) ||
      store.commit((p) => { p.features.find((x) => x.id === this.featureId).entities.push(e); }, { silent: true });
    this.redraw();
  }

  updateEntity(i, patch) {
    const ents = this.feature.entities;
    if (this.constraints.length) {
      // 拘束あり: 変更した値を固定して他を解き直す（つながりは一致として保たれる）
      const next = applyWithLinks(ents, i, { ...ents[i], ...patch }, this.num);
      const fields = Object.keys(patch).filter((k) => /^(x|y)/.test(k) || ["cx", "cy"].includes(k));
      this.commitSketch(next, this.constraints, { fixIdx: i, fixFields: fields, keepSel: true });
      return;
    }
    const next = applyWithLinks(ents, i, { ...ents[i], ...patch }, this.num);
    store.commit((p) => { p.features.find((x) => x.id === this.featureId).entities = next; }, { silent: true });
    this.redraw();
  }

  deleteSelected() {
    const del = new Set(this.selected);
    const ents = this.feature.entities.filter((_, i) => !del.has(i));
    const norm = normalizeSketch(ents, this.constraints);
    store.commit((p) => { const f = p.features.find((x) => x.id === this.featureId); f.entities = norm.entities; f.constraints = norm.constraints; }, { silent: true });
    this.selected.clear();
    this.redraw();
    this.app.showSketchSelection();
  }

  toggleConstruction() {
    const sel = [...this.selected];
    store.commit((p) => { const f = p.features.find((x) => x.id === this.featureId); for (const i of sel) f.entities[i].construction = !f.entities[i].construction; }, { silent: true });
    this.redraw();
  }

  hitEntity(ev) {
    const p = this.viewer.planePoint(ev, this.frame);
    if (!p) return -1;
    const tol = this.viewer.worldPerPixel() * (COARSE ? 16 : 6);
    const num = this.num;
    let best = -1, bd = tol;
    this.feature.entities.forEach((raw, i) => {
      let e; try { e = resolveEntity(raw, num); } catch { return; }
      const pl = entityPolyline(e);
      for (let k = 0; k < pl.length - 1; k++) {
        const d = segDist(p, pl[k], pl[k + 1]);
        if (d < bd) { bd = d; best = i; }
      }
    });
    return best;
  }

  // ------------------------------------------------ 描画
  redraw() {
    if (!this.active) return;
    this.group.clear();
    const f = this.feature;
    if (!f) return;
    const num = this.num;
    // 平面のグリッド
    this.group.add(this.planeGrid());
    this.group.add(sketchObject(this.frame, f.entities, num, { selected: this.selected, hover: this.hover }));
    // プロファイルの塗り
    let loops = [];
    try { loops = findLoops(f.entities, num); } catch { /* */ }
    for (const l of loops) {
      const shape = new THREE.Shape(l.poly.map((q) => new THREE.Vector2(q[0], q[1])));
      const m = new THREE.Mesh(new THREE.ShapeGeometry(shape), new THREE.MeshBasicMaterial({ color: 0x8fb8ee, transparent: true, opacity: 0.18, side: THREE.DoubleSide, depthTest: false, depthWrite: false }));
      m.applyMatrix4(frameMatrix(this.frame)); m.renderOrder = 22;
      this.group.add(m);
    }
    // 端点
    const pts = [];
    for (const raw of f.entities) {
      let e; try { e = resolveEntity(raw, num); } catch { continue; }
      if (e.type === "line") pts.push([e.x1, e.y1], [e.x2, e.y2]);
      if (e.type === "arc") pts.push([e.x1, e.y1], [e.x2, e.y2]);
      if (e.type === "circle") pts.push([e.cx, e.cy]);
    }
    if (pts.length) {
      const geo = new THREE.BufferGeometry().setFromPoints(pts.map((q) => new THREE.Vector3(q[0], q[1], 0)));
      const ps = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0x1d2228, size: 5, sizeAttenuation: false, depthTest: false }));
      ps.applyMatrix4(frameMatrix(this.frame)); ps.renderOrder = 31;
      this.group.add(ps);
    }
    this.previewObj = null;
    this.drawPreview();
    this.makeLabels();
    this.viewer.dirty = true;
  }

  planeGrid() {
    const g = new THREE.Group();
    const s = this.snapStep() * 5;
    const half = s * 40;
    const pts = [];
    for (let i = -40; i <= 40; i++) {
      pts.push(new THREE.Vector3(i * s, -half, 0), new THREE.Vector3(i * s, half, 0));
      pts.push(new THREE.Vector3(-half, i * s, 0), new THREE.Vector3(half, i * s, 0));
    }
    const geo = new THREE.BufferGeometry().setFromPoints(pts);
    const l = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0xc5ccd6, transparent: true, opacity: 0.7, depthWrite: false }));
    g.add(l);
    const ax = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-half, 0, 0), new THREE.Vector3(half, 0, 0), new THREE.Vector3(0, -half, 0), new THREE.Vector3(0, half, 0)]);
    const al = new THREE.LineSegments(ax, new THREE.LineBasicMaterial({ color: 0x9aa4b2, depthWrite: false }));
    g.add(al);
    g.applyMatrix4(frameMatrix(this.frame));
    g.renderOrder = -1;
    return g;
  }

  drawPreview() {
    if (this.previewObj) { this.group.remove(this.previewObj); this.previewObj = null; }
    if (!this.pts.length || !this.cursor) { this.viewer.dirty = true; return; }
    const c = this.inputOverride ? this.inputOverride() : this.cursor;
    const a = this.pts[0];
    let ents = [];
    const t = this.tool;
    if (t === "line") ents = [{ type: "line", x1: this.pts[this.pts.length - 1][0], y1: this.pts[this.pts.length - 1][1], x2: c[0], y2: c[1] }];
    if (t === "rect") ents = [{ type: "rect", x: a[0], y: a[1], w: c[0] - a[0], h: c[1] - a[1] }];
    if (t === "rectc") ents = [{ type: "rect", x: 2 * a[0] - c[0], y: 2 * a[1] - c[1], w: 2 * (c[0] - a[0]), h: 2 * (c[1] - a[1]) }];
    if (t === "circle") ents = [{ type: "circle", cx: a[0], cy: a[1], d: 2 * Math.hypot(c[0] - a[0], c[1] - a[1]) }];
    if (t === "arc") {
      if (this.pts.length === 1) ents = [{ type: "line", x1: a[0], y1: a[1], x2: c[0], y2: c[1] }];
      else ents = [{ type: "arc", x1: a[0], y1: a[1], x2: this.pts[1][0], y2: this.pts[1][1], xm: c[0], ym: c[1] }];
    }
    if (t === "polygon") {
      const r = Math.hypot(c[0] - a[0], c[1] - a[1]); const n = this.polySides || 6; const a0 = Math.atan2(c[1] - a[1], c[0] - a[0]);
      for (let i = 0; i < n; i++) { const t1 = a0 + i / n * Math.PI * 2, t2 = a0 + (i + 1) / n * Math.PI * 2; ents.push({ type: "line", x1: a[0] + r * Math.cos(t1), y1: a[1] + r * Math.sin(t1), x2: a[0] + r * Math.cos(t2), y2: a[1] + r * Math.sin(t2) }); }
    }
    this.previewObj = sketchObject(this.frame, ents, null, { color: 0xe8732a });
    this.group.add(this.previewObj);
    this.positionInput();
    this.viewer.dirty = true;
  }

  // ------------------------------------------------ 寸法ラベル
  clearLabels() { for (const l of this.labels) l.el.remove(); this.labels = []; }

  makeLabels() {
    this.clearLabels();
    const f = this.feature;
    const num = this.num;
    f.entities.forEach((raw, i) => {
      let e; try { e = resolveEntity(raw, num); } catch { return; }
      const add = (key, text, at, isExpr, extra = "") => {
        const el = document.createElement("div");
        el.className = "dimlabel" + (isExpr ? " expr" : "") + (extra ? " " + extra : "");
        if (this.tool !== "select") el.style.pointerEvents = "none";
        el.textContent = text;
        el.title = isExpr ? `式: ${raw[key]}` : "クリックして寸法を変更";
        el.addEventListener("click", (ev) => { ev.stopPropagation(); this.editDim(i, key, el); });
        this.app.overlay.appendChild(el);
        this.labels.push({ el, at });
      };
      const isE = (k) => typeof raw[k] === "string" && !/^-?\d+(\.\d+)?$/.test(raw[k]);
      if (e.type === "rect") {
        add("w", fmt(Math.abs(e.w)), [e.x + e.w / 2, e.y + (e.h > 0 ? 0 : e.h)], isE("w"));
        add("h", fmt(Math.abs(e.h)), [e.x + (e.w > 0 ? e.w : 0), e.y + e.h / 2], isE("h"));
      } else if (e.type === "circle") {
        add("d", "Ø" + fmt(Math.abs(e.d)), [e.cx + Math.abs(e.d) / 2 * 0.7071, e.cy + Math.abs(e.d) / 2 * 0.7071], isE("d"));
      } else if (e.type === "line") {
        const lc = this.constraints.find((c) => c.type === "len" && c.a === raw.id);
        const lenTxt = fmt(Math.hypot(e.x2 - e.x1, e.y2 - e.y1));
        if (lc || !raw.construction) add("len", lc ? `${lenTxt}` : lenTxt, [(e.x1 + e.x2) / 2, (e.y1 + e.y2) / 2], !!(lc && typeof lc.value === "string" && !/^-?\d+(\.\d+)?$/.test(lc.value)), lc ? "driving" : "");
      } else if (e.type === "arc") {
        const c = arcFrom3([e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym]);
        if (c) add("r", "R" + fmt(c.r), [e.xm, e.ym], false);
      }
    });
    // 拘束の印
    const byId = new Map(f.entities.map((e, i) => [e.id, i]));
    const wpp = this.viewer.worldPerPixel();
    const stack = new Map();
    (f.constraints || []).forEach((c, k) => {
      if (c.type === "len") return; // 長さは寸法ラベルで表示
      const i = byId.get(c.a); if (i === undefined) return;
      let e; try { e = resolveEntity(f.entities[i], num); } catch { return; }
      let at;
      if (e.type === "line") {
        const L = Math.hypot(e.x2 - e.x1, e.y2 - e.y1) || 1;
        const nx = -(e.y2 - e.y1) / L, ny = (e.x2 - e.x1) / L;
        const n = (stack.get(c.a) || 0); stack.set(c.a, n + 1);
        const t = 0.3 + 0.12 * n;
        at = [e.x1 + (e.x2 - e.x1) * t + nx * wpp * 14, e.y1 + (e.y2 - e.y1) * t + ny * wpp * 14];
      } else at = [e.x1 ?? e.cx ?? e.x, e.y1 ?? e.cy ?? e.y];
      if ((c.type === "pldist" || c.type === "ppdist") && byId.has(c.b)) {
        // 2 つの図形の中間に寸法を表示
        try { const e2 = resolveEntity(f.entities[byId.get(c.b)], num); const q = e2.type === "line" ? [(e2.x1 + e2.x2) / 2, (e2.y1 + e2.y2) / 2] : [e2.x ?? e2.cx, e2.y ?? e2.cy]; at = [(at[0] + q[0]) / 2, (at[1] + q[1]) / 2]; } catch { /* */ }
      }
      const isVal = ["ang", "dist", "pldist", "ppdist"].includes(c.type);
      const sym = { h: "H", v: "V", par: "∥", perp: "⊥", eq: "=", fix: "固", ang: `∠${fmt(num(c.value))}°`, dist: `↔${fmt(num(c.value))}`, pldist: `↔${fmt(num(c.value))}`, ppdist: `${c.mode === "h" ? "⟷" : c.mode === "v" ? "↕" : "↔"}${fmt(num(c.value))}` }[c.type] || c.type;
      const el = document.createElement("div");
      el.className = "cglyph" + (isVal ? " val" : "");
      el.textContent = sym;
      el.title = ({ h: "水平", v: "垂直", par: "平行", perp: "直交", eq: "等長", fix: "固定", ang: "角度", dist: "距離", pldist: "点と線の距離", ppdist: "2 点の距離" }[c.type] || "拘束") + "（クリックで変更・削除）";
      if (this.tool !== "select") el.style.pointerEvents = "none";
      el.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const items = [];
        if (isVal) items.push(["値を変更", () => this.askValue(c.type === "ang" ? "角度（°）" : "距離", c.value, (v) => { const cons = this.constraints.slice(); cons[k] = { ...c, value: v }; this.commitSketch(f.entities, cons, { keepSel: true }); })]);
        items.push(["この拘束を削除", () => this.removeConstraint(k)]);
        this.app.menu(ev, items);
      });
      this.app.overlay.appendChild(el);
      this.labels.push({ el, at });
    });
    // 長さ拘束（駆動寸法）を消すメニュー
    this.positionLabels();
  }

  positionLabels() {
    if (!this.active) return;
    const fr = this.frame;
    for (const l of this.labels) {
      const w = [0, 1, 2].map((k) => fr.origin[k] + fr.xDir[k] * l.at[0] + fr.yDir[k] * l.at[1]);
      const [x, y] = this.viewer.toScreen(w);
      l.el.style.left = x + "px"; l.el.style.top = y + "px";
    }
    this.positionInput();
  }

  editDim(i, key, el) {
    const raw = this.feature.entities[i];
    const num = this.num;
    const e = resolveEntity(raw, num);
    let cur = raw[key];
    if (key === "len") { const lc = this.constraints.find((c) => c.type === "len" && c.a === raw.id); cur = lc ? lc.value : fmt(Math.hypot(e.x2 - e.x1, e.y2 - e.y1)); }
    if (key === "r") { const c = arcFrom3([e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym]); cur = fmt(c.r); }
    if (key === "w" || key === "h") cur = typeof raw[key] === "number" ? fmt(Math.abs(raw[key])) : raw[key];
    if (key === "d") cur = typeof raw[key] === "number" ? fmt(Math.abs(raw[key])) : raw[key];
    const inp = document.createElement("input");
    inp.value = cur;
    inp.style.cssText = "position:absolute;width:90px;font-size:12px;padding:1px 4px;border:1px solid #2f7de1;border-radius:3px;pointer-events:auto;z-index:5";
    inp.style.left = el.style.left; inp.style.top = el.style.top; inp.style.transform = "translate(-50%,-50%)";
    this.app.overlay.appendChild(inp);
    inp.focus(); inp.select();
    let finished = false;
    const done = (ok) => {
      if (finished) return;
      finished = true;
      const v = inp.value.trim();
      inp.remove();
      if (!ok || !v) return;
      let val;
      try { val = num(v); } catch (err) { this.app.toast(err.message, true); return; }
      const isNum = /^-?\d+(\.\d+)?$/.test(v);
      const keep = isNum ? val : v;
      if (key === "w" || key === "h") {
        const neg = e[key] < 0;
        this.updateEntity(i, { [key]: neg ? (isNum ? -val : `-(${v})`) : keep });
      } else if (key === "d") {
        this.updateEntity(i, { d: keep });
      } else if (key === "len") {
        // 線の長さは「駆動寸法」として拘束にする（後からパラメータでも変えられる）
        const id = this.feature.entities[i].id;
        this.addConstraint({ type: "len", a: id, value: isNum ? val : v });
      } else if (key === "r") {
        const c = arcFrom3([e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym]);
        const s = val / c.r;
        const mx = c.cx + (e.xm - c.cx) * s, my = c.cy + (e.ym - c.cy) * s;
        // 端点固定で半径を変える: 中点を弦の垂直二等分線上に置き直す
        const hx = (e.x1 + e.x2) / 2, hy = (e.y1 + e.y2) / 2;
        const half = Math.hypot(e.x2 - e.x1, e.y2 - e.y1) / 2;
        if (val < half) { this.app.toast("半径が弦の半分より小さいです", true); return; }
        const nx = -(e.y2 - e.y1) / (2 * half), ny = (e.x2 - e.x1) / (2 * half);
        const side = Math.sign((e.xm - hx) * nx + (e.ym - hy) * ny) || 1;
        const sag = val - Math.sqrt(val * val - half * half);
        void mx; void my;
        this.updateEntity(i, { xm: +(hx + nx * sag * side).toFixed(6), ym: +(hy + ny * sag * side).toFixed(6) });
      }
    };
    inp.addEventListener("keydown", (ev) => { ev.stopPropagation(); if (ev.key === "Enter") done(true); if (ev.key === "Escape") done(false); });
    inp.addEventListener("blur", () => done(true));
  }

  // ------------------------------------------------ 数値入力ボックス
  openInput() {
    const t = this.tool;
    const fields = {
      line: [["長さ", ""], ["角度°", ""]],
      rect: [["幅", ""], ["高さ", ""]],
      rectc: [["幅", ""], ["高さ", ""]],
      circle: [["直径", ""]],
      polygon: [["直径", ""], ["辺数", String(this.polySides || 6)]],
    }[t];
    if (!fields) return;
    const box = document.createElement("div");
    box.className = "inbox";
    const inputs = fields.map(([ph, v]) => {
      const i = document.createElement("input"); i.placeholder = ph; i.value = v; box.appendChild(i); return i;
    });
    this.app.overlay.appendChild(box);
    this.inbox = box;
    const num = this.num;
    const vals = () => inputs.map((i) => { try { return i.value.trim() ? num(i.value) : null; } catch { return null; } });
    const a = this.pts[this.pts.length - 1];
    this.inputOverride = () => {
      const [v1, v2] = vals();
      const c = this.cursor || a;
      if (t === "line") {
        let ang = Math.atan2(c[1] - a[1], c[0] - a[0]);
        let L = Math.hypot(c[0] - a[0], c[1] - a[1]);
        if (v2 !== null) ang = v2 * Math.PI / 180;
        if (v1 !== null) L = v1;
        return [a[0] + L * Math.cos(ang), a[1] + L * Math.sin(ang)];
      }
      if (t === "rect") {
        const sx = Math.sign(c[0] - a[0]) || 1, sy = Math.sign(c[1] - a[1]) || 1;
        return [v1 !== null ? a[0] + sx * v1 : c[0], v2 !== null ? a[1] + sy * v2 : c[1]];
      }
      if (t === "rectc") {
        const sx = Math.sign(c[0] - a[0]) || 1, sy = Math.sign(c[1] - a[1]) || 1;
        return [v1 !== null ? a[0] + sx * v1 / 2 : c[0], v2 !== null ? a[1] + sy * v2 / 2 : c[1]];
      }
      if (t === "circle" || t === "polygon") {
        if (t === "polygon" && v2) this.polySides = Math.max(3, Math.round(v2));
        if (v1 === null) return c;
        const ang = Math.atan2(c[1] - a[1], c[0] - a[0]) || 0;
        return [a[0] + v1 / 2 * Math.cos(ang), a[1] + v1 / 2 * Math.sin(ang)];
      }
      return c;
    };
    inputs.forEach((inp, k) => {
      inp.addEventListener("input", () => this.drawPreview());
      inp.addEventListener("keydown", (ev) => {
        ev.stopPropagation();
        if (ev.key === "Tab") { ev.preventDefault(); inputs[(k + 1) % inputs.length].focus(); inputs[(k + 1) % inputs.length].select(); }
        if (ev.key === "Enter") { const p = this.inputOverride(); this.cancelInput(); this.addPoint(p); }
        if (ev.key === "Escape") { this.cancelInput(); this.pts = []; this.drawPreview(); }
      });
    });
    this.positionInput();
  }

  positionInput() {
    if (!this.inbox) return;
    if (COARSE) { // タッチ端末: 指で隠れないよう画面上部中央に固定
      this.inbox.style.left = "50%"; this.inbox.style.top = "8px"; this.inbox.style.transform = "translateX(-50%)";
      return;
    }
    if (!this.cursor) return;
    const fr = this.frame, c = this.cursor;
    const w = [0, 1, 2].map((k) => fr.origin[k] + fr.xDir[k] * c[0] + fr.yDir[k] * c[1]);
    const [x, y] = this.viewer.toScreen(w);
    this.inbox.style.left = x + 16 + "px"; this.inbox.style.top = y + 14 + "px";
  }

  cancelInput() {
    if (this.inbox) { this.inbox.remove(); this.inbox = null; }
    this.inputOverride = null;
  }
}

function segDist(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const L2 = dx * dx + dy * dy;
  let t = L2 ? ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2 : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy);
}

function isTyping(ev) {
  const t = ev.target;
  return t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT");
}
