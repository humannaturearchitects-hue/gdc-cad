// パソコンでのモデリング操作の使いやすさ（Fusion 360 に近い操作）
//  ・複数選択（Shift/Ctrl クリック・範囲選択・Ctrl+A）と、選んだものの一括操作（移動・削除・表示・材料・透過）
//  ・コピー＆貼り付け（Ctrl+C / Ctrl+V / Ctrl+D）。別のファイルへの貼り付けもできる
//  ・プロパティ（選んだボディの位置・大きさを見て、数値で直す）
//  ・計測（点・エッジ・面・ボディの間の最短距離、平行な面の間隔、角度、穴の直径）
//  ・視点（正面/上/右…・選択部分に合わせる・面を正面から見る）、非表示・単独表示・透過
//  ・キーボードショートカットの追加と一覧（? キー）
// main.js からは installUX(app) を呼ぶだけ（ほかの作業と衝突しにくいよう、ここにまとめる）
import * as THREE from "three";
import { store, newId } from "./store.js";
import { call } from "./kernel.js";
import { esc } from "./commands.js";
import { makeEvaluator } from "./shared/expr.js";
import { resolveEntity } from "./shared/sketchgeom.js";
import { newEntityId } from "./shared/solver.js";

const lsGet = (k, d = null) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* */ } };
const fmt = (v, d = 2) => (+(+v).toFixed(d)).toString();
const COARSE = typeof matchMedia !== "undefined" && matchMedia("(pointer: coarse)").matches;

// 視点（Fusion のビューキューブと同じ向き。Z が上）
export const VIEWS = {
  front: ["前（正面）", [0, -1, 0], [0, 0, 1], "1"],
  back: ["後ろ", [0, 1, 0], [0, 0, 1], "2"],
  right: ["右", [1, 0, 0], [0, 0, 1], "3"],
  left: ["左", [-1, 0, 0], [0, 0, 1], "4"],
  top: ["上", [0, 0, 1], [0, 1, 0], "5"],
  bottom: ["下", [0, 0, -1], [0, -1, 0], "6"],
  iso: ["斜め（等角）", [1, -1, 1], [0, 0, 1], "7"],
};

// キーボードショートカットの一覧（? キー・ファイル → ショートカット一覧）
export const SHORTCUTS = [
  ["基本", [
    ["Ctrl+Z", "元に戻す"], ["Ctrl+Y / Ctrl+Shift+Z", "やり直し"], ["Ctrl+S", "保存"], ["Ctrl+O", "ファイル一覧"], ["Ctrl+N", "新規"],
    ["Esc", "コマンドの取り消し・選択の解除"], ["Enter", "ダイアログの OK"], ["F1", "操作ガイド"], ["?", "このショートカット一覧"], ["/", "AI に頼む（言葉で操作）"],
  ]],
  ["選択・編集", [
    ["クリック", "面・エッジを選ぶ"], ["ダブルクリック", "ボディを選ぶ"], ["Shift / Ctrl + クリック", "選択に追加・外す"],
    ["Shift + ドラッグ", "範囲で選ぶ（左→右: 全体が入ったもの / 右→左: かかったもの）"], ["Ctrl+A", "表示中のボディをすべて選ぶ"],
    ["Ctrl+C", "コピー"], ["Ctrl+V", "貼り付け（移動ダイアログで位置を決める）"], ["Ctrl+D", "複製（コピー＆貼り付け）"],
    ["Delete", "選んだボディを削除"], ["M", "移動/コピー"], ["V", "表示 / 非表示"], ["Shift+V", "単独表示（選んだものだけ）/ 解除"],
    ["A", "色（外観）"], ["P", "プロパティ（位置・大きさ）を表示 / 隠す"],
  ]],
  ["作成・修正", [
    ["S", "スケッチ作成"], ["E", "押し出し"], ["H", "穴"], ["Q", "プレス/プル"], ["F", "フィレット（エッジ選択中）"], ["J", "ジョイント"], ["I", "計測"],
  ]],
  ["視点", [
    ["F6 / F", "全体表示"], ["Shift+F", "選んだものに合わせる"], ["Home / 0", "ホーム（斜め）"],
    ["1 / 2", "前 / 後ろ"], ["3 / 4", "右 / 左"], ["5 / 6", "上 / 下"], ["7", "斜め（等角）"],
    ["左ドラッグ", "回転"], ["右・中ドラッグ", "移動（パン）"], ["ホイール", "ズーム"],
  ]],
  ["スケッチ中", [
    ["L", "線"], ["R", "長方形"], ["C", "円"], ["A", "円弧"], ["P", "投影"], ["D", "寸法"], ["F", "フィレット"], ["O", "オフセット"], ["T", "トリム"], ["X", "補助線 切替"],
    ["S", "選択"], ["Ctrl+C / Ctrl+V", "線のコピー / 貼り付け"], ["Ctrl+A", "すべての線を選ぶ"], ["Delete", "削除"], ["E", "スケッチを終了して押し出し"],
  ]],
];

class UX {
  constructor(app) {
    this.app = app;
    this.v = app.viewer;
    this.isolated = null;             // 単独表示中のボディ id（表示だけ。保存されない）
    this.bodyPriority = lsGet("gdc-body-priority") === "1";
    this.multiTap = false;            // タッチで「追加して選ぶ」
    this.boxMode = false;             // 範囲選択モード（タッチ・マウス共通）
    this.propsOn = lsGet("gdc-props", COARSE ? "0" : "1") === "1";
    this.clip = null;
    this.meas = null;
    this.hookViewer();
    this.hookApp();
    this.bindKeys();
    this.bindBox();
    this.buildNav();
    this.addMenus();
  }

  // ------------------------------------------------------------ 選択の補助
  selBodies() {
    const s = this.app.selection || [];
    return [...new Set(s.filter((x) => x.bodyId && x.kind !== "profile").map((x) => x.bodyId))].filter((id) => this.app.meshes.some((m) => m.id === id));
  }
  bodyName(id) { return this.app.meshes.find((m) => m.id === id)?.name || id; }
  setSelection(list) {
    this.app.selection = list;
    this.app.reapplyHighlights(); this.app.renderBrowser();
    const n = list.length;
    this.app.status(n ? `${n} 個選択中 — M 移動 / Delete 削除 / V 表示切替 / Ctrl+C コピー / 右クリックでメニュー` : "準備完了");
  }
  idle() { return this.app.mode === "idle" && !this.app.dialog.isOpen; }

  // ------------------------------------------------------------ 3D 表示への後付け（単独表示・透過）
  hookViewer() {
    const v = this.v, orig = v.setBodies.bind(v);
    v.setBodies = (meshes) => { orig(meshes); this.applyViewState(); };
  }
  applyViewState() {
    const props = store.project.bodyProps || {};
    if (this.isolated) {
      const alive = [...this.isolated].filter((id) => this.v.bodies.has(id));
      if (!alive.length) this.isolated = null; else this.isolated = new Set(alive);
    }
    for (const [id, b] of this.v.bodies) {
      const vis = !b.data.hidden && (!this.isolated || this.isolated.has(id));
      if (b.mesh.visible !== vis) this.v.setBodyVisible(id, vis);
      const op = props[id] && props[id].opacity;
      if (op && op < 1) this.v.setBodyOpacity(id, op);
    }
    this.showIsoBar();
    // 消えたボディを指したままの選択は外す（元に戻す・削除のあと）
    const sel = this.app.selection || [];
    const keep = sel.filter((s) => !s.bodyId || this.v.bodies.has(s.bodyId));
    if (keep.length !== sel.length) this.app.selection = keep;
    this.schedProps();
  }
  showIsoBar() {
    let bar = document.getElementById("ux-isobar");
    if (!this.isolated) { if (bar) bar.remove(); return; }
    if (!bar) {
      bar = document.createElement("div"); bar.id = "ux-isobar";
      document.getElementById("viewport").appendChild(bar);
    }
    bar.innerHTML = `<span>単独表示中（${this.isolated.size} 個のボディ）</span><button>すべて表示に戻す（Shift+V）</button>`;
    bar.querySelector("button").onclick = () => this.unisolate();
  }

  // ------------------------------------------------------------ app への後付け
  hookApp() {
    const app = this.app;
    // 選択の優先: ボディ（Fusion の「ボディ優先で選択」）
    const ck = app.currentKinds.bind(app);
    app.currentKinds = () => (this.bodyPriority && app.mode === "idle" && !app.dialog.isOpen ? ["body"] : ck());
    // タッチで「追加して選ぶ」モード
    const vc = app.onViewClick.bind(app);
    app.onViewClick = (e) => {
      if (this.multiTap && !e.shiftKey && !e.ctrlKey && app.mode === "idle" && !app.dialog.isOpen) return vc({ clientX: e.clientX, clientY: e.clientY, shiftKey: true, ctrlKey: false, button: 0, pointerType: e.pointerType });
      return vc(e);
    };
    // 選択が変わったらプロパティを更新
    const ra = app.reapplyHighlights.bind(app);
    app.reapplyHighlights = () => { ra(); this.schedProps(); };
    // 計測
    app.measureClick = (e) => this.measureClick(e);
    const cm = app.clearMeasure.bind(app);
    app.clearMeasure = () => { cm(); this.clearMeas(); };
    const bm = app.beginMeasure.bind(app);
    app.beginMeasure = () => { bm(); this.meas = { ents: [] }; this.app.status("計測: 点（角）・エッジ・面をクリック。2 つ目をクリックすると間の距離を表示します。Esc で終了"); this.showMeasPanel(); };
    // 右クリックメニューに項目を足す
    const menu = app.menu.bind(app);
    app.menu = (ev, items) => {
      const extra = this.menuExtra; this.menuExtra = null;
      if (extra) items = extra(items);
      return menu(ev, items);
    };
    const bodyMenu = app.bodyMenu.bind(app);
    app.bodyMenu = (ev, id) => { this.menuExtra = (items) => this.extendBodyMenu(items, id); return bodyMenu(ev, id); };
    const vctx = app.onViewContext.bind(app);
    app.onViewContext = (e) => {
      if (app.mode === "idle" && !app.dialog.isOpen) {
        // ボディ優先のときはボディを右クリックで選ぶ
        if (this.bodyPriority) { const hit = this.v.pick(e, ["body"]); if (hit && !this.selBodies().includes(hit.bodyId)) this.setSelection([{ kind: "body", bodyId: hit.bodyId }]); }
        this.menuExtra = (items) => this.extendViewMenu(items);
      }
      return vctx(e);
    };
  }

  extendBodyMenu(items, id) {
    const ids = this.selBodies().includes(id) ? this.selBodies() : [id];
    const n = ids.length > 1 ? `（${ids.length} 個）` : "";
    const out = items.map(([l, fn]) => {
      if (l === "材料（密度）の設定") return [`材料（密度）の設定${n}`, () => this.setMaterial(ids)];
      if (l === "色の変更" && ids.length > 1) return [`色の変更${n}`, () => this.pickColor(ids)];
      if ((l === "表示" || l === "非表示") && ids.length > 1) return [`表示 / 非表示${n}`, () => this.toggleVisible(ids)];
      return [l, fn];
    });
    const at = out.findIndex(([l]) => l.startsWith("削除"));
    out.splice(at < 0 ? out.length : at, 0,
      [`コピー（Ctrl+C）${n}`, () => this.copy(ids)],
      [`複製（Ctrl+D）${n}`, () => this.duplicate(ids)],
      [`単独表示（Shift+V）${n}`, () => this.isolate(ids)],
      [this.isOpaque(ids) ? `透過して表示${n}` : `透過をやめる${n}`, () => this.toggleOpacity(ids)],
      ["選んだものに合わせて表示（Shift+F）", () => this.fitSelection(ids)],
      ["プロパティ（位置・大きさ）", () => { this.propsOn = true; lsSet("gdc-props", "1"); this.updateNav(); this.updateProps(); }],
    );
    return out;
  }
  extendViewMenu(items) {
    const ids = this.selBodies();
    const out = [...items];
    const face = (this.app.selection || []).find((s) => s.kind === "face" && s.normal);
    const at = (label) => { const i = out.findIndex(([l]) => l === label); return i < 0 ? out.length : i; };
    if (face) out.splice(at("この面にスケッチを作成") + 1, 0, ["この面を正面から見る", () => this.lookAt(face)]);
    if (ids.length) out.splice(at("スケッチを作成"), 0, [`コピー（Ctrl+C）`, () => this.copy(ids)], [`複製（Ctrl+D）`, () => this.duplicate(ids)], ["表示 / 非表示（V）", () => this.toggleVisible(ids)], ["単独表示（Shift+V）", () => this.isolate(ids)], [this.isOpaque(ids) ? "透過して表示" : "透過をやめる", () => this.toggleOpacity(ids)]);
    if (this.clip) out.splice(at("スケッチを作成"), 0, ["貼り付け（Ctrl+V）", () => this.paste()]);
    if (this.isolated) out.push(["単独表示を解除（すべて表示）", () => this.unisolate()]);
    out.push(["ショートカット一覧（?）", () => this.openShortcuts()]);
    return out;
  }

  // ------------------------------------------------------------ キーボード
  bindKeys() {
    window.addEventListener("keydown", (e) => {
      const t = e.target, typing = t && (["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName) || t.isContentEditable);
      if (typing) return;
      if (document.getElementById("drawing-ws") && !document.getElementById("drawing-ws").classList.contains("hidden")) return;
      const app = this.app, ctrl = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
      const done = () => { e.preventDefault(); e.stopImmediatePropagation(); };
      if (e.key === "?" || (e.key === "/" && e.shiftKey)) { done(); return this.openShortcuts(); }
      // スケッチ中: 線のコピー・貼り付け・全選択
      if (app.mode === "sketch") {
        if (ctrl && k === "c") { done(); return this.sketchCopy(); }
        if (ctrl && k === "v") { done(); return this.sketchPaste(); }
        if (ctrl && k === "a") { done(); return this.sketchSelectAll(); }
        return;
      }
      if (ctrl && !e.shiftKey && k === "c" && this.idle()) { done(); return this.copy(); }
      if (ctrl && !e.shiftKey && k === "v" && this.idle()) { done(); return this.paste(); }
      if (ctrl && k === "d" && this.idle()) { done(); return this.duplicate(); }
      if (ctrl && k === "a" && this.idle()) { done(); return this.selectAll(); }
      if (ctrl || e.altKey) return;
      if (e.key === "F6") { done(); return this.v.fit(); }
      if (e.key === "Home") { done(); return this.v.home(); }
      if (app.dialog.isOpen && app.mode !== "measure") return;
      if (k === "f" && e.shiftKey) { done(); return this.fitSelection(); }
      if (app.mode !== "idle" && app.mode !== "measure") return;
      if (/^[0-7]$/.test(e.key)) { done(); return e.key === "0" ? this.v.home() : this.setView(Object.keys(VIEWS).find((x) => VIEWS[x][3] === e.key)); }
      if (app.mode !== "idle") return;
      if (k === "v" && e.shiftKey) { done(); return this.isolated ? this.unisolate() : this.isolate(); }
      if (k === "v") { done(); return this.toggleVisible(); }
      if (k === "a" && !e.shiftKey) { done(); const ids = this.selBodies(); return ids.length ? this.pickColor(ids) : app.toast("色を変えるボディを選んでください"); }
      if (k === "p" && !e.shiftKey) { done(); return this.toggleProps(); }
    }, { capture: true });
  }

  // ------------------------------------------------------------ 範囲選択（Shift/Ctrl + ドラッグ、または「範囲」ボタン）
  bindBox() {
    const c = this.v.canvas;
    let B = null;
    c.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || !this.idle()) return;
      const want = this.boxMode || (e.pointerType === "mouse" && (e.shiftKey || e.ctrlKey || e.metaKey));
      if (!want) return;
      e.stopImmediatePropagation(); e.preventDefault();
      const r = c.getBoundingClientRect();
      B = { x0: e.clientX - r.left, y0: e.clientY - r.top, x1: e.clientX - r.left, y1: e.clientY - r.top, add: e.shiftKey || e.ctrlKey || e.metaKey || this.multiTap, ev: e, moved: false };
      try { c.setPointerCapture(e.pointerId); } catch { /* */ }
    }, { capture: true });
    c.addEventListener("pointermove", (e) => {
      if (!B) return;
      e.stopImmediatePropagation();
      const r = c.getBoundingClientRect();
      B.x1 = e.clientX - r.left; B.y1 = e.clientY - r.top;
      if (Math.hypot(B.x1 - B.x0, B.y1 - B.y0) > 5) B.moved = true;
      if (B.moved) this.drawBox(B);
    }, { capture: true });
    const end = (e) => {
      if (!B) return;
      e.stopImmediatePropagation();
      const b = B; B = null;
      try { c.releasePointerCapture(e.pointerId); } catch { /* */ }
      this.drawBox(null);
      if (!b.moved) {
        // ただのクリック（Shift/Ctrl + クリック）は、ふつうの追加選択
        this.app.onViewClick({ clientX: e.clientX, clientY: e.clientY, shiftKey: b.add, ctrlKey: false, button: 0, pointerType: e.pointerType });
        return;
      }
      this.boxSelect(b);
    };
    c.addEventListener("pointerup", end, { capture: true });
    c.addEventListener("pointercancel", end, { capture: true });
    // Shift/Ctrl + ダブルクリック: ボディを選択に追加（外す）
    c.addEventListener("dblclick", (e) => {
      if (!(e.shiftKey || e.ctrlKey || e.metaKey || this.multiTap) || !this.idle()) return;
      e.stopImmediatePropagation();
      const hit = this.v.pick(e, ["body"]); if (!hit) return;
      const sel = (this.app.selection || []).filter((s) => s.bodyId !== hit.bodyId || s.kind !== "body");
      const had = sel.length !== (this.app.selection || []).length;
      this.setSelection(had ? sel : [...sel.filter((s) => !(s.kind === "face" && s.bodyId === hit.bodyId)), { kind: "body", bodyId: hit.bodyId }]);
    }, { capture: true });
  }
  drawBox(b) {
    let el = document.getElementById("ux-box");
    if (!b) { if (el) el.remove(); return; }
    if (!el) { el = document.createElement("div"); el.id = "ux-box"; this.app.overlay.appendChild(el); }
    const cross = b.x1 < b.x0;
    el.className = cross ? "cross" : "";
    Object.assign(el.style, { left: Math.min(b.x0, b.x1) + "px", top: Math.min(b.y0, b.y1) + "px", width: Math.abs(b.x1 - b.x0) + "px", height: Math.abs(b.y1 - b.y0) + "px" });
  }
  // 左→右: 全体が枠に入ったボディ / 右→左: 枠にかかったボディ（Fusion と同じ）
  boxSelect(b) {
    const x0 = Math.min(b.x0, b.x1), x1 = Math.max(b.x0, b.x1), y0 = Math.min(b.y0, b.y1), y1 = Math.max(b.y0, b.y1);
    const cross = b.x1 < b.x0;
    const cam = this.v.camera; cam.updateMatrixWorld();
    const W = this.v.canvas.clientWidth, H = this.v.canvas.clientHeight, p = new THREE.Vector3();
    const hits = [];
    for (const [id, body] of this.v.bodies) {
      if (!body.mesh.visible) continue;
      const vs = body.data.vertices; if (!vs || !vs.length) continue;
      const n = vs.length / 3, step = Math.max(1, Math.floor(n / 4000));
      let inside = 0, total = 0;
      let mnx = Infinity, mny = Infinity, mxx = -Infinity, mxy = -Infinity;
      for (let i = 0; i < n; i += step) {
        p.set(vs[i * 3], vs[i * 3 + 1], vs[i * 3 + 2]).project(cam);
        const sx = (p.x + 1) / 2 * W, sy = (1 - p.y) / 2 * H;
        total++;
        if (sx >= x0 && sx <= x1 && sy >= y0 && sy <= y1) inside++;
        mnx = Math.min(mnx, sx); mxx = Math.max(mxx, sx); mny = Math.min(mny, sy); mxy = Math.max(mxy, sy);
      }
      if (!total) continue;
      const ok = cross ? (inside > 0 || (mnx <= x1 && mxx >= x0 && mny <= y1 && mxy >= y0 && this.boxCrossesBody(body, x0, y0, x1, y1))) : inside === total;
      if (ok) hits.push(id);
    }
    const base = b.add ? (this.app.selection || []).slice() : [];
    for (const id of hits) if (!base.some((s) => s.kind === "body" && s.bodyId === id)) base.push({ kind: "body", bodyId: id });
    this.setSelection(base);
    if (!hits.length) this.app.status(cross ? "枠にかかったボディはありません" : "枠の中に全体が入ったボディはありません（右から左へドラッグすると、かかったものも選べます）");
  }
  // 枠の中心を通る視線がボディに当たるか（大きな板の中ほどだけを囲んだとき）
  boxCrossesBody(body, x0, y0, x1, y1) {
    const r = this.v.canvas.getBoundingClientRect();
    for (const [fx, fy] of [[0.5, 0.5], [0.25, 0.25], [0.75, 0.75], [0.25, 0.75], [0.75, 0.25]]) {
      const ev = { clientX: r.left + x0 + (x1 - x0) * fx, clientY: r.top + y0 + (y1 - y0) * fy };
      this.v.raycaster.setFromCamera(this.v.ndc(ev), this.v.camera);
      if (this.v.raycaster.intersectObject(body.mesh, false).length) return true;
    }
    return false;
  }
  selectAll() {
    const list = [...this.v.bodies.entries()].filter(([, b]) => b.mesh.visible).map(([id]) => ({ kind: "body", bodyId: id }));
    this.setSelection(list);
    this.app.toast(list.length ? `表示中のボディ ${list.length} 個を選びました` : "ボディがありません");
  }

  // ------------------------------------------------------------ コピー・貼り付け・複製
  copy(ids = this.selBodies()) {
    if (!ids.length) return this.app.toast("コピーするボディを選んでください（ボディはダブルクリック、またはツリーで選択）");
    const names = ids.map((id) => this.bodyName(id));
    this.clip = { docId: store.docId, ids: [...ids], names, step: null };
    // 別のファイルに貼り付けるときのために、形のデータ（STEP）も取っておく
    this.clip.step = call("export", { ids, format: "step" }).catch(() => null);
    this.app.toast(`${ids.length} 個のボディをコピーしました（Ctrl+V で貼り付け）`);
  }
  async paste() {
    const c = this.clip;
    if (!c) return this.app.toast("先にボディを選んで Ctrl+C でコピーしてください");
    if (c.docId === store.docId) {
      const ids = c.ids.filter((id) => this.app.meshes.some((m) => m.id === id));
      if (!ids.length) return this.app.toast("コピーしたボディがもうありません（削除されたか、手順をさかのぼっています）", true);
      return this.openCopyMove(ids);
    }
    // 別のファイルへ: コピーしたときの形を STEP として読み込む
    const buf = await c.step;
    if (!buf) return this.app.toast("コピーした形を読み込めませんでした。元のファイルで、もう一度コピーしてください", true);
    const name = (c.names.length === 1 ? c.names[0] : `${c.names[0]} ほか${c.names.length - 1}個`).replace(/[\\/:*?"<>|]/g, "_");
    await this.app.importFile(new File([buf], `${name}.step`));
    this.app.toast(`${c.ids.length} 個のボディを貼り付けました（別のファイルからの貼り付けは、形だけのコピーになります）`);
  }
  duplicate(ids = this.selBodies()) {
    if (!ids.length) return this.app.toast("複製するボディを選んでください");
    this.copy(ids);
    this.openCopyMove(ids);
  }
  // Fusion と同じく、貼り付けると「移動/コピー」が開き、矢印や数値で置き場所を決める
  openCopyMove(ids) {
    const app = this.app;
    app.preselect = ids.map((id) => ({ kind: "body", bodyId: id }));
    try { app.dialog.open("move"); } finally { app.preselect = null; }
    const a = app.dialog.active; if (!a) return;
    a.draft.copy = true; app.dialog.touched = true;
    app.dialog.render(); app.dialog.preview();
    app.status("貼り付け: 矢印をドラッグするか、移動 X,Y,Z に数値を入れて OK（Enter）。コピーは元と同じ位置にできています");
  }

  // スケッチ中の線のコピー・貼り付け（少しずらして貼り、貼ったものを選んだ状態に）
  sketchCopy() {
    const sk = this.app.sketcher; const f = sk.feature;
    if (!f || !sk.selected.size) return this.app.toast("コピーする線を選んでください（選択ツール S でクリック）");
    const num = makeEvaluator(store.project.params || []);
    const ents = [...sk.selected].map((i) => f.entities[i]).filter(Boolean).map((e) => { const r = resolveEntity(e, num); delete r.id; return r; });
    this.sclip = ents;
    this.app.toast(`${ents.length} 個の図形をコピーしました（Ctrl+V で貼り付け）`);
  }
  sketchPaste() {
    const sk = this.app.sketcher;
    if (!this.sclip || !this.sclip.length) return this.app.toast("先に線を選んで Ctrl+C でコピーしてください");
    // 図形の大きさに合わせて右下にずらす（重ならないように）
    let mx = 0; for (const e of this.sclip) { if (e.type === "rect") mx = Math.max(mx, Math.abs(e.w), Math.abs(e.h)); if (e.type === "circle") mx = Math.max(mx, Math.abs(e.d)); if (e.type === "line") mx = Math.max(mx, Math.abs(e.x2 - e.x1), Math.abs(e.y2 - e.y1)); }
    const off = Math.max(5, Math.round(mx * 0.2));
    const sh = (e) => {
      const o = { ...e, id: newEntityId() };
      for (const k of ["x", "x1", "x2", "xm", "cx"]) if (typeof o[k] === "number") o[k] = +(o[k] + off).toFixed(6);
      for (const k of ["y", "y1", "y2", "ym", "cy"]) if (typeof o[k] === "number") o[k] = +(o[k] - off).toFixed(6);
      return o;
    };
    const add = this.sclip.map(sh);
    const n0 = sk.feature.entities.length;
    store.commit((p) => { const f = p.features.find((x) => x.id === sk.featureId); f.entities.push(...add); }, { silent: true });
    sk.selected = new Set(add.map((_, i) => n0 + i));
    if (sk.tool !== "select") sk.setTool("select");
    sk.selected = new Set(add.map((_, i) => n0 + i));
    sk.redraw();
    this.app.status(`${add.length} 個の図形を貼り付けました（${off} mm ずらしています。ドラッグで動かせます。Ctrl+Z で取り消し）`);
  }
  sketchSelectAll() {
    const sk = this.app.sketcher; if (!sk.feature) return;
    if (sk.tool !== "select") sk.setTool("select");
    sk.selected = new Set(sk.feature.entities.map((_, i) => i));
    sk.redraw(); this.app.showSketchSelection && this.app.showSketchSelection();
    this.app.status(`${sk.selected.size} 個の図形を選びました`);
  }

  // ------------------------------------------------------------ 表示・非表示・単独表示・透過
  toggleVisible(ids = this.selBodies()) {
    if (!ids.length) return this.app.toast("表示を切り替えるボディを選んでください（ツリーの 👁 でも切り替えられます）");
    const allHidden = ids.every((id) => this.app.meshes.find((m) => m.id === id)?.hidden);
    store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const id of ids) p.bodyProps[id] = { ...(p.bodyProps[id] || {}), hidden: !allHidden }; });
    if (!allHidden) this.app.selection = (this.app.selection || []).filter((s) => !ids.includes(s.bodyId));
    this.app.toast(`${ids.length} 個のボディを${allHidden ? "表示" : "非表示に"}しました${allHidden ? "" : "（V でもう一度・ツリーの 👁 で戻せます）"}`);
  }
  showAll() {
    this.isolated = null;
    store.commit((p) => { for (const k of p.components || []) k.hidden = false; for (const m of this.app.meshes) if (p.bodyProps?.[m.id]) p.bodyProps[m.id].hidden = false; });
  }
  isolate(ids = this.selBodies()) {
    if (!ids.length) return this.app.toast("単独表示するボディを選んでください");
    this.isolated = new Set(ids);
    this.applyViewState();
    this.app.toast(`選んだ ${ids.length} 個だけを表示しています（Shift+V で元に戻す）`);
  }
  unisolate() { this.isolated = null; this.applyViewState(); }
  isOpaque(ids) { const bp = store.project.bodyProps || {}; return ids.some((id) => !(bp[id] && bp[id].opacity < 1)); }
  toggleOpacity(ids = this.selBodies()) {
    if (!ids.length) return this.app.toast("透過するボディを選んでください");
    const to = this.isOpaque(ids) ? 0.35 : 1;
    store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const id of ids) { const q = { ...(p.bodyProps[id] || {}) }; if (to < 1) q.opacity = to; else delete q.opacity; p.bodyProps[id] = q; } });
  }
  pickColor(ids) {
    const inp = document.createElement("input"); inp.type = "color";
    inp.value = this.app.meshes.find((x) => x.id === ids[0])?.color || "#9aa3ad";
    inp.style.cssText = "position:fixed;left:-100px";
    document.body.appendChild(inp);
    inp.addEventListener("change", () => { store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const id of ids) p.bodyProps[id] = { ...(p.bodyProps[id] || {}), color: inp.value }; }); inp.remove(); });
    inp.click();
  }
  setMaterial(ids) {
    const M = this.app.MATERIALS;
    const ms = ids.map((id) => this.app.meshes.find((x) => x.id === id)?.material || {});
    const cur = ms.every((m) => (m.name || "") === (ms[0].name || "")) ? ms[0].name || "" : null;
    this.app.panel(`材料の設定${ids.length > 1 ? `（${ids.length} 個のボディ）` : ""}`, `
      <label>材料</label><select id="mat-sel">${cur === null ? '<option value="@">（いろいろ）</option>' : ""}${M.map(([k, l]) => `<option value="${k}" ${k === cur ? "selected" : ""}>${l}</option>`).join("")}</select>
      <label>密度 g/cm³</label><input type="text" id="mat-d" value="${cur !== null && ms[0].density ? ms[0].density : ""}" placeholder="材料から自動"/>`,
    () => {
      const k = document.getElementById("mat-sel").value;
      if (k === "@") { this.app.toast("材料を選んでください", true); return false; }
      const d = parseFloat(document.getElementById("mat-d").value) || M.find((m) => m[0] === k)[2];
      store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const id of ids) p.bodyProps[id] = { ...(p.bodyProps[id] || {}), material: { name: k, density: d } }; });
    });
  }

  // ------------------------------------------------------------ 視点
  setView(key) {
    const vw = VIEWS[key]; if (!vw) return;
    this.v.setView(vw[1], vw[2]);
  }
  selBox(ids) {
    const box = new THREE.Box3();
    const sel = ids ? ids.map((id) => ({ kind: "body", bodyId: id })) : (this.app.selection || []);
    for (const s of sel) {
      const b = this.v.bodies.get(s.bodyId);
      if (s.kind === "body" && b) box.expandByObject(b.mesh);
      else if (s.kind === "face" && b && s.group) {
        const pos = b.mesh.geometry.getAttribute("position"), tri = b.data.triangles;
        for (let i = s.group.start; i < s.group.start + s.group.count; i++) box.expandByPoint(new THREE.Vector3().fromBufferAttribute(pos, tri[i]));
      } else if (s.kind === "edge" && b && s.group) {
        const L = b.data.lines;
        for (let i = s.group.start; i < s.group.start + s.group.count; i++) box.expandByPoint(new THREE.Vector3(L[i * 3], L[i * 3 + 1], L[i * 3 + 2]));
      }
    }
    return box;
  }
  fitSelection(ids) {
    const box = this.selBox(ids);
    if (box.isEmpty()) { this.v.fit(); return this.app.status("何も選んでいないので全体を表示しました"); }
    const pad = Math.max(box.getSize(new THREE.Vector3()).length() * 0.1, 5);
    box.expandByScalar(pad);
    this.v.fit(box);
  }
  lookAt(face) {
    const n = face.normal; if (!n) return;
    const up = Math.abs(n[2]) > 0.9 ? [0, 1, 0] : [0, 0, 1];
    this.v.setView(n, up, false);
    this.fitSelection();
  }

  // ------------------------------------------------------------ ビュー下のボタン（視点メニュー・範囲選択・選択モードなど）
  buildNav() {
    const nav = document.getElementById("navbar"); if (!nav) return;
    const mk = (id, label, title, fn) => { const b = document.createElement("button"); b.dataset.ux = id; b.innerHTML = label; b.title = title; b.addEventListener("click", (e) => { e.stopPropagation(); fn(b, e); }); nav.appendChild(b); return b; };
    const sep = () => { const s = document.createElement("span"); s.className = "ux-sep"; nav.appendChild(s); };
    sep();
    mk("views", "視点▾", "視点を切り替える（1〜7 キー）", (b) => this.viewMenu(b));
    mk("fitsel", "⛶", "選んだものに合わせる（Shift+F）", () => this.fitSelection());
    sep();
    mk("box", "⬚", "範囲選択（ドラッグで囲んで選ぶ。マウスは Shift+ドラッグでも）", () => { this.boxMode = !this.boxMode; this.updateNav(); this.app.status(this.boxMode ? "範囲選択: ドラッグで囲む（左→右: 全体が入ったもの / 右→左: かかったもの）。回転するときはもう一度ボタンを押して解除" : "準備完了"); });
    mk("multi", "＋選", "追加して選ぶ（タップするたびに選択に足す・外す）", () => { this.multiTap = !this.multiTap; this.updateNav(); this.app.status(this.multiTap ? "追加して選ぶ: タップするたびに選択に足します（もう一度タップで外す）" : "準備完了"); });
    mk("prio", "面", "クリックで選ぶもの: 面・エッジ / ボディ（切り替え）", () => { this.bodyPriority = !this.bodyPriority; lsSet("gdc-body-priority", this.bodyPriority ? "1" : "0"); this.updateNav(); this.app.status(this.bodyPriority ? "クリックでボディ全体を選びます（面・エッジを選ぶときはもう一度押す）" : "クリックで面・エッジを選びます（ボディはダブルクリック）"); });
    mk("props", "ⓘ", "プロパティ（選んだボディの位置・大きさ）P", () => this.toggleProps());
    mk("keys", "?", "キーボードショートカット一覧（?）", () => this.openShortcuts());
    this.updateNav();
  }
  updateNav() {
    const q = (id) => document.querySelector(`#navbar [data-ux="${id}"]`);
    q("box")?.classList.toggle("on", this.boxMode);
    q("multi")?.classList.toggle("on", this.multiTap);
    const p = q("prio"); if (p) { p.textContent = this.bodyPriority ? "ボディ" : "面"; p.classList.toggle("on", this.bodyPriority); }
    q("props")?.classList.toggle("on", this.propsOn);
  }
  viewMenu(btn) {
    const r = btn.getBoundingClientRect();
    const ev = { clientX: r.left, clientY: r.top - 10 - 30 * 12 };
    const items = Object.entries(VIEWS).map(([k, [l, , , key]]) => [`${l}（${key}）`, () => this.setView(k)]);
    items.push(["ホーム（0 / Home）", () => this.v.home()], ["全体表示（F6）", () => this.v.fit()], ["選んだものに合わせる（Shift+F）", () => this.fitSelection()]);
    const face = (this.app.selection || []).find((s) => s.kind === "face" && s.normal);
    if (face) items.push(["選んだ面を正面から見る", () => this.lookAt(face)]);
    items.push(["すべて表示（非表示・単独表示を解除）", () => this.showAll()]);
    this.app.menu(ev, items);
    const m = document.getElementById("ctxmenu"); m.style.top = Math.max(8, r.top - m.offsetHeight - 6) + "px";
  }

  // ------------------------------------------------------------ メニュー（ファイル・ヘルプ）
  addMenus() {
    const pop = document.querySelector("#menu-file .menu-pop");
    if (!pop) return;
    const help = [...pop.querySelectorAll("button")].find((b) => b.textContent.includes("操作ガイド"));
    const b = document.createElement("button");
    b.innerHTML = `<span>キーボードショートカット一覧</span><span class="kbd">?</span>`;
    b.onclick = () => { document.getElementById("menu-file").classList.remove("open"); this.openShortcuts(); };
    if (help) help.after(b); else pop.appendChild(b);
  }
  openShortcuts() {
    const html = SHORTCUTS.map(([g, rows]) => `<div class="ux-kg"><b>${g}</b><table>${rows.map(([k, d]) => `<tr><td><kbd>${esc(k)}</kbd></td><td>${esc(d)}</td></tr>`).join("")}</table></div>`).join("");
    this.app.panel("キーボードショートカット", `<div class="full ux-keys">${html}<div class="dlg-note">Fusion 360 と同じキーを優先しています。Mac は Ctrl の代わりに ⌘ でも使えます。</div></div>`, null, { wide: true, noCancel: true, okLabel: "閉じる", cls: "ux-keys-panel" });
  }

  // ------------------------------------------------------------ プロパティ（位置・大きさを見て、数値で直す）
  toggleProps() { this.propsOn = !this.propsOn; lsSet("gdc-props", this.propsOn ? "1" : "0"); this.updateNav(); this.updateProps(); }
  schedProps() { clearTimeout(this.pt); this.pt = setTimeout(() => this.updateProps(), 60); }
  async updateProps() {
    let el = document.getElementById("ux-props");
    const ids = this.selBodies();
    const show = this.propsOn && ids.length && this.app.mode === "idle" && !this.app.dialog.isOpen;
    if (!show) { if (el) el.remove(); this.propIds = null; return; }
    if (el && el.contains(document.activeElement) && document.activeElement.tagName === "INPUT" && this.propIds === ids.join()) return; // 入力中は書き換えない
    const key = ids.join();
    const seq = (this.propSeq = (this.propSeq || 0) + 1);
    let r;
    try { r = await call("measure", { ids }); } catch { return; }
    if (seq !== this.propSeq) return;
    if (!r.list.length) return;
    const mn = [0, 1, 2].map((i) => Math.min(...r.list.map((b) => b.bounds[0][i])));
    const mx = [0, 1, 2].map((i) => Math.max(...r.list.map((b) => b.bounds[1][i])));
    const size = mn.map((v, i) => mx[i] - v);
    const one = ids.length === 1 ? this.app.meshes.find((m) => m.id === ids[0]) : null;
    const src = one && store.feature(one.src);
    void src;
    // 大きさは元の手順（押し出しの距離・スケッチの寸法など）につないで直す（src/edit.js）
    const drv = one && this.app.edit ? this.app.edit.sizeDrivers(one) : [null, null, null];
    const boxF = one && this.app.edit ? one : null; // 1 つのボディなら大きさを直せる
    const multi = !one && ids.length > 1 && !!this.app.edit; // 複数なら、まとめて伸縮（板厚はそのまま）
    const mass = r.list.reduce((a, b) => a + b.mass, 0), vol = r.list.reduce((a, b) => a + b.volume, 0);
    const mat = one && one.material && one.material.name ? one.material.name : (one ? "未設定" : "");
    if (!el) { el = document.createElement("div"); el.id = "ux-props"; document.getElementById("viewport").appendChild(el); }
    this.propIds = key; this.propData = { ids, mn, size, boxF, drv, multi };
    const ax = ["X", "Y", "Z"], dn = ["幅 X", "奥行 Y", "高さ Z"];
    el.innerHTML = `<div class="uxp-head"><span>${one ? esc(one.name) : `${ids.length} 個のボディ`}</span><button class="x" title="閉じる（P）">×</button></div>
      <div class="uxp-body">
        <div class="uxp-sec">位置（いちばん小さい角）mm</div>
        <div class="uxp-row">${ax.map((a, i) => `<label>${a}<input type="text" inputmode="decimal" data-pos="${i}" value="${fmt(mn[i], 3)}"/></label>`).join("")}</div>
        <div class="uxp-sec">大きさ mm${boxF ? "" : multi ? '<span class="uxp-ro" title="選んだ板全体を、その方向にだけ伸び縮みさせます。板厚は変わりません">（全体をまとめて伸縮）</span>' : '<span class="uxp-ro">（表示のみ）</span>'}</div>
        <div class="uxp-row">${dn.map((a, i) => `<label>${a}<input type="text" inputmode="decimal" data-size="${i}" value="${fmt(size[i], 3)}" ${boxF || multi ? "" : "readonly"} title="${boxF ? esc(drv[i] ? drv[i].label + "を直します" : "比率を保って拡大・縮小します") : ""}"/>${boxF ? `<small class="uxp-drv ${drv[i] ? "" : "scale"}">${esc(drv[i] ? drv[i].label : "比率で拡大縮小")}</small>` : ""}</label>`).join("")}</div>
        <div class="uxp-info">体積 ${fmt(vol / 1000, 1)} cm³・重さ ${fmt(mass, 2)} kg${one ? `・材料 ${esc(mat)}` : ""}</div>
        <div class="uxp-acts"><button class="btn" data-a="mat">材料</button><button class="btn" data-a="op">透過</button><button class="btn" data-a="iso">単独表示</button><button class="btn" data-a="fit">合わせる</button></div>
        <div class="uxp-note">数値を変えて Enter で反映（式・単位も可: 600/2、60cm）。位置の変更は「移動」としてタイムラインに残ります${multi ? "。複数選んだときの大きさは、全体をその方向に伸び縮み（板厚はそのまま、仕切りは割合の位置へ）" : ""}</div>
      </div>`;
    el.querySelector(".x").onclick = () => this.toggleProps();
    el.querySelectorAll("input").forEach((inp) => {
      inp.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); this.applyProp(inp); } if (e.key === "Escape") { inp.blur(); this.propIds = null; this.updateProps(); } });
      inp.addEventListener("focus", () => inp.select());
      inp.addEventListener("change", () => this.applyProp(inp));
    });
    el.querySelectorAll("[data-a]").forEach((b) => b.addEventListener("click", () => {
      const a = b.dataset.a;
      if (a === "mat") this.setMaterial(ids);
      if (a === "op") this.toggleOpacity(ids);
      if (a === "iso") this.isolate(ids);
      if (a === "fit") this.fitSelection(ids);
    }));
  }
  applyProp(inp) {
    const D = this.propData; if (!D || inp.readOnly) return;
    if (inp.dataset.applied === inp.value) return;
    const num = makeEvaluator(store.project.params || []);
    let v;
    try { v = num(inp.value); } catch (e) { inp.classList.add("err"); this.app.toast(e.message, true); return; }
    inp.classList.remove("err"); inp.dataset.applied = inp.value;
    if (inp.dataset.pos !== undefined) {
      const i = +inp.dataset.pos, dv = v - D.mn[i];
      if (Math.abs(dv) < 1e-9) return;
      const t = [0, 0, 0]; t[i] = dv;
      this.moveBodies(D.ids, t);
    } else if (inp.dataset.size !== undefined && D.multi) {
      const i = +inp.dataset.size;
      if (Math.abs(v - D.size[i]) < 1e-9) return;
      this.propIds = null;
      this.app.edit.bulkResize(D.ids, i, v).then((r) => { if (!r) { inp.value = fmt(D.size[i], 3); inp.dataset.applied = ""; } this.propIds = null; this.schedProps(); });
      return;
    } else if (inp.dataset.size !== undefined && D.boxF) {
      const i = +inp.dataset.size;
      this.propIds = null;
      this.app.edit.applySize(D.boxF, i, v, D.size[i], D.mn).then((r) => { if (!r) { inp.value = fmt(D.size[i], 3); inp.dataset.applied = ""; } this.propIds = null; this.schedProps(); });
      return;
    }
    this.propIds = null;
  }
  // 位置を数値で直す: 「移動」をタイムラインに追加（続けて直したときは同じ移動にまとめる）
  moveBodies(ids, t) {
    const same = (a, b) => a.length === b.length && a.every((x) => b.includes(x));
    store.commit((p) => {
      const at = p.rollback ?? p.features.length;
      const last = p.features[at - 1];
      if (last && last.type === "move" && last._props && !last.copy && same(last.bodies || [], ids) && (+last.angle || 0) === 0) {
        last.translate = (last.translate || ["0", "0", "0"]).map((x, i) => String(+((parseFloat(x) || 0) + t[i]).toFixed(6)));
        return;
      }
      p.features.splice(at, 0, { id: newId(), type: "move", name: store.nameFor("move"), bodies: [...ids], translate: t.map((x) => String(+x.toFixed(6))), rotAxis: "Z", angle: "0", center: ["0", "0", "0"], copy: false, _props: true });
      if (p.rollback != null) p.rollback = at + 1;
    });
  }

  // ------------------------------------------------------------ 計測
  measPick(e) {
    // 角（頂点）の近くなら点、なければエッジ・面
    const vtx = this.app.snapVertex(e, null);
    if (vtx) return { kind: "point", p: [...vtx] };
    const hit = this.v.pick(e, ["edge", "face"]);
    if (!hit) return null;
    if (hit.kind === "edge") return { kind: "edge", bodyId: hit.bodyId, point: hit.point, group: hit.group, hl: hit };
    return { kind: "face", bodyId: hit.bodyId, point: hit.point, normal: hit.normal, group: hit.group, hl: hit };
  }
  async measureClick(e) {
    if (!this.meas) this.meas = { ents: [] };
    let ent = this.measPick(e);
    if (!ent) return;
    const M = this.meas;
    if (M.ents.length >= 2) { M.ents = []; M.res = null; this.clearMeasGfx(); }
    // 同じ面の 2 か所をクリックしたときは、クリックした 2 点の距離（面どうしだと 0 になってしまうので）
    const f0 = M.ents[0];
    if (M.ents.length === 1 && ent.kind === "face" && f0.kind === "face" && f0.bodyId === ent.bodyId && f0.group && ent.group && f0.group.start === ent.group.start) {
      M.ents[0] = { kind: "point", p: f0.point.slice(0, 3) };
      ent = { kind: "point", p: ent.point.slice(0, 3) };
    }
    M.ents.push(ent);
    this.drawMeasEnts();
    const seq = (M.seq = (M.seq || 0) + 1);
    const strip = (x) => ({ kind: x.kind, p: x.p, bodyId: x.bodyId, point: x.point && x.point.slice(0, 3) });
    let r;
    try { r = await call("measureBetween", { a: strip(M.ents[0]), b: M.ents[1] ? strip(M.ents[1]) : null }); }
    catch (err) { M.ents.pop(); this.drawMeasEnts(); return this.app.toast("計測できませんでした: " + err.message, true); }
    if (seq !== M.seq || this.app.mode !== "measure") return;
    M.res = r;
    if (M.ents.length === 2 && r.pa) this.drawMeasLine(r);
    this.showMeasPanel();
  }
  entLabel(i) {
    if (!i) return "";
    if (i.kind === "point") return `点 (${i.p.map((v) => fmt(v)).join(", ")})`;
    if (i.kind === "edge") return i.geom === "CIRCLE" && i.radius ? `円のエッジ Ø${fmt(i.radius * 2, 3)}` : `エッジ 長さ ${fmt(i.length ?? 0, 3)} mm`;
    if (i.kind === "face") return `${i.geom === "PLANE" ? "平らな面" : i.geom === "CYLINDER" ? "円筒の面" : "面"}（${esc(i.name || "")}）面積 ${fmt((i.area || 0) / 100, 2)} cm²`;
    return `ボディ ${esc(i.name || "")}`;
  }
  showMeasPanel() {
    let el = document.getElementById("ux-meas");
    if (!el) {
      el = document.createElement("div"); el.id = "ux-meas";
      document.getElementById("viewport").appendChild(el);
    }
    const M = this.meas || { ents: [] }, r = M.res;
    const rows = [];
    if (!M.ents.length) rows.push(`<div class="uxm-hint">1 つ目をクリック: 角（点）・エッジ・面。<br>穴の縁をクリックすると直径が分かります。</div>`);
    if (r && r.a) rows.push(`<div class="uxm-ent"><span class="uxm-n">1</span>${this.entLabel(r.a)}</div>`);
    if (r && r.b) rows.push(`<div class="uxm-ent"><span class="uxm-n">2</span>${this.entLabel(r.b)}</div>`);
    if (M.ents.length === 1) rows.push(`<div class="uxm-hint">2 つ目をクリックすると、間の距離を出します</div>`);
    if (r && r.b && r.dist != null) {
      const d = [0, 1, 2].map((i) => r.pb[i] - r.pa[i]);
      if (r.gap != null) rows.push(`<div class="uxm-big">面と面の間隔 <b>${fmt(r.gap, 3)}</b> mm</div>`);
      rows.push(`<div class="${r.gap != null ? "uxm-mid" : "uxm-big"}">最短距離 <b>${fmt(r.dist, 3)}</b> mm</div>`);
      rows.push(`<div class="uxm-d">ΔX ${fmt(d[0], 3)}　ΔY ${fmt(d[1], 3)}　ΔZ ${fmt(d[2], 3)}</div>`);
      if (r.angle != null) rows.push(`<div class="uxm-d">角度 ${fmt(r.angle, 2)}°${r.angle < 0.01 ? "（平行）" : Math.abs(r.angle - 90) < 0.01 ? "（直角）" : ""}</div>`);
    }
    el.innerHTML = `<div class="uxp-head"><span>計測</span><button class="x" title="計測を終わる（Esc）">×</button></div><div class="uxm-body">${rows.join("")}</div>
      <div class="uxm-acts"><button class="btn" data-a="reset">やり直す</button><button class="btn primary" data-a="end">終わる</button></div>`;
    el.querySelector(".x").onclick = () => this.app.endMeasure();
    el.querySelector('[data-a="end"]').onclick = () => this.app.endMeasure();
    el.querySelector('[data-a="reset"]').onclick = () => { this.clearMeasGfx(); this.meas = { ents: [] }; this.showMeasPanel(); };
    if (r && r.b && r.dist != null) this.app.status(`${r.gap != null ? `面と面の間隔 ${fmt(r.gap, 3)} mm / ` : ""}最短距離 ${fmt(r.dist, 3)} mm — 次をクリックで計り直し、Esc で終了`);
    else if (M.ents.length === 1 && r) this.app.status(`1 つ目: ${r.a.kind === "point" ? r.a.p.map((v) => fmt(v)).join(", ") : this.entLabel(r.a).replace(/<[^>]+>/g, "")} — 2 つ目をクリック`);
  }
  drawMeasEnts() {
    this.v.clearHighlight("meas");
    if (this.mpts) { this.v.helperGroup.remove(this.mpts); this.mpts = null; }
    const M = this.meas; if (!M) return;
    const pts = [];
    for (const e of M.ents) {
      if (e.hl) this.v.highlight(e.hl, "meas", 0xd23b3b);
      if (e.kind === "point") pts.push(...e.p);
    }
    if (pts.length) {
      const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
      this.mpts = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xd23b3b, size: 9, sizeAttenuation: false, depthTest: false }));
      this.mpts.renderOrder = 60; this.v.helperGroup.add(this.mpts);
    }
    this.v.dirty = true;
  }
  drawMeasLine(r) {
    const app = this.app;
    if (app.mline) { this.v.helperGroup.remove(app.mline); app.mline = null; }
    if (app.mlabel) { app.mlabel.remove(); app.mlabel = null; }
    const a = r.pa, b = r.pb;
    const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...a), new THREE.Vector3(...b)]);
    app.mline = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xd23b3b, depthTest: false }));
    app.mline.renderOrder = 50; this.v.helperGroup.add(app.mline);
    const lab = document.createElement("div"); lab.className = "measure-label";
    lab.textContent = r.gap != null ? `間隔 ${fmt(r.gap, 3)} mm` : `距離 ${fmt(r.dist, 3)} mm`;
    if (r.gap != null && Math.abs(r.gap - r.dist) > 1e-6) lab.textContent += `（最短 ${fmt(r.dist, 3)}）`;
    if (r.a.kind === "point" && r.b.kind === "point") { const f = (v) => fmt(v, 3); lab.textContent = `距離 ${f(r.dist)} mm（ΔX ${f(b[0] - a[0])} ΔY ${f(b[1] - a[1])} ΔZ ${f(b[2] - a[2])}）`; }
    app.overlay.appendChild(lab);
    app.mlabel = lab; app.mmid = a.map((v, i) => (v + b[i]) / 2);
    app.positionMeasure();
    this.v.dirty = true;
  }
  clearMeasGfx() {
    const app = this.app;
    if (app.mline) { this.v.helperGroup.remove(app.mline); app.mline = null; }
    if (app.mlabel) { app.mlabel.remove(); app.mlabel = null; }
    this.v.clearHighlight("meas");
    if (this.mpts) { this.v.helperGroup.remove(this.mpts); this.mpts = null; }
    this.v.dirty = true;
  }
  clearMeas() {
    this.clearMeasGfx();
    // exitModes からは mode を戻す前に呼ばれるので、少し待ってから確かめる
    setTimeout(() => { if (this.app.mode !== "measure") { this.meas = null; document.getElementById("ux-meas")?.remove(); } }, 0);
  }
}

export function installUX(app) {
  const ux = new UX(app);
  app.ux = ux;
  return ux;
}
