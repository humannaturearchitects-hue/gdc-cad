// 形状計算ワーカーとのやり取り
import KernelWorker from "./kernel/worker.js?worker&inline";
import wasmUrl from "replicad-opencascadejs/wasm?url";

let worker = null;
let seq = 0;
const pending = new Map();

let startReject = null;
let started = false;
// onRestart(reason): 再起動できた（形を計算し直す）／onGiveUp(reason): 続けて止まったので自動の計算をやめた
// onFatal(reason): 止まったことを知らせる（メモリ不足など）
export const kernelHooks = { onRestart: null, onGiveUp: null, onFatal: null };
export const kernelState = { crashes: [], lastReason: "", gaveUp: false, wasmBytes: 0 };

// メモリ不足・エンジン内部の致命的なエラーか（このあとエンジンは使えないので作り直す）
export function isFatalMessage(msg) {
  return /out of memory|Cannot enlarge memory|Aborted\(|memory access out of bounds|OOM|RangeError: (WebAssembly|Array buffer)|could not allocate|メモリが足りません/i.test(String(msg || ""));
}

// エンジンが落ちたら（メモリ不足など）自動で再起動する。
// 短い間に何度も落ちるとき（同じ形で毎回メモリが足りない）は、計算し直しを繰り返さずに利用者に選んでもらう
function crashed(msg, { user = false, reason = null } = {}) {
  const oom = isFatalMessage(msg);
  const text = user ? "CADエンジンを再起動しています" : oom ? "形状エンジンのメモリが足りなくなりました。再起動します" : "CADエンジンが停止しました（" + msg + "）。再起動します";
  for (const p of pending.values()) p.reject(Object.assign(new Error(text), { kernelRestart: true, oom }));
  pending.clear();
  // 待っていた計算も終わらせる（終わらせないと「計算中」の表示が消えない）
  if (queued) { queued.reject(Object.assign(new Error("superseded"), { superseded: true })); queued = null; }
  building = false;
  try { worker.terminate(); } catch { /* */ }
  started = false;
  const now = Date.now();
  if (user) kernelState.crashes = [];
  else kernelState.crashes = [...kernelState.crashes.filter((t) => now - t < 180000), now];
  kernelState.lastReason = reason || (oom ? "oom" : user ? "user" : "crash");
  kernelState.wasmBytes = 0;
  const giveUp = !user && kernelState.crashes.length >= 3;
  kernelState.gaveUp = giveUp;
  if (!user && kernelHooks.onFatal) { try { kernelHooks.onFatal(kernelState.lastReason, msg); } catch { /* */ } }
  startKernel().then(() => {
    if (giveUp) { if (kernelHooks.onGiveUp) kernelHooks.onGiveUp(kernelState.lastReason); }
    else if (kernelHooks.onRestart) kernelHooks.onRestart(kernelState.lastReason);
  }).catch((e) => { kernelState.gaveUp = true; if (kernelHooks.onGiveUp) kernelHooks.onGiveUp("start", e); });
}

export function kernelReady() { return started; }
// 計算が終わらないとき、利用者の操作で計算エンジンを作り直す
export function restartKernel() { if (started) crashed("利用者が再起動", { user: true }); }
// メモリを片付けるための再起動（知らせない。ファイルを切り替えるときなど、どうせ全部計算し直すときに使う）
export function refreshKernel() { if (started) crashed("メモリの片付け", { user: true, reason: "refresh" }); }
// 返事を待っている計算の数（「中止して再起動」を出すかどうか）
export function pendingCalls() { return pending.size; }
// 自動の計算をやめていた状態から、もう一度計算できるようにする
export function resetCrashes() { kernelState.crashes = []; kernelState.gaveUp = false; }

export function startKernel() {
  worker = new KernelWorker();
  worker.onmessage = (ev) => {
    if (ev.data && ev.data.progress) { progress = { ...ev.data.progress, t: Date.now() }; return; }
    const { id, ok, result, error, fatal } = ev.data;
    const p = pending.get(id);
    if (p) {
      pending.delete(id);
      if (ok && result && result.wasmBytes) kernelState.wasmBytes = result.wasmBytes; // 形状エンジンのメモリの大きさ（増えすぎたら片付ける）
      ok ? p.resolve(result) : p.reject(Object.assign(new Error(error), { fatal: !!fatal, oom: !!fatal && isFatalMessage(error) }));
    }
    // メモリ不足などでエンジンの中が壊れたら、このあと何をしても失敗するので作り直す
    if (fatal && started) crashed(error);
  };
  worker.onerror = (e) => {
    console.error("kernel error", e.message, e.filename, e.lineno);
    if (startReject) startReject(new Error("CADエンジンの起動に失敗しました: " + (e.message || "不明なエラー")));
    else if (started) crashed(e.message || "不明なエラー");
  };
  const failed = new Promise((_, rej) => (startReject = rej));
  const starting = fetch(wasmUrl).then((r) => r.arrayBuffer()).then((wasm) => call("init", { wasm }, [wasm]));
  // 起動が終わらないまま待ち続けないように（ブラウザが対応していない場合など）
  const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error("CADエンジンが 90 秒たっても起動しませんでした")), 90000));
  return Promise.race([starting, failed, timeout]).then((r) => { started = true; return r; }).finally(() => (startReject = null));
}

export function call(cmd, args = {}, transfer = []) {
  const id = ++seq;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    worker.postMessage({ id, cmd, args }, transfer);
  });
}

// 計算の進み具合（形状エンジンから 0.3 秒ごとに届く）
let progress = null;
export function buildProgressText() {
  const p = progress;
  if (!p || Date.now() - p.t > 5000) return "計算に時間がかかっています";
  return p.phase === "mesh" ? `表示の準備中… ${p.done} / ${p.total} 部品` : `計算中… 手順 ${p.done} / ${p.total}`;
}

// 連続した再計算要求は最新だけを処理する
let building = false;
let queued = null;
export function requestBuild(args) {
  return new Promise((resolve, reject) => {
    if (queued) queued.reject(Object.assign(new Error("superseded"), { superseded: true }));
    queued = { args, resolve, reject };
    pump();
  });
}
async function pump() {
  if (building || !queued) return;
  const job = queued;
  queued = null;
  building = true;
  progress = null;
  try {
    const r = await call("build", job.args);
    job.resolve(r);
  } catch (e) {
    job.reject(e);
  } finally {
    building = false;
    pump();
  }
}
