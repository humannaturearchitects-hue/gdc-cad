// 形状計算ワーカーとのやり取り
import KernelWorker from "./kernel/worker.js?worker&inline";
import wasmUrl from "replicad-opencascadejs/wasm?url";

let worker = null;
let seq = 0;
const pending = new Map();

let startReject = null;
let started = false;
export const kernelHooks = { onRestart: null };

// エンジンが落ちたら（メモリ不足など）自動で再起動する
function crashed(msg) {
  for (const p of pending.values()) p.reject(new Error("CADエンジンが停止しました（" + msg + "）。再起動します"));
  pending.clear();
  building = false; queued = null;
  try { worker.terminate(); } catch { /* */ }
  started = false;
  startKernel().then(() => kernelHooks.onRestart && kernelHooks.onRestart()).catch(() => {});
}

export function kernelReady() { return started; }
// 計算が終わらないとき、利用者の操作で計算エンジンを作り直す
export function restartKernel() { if (started) crashed("利用者が再起動"); }

export function startKernel() {
  worker = new KernelWorker();
  worker.onmessage = (ev) => {
    const { id, ok, result, error } = ev.data;
    const p = pending.get(id);
    if (!p) return;
    pending.delete(id);
    ok ? p.resolve(result) : p.reject(new Error(error));
  };
  worker.onerror = (e) => {
    console.error("kernel error", e.message, e.filename, e.lineno);
    if (startReject) startReject(new Error("CADエンジンの起動に失敗しました: " + (e.message || "不明なエラー")));
    else if (started) crashed(e.message || "不明なエラー");
  };
  const failed = new Promise((_, rej) => (startReject = rej));
  const starting = fetch(wasmUrl).then((r) => r.arrayBuffer()).then((wasm) => call("init", { wasm }, [wasm]));
  // 起動が終わらないまま待ち続けないように（ブラウザが対応していない場合など）
  const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error("CADエンジンが 90 秒たっても起動しませんでした")), 90000));
  return Promise.race([starting, failed, timeout]).then((r) => { started = true; return r; }).finally(() => (startReject = null));
}

export function call(cmd, args = {}, transfer = []) {
  const id = ++seq;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    worker.postMessage({ id, cmd, args }, transfer);
  });
}

// 連続した再計算要求は最新だけを処理する
let building = false;
let queued = null;
export function requestBuild(args) {
  return new Promise((resolve, reject) => {
    if (queued) queued.reject(Object.assign(new Error("superseded"), { superseded: true }));
    queued = { args, resolve, reject };
    pump();
  });
}
async function pump() {
  if (building || !queued) return;
  const job = queued;
  queued = null;
  building = true;
  try {
    const r = await call("build", job.args);
    job.resolve(r);
  } catch (e) {
    job.reject(e);
  } finally {
    building = false;
    pump();
  }
}
