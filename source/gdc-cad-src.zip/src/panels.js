// パネル加工データ: 各パネルを平らに展開して材料の板に並べた DXF（CNC ルーター用）と、切り出し一覧 CSV
//  画層: OUTLINE（外形カット）/ HOLES（貫通穴・抜き）/ POCKET_D<深さ>（表から彫り）/ BACK_POCKET_D<深さ>（裏から彫り）
//        ENGRAVE（段差など深さ不明の彫り）/ LABEL（部品ラベル・加工しない）/ SHEET（材料の板の外形・加工しない）
import { call } from "./kernel.js";
import { download } from "./exporters.js";
import { store } from "./store.js";
import { esc } from "./commands.js";
import { layupSpec } from "./layup.js";

export const STOCKS = [
  ["1820x910", "サブロク 1820×910", [1820, 910]],
  ["2440x1220", "シハチ 2440×1220", [2440, 1220]],
  ["3030x1520", "3030×1520", [3030, 1520]],
  ["none", "材料サイズなし（並べるだけ）", null],
];

const baseName = (n) => String(n || "").replace(/(_\d+(-\d+)?|\((コピー|ミラー)\))+$/, "");
const r1 = (v) => +(+v).toFixed(1);
const fmt = (v) => String(r1(v));

function materialOf(app, id) {
  const m = app.meshes.find((x) => x.id === id);
  if (!m) return "";
  return m.layup ? layupSpec(m.layup) : (m.material?.name || "");
}

// 展開データ（形状エンジン）→ 同じ部品をまとめた一覧
export async function panelParts(app, ids) {
  const flats = await call("panelFlat", { ids });
  const parts = [], errors = [];
  for (const f of flats) {
    if (f.error) { errors.push(`${f.name}: ${f.error}`); continue; }
    // 長い方を X に
    const p = f.w >= f.h ? f : rotateFlat(f);
    const material = materialOf(app, f.id);
    const nPock = p.engrave.filter((e) => e.kind === "pocket").length;
    const key = [baseName(f.name), fmt(p.w), fmt(p.h), fmt(p.thk), material, p.holes.length, nPock].join("|");
    const ex = parts.find((q) => q.key === key);
    if (ex) { ex.qty++; ex.ids.push(f.id); continue; }
    parts.push({ key, name: baseName(f.name), ids: [f.id], qty: 1, w: p.w, h: p.h, thk: p.thk, material, flat: p, holes: p.holes.length, pockets: nPock, notes: p.notes || [] });
  }
  parts.forEach((p, i) => { p.no = i + 1; });
  return { parts, errors };
}

function rotPrim(p) {
  const R = (q) => [-q[1], q[0]];
  if (p.t === "line") return { t: "line", a: R(p.a), b: R(p.b) };
  if (p.t === "poly") return { t: "poly", pts: p.pts.map(R) };
  return { ...p, c: R(p.c), s: p.s + Math.PI / 2 };
}
function movePrim(p, dx, dy) {
  const T = (q) => [q[0] + dx, q[1] + dy];
  if (p.t === "line") return { t: "line", a: T(p.a), b: T(p.b) };
  if (p.t === "poly") return { t: "poly", pts: p.pts.map(T) };
  return { ...p, c: T(p.c) };
}
// 90° 回して左下を原点に
function rotateFlat(f) {
  const tr = (prims) => prims.map(rotPrim).map((p) => movePrim(p, f.h, 0));
  return { ...f, w: f.h, h: f.w, outer: tr(f.outer), holes: f.holes.map((h) => ({ ...h, prims: tr(h.prims) })), engrave: f.engrave.map((e) => ({ ...e, prims: tr(e.prims) })) };
}

// 板取り（棚段の詰め込み）: 厚さ・材料ごとに別の板
export function nest(parts, { stock = "1820x910", gap = 10, margin = 10 } = {}) {
  const st = STOCKS.find((s) => s[0] === stock) || STOCKS[0];
  const size = st[2];
  const groups = new Map();
  for (const p of parts) {
    const k = `${fmt(p.thk)}|${p.material}`;
    if (!groups.has(k)) groups.set(k, []);
    for (let i = 0; i < p.qty; i++) groups.get(k).push(p);
  }
  const sheets = [], over = [];
  for (const [k, list] of groups) {
    const [thk, material] = k.split("|");
    const items = [...list].sort((a, b) => b.h - a.h || b.w - a.w);
    const W = size ? size[0] : Math.max(2400, ...items.map((p) => p.w + 2 * margin));
    const H = size ? size[1] : Infinity;
    let cur = null;
    const newSheet = () => { cur = { w: W, h: H, thk: +thk, material, items: [], rows: [], y: margin }; sheets.push(cur); };
    for (const p of items) {
      let rot = false, w = p.w, h = p.h;
      if (size && (w > W - 2 * margin || h > H - 2 * margin)) {
        // 回せば入るか
        if (h <= W - 2 * margin && w <= H - 2 * margin) { rot = true; [w, h] = [h, w]; } else { over.push(p); continue; }
      }
      const tryPlace = () => {
        for (const row of cur.rows) if (row.x + w <= W - margin + 1e-6 && h <= row.h + 1e-6) { const at = [row.x, row.y]; row.x += w + gap; return at; }
        if (cur.y + h <= H - margin + 1e-6) { const row = { y: cur.y, h, x: margin }; cur.rows.push(row); cur.y += h + gap; const at = [row.x, row.y]; row.x += w + gap; return at; }
        return null;
      };
      if (!cur) newSheet();
      let at = tryPlace();
      if (!at) { newSheet(); at = tryPlace(); }
      if (!at) { over.push(p); continue; }
      cur.items.push({ part: p, x: at[0], y: at[1], rot, w, h });
    }
    cur = null;
  }
  for (const s of sheets) if (!isFinite(s.h)) s.h = Math.max(...s.rows.map((r) => r.y + r.h)) + margin;
  return { sheets, over, stock: st };
}

// ---------------------------------------------------------------- DXF（R12, mm, 閉じたポリライン）
const LAYERS = { OUTLINE: 7, HOLES: 1, ENGRAVE: 4, LABEL: 3, SHEET: 8 };

function dxfText(s) {
  return String(s).replace(/[^\x20-\x7e]/g, (c) => "\\U+" + c.codePointAt(0).toString(16).toUpperCase().padStart(4, "0"));
}

// 図形をつないで閉じた輪郭に（端点が一致するもの）
function chains(prims) {
  const segs = [], circles = [];
  for (const p of prims) {
    if (p.t === "arc" && Math.abs(p.d) >= 2 * Math.PI - 1e-6) { circles.push(p); continue; }
    if (p.t === "line") segs.push({ a: p.a, b: p.b, bulge: 0, pts: [] });
    else if (p.t === "arc") {
      const a = [p.c[0] + p.r * Math.cos(p.s), p.c[1] + p.r * Math.sin(p.s)], b = [p.c[0] + p.r * Math.cos(p.s + p.d), p.c[1] + p.r * Math.sin(p.s + p.d)];
      segs.push({ a, b, bulge: Math.tan(p.d / 4), pts: [] });
    } else if (p.t === "poly" && p.pts.length > 1) segs.push({ a: p.pts[0], b: p.pts[p.pts.length - 1], bulge: 0, pts: p.pts.slice(1, -1) });
  }
  const tol = 1e-3, same = (u, v) => Math.hypot(u[0] - v[0], u[1] - v[1]) < tol;
  const rev = (s) => ({ a: s.b, b: s.a, bulge: -s.bulge, pts: [...s.pts].reverse() });
  const out = [];
  const left = segs.slice();
  while (left.length) {
    const chain = [left.shift()];
    let grown = true;
    while (grown && !same(chain[0].a, chain[chain.length - 1].b)) {
      grown = false;
      const end = chain[chain.length - 1].b;
      for (let i = 0; i < left.length; i++) {
        if (same(left[i].a, end)) { chain.push(left.splice(i, 1)[0]); grown = true; break; }
        if (same(left[i].b, end)) { chain.push(rev(left.splice(i, 1)[0])); grown = true; break; }
      }
    }
    out.push({ segs: chain, closed: same(chain[0].a, chain[chain.length - 1].b) });
  }
  return { chains: out, circles };
}

class DxfWriter {
  constructor() { this.L = []; this.layers = new Map(Object.entries(LAYERS)); this.ext = [Infinity, Infinity, -Infinity, -Infinity]; }
  g(c, v) { this.L.push(String(c), String(v)); }
  f(v) { return (+v).toFixed(4).replace(/\.?0+$/, "") || "0"; }
  layer(name, color = 6) { if (!this.layers.has(name)) this.layers.set(name, color); return name; }
  pt(x, y, k = 0) { this.g(10 + k, this.f(x)); this.g(20 + k, this.f(y)); this.g(30 + k, 0); this.ext = [Math.min(this.ext[0], x), Math.min(this.ext[1], y), Math.max(this.ext[2], x), Math.max(this.ext[3], y)]; }
  prims(layer, prims) {
    const { chains: cs, circles } = chains(prims);
    for (const c of circles) { this.g(0, "CIRCLE"); this.g(8, layer); this.pt(c.c[0], c.c[1]); this.g(40, this.f(c.r)); }
    for (const ch of cs) {
      this.g(0, "POLYLINE"); this.g(8, layer); this.g(66, 1); this.g(10, 0); this.g(20, 0); this.g(30, 0); this.g(70, ch.closed ? 1 : 0);
      const vtx = (p, bulge) => { this.g(0, "VERTEX"); this.g(8, layer); this.pt(p[0], p[1]); if (bulge) this.g(42, this.f(bulge)); };
      ch.segs.forEach((s, i) => {
        vtx(s.a, s.bulge);
        for (const q of s.pts) vtx(q, 0);
        if (!ch.closed && i === ch.segs.length - 1) vtx(s.b, 0);
      });
      this.g(0, "SEQEND"); this.g(8, layer);
    }
  }
  text(layer, x, y, h, s) { this.g(0, "TEXT"); this.g(8, layer); this.pt(x, y); this.g(40, this.f(h)); this.g(1, dxfText(s)); }
  toString() {
    const body = this.L; this.L = [];
    const e = isFinite(this.ext[0]) ? this.ext : [0, 0, 0, 0];
    this.g(0, "SECTION"); this.g(2, "HEADER");
    this.g(9, "$ACADVER"); this.g(1, "AC1009");
    this.g(9, "$INSUNITS"); this.g(70, 4);
    this.g(9, "$MEASUREMENT"); this.g(70, 1);
    this.g(9, "$EXTMIN"); this.g(10, this.f(e[0])); this.g(20, this.f(e[1])); this.g(30, 0);
    this.g(9, "$EXTMAX"); this.g(10, this.f(e[2])); this.g(20, this.f(e[3])); this.g(30, 0);
    this.g(0, "ENDSEC");
    this.g(0, "SECTION"); this.g(2, "TABLES");
    this.g(0, "TABLE"); this.g(2, "LTYPE"); this.g(70, 1);
    this.g(0, "LTYPE"); this.g(2, "CONTINUOUS"); this.g(70, 0); this.g(3, "Solid line"); this.g(72, 65); this.g(73, 0); this.g(40, 0);
    this.g(0, "ENDTAB");
    this.g(0, "TABLE"); this.g(2, "LAYER"); this.g(70, this.layers.size + 1);
    for (const [n, c] of [["0", 7], ...this.layers]) { this.g(0, "LAYER"); this.g(2, n); this.g(70, 0); this.g(62, c); this.g(6, "CONTINUOUS"); }
    this.g(0, "ENDTAB");
    this.g(0, "TABLE"); this.g(2, "STYLE"); this.g(70, 1);
    this.g(0, "STYLE"); this.g(2, "STANDARD"); this.g(70, 0); this.g(40, 0); this.g(41, 1); this.g(50, 0); this.g(71, 0); this.g(42, 2.5); this.g(3, "txt"); this.g(4, "");
    this.g(0, "ENDTAB");
    this.g(0, "ENDSEC");
    this.g(0, "SECTION"); this.g(2, "ENTITIES");
    const head = this.L;
    const tail = ["0", "ENDSEC", "0", "EOF"];
    return [...head, ...body, ...tail].join("\r\n") + "\r\n";
  }
}

const depthLayer = (e) => (e.kind === "pocket" && e.depth ? `${e.side === "裏" ? "BACK_POCKET" : "POCKET"}_D${fmt(e.depth)}` : "ENGRAVE");

export function nestingDXF(nested, { labels = true, ascii = false } = {}) {
  const d = new DxfWriter();
  let ox = 0;
  nested.sheets.forEach((sh, si) => {
    const r = (x, y, w, h) => [{ t: "line", a: [x, y], b: [x + w, y] }, { t: "line", a: [x + w, y], b: [x + w, y + h] }, { t: "line", a: [x + w, y + h], b: [x, y + h] }, { t: "line", a: [x, y + h], b: [x, y] }];
    d.prims("SHEET", r(ox, 0, sh.w, sh.h));
    d.text("SHEET", ox, sh.h + 15, 20, ascii ? `SHEET ${si + 1}/${nested.sheets.length}  ${sh.w}x${sh.h}  t=${fmt(sh.thk)}` : `板 ${si + 1}/${nested.sheets.length}  ${sh.w}x${sh.h}  t=${fmt(sh.thk)}  ${sh.material}`);
    for (const it of sh.items) {
      const f = it.part.flat;
      const place = (prims) => {
        let ps = prims;
        if (it.rot) ps = ps.map(rotPrim).map((p) => movePrim(p, f.h, 0));
        return ps.map((p) => movePrim(p, ox + it.x, it.y));
      };
      d.prims("OUTLINE", place(f.outer));
      for (const h of f.holes) d.prims("HOLES", place(h.prims));
      for (const e of f.engrave) d.prims(d.layer(depthLayer(e), e.side === "裏" ? 5 : 4), place(e.prims));
      if (labels) {
        const th = Math.max(4, Math.min(20, it.h / 8, it.w / 14));
        const cx = ox + it.x + it.w * 0.1, cy = it.y + it.h / 2;
        d.text("LABEL", cx, cy + th * 0.3, th, ascii ? `P${it.part.no}` : `${it.part.no}  ${it.part.name}`);
        d.text("LABEL", cx, cy - th * 1.2, th * 0.7, `${fmt(it.part.w)}x${fmt(it.part.h)}x${fmt(it.part.thk)}`);
      }
    }
    ox += sh.w + 200;
  });
  return d.toString();
}

// 1 部品ずつの DXF（原寸, 左下が原点）
export function partDXF(part) {
  const d = new DxfWriter();
  const f = part.flat;
  d.prims("OUTLINE", f.outer);
  for (const h of f.holes) d.prims("HOLES", h.prims);
  for (const e of f.engrave) d.prims(d.layer(depthLayer(e), e.side === "裏" ? 5 : 4), e.prims);
  return d.toString();
}

// ---------------------------------------------------------------- 切り出し一覧 CSV
const csvCell = (v) => { const s = String(v ?? ""); return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };

export function cutListCSV(parts, nested) {
  const rows = [["No.", "部品名", "長さ(mm)", "幅(mm)", "厚さ(mm)", "枚数", "材料", "面積(m²/枚)", "面積合計(m²)", "穴(貫通)", "彫り", "備考"]];
  let tot = 0, totN = 0;
  for (const p of parts) {
    const a = (p.w * p.h) / 1e6;
    tot += a * p.qty; totN += p.qty;
    const notes = [...p.notes, ...p.flat.engrave.filter((e) => e.kind === "pocket").map((e) => `${e.side}彫り 深さ${e.depth ?? "?"}`)];
    rows.push([p.no, p.name, fmt(p.w), fmt(p.h), fmt(p.thk), p.qty, p.material, a.toFixed(3), (a * p.qty).toFixed(3), p.holes, p.pockets, [...new Set(notes)].join(" / ")]);
  }
  rows.push(["", "合計", "", "", "", totN, "", "", tot.toFixed(3), "", "", ""]);
  if (nested && nested.sheets.length) {
    rows.push([]);
    rows.push(["材料の板", "サイズ", "厚さ(mm)", "材料", "部品数", "歩留まり(%)"]);
    nested.sheets.forEach((s, i) => {
      const used = s.items.reduce((t, it) => t + it.w * it.h, 0);
      rows.push([i + 1, `${s.w}x${s.h}`, fmt(s.thk), s.material, s.items.length, ((used / (s.w * s.h)) * 100).toFixed(1)]);
    });
  }
  // Excel で文字化けしないよう BOM 付き UTF-8、改行は CRLF
  return "﻿" + rows.map((r) => r.map(csvCell).join(",")).join("\r\n") + "\r\n";
}

// ---------------------------------------------------------------- 画面
function previewSVG(nested) {
  if (!nested.sheets.length) return "";
  const gapX = 120;
  const totalW = nested.sheets.reduce((s, sh) => s + sh.w + gapX, -gapX);
  const H = Math.max(...nested.sheets.map((s) => s.h));
  let ox = 0;
  const parts = [];
  for (const sh of nested.sheets) {
    parts.push(`<rect x="${ox}" y="0" width="${sh.w}" height="${sh.h}" fill="#f4efe6" stroke="#888" stroke-width="4"/>`);
    for (const it of sh.items) {
      parts.push(`<rect x="${ox + it.x}" y="${sh.h - it.y - it.h}" width="${it.w}" height="${it.h}" fill="#cfe3f7" stroke="#1a5fb4" stroke-width="3"/>`);
      const fs = Math.max(18, Math.min(60, it.h / 4, it.w / 6));
      parts.push(`<text x="${ox + it.x + it.w / 2}" y="${sh.h - it.y - it.h / 2 + fs / 3}" font-size="${fs}" text-anchor="middle" fill="#123">${it.part.no}</text>`);
    }
    ox += sh.w + gapX;
  }
  return `<svg viewBox="-10 -10 ${totalW + 20} ${H + 20}" style="width:100%;max-height:220px;background:#fff;border:1px solid #ccc;border-radius:6px">${parts.join("")}</svg>`;
}

export async function openPanelExport(app, ids) {
  ids = ids && ids.length ? ids : app.bodyList().filter((b) => !b.hidden).map((b) => b.id);
  if (!ids.length) return app.toast("表示中のボディがありません", true);
  app.busy(true, "パネルを展開中…");
  let res;
  try { res = await panelParts(app, ids); } catch (e) { app.busy(false); return app.toast("展開に失敗しました: " + e.message, true); }
  app.busy(false);
  const { parts, errors } = res;
  const opt = { stock: "1820x910", gap: 10, margin: 10, labels: true, ascii: false, ...(store.project.panelExport || {}) };
  const el = app.panel("パネル加工データ（CNC 用 DXF・切り出し一覧）", `
    <label>材料の板</label><select id="pn-stock">${STOCKS.map(([k, n]) => `<option value="${k}" ${opt.stock === k ? "selected" : ""}>${n}</option>`).join("")}</select>
    <label>部品の間隔 mm</label><input type="text" id="pn-gap" value="${opt.gap}" inputmode="decimal"/>
    <label>板の端の余白 mm</label><input type="text" id="pn-margin" value="${opt.margin}" inputmode="decimal"/>
    <label class="full"><input type="checkbox" id="pn-labels" ${opt.labels ? "checked" : ""}/> 部品ラベル（番号・名前・寸法）を DXF に入れる（画層 LABEL・加工しない）</label>
    <label class="full"><input type="checkbox" id="pn-ascii" ${opt.ascii ? "checked" : ""}/> ラベルを英数字だけにする（日本語が文字化けする CAM ソフト用。番号は切り出し一覧と同じ）</label>
    <div class="full" id="pn-prev"></div>
    <div class="full" style="max-height:180px;overflow:auto"><table class="grid" id="pn-list"><tr><th>No.</th><th>部品名</th><th class="num">長さ×幅×厚さ</th><th class="num">枚数</th><th>材料</th><th class="num">穴</th><th class="num">彫り</th></tr>
      ${parts.map((p) => `<tr><td>${p.no}</td><td>${esc(p.name)}</td><td class="num">${fmt(p.w)}×${fmt(p.h)}×${fmt(p.thk)}</td><td class="num">${p.qty}</td><td>${esc(p.material || "—")}</td><td class="num">${p.holes}</td><td class="num">${p.pockets}</td></tr>`).join("")}
    </table></div>
    <div class="full dlg-note" id="pn-msg"></div>
    <div class="full btns" style="display:flex;gap:6px;flex-wrap:wrap">
      <button class="btn primary" id="pn-dxf">板取り DXF</button>
      <button class="btn" id="pn-parts">部品ごとの DXF</button>
      <button class="btn" id="pn-csv">切り出し一覧 CSV</button>
    </div>
    <div class="full dlg-note">原寸（1:1, 単位 mm）。厚さ・材料が違う部品は別の板に並べます。画層: OUTLINE＝外形カット、HOLES＝貫通穴・抜き、POCKET_D深さ＝表から彫り、BACK_POCKET_D深さ＝裏から彫り、LABEL・SHEET＝加工しない。
    ${errors.length ? `<br><b>展開できなかった部品:</b> ${esc(errors.join("、"))}` : ""}</div>`, null, { okLabel: "閉じる", noCancel: true, wide: true, cls: "pn-dlg" });
  const read = () => {
    opt.stock = el.querySelector("#pn-stock").value;
    opt.gap = Math.max(0, parseFloat(el.querySelector("#pn-gap").value) || 0);
    opt.margin = Math.max(0, parseFloat(el.querySelector("#pn-margin").value) || 0);
    opt.labels = el.querySelector("#pn-labels").checked;
    opt.ascii = el.querySelector("#pn-ascii").checked;
    store.project.panelExport = { ...opt };
    return nest(parts, opt);
  };
  const show = () => {
    const n = read();
    el.querySelector("#pn-prev").innerHTML = previewSVG(n);
    const used = n.sheets.reduce((t, s) => t + s.items.reduce((u, it) => u + it.w * it.h, 0), 0);
    const area = n.sheets.reduce((t, s) => t + s.w * s.h, 0);
    el.querySelector("#pn-msg").innerHTML = `材料の板 <b>${n.sheets.length} 枚</b>（部品 ${parts.reduce((t, p) => t + p.qty, 0)} 個${area ? `、歩留まり ${((used / area) * 100).toFixed(0)}%` : ""}）`
      + (n.over.length ? `<br><span style="color:#c33">板に入らない部品: ${esc([...new Set(n.over.map((p) => p.name))].join("、"))}（材料サイズを大きくしてください）</span>` : "");
    return n;
  };
  el.querySelectorAll("#pn-stock,#pn-gap,#pn-margin,#pn-labels,#pn-ascii").forEach((i) => i.addEventListener("change", show));
  show();
  const base = (store.project.name || "panels").replace(/[\\/:*?"<>|]/g, "_");
  el.querySelector("#pn-dxf").onclick = () => { const n = show(); download(nestingDXF(n, opt), `${base}_板取り.dxf`, "application/dxf"); app.toast(`板取り DXF を書き出しました（板 ${n.sheets.length} 枚、mm）`); };
  el.querySelector("#pn-csv").onclick = () => { const n = show(); download(cutListCSV(parts, n), `${base}_切り出し一覧.csv`, "text/csv"); app.toast("切り出し一覧（CSV）を書き出しました"); };
  el.querySelector("#pn-parts").onclick = async () => {
    for (const p of parts) {
      download(partDXF(p), `${base}_${String(p.no).padStart(2, "0")}_${p.name}_x${p.qty}.dxf`.replace(/[\\/:*?"<>|]/g, "_"), "application/dxf");
      await new Promise((r) => setTimeout(r, 250));
    }
    app.toast(`部品ごとの DXF を ${parts.length} 個書き出しました`);
  };
  return el;
}
