// AI の返事（JSON・コードブロック・ふつうの文）から、このソフトのコマンドを取り出す
// 「ほかの AI アプリに頼む（コピー＆貼り付け）」と「自分の PC の AI」（JSON で返せないとき）で使う
import { SYSTEM, buildUserMessage } from "./ai.js";

// コマンドの行の始まり（決まった書き方）。これ以外の行は説明として扱う
const CMD_START = /^(板|直方体|箱|円柱|球|スケッチ|長方形|円|円弧|線|点|押し出し|押出|穴|フィレット|面取り|移動|コピー|削除|置く|回す|回転|スケール|材料|色|矩形パターン|円形パターン|ミラー|シェル|分割|結合|プレスプル|構築平面|名前変更|非表示|表示|すべて表示|抑制|抑制解除|ロールバック|重さ|大きさ|体積|部品一覧|干渉チェック|元に戻す|やり直し|視点|全体表示|パラメータ|コンポーネント|多角形|長穴|STEP|STL|OBJ|図面|ビス接合|板厚)(\s|$)/;
// 既にある名前で始まる「直す」行（床板 厚さ 30 ／ 穴1 径 10）
const MODIFY = /^\S+\s+(厚さ|幅|奥行|高さ|直径|径|深さ|距離|R|C|位置|色|材料|名前)\s*\S+/;

function fromJSON(text) {
  const tryParse = (s) => { try { const o = JSON.parse(s); return o && typeof o === "object" ? o : null; } catch { return null; } };
  let o = tryParse(text.trim());
  if (!o) { const m = text.match(/\{[\s\S]*\}/); if (m) o = tryParse(m[0]); }
  if (!o || !("commands" in o || "question" in o || "explanation" in o)) return null;
  const cmds = Array.isArray(o.commands) ? o.commands.join("\n") : String(o.commands || "");
  return { commands: cmds.trim(), explanation: String(o.explanation || ""), question: String(o.question || "") };
}

// 返事の文 → { commands, explanation, question }
export function extractCommands(text) {
  const t = String(text || "").replace(/\r/g, "");
  const j = fromJSON(t);
  if (j) return j;
  const clean = (l) => l.replace(/^\s*(?:[-*・•]|\d+[.)．、])\s*/, "").replace(/^`+|`+$/g, "").trim();
  // ``` で囲んだところがあれば、そこだけ
  const blocks = [...t.matchAll(/```[a-zA-Z]*\n?([\s\S]*?)```/g)].map((m) => m[1]);
  const src = blocks.length ? blocks.join("\n") : t;
  const lines = src.split("\n").map(clean).filter(Boolean);
  const cmds = lines.filter((l) => CMD_START.test(l.normalize("NFKC")) || (blocks.length && MODIFY.test(l)) || (!blocks.length && MODIFY.test(l) && l.length < 40));
  const rest = (blocks.length ? t.replace(/```[\s\S]*?```/g, "") : t.split("\n").filter((l) => !cmds.includes(clean(l))).join("\n")).trim();
  const q = !cmds.length && /[？?]\s*$/.test(rest) ? rest : "";
  return { commands: cmds.join("\n"), explanation: q ? "" : rest.split("\n").filter(Boolean).slice(0, 3).join(" ").slice(0, 300), question: q };
}

// 貼り付けて使うための 1 つの文（説明書＋今のモデルの概要＋頼みごと＋答え方）
export function buildPastePrompt({ instruction, context }) {
  return `${SYSTEM}

===== 答え方（大事） =====
次の形で答えてください。コマンドは \`\`\` で囲んだ中に 1 行に 1 つだけ書き、説明は 1〜2 文。寸法などが足りないときはコマンドを書かずに質問だけを書いてください。
\`\`\`
（コマンド）
\`\`\`
（説明）

===== 頼みごと =====
${buildUserMessage({ instruction, context })}`;
}

// 入力がすでに決まった書き方のコマンドか（それなら AI に聞かずにそのまま実行する＝速く確実）
export function looksLikeCommand(text) {
  const lines = String(text || "").normalize("NFKC").split(/\n/).map((s) => s.trim()).filter(Boolean);
  return lines.length > 0 && lines.every((l) => CMD_START.test(l) && !/[ぁ-ん]{2,}/.test(l.replace(/^元に戻す|やり直し|すべて表示/, "")));
}
