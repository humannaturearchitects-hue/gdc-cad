// 「落ちない・固まらない・作業を失わない」ための見張り（robust）
// ・形状エンジンが止まった（メモリ不足など）→ 作業を保存して、分かる言葉で知らせ、再起動して計算し直す
// ・何度も続けて止まるとき → 計算し直しを繰り返さず、利用者に「元に戻す／もう一度／読み込み直す」を選んでもらう
// ・書き出し・図面などで計算が長く終わらないとき → 経過時間と「中止して再起動」を出す（画面が止まったままにしない）
import { kernelHooks, restartKernel, refreshKernel, kernelState, pendingCalls, resetCrashes, call } from "./kernel.js";

// 形状エンジンのメモリがこれを超えていたら、ファイルを切り替えるときにエンジンを作り直して片付ける
// （形の計算で出たごみは自動では片付きにくく、長く使うと少しずつ増えるため。iPhone は使えるメモリが少ない）
const isPhone = typeof navigator !== "undefined" && /iPhone|iPad|iPod|Android/i.test(navigator.userAgent || "");
export const REFRESH_BYTES = (isPhone ? 450 : 1200) * 1048576;
import { store } from "./store.js";

export function installRobust(app) {
  const saveNow = () => { try { store.flush().catch(() => {}); } catch { /* */ } };

  kernelHooks.onFatal = (reason) => {
    saveNow(); // 画面側のデータは無事。念のためすぐ保存しておく
    hideBanner();
    app.toast(reason === "oom"
      ? "形状エンジンのメモリが足りなくなりました。作業内容は保存されています。エンジンを再起動して計算し直します…"
      : "CADエンジンが停止しました。作業内容は保存されています。再起動します…", true);
  };
  kernelHooks.onRestart = (reason) => {
    app.loadedImports.clear();
    if (reason === "refresh") { app.rebuild(); return; } // 片付けのための再起動は知らせない
    app.toast(reason === "oom" ? "CADエンジンを再起動しました（メモリ不足のため）。作業は保たれています" : "CADエンジンを再起動しました。作業は保たれています");
    app.rebuild();
  };
  kernelHooks.onGiveUp = (reason) => {
    app.loadedImports.clear();
    saveNow();
    showBanner(app, reason);
  };

  // ------------------------------------------------------------ ファイルを切り替えたとき
  // 前のファイルの取り込みデータ（STEP など）を手元と形状エンジンの両方から捨てる（切り替えを繰り返してもメモリが増えない）
  const origReplace = store.replace.bind(store);
  store.replace = (project, docId) => {
    // どうせ全部計算し直すので、メモリが増えていたらここでエンジンを作り直す（待ち時間はほぼ増えない）
    const limit = window.__gdcRefreshBytes || REFRESH_BYTES;
    if (kernelState.wasmBytes > limit && !app.buildsRunning) { refreshKernel(); app.loadedImports.clear(); }
    const r = origReplace(project, docId);
    try {
      const keep = new Set((store.project.features || []).filter((f) => f.type === "import" && f.dataKey).map((f) => f.dataKey));
      for (const k of [...app.importBuffers.keys()]) if (!keep.has(k)) app.importBuffers.delete(k);
      for (const k of [...app.loadedImports]) if (!keep.has(k)) app.loadedImports.delete(k);
      call("fileSwitched", { keep: [...keep] }).catch(() => {});
      hideBanner();
    } catch { /* 片付けの失敗で切り替えを止めない */ }
    return r;
  };

  // ------------------------------------------------------------ 長い計算の見張り
  // 計算（再計算）は main.js が自分で「中止して再起動」を出す。それ以外（書き出し・図面・干渉など）をここで見る
  const origBusy = app.busy.bind(app);
  let since = 0, timer = null, baseMsg = "";
  app.busy = (on, msg) => {
    origBusy(on, msg);
    if (on) {
      if (msg) baseMsg = String(msg).replace(/（\d+ 秒）$/, "");
      if (!since) since = Date.now();
      if (!timer) timer = setInterval(tick, 1000);
    } else {
      since = 0; clearInterval(timer); timer = null;
      const b = document.getElementById("busy-act"); if (b && b.dataset.robust) b.remove();
    }
  };
  function tick() {
    if (!since || app.buildsRunning) return;
    const sec = Math.round((Date.now() - since) / 1000);
    if (sec < 10 || !pendingCalls()) return;
    const m = document.getElementById("busy-msg");
    if (m) m.textContent = `${baseMsg}（${sec} 秒）`;
    if (!document.getElementById("busy-act")) {
      app.busyAction("中止して再起動", () => { app.busyAction(null); restartKernel(); origBusy(false); since = 0; });
      const b = document.getElementById("busy-act"); if (b) b.dataset.robust = "1";
    }
  }
}

// ------------------------------------------------------------ 続けて止まったときのお知らせ
function hideBanner() { document.getElementById("robust-banner")?.remove(); }
function showBanner(app, reason) {
  hideBanner();
  const el = document.createElement("div");
  el.id = "robust-banner";
  el.setAttribute("role", "alert");
  const why = reason === "start"
    ? "CADエンジンを起動し直せませんでした。"
    : reason === "oom" ? "形状エンジンのメモリが足りず、何度も止まりました。モデルが大きすぎるか、直前の変更で計算が重くなった可能性があります。"
    : "CADエンジンが何度も続けて止まりました。";
  el.innerHTML = `<div class="rb-text"><b>計算を止めています</b><br>${why}<br>作業内容は保存されています（画面の形は止まる前のままです）。</div>
    <div class="rb-btns">
      ${reason === "start" ? "" : `<button class="btn primary" data-rb="undo">直前の変更を元に戻して計算</button><button class="btn" data-rb="retry">もう一度計算する</button>`}
      <button class="btn" data-rb="reload">読み込み直す</button>
    </div>`;
  (document.getElementById("viewport") || document.body).appendChild(el);
  el.querySelector('[data-rb="undo"]')?.addEventListener("click", () => { hideBanner(); resetCrashes(); if (store.undoStack.length) store.undo(); else app.rebuild(); });
  el.querySelector('[data-rb="retry"]')?.addEventListener("click", () => { hideBanner(); resetCrashes(); app.rebuild(); });
  el.querySelector('[data-rb="reload"]')?.addEventListener("click", async () => { try { await store.flush(); } catch { /* */ } location.reload(); });
}
