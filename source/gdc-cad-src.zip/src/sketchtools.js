// スケッチの編集操作: つながった点の追従、フィレット、オフセット、トリム、ミラー
import { resolveEntity, findLoops, intersect, arcParams, arcPoint, arcParamOf, arcFrom3 } from "./shared/sketchgeom.js";

const TOL = 1e-6;
const isNum = (v) => typeof v === "number" || (typeof v === "string" && /^-?\d+(\.\d+)?$/.test(v.trim()));
const r6 = (v) => +(+v).toFixed(6);
const same = (p, q) => Math.abs(p[0] - q[0]) < 1e-6 && Math.abs(p[1] - q[1]) < 1e-6;

// 各図形の「点」（端点・中心・角）とその座標キー
export function handles(e) {
  if (e.type === "line") return [{ k: ["x1", "y1"], p: [e.x1, e.y1] }, { k: ["x2", "y2"], p: [e.x2, e.y2] }];
  if (e.type === "arc") return [{ k: ["x1", "y1"], p: [e.x1, e.y1] }, { k: ["x2", "y2"], p: [e.x2, e.y2] }, { k: ["xm", "ym"], p: [e.xm, e.ym], mid: true }];
  if (e.type === "circle") return [{ k: ["cx", "cy"], p: [e.cx, e.cy] }];
  if (e.type === "rect") return [
    { corner: 0, p: [e.x, e.y] }, { corner: 1, p: [e.x + e.w, e.y] },
    { corner: 2, p: [e.x + e.w, e.y + e.h] }, { corner: 3, p: [e.x, e.y + e.h] },
  ];
  return [];
}

// 点 h を np へ動かした図形（rect の角は対角を固定）
export function moveHandle(raw, e, h, np) {
  const out = { ...raw };
  if (h.k) {
    if (isNum(raw[h.k[0]]) || raw[h.k[0]] === undefined) out[h.k[0]] = r6(np[0]);
    if (isNum(raw[h.k[1]]) || raw[h.k[1]] === undefined) out[h.k[1]] = r6(np[1]);
    return out;
  }
  if (e.type === "rect") {
    const C = [[e.x, e.y], [e.x + e.w, e.y], [e.x + e.w, e.y + e.h], [e.x, e.y + e.h]];
    const F = C[(h.corner + 2) % 4];
    if (!isNum(raw.w) || !isNum(raw.h)) { // 寸法が式なら形はそのまま平行移動
      const dx = np[0] - h.p[0], dy = np[1] - h.p[1];
      if (isNum(raw.x)) out.x = r6(e.x + dx);
      if (isNum(raw.y)) out.y = r6(e.y + dy);
      return out;
    }
    out.x = r6(F[0]); out.y = r6(F[1]); out.w = r6(np[0] - F[0]); out.h = r6(np[1] - F[1]);
    return out;
  }
  return out;
}

// i 番目の図形を newRaw に置き換え、動いた端点とつながっていた他の線の端点も一緒に動かす
export function applyWithLinks(entities, i, newRaw, num) {
  const ents = entities.map((x) => ({ ...x }));
  let oldE, newE;
  try { oldE = resolveEntity(entities[i], num); newE = resolveEntity(newRaw, num); } catch { ents[i] = newRaw; return ents; }
  ents[i] = newRaw;
  const oldH = handles(oldE).filter((h) => !h.mid), newH = handles(newE).filter((h) => !h.mid);
  const moves = [];
  oldH.forEach((h, k) => { if (newH[k] && !same(h.p, newH[k].p)) moves.push([h.p, newH[k].p]); });
  if (!moves.length) return ents;
  ents.forEach((raw, j) => {
    if (j === i) return;
    let e; try { e = resolveEntity(raw, num); } catch { return; }
    let cur = raw;
    for (const [from, to] of moves) {
      for (const h of handles(e)) {
        if (h.mid || h.corner !== undefined) continue; // 円弧の通過点・長方形は追従させない
        if (same(h.p, from)) cur = moveHandle(cur, e, h, to);
      }
    }
    ents[j] = cur;
  });
  return ents;
}

// ---------------------------------------------------------------- フィレット（角を丸める）
// 長方形は 4 本の線に分解
export function explodeRect(e) {
  const p = [[e.x, e.y], [e.x + e.w, e.y], [e.x + e.w, e.y + e.h], [e.x, e.y + e.h]];
  return p.map((a, k) => ({ type: "line", x1: r6(a[0]), y1: r6(a[1]), x2: r6(p[(k + 1) % 4][0]), y2: r6(p[(k + 1) % 4][1]) }));
}

export function filletCorner(entities, P, r, num) {
  // P に端点を持つ線を 2 本探す（長方形の角なら分解）
  let ents = entities.map((x) => ({ ...x }));
  for (let i = ents.length - 1; i >= 0; i--) {
    if (ents[i].type !== "rect") continue;
    const e = resolveEntity(ents[i], num);
    if (handles(e).some((h) => same(h.p, P))) ents.splice(i, 1, ...explodeRect(e));
  }
  const at = [];
  ents.forEach((raw, i) => {
    if (raw.type !== "line") return;
    const e = resolveEntity(raw, num);
    if (same([e.x1, e.y1], P)) at.push({ i, e, end: 1, far: [e.x2, e.y2] });
    else if (same([e.x2, e.y2], P)) at.push({ i, e, end: 2, far: [e.x1, e.y1] });
  });
  if (at.length !== 2) throw new Error("2 本の線が交わる角をクリックしてください");
  const [A, B] = at;
  const u = (q) => { const d = [q[0] - P[0], q[1] - P[1]]; const L = Math.hypot(...d); return [d[0] / L, d[1] / L, L]; };
  const [u1x, u1y, L1] = u(A.far), [u2x, u2y, L2] = u(B.far);
  const cos = u1x * u2x + u1y * u2y;
  const th = Math.acos(Math.max(-1, Math.min(1, cos)));
  if (th < 1e-3 || Math.abs(th - Math.PI) < 1e-3) throw new Error("一直線の角には丸めを付けられません");
  const t = r / Math.tan(th / 2);
  if (t >= L1 - 1e-9 || t >= L2 - 1e-9) throw new Error("半径が大きすぎます（線より長くなります）");
  const T1 = [P[0] + u1x * t, P[1] + u1y * t], T2 = [P[0] + u2x * t, P[1] + u2y * t];
  let bx = u1x + u2x, by = u1y + u2y; const bl = Math.hypot(bx, by); bx /= bl; by /= bl;
  const dc = r / Math.sin(th / 2);
  const C = [P[0] + bx * dc, P[1] + by * dc];
  const M = [C[0] - bx * r, C[1] - by * r];
  const setEnd = (o, end, q) => (end === 1 ? { ...ents[o.i], x1: r6(q[0]), y1: r6(q[1]) } : { ...ents[o.i], x2: r6(q[0]), y2: r6(q[1]) });
  ents[A.i] = setEnd(A, A.end, T1);
  ents[B.i] = setEnd(B, B.end, T2);
  ents.push({ type: "arc", x1: r6(T1[0]), y1: r6(T1[1]), x2: r6(T2[0]), y2: r6(T2[1]), xm: r6(M[0]), ym: r6(M[1]) });
  return ents;
}

// クリック位置に近い「角」（2 本の線の共有点、または長方形の角）
export function nearestCorner(entities, q, tol, num) {
  let best = null, bd = tol;
  const pts = [];
  entities.forEach((raw) => {
    let e; try { e = resolveEntity(raw, num); } catch { return; }
    if (e.type === "line") pts.push([e.x1, e.y1], [e.x2, e.y2]);
    if (e.type === "rect") pts.push(...handles(e).map((h) => h.p));
  });
  for (const p of pts) { const d = Math.hypot(p[0] - q[0], p[1] - q[1]); if (d < bd) { bd = d; best = p; } }
  return best;
}

// ---------------------------------------------------------------- オフセット
export function offsetEntity(entities, i, dist, num) {
  const raw = entities[i];
  const e = resolveEntity(raw, num);
  if (e.type === "circle") return [{ type: "circle", cx: r6(e.cx), cy: r6(e.cy), d: r6(Math.abs(e.d) + 2 * dist) }];
  if (e.type === "rect") {
    const x0 = Math.min(e.x, e.x + e.w), y0 = Math.min(e.y, e.y + e.h), w = Math.abs(e.w), h = Math.abs(e.h);
    if (w + 2 * dist <= 0 || h + 2 * dist <= 0) throw new Error("内側へのオフセットが大きすぎます");
    return [{ type: "rect", x: r6(x0 - dist), y: r6(y0 - dist), w: r6(w + 2 * dist), h: r6(h + 2 * dist) }];
  }
  // 線・円弧: その線を含む閉じた輪郭（最も小さい領域）をまとめてオフセット
  const loops = findLoops(entities, num).filter((l) => l.kind === "chain" && l.src.includes(i)).sort((a, b) => a.area - b.area);
  if (!loops.length) throw new Error("閉じた輪郭の線を選んでください");
  const segs = loops[0].segs; // 反時計回り
  const out = [];
  const off = segs.map((s) => {
    if (s.type === "line") {
      const dx = s.b[0] - s.a[0], dy = s.b[1] - s.a[1], L = Math.hypot(dx, dy);
      const n = [dy / L, -dx / L]; // 外向き（進行方向の右）
      return { type: "line", a: [s.a[0] + n[0] * dist, s.a[1] + n[1] * dist], b: [s.b[0] + n[0] * dist, s.b[1] + n[1] * dist] };
    }
    const c = arcFrom3(s.a, s.b, s.m);
    const ccw = (s.m[0] - s.a[0]) * (s.b[1] - s.m[1]) - (s.m[1] - s.a[1]) * (s.b[0] - s.m[0]) > 0;
    const k = (c.r + (ccw ? dist : -dist)) / c.r;
    if (k <= 0) throw new Error("内側へのオフセットが大きすぎます");
    const mv = (p) => [c.cx + (p[0] - c.cx) * k, c.cy + (p[1] - c.cy) * k];
    return { type: "arc", a: mv(s.a), b: mv(s.b), m: mv(s.m) };
  });
  // 線どうしの角は延長して交わらせる
  for (let k = 0; k < off.length; k++) {
    const s1 = off[k], s2 = off[(k + 1) % off.length];
    if (s1.type === "line" && s2.type === "line") {
      const p = lineX(s1.a, s1.b, s2.a, s2.b);
      if (p) { s1.b = p; s2.a = p; }
    }
  }
  for (let k = 0; k < off.length; k++) {
    const s = off[k], nx = off[(k + 1) % off.length];
    if (s.type === "line") out.push({ type: "line", x1: r6(s.a[0]), y1: r6(s.a[1]), x2: r6(s.b[0]), y2: r6(s.b[1]) });
    else out.push({ type: "arc", x1: r6(s.a[0]), y1: r6(s.a[1]), x2: r6(s.b[0]), y2: r6(s.b[1]), xm: r6(s.m[0]), ym: r6(s.m[1]) });
    if (!same(s.b, nx.a)) out.push({ type: "line", x1: r6(s.b[0]), y1: r6(s.b[1]), x2: r6(nx.a[0]), y2: r6(nx.a[1]) });
  }
  return out;
}

function lineX(a, b, c, d) {
  const den = (b[0] - a[0]) * (d[1] - c[1]) - (b[1] - a[1]) * (d[0] - c[0]);
  if (Math.abs(den) < 1e-12) return null;
  const t = ((c[0] - a[0]) * (d[1] - c[1]) - (c[1] - a[1]) * (d[0] - c[0])) / den;
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
}

// ---------------------------------------------------------------- トリム（交点で区切った一部分を消す）
function curveOf(e) {
  if (e.type === "line") return { type: "line", a: [e.x1, e.y1], b: [e.x2, e.y2] };
  if (e.type === "arc") { const g = arcParams([e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym]); return g ? { type: "arc", g } : null; }
  if (e.type === "circle") return { type: "arc", g: { cx: e.cx, cy: e.cy, r: Math.abs(e.d) / 2, t0: 0, sweep: Math.PI * 2 }, full: true };
  return null;
}

export function trimAt(entities, i, q, num) {
  let ents = entities.map((x) => ({ ...x }));
  // 長方形は分解してから
  const target = resolveEntity(ents[i], num);
  if (target.type === "rect") {
    const lines = explodeRect(target);
    ents.splice(i, 1, ...lines);
    // クリックに最も近い辺を対象に
    let bi = i, bd = Infinity;
    lines.forEach((l, k) => { const d = segD(q, [l.x1, l.y1], [l.x2, l.y2]); if (d < bd) { bd = d; bi = i + k; } });
    i = bi;
  }
  const e = resolveEntity(ents[i], num);
  const C = curveOf(e);
  if (!C) throw new Error("この図形はトリムできません");
  const cuts = [0, 1];
  const real = [];
  ents.forEach((raw, j) => {
    if (j === i || raw.construction) return;
    let o; try { o = resolveEntity(raw, num); } catch { return; }
    const others = o.type === "rect" ? explodeRect(o).map((l) => curveOf(resolveEntity(l, num))) : [curveOf(o)];
    for (const D of others) if (D) for (const [s] of intersect(C, D, 1e-6)) { cuts.push(s); real.push(s); }
  });
  // クリック位置のパラメータ
  let tq;
  if (C.type === "line") { const dx = C.b[0] - C.a[0], dy = C.b[1] - C.a[1]; tq = ((q[0] - C.a[0]) * dx + (q[1] - C.a[1]) * dy) / (dx * dx + dy * dy); }
  else tq = arcParamOf(C.g, q);
  const ps = [...new Set(cuts.map((x) => +x.toFixed(9)))].sort((a, b) => a - b);
  if (C.full) {
    // 円: クリックを挟む 2 つの交点の間を消して円弧にする
    const inner = [...new Set(real.map((x) => +(((x % 1) + 1) % 1 > 1 - 1e-9 ? 0 : ((x % 1) + 1) % 1).toFixed(9)))].sort((a, b) => a - b);
    if (inner.length < 2) { ents.splice(i, 1); return ents; }
    let lo = inner.filter((x) => x <= tq).pop(), hi = inner.find((x) => x > tq);
    if (lo === undefined) lo = inner[inner.length - 1] - 1;
    if (hi === undefined) hi = inner[0] + 1;
    const span = 1 - (hi - lo);
    const at = (s) => arcPoint(C.g, ((s % 1) + 1) % 1);
    const a = at(hi), b = at(hi + span), m = at(hi + span / 2);
    ents[i] = { type: "arc", x1: r6(a[0]), y1: r6(a[1]), x2: r6(b[0]), y2: r6(b[1]), xm: r6(m[0]), ym: r6(m[1]) };
    return ents;
  }
  let lo = 0;
  for (const x of ps) if (x <= tq + 1e-12) lo = x;
  const hi = ps.find((x) => x > tq + 1e-12) ?? 1;
  const keep = [];
  if (lo > 1e-9) keep.push([0, lo]);
  if (hi < 1 - 1e-9) keep.push([hi, 1]);
  const pieces = keep.map(([s0, s1]) => {
    if (C.type === "line") {
      const P = (s) => [C.a[0] + (C.b[0] - C.a[0]) * s, C.a[1] + (C.b[1] - C.a[1]) * s];
      const a = P(s0), b = P(s1);
      return { ...ents[i], type: "line", x1: r6(a[0]), y1: r6(a[1]), x2: r6(b[0]), y2: r6(b[1]) };
    }
    const a = arcPoint(C.g, s0), b = arcPoint(C.g, s1), m = arcPoint(C.g, (s0 + s1) / 2);
    return { ...ents[i], type: "arc", x1: r6(a[0]), y1: r6(a[1]), x2: r6(b[0]), y2: r6(b[1]), xm: r6(m[0]), ym: r6(m[1]) };
  });
  ents.splice(i, 1, ...pieces);
  return ents;
}

function segD(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const L2 = dx * dx + dy * dy || 1e-12;
  const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2));
  return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy);
}

// ---------------------------------------------------------------- ミラー
export function mirrorEntities(entities, idxs, axis, num) {
  // axis: {a:[x,y], b:[x,y]}
  const [ax, ay] = axis.a, dx = axis.b[0] - ax, dy = axis.b[1] - ay, L2 = dx * dx + dy * dy;
  const R = (p) => { const t = ((p[0] - ax) * dx + (p[1] - ay) * dy) / L2; const fx = ax + dx * t, fy = ay + dy * t; return [r6(2 * fx - p[0]), r6(2 * fy - p[1])]; };
  const axisAligned = Math.abs(dx) < 1e-12 || Math.abs(dy) < 1e-12;
  const out = [];
  for (const i of idxs) {
    const e = resolveEntity(entities[i], num);
    const cons = entities[i].construction ? { construction: true } : {};
    if (e.type === "line") { const a = R([e.x1, e.y1]), b = R([e.x2, e.y2]); out.push({ type: "line", x1: a[0], y1: a[1], x2: b[0], y2: b[1], ...cons }); }
    else if (e.type === "arc") { const a = R([e.x1, e.y1]), b = R([e.x2, e.y2]), m = R([e.xm, e.ym]); out.push({ type: "arc", x1: a[0], y1: a[1], x2: b[0], y2: b[1], xm: m[0], ym: m[1], ...cons }); }
    else if (e.type === "circle") { const c = R([e.cx, e.cy]); out.push({ type: "circle", cx: c[0], cy: c[1], d: r6(Math.abs(e.d)), ...cons }); }
    else if (e.type === "rect") {
      if (axisAligned) { const a = R([e.x, e.y]), b = R([e.x + e.w, e.y + e.h]); out.push({ type: "rect", x: Math.min(a[0], b[0]), y: Math.min(a[1], b[1]), w: r6(Math.abs(b[0] - a[0])), h: r6(Math.abs(b[1] - a[1])), ...cons }); }
      else for (const l of explodeRect(e)) { const a = R([l.x1, l.y1]), b = R([l.x2, l.y2]); out.push({ type: "line", x1: a[0], y1: a[1], x2: b[0], y2: b[1], ...cons }); }
    }
  }
  return out;
}
