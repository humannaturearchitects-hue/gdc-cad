// データの安全と受け渡し（files 担当）
// ・保存できないとき／別のタブとぶつかったときの目立つ表示と対処ボタン
// ・同じファイルを 2 つのタブで開いたときの警告と、別のタブで保存された内容の自動取り込み（BroadcastChannel）
// ・新しい版が出たときの「更新があります → 更新」（Service Worker）
// ・ファイルごとの「版の履歴」パネル、名前を付けて版を残す
// ・バックアップを長くしていないときの控えめなお知らせ
// ・起動時に前回のファイルで止まった場合は開かずに起動する
// ・パソコンのアプリ版（PWA）で .kcad をダブルクリックして開く（launchQueue）
import { store } from "./store.js";
import { library, fmtSize, fmtDate, isQuotaError } from "./library.js";

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const TAB = Math.random().toString(36).slice(2, 10);
let app = null;

// ---------------------------------------------------------------- お知らせの帯（画面上部、閉じるまで残る）
function bars() {
  let c = document.getElementById("safety-bars");
  if (!c) { c = document.createElement("div"); c.id = "safety-bars"; document.body.appendChild(c); }
  return c;
}
// kind: err（赤）/ warn（黄）/ info（青）。buttons: [[ラベル, 関数, primary?]]
export function showBar(key, html, { kind = "info", buttons = [], closable = true } = {}) {
  const c = bars();
  let el = c.querySelector(`[data-key="${key}"]`);
  if (!el) { el = document.createElement("div"); el.dataset.key = key; c.appendChild(el); }
  el.className = "sbar " + kind;
  el.innerHTML = `<div class="sbar-msg">${html}</div><div class="sbar-btns">${buttons.map((b, i) => `<button class="btn${b[2] ? " primary" : ""}" data-i="${i}">${esc(b[0])}</button>`).join("")}${closable ? '<button class="sbar-x" title="閉じる" aria-label="閉じる">×</button>' : ""}</div>`;
  el.querySelectorAll("[data-i]").forEach((b) => (b.onclick = async () => { try { await buttons[+b.dataset.i][1](); } catch (e) { app?.toast(e.message || String(e), true); } }));
  const x = el.querySelector(".sbar-x"); if (x) x.onclick = () => hideBar(key);
  return el;
}
export function hideBar(key) { document.querySelector(`#safety-bars [data-key="${key}"]`)?.remove(); }

// ---------------------------------------------------------------- 保存の状態
function onSaveState(st, err) {
  if (st === "saved") { hideBar("save-error"); hideBar("conflict"); return; }
  if (st === "error") {
    const quota = isQuotaError({ message: err });
    showBar("save-error", `<b>⚠ 保存できていません。</b>${esc(err)}<br><small>このまま閉じると、最後の変更が失われます。下のボタンで対処してください。</small>`, {
      kind: "err", closable: false,
      buttons: [
        ["もう一度保存", async () => { await store.flush(); if (store.saveState === "saved") app.toast("保存できました"); }, true],
        ["ファイルに書き出す（.kcad）", () => app.exportDoc()],
        ...(quota ? [["古い版を消して空ける", freeSpace]] : []),
        ["ファイル一覧（不要なものを削除）", () => app.openLibrary()],
      ],
    });
  }
  if (st === "conflict") showConflict();
}
async function freeSpace() {
  const n = await library.purgeAutoVersions();
  app.toast(n ? `自動で残していた古い版 ${n} 個を削除しました。もう一度保存します` : "削除できる古い版はありませんでした。ファイル一覧から不要なファイルを削除してください");
  await store.flush();
}
function showConflict() {
  showBar("conflict", `<b>このファイルは別のタブ（または別の画面）で変更・保存されました。</b><br><small>このタブでの変更は、まだ保存していません（上書き事故を防ぐため止めています）。どうするか選んでください。</small>`, {
    kind: "warn", closable: false,
    buttons: [
      ["あちらの内容を読み込む", adoptOther, true],
      ["このタブの内容を別のファイルに保存", async () => {
        const p = JSON.parse(JSON.stringify(store.project)); p.name = (p.name || "無題") + "（別タブでの変更）";
        await app.switchTo(p); await store.flush(); app.toast(`「${p.name}」として保存しました`);
      }],
      ["このタブの内容で上書き", async () => { if (!confirm("別のタブで保存された内容を、このタブの内容で上書きします。よろしいですか？（上書き前の内容は「版の履歴」に残ります）")) return; const id = store.docId; const prev = await library.load(id).catch(() => null); if (prev) await library.addVersion(id, prev, { kind: "before", label: "上書きされる前の内容" }).catch(() => {}); await store.forceSave(); if (store.saveState === "saved") app.toast("このタブの内容で保存しました"); }],
    ],
  });
}
async function adoptOther() {
  const id = store.docId, p = await library.load(id);
  if (!p) throw new Error("保管庫にこのファイルが見つかりません（削除された可能性があります）");
  store.adopt(p, library.revOf(id));
  hideBar("conflict");
  app.toast("別のタブで保存された内容を読み込みました（元に戻す で、このタブの前の内容に戻せます）");
}

// ---------------------------------------------------------------- 別のタブとの連絡
let chan = null;
const others = new Map(); // タブ id → 開いているファイル id
function post(m) { try { chan?.postMessage({ ...m, tab: TAB }); } catch { /* */ } }
function updateTabsBar() {
  const n = [...others.values()].filter((d) => d === store.docId).length;
  if (n && store.docSaved) {
    showBar("tabs", `このファイルは<b>別のタブでも開いています</b>。両方で編集すると、片方の変更が保存できなくなります。どちらか一方だけで作業してください。`, { kind: "warn" });
  } else hideBar("tabs");
}
function initTabs() {
  if (typeof BroadcastChannel === "undefined") return;
  chan = new BroadcastChannel("gdc-cad-tabs");
  chan.onmessage = async ({ data: m }) => {
    if (!m || m.tab === TAB) return;
    if (m.t === "open" || m.t === "here") { others.set(m.tab, m.doc); if (m.t === "open") post({ t: "here", doc: store.docId }); updateTabsBar(); }
    else if (m.t === "bye") { others.delete(m.tab); updateTabsBar(); }
    else if (m.t === "saved" && m.doc === store.docId) {
      others.set(m.tab, m.doc);
      // こちらに保存していない変更がなく、作業中でもなければ、そのまま最新を取り込む
      if (store.saveState !== "saved" || store.conflict || (store.docRev || 0) >= m.rev) return;
      if (app.mode !== "idle" || app.dialog?.isOpen) { store.conflict = { meta: null }; store.setSave("conflict", "別のタブで保存されました"); return; }
      try {
        const p = await library.load(store.docId);
        if (!p) return;
        if (JSON.stringify(p) === JSON.stringify(store.project)) { store.docRev = library.revOf(store.docId); return; }
        store.adopt(p, library.revOf(store.docId));
        app.toast("別のタブで保存された変更を読み込みました");
      } catch { /* */ }
    } else if (m.t === "removed" && m.doc === store.docId) {
      app.toast("このファイルは別のタブで削除されました。続けて作業すると、新しいファイルとして保存されます", true);
      store.docSaved = false; store.docRev = 0;
    }
  };
  let lastDoc = null;
  store.on(() => { if (store.docId !== lastDoc) { lastDoc = store.docId; post({ t: "open", doc: lastDoc }); setTimeout(updateTabsBar, 300); } });
  store.savedListeners.add((id, m) => { post({ t: "saved", doc: id, rev: m.rev }); if (others.size) updateTabsBar(); });
  window.addEventListener("pagehide", () => post({ t: "bye" }));
}
export const tabs = { notifyRemoved(id) { post({ t: "removed", doc: id }); } };

// ---------------------------------------------------------------- 新しい版（Service Worker）
export function watchUpdates(reg) {
  if (!reg || !navigator.serviceWorker) return;
  const hadController = !!navigator.serviceWorker.controller;
  let wantReload = false;
  const offer = (w) => {
    showBar("update", "<b>新しい版があります。</b>作業は保存されたまま、すぐに切り替えられます。", {
      kind: "info",
      buttons: [["更新する", async () => {
        try { await store.flush(); } catch { /* */ }
        if (store.saveState === "error" || store.saveState === "conflict") { if (!confirm("保存できていない変更があります。このまま更新しますか？")) return; }
        wantReload = true;
        w.postMessage({ type: "skipWaiting" });
        setTimeout(() => location.reload(), 4000); // 切り替わりの合図が来なくても読み込み直す
      }, true], ["あとで", () => hideBar("update")]],
      closable: false,
    });
  };
  if (reg.waiting && hadController) offer(reg.waiting);
  reg.addEventListener("updatefound", () => {
    const w = reg.installing; if (!w) return;
    w.addEventListener("statechange", () => { if (w.state === "installed" && navigator.serviceWorker.controller) offer(w); });
  });
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (wantReload) return location.reload();
    if (hadController) showBar("update", "このソフトの新しい版に切り替わりました。<b>読み込み直してください</b>（作業は保存されています）。", { kind: "info", buttons: [["読み込み直す", async () => { try { await store.flush(); } catch { /* */ } location.reload(); }, true]] });
  });
  let lastCheck = Date.now();
  const check = () => { lastCheck = Date.now(); reg.update().catch(() => {}); };
  setInterval(check, 60 * 60 * 1000);
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && Date.now() - lastCheck > 10 * 60 * 1000) check(); });
  window.__checkUpdate = check; // テスト用
}

// ---------------------------------------------------------------- 起動時: 前回開いたファイル（止まったら次は開かない）
const GUARD = "gdc-opening";
export function startupDocId() {
  let id = null;
  try { id = sessionStorage.getItem("gdc-tab-doc") || localStorage.getItem("gdc-last-doc"); } catch { /* */ }
  if (!id) return { id: null };
  try {
    const g = JSON.parse(localStorage.getItem(GUARD) || "null");
    if (g && g.id === id && Date.now() - g.t < 30 * 60 * 1000) { localStorage.removeItem(GUARD); return { id: null, skipped: id }; }
    localStorage.setItem(GUARD, JSON.stringify({ id, t: Date.now() }));
  } catch { /* */ }
  return { id };
}
function clearGuard() { try { localStorage.removeItem(GUARD); } catch { /* */ } }
function watchFirstBuild() {
  window.addEventListener("pagehide", clearGuard); // ふつうに閉じた・読み込み直した＝止まっていない
  let n = 0;
  const t = setInterval(() => {
    n++;
    const busy = !document.getElementById("busy")?.classList.contains("hidden");
    if ((!app.buildsRunning && !busy && n > 2) || n > 600) { clearInterval(t); clearGuard(); }
  }, 250);
}

// ---------------------------------------------------------------- バックアップのお知らせ
const DAY = 864e5;
async function backupReminder() {
  let items;
  try { items = await library.list(); } catch { return; }
  if (!items.length) return;
  const last = +(localStorage.getItem("gdc-last-backup") || 0), snooze = +(localStorage.getItem("gdc-backup-snooze") || 0);
  if (Date.now() < snooze) return;
  const oldest = Math.min(...items.map((m) => m.created || Date.now()));
  const since = last ? Date.now() - last : Date.now() - oldest;
  const changed = items.some((m) => (m.updated || 0) > last);
  if (since < 7 * DAY || !changed) return;
  const days = Math.floor(since / DAY);
  showBar("backup", last ? `最後のバックアップから <b>${days} 日</b>たちました。大事な設計データは、時々ファイルにも残しておくと安心です。` : `まだ一度もバックアップしていません（いちばん古いファイルは ${days} 日前）。時々ファイルにも残しておくと安心です。`, {
    kind: "info",
    buttons: [["今すぐバックアップ", async () => { hideBar("backup"); await app.backupAll(); }, true], ["あとで", () => { localStorage.setItem("gdc-backup-snooze", String(Date.now() + 3 * DAY)); hideBar("backup"); }]],
  });
}

// ---------------------------------------------------------------- 容量が残り少ないとき（一度だけ）
let quotaWarned = false;
async function checkQuota() {
  if (quotaWarned) return;
  const u = await library.usage().catch(() => null);
  if (!u || !u.quota || !u.used) return;
  if (u.used / u.quota < 0.85) return;
  quotaWarned = true;
  showBar("quota", `端末の保存容量が残り少なくなっています（${fmtSize(u.used)} / ${fmtSize(u.quota)}）。バックアップを書き出して、使わないファイルや古い版を削除してください。`, {
    kind: "warn", buttons: [["すべてをバックアップ", () => app.backupAll()], ["古い版を消す", freeSpace], ["ファイル一覧", () => app.openLibrary()]],
  });
}

// ---------------------------------------------------------------- 版の履歴
const KIND = { auto: "自動", named: "名前付き", before: "戻す前" };
export async function openHistory(docId = store.docId) {
  try { await store.flush(); } catch { /* */ }
  const cur = docId === store.docId;
  let hs = [], meta = null;
  try { hs = await library.history(docId); meta = await library.meta(docId); } catch (e) { return app.toast("版の履歴を開けません: " + e.message, true); }
  const name = cur ? store.project.name : meta?.name;
  const row = (h) => `<div class="hist-row ${h.kind}" data-k="${h.k}">
      <div class="hist-info"><b>${h.label ? esc(h.label) : fmtDate(h.t)}</b> <span class="hist-kind">${KIND[h.kind] || ""}</span><br><small>${h.label ? fmtDate(h.t) + "・" : ""}${esc(h.name)}・手順 ${h.features}・${fmtSize(h.size)}</small></div>
      <div class="hist-acts"><button class="btn primary" data-a="restore">${cur ? "この版に戻す" : "この版で開く"}</button><button class="btn" data-a="copy">別のファイルとして開く</button><button class="btn" data-a="label">名前</button><button class="btn" data-a="del">削除</button></div>
    </div>`;
  const el = app.panel(`版の履歴 —「${esc(name || "無題")}」`, `<div class="full hist">
      <div class="dlg-note">作業中は自動で版が残ります（開いたときの状態と、その後 30 分ごと）。古い自動の版は 1 日 1 個に間引かれます（30 日まで）。名前を付けた版は消えません。</div>
      ${cur ? '<div><button class="btn primary" id="hist-snap">＋ 今の状態に名前を付けて残す</button></div>' : ""}
      <div class="hist-list">${hs.length ? hs.map(row).join("") : '<div class="dlg-note">まだ版はありません。作業を続けると自動で残ります。</div>'}</div>
    </div>`, null, { okLabel: "閉じる", noCancel: true, wide: true, cls: "hist-panel" });
  const close = () => el.querySelector("[data-o]").click();
  const snap = el.querySelector("#hist-snap"); if (snap) snap.onclick = async () => { if (await saveNamedVersion()) openHistory(docId); };
  el.querySelectorAll(".hist-row").forEach((r) => {
    const k = +r.dataset.k, h = hs.find((x) => x.k === k);
    r.querySelectorAll("[data-a]").forEach((b) => (b.onclick = async () => {
      try {
        const a = b.dataset.a;
        if (a === "restore") {
          const p = await library.loadVersion(k); if (!p) throw new Error("この版が見つかりません");
          if (!cur) { close(); await app.switchTo(p, docId); app.toast(`「${p.name}」を ${fmtDate(h.t)} の版で開きました`); return; }
          if (!confirm(`${h.label || fmtDate(h.t)} の版に戻します。今の状態は「戻す前」として履歴に残ります。よろしいですか？`)) return;
          await library.addVersion(docId, JSON.parse(JSON.stringify(store.project)), { kind: "before", label: `戻す前（${fmtDate(Date.now())}）` });
          store.commit((proj) => { for (const key of Object.keys(proj)) delete proj[key]; Object.assign(proj, p); });
          close(); app.toast(`${h.label || fmtDate(h.t)} の版に戻しました（元に戻す で取り消せます）`);
        } else if (a === "copy") {
          const p = await library.loadVersion(k); if (!p) throw new Error("この版が見つかりません");
          p.name = `${p.name || "無題"}（${h.label || fmtDate(h.t)} の版）`;
          close(); await app.switchTo(p); await store.flush(); app.toast(`「${p.name}」を別のファイルとして作りました`);
        } else if (a === "label") {
          const n = prompt("この版の名前", h.label || ""); if (n == null) return;
          await library.renameVersion(k, n.trim()); openHistory(docId);
        } else if (a === "del") {
          if (!confirm("この版を削除します。よろしいですか？")) return;
          await library.removeVersion(k); openHistory(docId);
        }
      } catch (e) { app.toast(e.message || String(e), true); }
    }));
  });
}
export async function saveNamedVersion(label) {
  if (!store.project.features.length) { app.toast("まだ何も作っていません"); return false; }
  if (label == null) { label = prompt("この版の名前（例: 見積り提出版、お客様確認済み）", ""); if (label == null) return false; }
  store.docSaved = true;
  await store.flush();
  if (store.saveState !== "saved") { app.toast("保存できていないため、版を残せませんでした", true); return false; }
  try { await library.addVersion(store.docId, JSON.parse(JSON.stringify(store.project)), { kind: "named", label: label.trim() || "名前なし" }); }
  catch (e) { app.toast("版を残せませんでした: " + e.message, true); return false; }
  app.toast(`版「${label.trim() || "名前なし"}」を残しました（ファイル → 版の履歴 から戻せます）`);
  return true;
}

// ---------------------------------------------------------------- 開始
export function initSafety(a) {
  app = a;
  store.saveListeners.add(onSaveState);
  store.savedListeners.add(() => { setTimeout(checkQuota, 0); });
  initTabs();
  watchFirstBuild();
  setTimeout(backupReminder, 5000);
  // パソコンのアプリ版（ホーム画面／アプリとしてインストール）で .kcad を開いたとき
  if ("launchQueue" in window) {
    window.launchQueue.setConsumer(async (params) => {
      const h = params.files && params.files[0]; if (!h) return;
      const f = await h.getFile();
      if (/\.gdcbackup$/i.test(f.name)) return app.restoreBackup(f);
      return app.openDoc(f);
    });
  }
  window.__safety = { showBar, hideBar, openHistory, saveNamedVersion, backupReminder, library };
}
