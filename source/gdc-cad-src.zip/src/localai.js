// 端末内 AI: ブラウザの WebGPU で小さな言語モデルを動かす（無料・オフライン・データが外に出ない）
// 初回だけモデルをダウンロードし（Hugging Face から）、端末の Cache Storage に保存する。2 回目からはオフラインで動く。
// web-llm 本体は Worker（localai.worker.js）の中だけで読み込む（画面側の起動を重くしない）
import { localMessages, buildGrammar, normalizeRequest, postProcess } from "./localprompt.js";

const LIB = "https://raw.githubusercontent.com/mlc-ai/binary-mlc-llm-libs/main/web-llm-models/v0_2_87/base/";
const HF = "https://huggingface.co/mlc-ai/";
// 候補（選んだ根拠は tests/localai_eval/README.txt）。mb はダウンロードの大きさ、mem は動かすときに要るメモリの目安
// f16: 半精度が使える GPU（iPhone・Mac・多くのパソコン）用、f32: 使えない GPU 用（少し大きく遅い）
export const LOCAL_MODELS = [
  { key: "std", label: "標準（Qwen2.5 1.5B）", f16: "Qwen2.5-1.5B-Instruct-q4f16_1-MLC", f32: "Qwen2.5-1.5B-Instruct-q4f32_1-MLC", lib16: "Qwen2-1.5B-Instruct-q4f16_1_cs1k-webgpu.wasm", lib32: "Qwen2-1.5B-Instruct-q4f32_1_cs1k-webgpu.wasm", mb: 880, mem: 1300 },
  { key: "small", label: "小さい・速い（Qwen2.5 0.5B）", f16: "Qwen2.5-0.5B-Instruct-q4f16_1-MLC", f32: "Qwen2.5-0.5B-Instruct-q4f32_1-MLC", lib16: "Qwen2-0.5B-Instruct-q4f16_1_cs1k-webgpu.wasm", lib32: "Qwen2-0.5B-Instruct-q4f32_1_cs1k-webgpu.wasm", mb: 290, mem: 650 },
];
const CTX = 2048; // 文の長さの上限（短くするとメモリが減る）

const ls = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } };
// 既定: iPhone・iPad は「小さい・速い」（CAD 本体と合わせてメモリに収まるように）、パソコンは「標準」
const isIOS = () => typeof navigator !== "undefined" && (/iPhone|iPad|iPod/.test(navigator.userAgent || "") || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1));
export function localModelKey() { const def = isIOS() ? "small" : LOCAL_MODELS[0].key; const k = ls("gdc-local-model", def); return LOCAL_MODELS.some((m) => m.key === k) ? k : def; }
export function setLocalModelKey(k) { try { localStorage.setItem("gdc-local-model", k); } catch { /* */ } }
export function localModelInfo(key = localModelKey()) { return LOCAL_MODELS.find((m) => m.key === key) || LOCAL_MODELS[0]; }

// WebGPU が使えるか（使えないときは理由を日本語で）
let supportCache = null;
export async function checkSupport() {
  if (supportCache) return supportCache;
  const r = await (async () => {
    if (typeof navigator === "undefined" || !navigator.gpu) {
      const ios = /iPhone|iPad|iPod/.test(navigator?.userAgent || "");
      return { ok: false, reason: ios ? "この iPhone では端末内 AI が使えません（WebGPU に対応していません）。iOS 26 以降に更新すると使えます。" : "このブラウザでは端末内 AI が使えません（WebGPU に対応していません）。新しい Chrome・Edge・Safari 26 以降で使えます。" };
    }
    let a = null;
    try { a = await navigator.gpu.requestAdapter({ powerPreference: "high-performance" }); } catch { /* */ }
    if (!a) return { ok: false, reason: "この端末の GPU が使えないため、端末内 AI が使えません（WebGPU のアダプターがありません）。" };
    const f16 = a.features && a.features.has("shader-f16");
    const maxBuf = (a.limits && a.limits.maxBufferSize) || 0;
    return { ok: true, f16, maxBuf };
  })();
  supportCache = r;
  return r;
}

// テストや社内の置き場所から読むとき: localStorage "gdc-local-model-base" に、モデルを置いた URL（…/{モデルID}/ と …/libs/ がある所）
export function appConfigFor(info, f16) {
  const id = f16 ? info.f16 : info.f32, lib = f16 ? info.lib16 : info.lib32;
  const base = ls("gdc-local-model-base", "");
  return {
    id,
    appConfig: {
      model_list: [{ model: base ? `${base.replace(/\/$/, "")}/${id}` : HF + id, model_id: id, model_lib: base ? `${base.replace(/\/$/, "")}/libs/${lib}` : LIB + lib, overrides: { context_window_size: CTX } }],
      cacheBackend: "cache",
    },
  };
}

// わかりやすい言葉に
export function explainLocalError(msg) {
  const m = String(msg || "");
  if (/out of memory|OutOfMemory|allocation|Device was lost|device lost|DXGI|insufficient|exceeds|too large|maxBufferSize|maxStorageBuffer/i.test(m)) return "この端末のメモリが足りないため、端末内 AI を動かせませんでした。ほかのアプリやタブを閉じてもう一度試すか、⚙ 設定で「小さい・速い」モデルにしてください。";
  if (/QuotaExceeded|quota|storage/i.test(m)) return "端末の空き容量が足りないため、AI を保存できませんでした。空き容量を増やしてからもう一度試してください。";
  if (/fetch|network|Failed to fetch|NetworkError|Load failed/i.test(m)) return "AI のダウンロードが途中で止まりました（インターネット接続を確認して、もう一度試してください。途中まで保存した分は続きから読みます）。";
  return "端末内 AI でエラーが起きました: " + m;
}

class LocalEngine {
  constructor() { this.worker = null; this.seq = 0; this.wait = new Map(); this.state = "idle"; this.progress = 0; this.text = ""; this.listeners = new Set(); this.loadedId = null; this.loading = null; }
  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit() { for (const f of this.listeners) { try { f(this); } catch { /* */ } } }
  w() {
    if (this.worker) return this.worker;
    // テスト用: 本物のモデルの代わりに決まった返事をする Worker（window.__localaiWorker）
    const Fake = typeof window !== "undefined" && window.__localaiWorker;
    this.worker = Fake ? new Fake() : new Worker(new URL("./localai.worker.js", import.meta.url), { type: "module" });
    this.worker.onmessage = (ev) => {
      const m = ev.data || {};
      if (m.type === "progress") { this.progress = m.progress || 0; this.text = m.text || ""; this.emit(); return; }
      const p = this.wait.get(m.id); if (!p) return;
      this.wait.delete(m.id);
      if (m.type === "error") p.reject(Object.assign(new Error(m.message), { name: m.name || "Error" })); else p.resolve(m);
    };
    this.worker.onerror = (e) => { for (const p of this.wait.values()) p.reject(new Error(e.message || "worker error")); this.wait.clear(); };
    return this.worker;
  }
  send(msg) { const id = ++this.seq; return new Promise((resolve, reject) => { this.wait.set(id, { resolve, reject }); this.w().postMessage({ ...msg, id }); }); }
  async target() { const s = await checkSupport(); return appConfigFor(localModelInfo(), !!s.f16); }
  // ダウンロード済みか（端末に保存されているか）
  // 画面側で Cache Storage を見るだけ（GPU にも Worker にも触らない＝設定を開くだけで重くならない）
  async isCached() {
    try {
      if (typeof caches === "undefined" || !(await caches.has("webllm/model"))) return false;
      const c = await caches.open("webllm/model"), info = localModelInfo();
      for (const f16 of [true, false]) {
        const base = appConfigFor(info, f16).appConfig.model_list[0].model.replace(/\/$/, "") + "/resolve/main/";
        if ((await c.match(base + "tensor-cache.json")) || (await c.match(base + "ndarray-cache.json"))) return true;
      }
      return false;
    } catch { return false; }
  }
  ready() { return this.state === "ready" && this.loadedId; }
  // 読み込む（初回はダウンロード）。進み具合は on() で
  load() {
    if (this.loading) return this.loading;
    this.loading = (async () => {
      const s = await checkSupport();
      if (!s.ok) { this.state = "error"; this.error = s.reason; this.emit(); throw new Error(s.reason); }
      const { id, appConfig } = appConfigFor(localModelInfo(), !!s.f16);
      this.state = "loading"; this.progress = 0; this.text = ""; this.emit();
      try {
        await this.send({ type: "load", modelId: id, appConfig, chatOpts: { context_window_size: CTX } });
        this.state = "ready"; this.loadedId = id; this.error = null; this.emit();
      } catch (e) {
        this.state = "error"; this.error = explainLocalError(e.message); this.emit();
        throw new Error(this.error);
      } finally { this.loading = null; }
    })();
    return this.loading;
  }
  async remove() {
    const { id, appConfig } = await this.target();
    await this.send({ type: "delete", modelId: id, appConfig });
    this.state = "idle"; this.loadedId = null; this.emit();
  }
  async chat(request) {
    if (!this.ready()) await this.load();
    return this.send({ type: "chat", request });
  }
}
export const localEngine = new LocalEngine();

// 頼みごと 1 回分: 言葉を整える → 短い説明＋文法で縛ってモデルに聞く → 短い書き方を座標に直し、数値を照合
// model: { bodies:[{name,size,min,max}], features:[名前], selected:[ボディ名] }
export async function askLocal({ instruction, model }) {
  const norm = normalizeRequest(instruction);
  const t0 = Date.now();
  const r = await localEngine.chat({
    messages: localMessages(norm, model),
    temperature: 0, max_tokens: 160,
    response_format: { type: "grammar", grammar: buildGrammar(model) },
    extra_body: { enable_thinking: false },
  });
  const pp = postProcess(r.content, norm, model);
  return {
    commands: pp.lines.join("\n"), question: pp.ask, explanation: "",
    raw: r.content, fixes: pp.fixes, suspicious: pp.suspicious, ms: Date.now() - t0, usage: r.usage,
  };
}
