// 形を作ったあとに「直す」操作（Fusion の編集に近づける）
//  ・プロパティの「大きさ」を、元の手順（押し出しの距離・スケッチの寸法・円柱の直径…）につないで直す
//    元の手順が無い形（取り込んだ形など）は、比率を保って拡大・縮小（尺度）
//  ・タイムラインの並べ替え（ドラッグ / メニューの「前へ」「後ろへ」）。使っている手順より前には動かせない
//  ・iPhone の 2 本指ひねりで回転
//  ・パラメータの使用箇所・使用中のパラメータの削除の確認
// main.js からは installEdit(app) と、タイムライン・メニューの小さなフックを呼ぶだけ
import * as THREE from "three";
import { store, newId } from "./store.js";
import { makeEvaluator, evaluateParams } from "./shared/expr.js";
import { DEFS, esc } from "./commands.js";
import { resolveEntity, findLoops } from "./shared/sketchgeom.js";
import { solveSketch } from "./shared/solver.js";
import { call } from "./kernel.js";

const fmt = (v, d = 3) => (+(+v).toFixed(d)).toString();
const isNum = (s) => typeof s === "number" || /^-?\d+(\.\d+)?$/.test(String(s ?? "").trim());
const AX = ["X", "Y", "Z"];

function solved(f, num) {
  const ents = f.entities || [];
  if (!f.constraints || !f.constraints.length) return ents;
  try { const r = solveSketch(ents, f.constraints, num); return r.ok ? r.entities : ents; } catch { return ents; }
}
// ベクトルがどの軸（X/Y/Z）を向いているか（斜めなら -1）
function axisOf(v) { if (!v) return -1; for (let i = 0; i < 3; i++) if (Math.abs(Math.abs(v[i]) - 1) < 1e-6) return i; return -1; }

// ------------------------------------------------------------------ 大きさ → 元の手順
// 戻り値: [X, Y, Z] それぞれ { fid, path, label, kind } または null
//  path: 手順の中の値の場所（例 ["distance"]・["entities", 0, "w"]・["constraints", 2, "value"]）
export function sizeDrivers(app, mesh) {
  const out = [null, null, null];
  if (!mesh) return out;
  const f = store.feature(mesh.src);
  if (!f || f.suppressed) return out;
  const own = mesh.id === (f.bodyId || `B_${f.id}`);
  if (!own) return out;
  const num = makeEvaluator(store.project.params || []);
  const nm = f.name;
  const put = (i, path, what, fid = f.id, owner = nm) => { if (i >= 0 && !out[i]) out[i] = { fid, path, label: `${owner} の${what}` }; };
  if (f.type === "box") { put(0, ["w"], "幅"); put(1, ["d"], "奥行"); put(2, ["h"], "高さ"); return out; }
  if (f.type === "cylinder") {
    const a = { X: 0, Y: 1, Z: 2 }[f.axis || "Z"];
    put(a, ["h"], "高さ"); for (let i = 0; i < 3; i++) if (i !== a) put(i, ["d"], "直径");
    return out;
  }
  if (f.type === "sphere") { for (let i = 0; i < 3; i++) put(i, ["d"], "直径"); return out; }
  if (f.type === "extrude") {
    const items = Array.isArray(f.items) && f.items.length ? f.items : (f.sketch ? [{ sketch: f.sketch, loops: f.profiles && f.profiles.length ? f.profiles : "all" }] : []);
    const skIds = [...new Set(items.filter((x) => x.sketch).map((x) => x.sketch))];
    // 押し出しの距離（1 つのスケッチで、平面が軸に沿っているとき）
    if (skIds.length === 1 && !items.some((x) => x.face)) {
      const sk = store.feature(skIds[0]);
      const fr = sk && ((app.sketchFrames && app.sketchFrames[sk.id]) || (() => { try { return app.frameOf(sk, num); } catch { return null; } })());
      if (fr) {
        if ((f.extent || "dist") === "dist") put(axisOf(fr.normal), ["distance"], (f.direction === "symmetric" ? "距離（全体）" : "距離"));
        // スケッチの寸法（使っている輪郭の外形と同じ大きさの長方形・円・寸法付きの線）
        let ents, loops;
        try { ents = solved(sk, num); loops = findLoops(ents, num); } catch { loops = []; }
        const used = new Set();
        for (const it of items) {
          if (it.loops === "all" || (it.loops === undefined && it.loop === undefined)) loops.forEach((_, k) => used.add(k));
          else if (Array.isArray(it.loops)) it.loops.forEach((k) => used.add(k));
          else used.add(it.loop);
        }
        const ul = loops.filter((_, k) => used.has(k));
        if (ul.length) {
          const lo = [Math.min(...ul.map((l) => l.bbox.min[0])), Math.min(...ul.map((l) => l.bbox.min[1]))];
          const hi = [Math.max(...ul.map((l) => l.bbox.max[0])), Math.max(...ul.map((l) => l.bbox.max[1]))];
          const span = [hi[0] - lo[0], hi[1] - lo[1]];
          const srcs = new Set(ul.flatMap((l) => l.src));
          const dirs = [fr.xDir, fr.yDir];
          for (let uv = 0; uv < 2; uv++) {
            const wa = axisOf(dirs[uv]); if (wa < 0 || out[wa]) continue;
            const tol = Math.max(1e-6, span[uv] * 1e-6);
            for (const idx of srcs) {
              const raw = sk.entities[idx]; if (!raw) continue;
              let e; try { e = resolveEntity(ents[idx] || raw, num); } catch { continue; }
              if (e.type === "rect" && Math.abs(Math.abs(uv ? e.h : e.w) - span[uv]) < tol) { put(wa, ["entities", idx, uv ? "h" : "w"], `長方形の${uv ? "縦" : "横"}`, sk.id, sk.name); break; }
              if (e.type === "circle" && Math.abs(Math.abs(e.d) - span[uv]) < tol) { put(wa, ["entities", idx, "d"], "円の直径", sk.id, sk.name); break; }
              if (e.type === "line") {
                const dx = Math.abs(e.x2 - e.x1), dy = Math.abs(e.y2 - e.y1);
                const along = uv ? dy : dx, across = uv ? dx : dy;
                const k = (sk.constraints || []).findIndex((c) => c.type === "len" && c.a === raw.id);
                if (k >= 0 && across < 1e-6 && Math.abs(along - span[uv]) < tol) { put(wa, ["constraints", k, "value"], "線の長さ", sk.id, sk.name); break; }
              }
            }
          }
        }
      }
    }
    return out;
  }
  return out;
}

const getAt = (obj, path) => path.reduce((o, k) => (o == null ? o : o[k]), obj);
const setAt = (obj, path, v) => { const last = path[path.length - 1]; getAt(obj, path.slice(0, -1))[last] = v; };

// 大きさを直す。target: 新しい大きさ（mm）、cur: 今の大きさ。成功したら説明の文字列、やめたら null
export async function applySize(app, mesh, axis, target, cur, mn) {
  if (!(target > 0)) { app.toast("大きさは 0 より大きくしてください", true); return null; }
  if (Math.abs(target - cur) < 1e-9) return null;
  const d = sizeDrivers(app, mesh)[axis];
  if (!d) return scaleBody(app, mesh, target / cur, mn, axis);
  const f = store.feature(d.fid);
  const raw = getAt(f, d.path);
  const params = store.project.params || [];
  const num = makeEvaluator(params);
  let v0; try { v0 = num(raw); } catch (e) { app.toast(e.message, true); return null; }
  const sign = v0 < 0 ? -1 : 1;
  // 今の大きさとの差だけ元の値を増やす（あとからプレス/プルなどで厚くしていても合う）
  const nv = Math.abs(v0) + (target - cur);
  if (!(nv > 1e-9)) { app.toast(`${d.label}が 0 以下になってしまいます`, true); return null; }
  const pName = typeof raw === "string" ? raw.trim().replace(/^-\s*/, "") : "";
  const param = pName && params.find((p) => p.name === pName);
  let msg;
  if (param && isNum(param.expr)) {
    // パラメータで決めてある寸法は、パラメータの値を変える（同じパラメータを使うほかの寸法も一緒に変わる）
    const users = paramUsers(param.name);
    if (users.length > 1 && !confirm(`この寸法はパラメータ「${param.name}」で決めてあります。\n「${param.name}」を ${fmt(nv)} に変えると、使っているほかの所（${users.filter((u) => u !== f.name).slice(0, 4).join("、")}）も一緒に変わります。よろしいですか？`)) return null;
    store.commit((p) => { const q = p.params.find((x) => x.name === param.name); q.expr = fmt(nv, 6); }, { silent: true });
    msg = `パラメータ「${param.name}」を ${fmt(nv)} にしました（${d.label}）`;
  } else {
    if (!isNum(raw) && !confirm(`${d.label}は「${raw}」で決めてあります。数値 ${fmt(nv)} に置き換えますか？`)) return null;
    const val = typeof raw === "number" ? +(sign * nv).toFixed(6) : String(+(sign * nv).toFixed(6));
    store.commit((p) => { const x = p.features.find((y) => y.id === f.id); setAt(x, d.path, val); }, { silent: true });
    msg = `${d.label}を ${fmt(nv)} mm にしました`;
  }
  return finish(app, d.fid, msg);
}

async function finish(app, fid, msg) {
  const errs = (await app.rebuild()) || [];
  const e = errs.find((x) => x.featureId === fid) || errs[0];
  if (e) { store.undo(); app.toast(`直せませんでした: ${e.message}`, true); return null; }
  store.touch();
  app.toast(msg);
  return msg;
}

// 元の寸法の手順が無い形は、比率を保って拡大・縮小（尺度）。いちばん小さい角は動かさない
async function scaleBody(app, mesh, k, mn, axis) {
  if (!(k > 0) || !isFinite(k)) return null;
  const why = store.feature(mesh.src)?.type === "import" ? "取り込んだ形なので元の寸法がありません" : "この方向の大きさを決めている寸法が見つかりません";
  if (!confirm(`「${mesh.name}」は${why}。\n${AX[axis]} 方向を合わせるために、縦・横・高さの比率を保ったまま ${fmt(k, 4)} 倍にします。よろしいですか？\n（寸法を 1 方向だけ変えたいときは、タイムラインの元の手順を直してください）`)) return null;
  const c = (mn || [0, 0, 0]).map((v) => String(+v.toFixed(6)));
  let fid;
  store.commit((p) => {
    const at = p.rollback ?? p.features.length;
    const last = p.features[at - 1];
    // 続けて直したときは同じ「尺度」にまとめる
    if (last && last.type === "scale" && last._props && (last.bodies || []).length === 1 && last.bodies[0] === mesh.id && JSON.stringify(last.center) === JSON.stringify(c)) {
      last.factor = String(+(parseFloat(last.factor) * k).toPrecision(10)); fid = last.id; return;
    }
    fid = newId();
    p.features.splice(at, 0, { id: fid, type: "scale", name: store.nameFor("scale"), factor: String(+k.toPrecision(10)), bodies: [mesh.id], center: c, about: "point", _props: true });
    if (p.rollback != null) p.rollback = at + 1;
  }, { silent: true });
  return finish(app, fid, `「${mesh.name}」を ${fmt(k, 4)} 倍にしました（タイムラインの「尺度」で直せます）`);
}

// ------------------------------------------------------------------ パラメータの使用箇所
export function paramUsers(name) {
  const re = new RegExp(`(^|[^A-Za-z0-9_぀-ヿ㐀-鿿ｦ-ﾟ])${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![A-Za-z0-9_぀-ヿ㐀-鿿ｦ-ﾟ])`);
  const hit = (v) => typeof v === "string" && !isNum(v) && re.test(v);
  const deep = (o) => { if (hit(o)) return true; if (o && typeof o === "object") { for (const k of Object.keys(o)) { if (k === "id" || k === "name" || k === "data") continue; if (deep(o[k])) return true; } } return false; };
  const out = store.project.features.filter((f) => deep(f)).map((f) => f.name);
  for (const p of store.project.params || []) if (p.name !== name && hit(p.expr)) out.push(`パラメータ ${p.name}`);
  return out;
}

// ------------------------------------------------------------------ タイムラインの並べ替え
// その手順が使っている（参照している）ほかの手順
function refsOf(f, feats) {
  const s = JSON.stringify({ ...f, id: undefined, name: undefined, data: undefined });
  return feats.filter((g) => g !== f && s.includes(g.id));
}
// 手順 id を、手順 beforeId の前（null なら最後）に動かす。できないときは理由の文字列
export function moveCheck(id, toIndex) {
  const feats = store.project.features;
  const from = feats.findIndex((f) => f.id === id);
  if (from < 0) return "手順が見つかりません";
  const f = feats[from];
  const arr = feats.slice(); arr.splice(from, 1);
  const to = Math.max(0, Math.min(arr.length, toIndex > from ? toIndex - 1 : toIndex));
  arr.splice(to, 0, f);
  const pos = new Map(arr.map((g, i) => [g.id, i]));
  for (const r of refsOf(f, feats)) if (pos.get(r.id) > to) return `「${f.name}」は「${r.name}」を使っているので、「${r.name}」より前には動かせません`;
  for (const g of feats) if (g !== f && refsOf(g, [f]).length && pos.get(g.id) < to) return `「${g.name}」が「${f.name}」を使っているので、「${g.name}」より後ろには動かせません`;
  return null;
}
export async function moveFeature(app, id, toIndex) {
  const why = moveCheck(id, toIndex);
  if (why) { app.toast(why, true); return false; }
  const before = new Set((app.errors || []).map((e) => e.featureId));
  const p0 = store.project;
  const from = p0.features.findIndex((f) => f.id === id);
  if (toIndex === from || toIndex === from + 1) return false;
  store.commit((p) => {
    // ロールバックの印（ここまで表示）も一緒に並べ替えて、印の位置を保つ
    const MARK = {};
    const arr = p.features.slice();
    if (p.rollback != null) arr.splice(p.rollback, 0, MARK);
    const f = p.features[from];
    const fi = arr.indexOf(f);
    const tgt = toIndex < p.features.length ? arr.indexOf(p.features[toIndex]) : arr.length;
    arr.splice(fi, 1);
    arr.splice(tgt > fi ? tgt - 1 : tgt, 0, f);
    const mi = arr.indexOf(MARK);
    p.features = arr.filter((x) => x !== MARK);
    if (p.rollback != null) p.rollback = mi >= p.features.length ? null : mi;
  }, { silent: true });
  const errs = (await app.rebuild()) || [];
  const fresh = errs.filter((e) => !before.has(e.featureId));
  if (fresh.length) {
    store.undo();
    const g = store.feature(fresh[0].featureId);
    app.toast(`並べ替えると「${g ? g.name : "手順"}」が計算できなくなるので、元に戻しました（${fresh[0].message}）`, true);
    return false;
  }
  store.touch();
  const f = store.feature(id);
  app.toast(`「${f.name}」を ${store.project.features.indexOf(f) + 1} 番目に動かしました`);
  return true;
}

// タイムライン項目の右クリック・長押しメニューに足す項目
export function featureMenuItems(app, id) {
  const feats = store.project.features;
  const i = feats.findIndex((f) => f.id === id);
  const items = [];
  if (i > 0) items.push(["◀ 1つ前へ移動", () => moveFeature(app, id, i - 1)]);
  if (i >= 0 && i < feats.length - 1) items.push(["1つ後ろへ移動 ▶", () => moveFeature(app, id, i + 2)]);
  return items;
}

// タイムラインのドラッグで並べ替え（マウス）。iPhone はメニューの「前へ」「後ろへ」
export function bindTimeline(app, el) {
  bindMarker(app, el);
  el.querySelectorAll("[data-f]").forEach((d) => {
    d.addEventListener("pointerdown", (e) => {
      if (e.pointerType === "touch" || e.button !== 0) return;
      const x0 = e.clientX, y0 = e.clientY;
      let ghost = null, mark = null, drop = null;
      const items = () => [...el.querySelectorAll("[data-f]")];
      const move = (ev) => {
        if (!ghost) {
          if (Math.hypot(ev.clientX - x0, ev.clientY - y0) < 6) return;
          ghost = d.cloneNode(true); ghost.className = "tl-item tl-ghost"; document.body.appendChild(ghost);
          mark = document.createElement("div"); mark.className = "tl-drop"; (el.querySelector(".tl-items") || el).appendChild(mark);
          d.classList.add("tl-dragging");
        }
        ghost.style.left = ev.clientX - 14 + "px"; ghost.style.top = ev.clientY - 14 + "px";
        const list = items();
        let k = list.length;
        for (let j = 0; j < list.length; j++) { const r = list[j].getBoundingClientRect(); if (ev.clientX < r.left + r.width / 2) { k = j; break; } }
        drop = k;
        const ref = list[Math.min(k, list.length - 1)].getBoundingClientRect(), er = mark.parentElement.getBoundingClientRect();
        const x = k < list.length ? ref.left - 3 : ref.right + 1;
        mark.style.left = x - er.left + "px";
        const bad = moveCheck(d.dataset.f, k);
        mark.classList.toggle("bad", !!bad); ghost.title = bad || "";
      };
      const up = () => {
        removeEventListener("pointermove", move); removeEventListener("pointerup", up);
        if (!ghost) return;
        ghost.remove(); mark.remove(); d.classList.remove("tl-dragging");
        app.tlDragged = performance.now();
        if (drop != null) moveFeature(app, d.dataset.f, drop);
      };
      addEventListener("pointermove", move); addEventListener("pointerup", up);
    });
  });
}

// 「ここまで表示」の印（ロールバック）をドラッグで動かす（Fusion と同じ）
function bindMarker(app, el) {
  el.querySelectorAll(".tl-marker").forEach((mk) => {
    mk.title = "ドラッグで、ここまでの履歴だけを表示（途中に手順を追加できます）";
    mk.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault(); e.stopPropagation();
      let k = null;
      const move = (ev) => {
        const list = [...el.querySelectorAll("[data-f]")];
        k = list.length;
        for (let j = 0; j < list.length; j++) { const r = list[j].getBoundingClientRect(); if (ev.clientX < r.left + r.width / 2) { k = j; break; } }
        list.forEach((d, j) => d.classList.toggle("rolled", j >= k));
      };
      const up = () => {
        removeEventListener("pointermove", move); removeEventListener("pointerup", up);
        if (k == null) return;
        const n = store.project.features.length, r = k >= n ? null : k;
        if (r !== (store.project.rollback ?? null)) store.commit((p) => { p.rollback = r; });
      };
      addEventListener("pointermove", move); addEventListener("pointerup", up);
    });
  });
}

// ------------------------------------------------------------------ 2 本指ひねりで回転（iPhone）
// 2 本の指の角度の変化だけ、上下の軸（Z）のまわりに視点を回す。ピンチ（拡大）と移動はそのまま
export function bindTwist(app) {
  const v = app.viewer, cv = v.canvas;
  const pts = new Map();
  let last = null, acc = 0, on = false;
  const ang = () => { const [a, b] = [...pts.values()]; return Math.atan2(b.y - a.y, b.x - a.x); };
  cv.addEventListener("pointerdown", (e) => {
    if (e.pointerType !== "touch") return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 2) { last = ang(); acc = 0; on = false; }
  });
  cv.addEventListener("pointermove", (e) => {
    if (e.pointerType !== "touch" || !pts.has(e.pointerId)) return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size !== 2 || last == null) return;
    const a = ang();
    let da = a - last; if (da > Math.PI) da -= 2 * Math.PI; if (da < -Math.PI) da += 2 * Math.PI;
    last = a;
    if (app.mode === "sketch") return; // スケッチ中は平面を正面から見たままにする
    acc += da;
    // ピンチのときの小さなぶれでは回さない（10° を超えたら回し始める）
    if (!on && Math.abs(acc) < 0.17) return;
    if (!on) { on = true; da = acc; }
    rotateAboutZ(v, da);
  });
  const end = (e) => { if (!pts.delete(e.pointerId)) return; if (pts.size < 2) { last = null; on = false; } };
  cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
}
// 注視点を通る上下の軸（Z）のまわりに、カメラの位置と上向きを一緒に回す（真上から見ていても回る）
export function rotateAboutZ(v, da) {
  const c = v.controls, cam = v.camera, t = c.target;
  // 上から見て指を時計回りにひねると、モデルも時計回りに回って見えるように（カメラは逆向きに回す）
  const s = cam.position.z - t.z >= 0 ? 1 : -1;
  const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), da * s);
  const off = cam.position.clone().sub(t).applyQuaternion(q);
  cam.position.copy(t).add(off);
  cam.up.applyQuaternion(q);
  cam.lookAt(t);
  c.update();
  v.dirty = true;
  v.onCameraChange && v.onCameraChange();
}


// ------------------------------------------------------------------ パラメータとモデルの寸法（Fusion の「パラメータを変更」）
// 上: 自分で作るパラメータ（名前・式・使用箇所）。下: モデルのすべての寸法（手順ごと）を一覧で直せる。
// 寸法の欄にパラメータ名を書けばつながり、「P」ボタンで今の値からパラメータを作ってつなげる
export function modelDims(features) {
  const rows = [];
  for (const f of features) {
    if (f.type === "sketch") {
      const cnt = {};
      (f.entities || []).forEach((e, i) => {
        const k = e.type; cnt[k] = (cnt[k] || 0) + 1;
        const nm = { rect: "長方形", circle: "円" }[k];
        if (k === "rect") { rows.push({ fid: f.id, path: ["entities", i, "w"], label: `${nm}${cnt[k]} の横`, abs: true }); rows.push({ fid: f.id, path: ["entities", i, "h"], label: `${nm}${cnt[k]} の縦`, abs: true }); }
        if (k === "circle") rows.push({ fid: f.id, path: ["entities", i, "d"], label: `${nm}${cnt[k]} の直径`, abs: true });
      });
      (f.constraints || []).forEach((c, i) => {
        const lab = { len: "線の長さ", dist: "距離", pldist: "点と線の距離", ppdist: "2 点の距離", ang: "角度°" }[c.type];
        if (lab) rows.push({ fid: f.id, path: ["constraints", i, "value"], label: lab });
      });
      if (f.plane && f.plane.offset !== undefined && f.plane.offset !== "0" && f.plane.offset !== 0) rows.push({ fid: f.id, path: ["plane", "offset"], label: "平面のオフセット" });
      continue;
    }
    const def = DEFS[f.type];
    if (!def) continue;
    let fields = [];
    try { fields = def.fields(f); } catch { /* */ }
    for (const fd of fields) if (fd.type === "expr" && f[fd.key] !== undefined) rows.push({ fid: f.id, path: [fd.key], label: fd.label });
  }
  return rows;
}

export function openParamsDialog(app) {
  const params = JSON.parse(JSON.stringify(store.project.params || []));
  const feats = JSON.parse(JSON.stringify(store.project.features));
  const dims = modelDims(feats);
  const fById = new Map(feats.map((f) => [f.id, f]));
  let filter = "";
  const usersOf = (name) => {
    const saved = store.project; // 使用箇所は編集中の内容で数える
    try { store.project = { ...saved, features: feats, params }; return paramUsers(name); } finally { store.project = saved; }
  };
  const render = () => {
    const ev = evaluateParams(params);
    const num = makeEvaluator(params);
    const val = (x) => { try { return { v: +num(x).toFixed(4) }; } catch (e) { return { err: e.message }; } };
    const prow = ev.map((p, i) => {
      const us = usersOf(p.name);
      return `<tr><td><input data-i="${i}" data-k="name" value="${esc(p.name)}"/></td><td><input data-i="${i}" data-k="expr" value="${esc(p.expr)}"/></td><td class="num ${p.error ? "err" : ""}" title="${esc(p.error || "")}">${p.error ? "エラー" : +p.value.toFixed(4)}</td><td><input data-i="${i}" data-k="comment" value="${esc(p.comment || "")}"/></td><td class="ed-use" title="${esc(us.join("\n"))}">${us.length ? `${us.length} か所` : "未使用"}</td><td><button class="btn" data-del="${i}" style="padding:0 6px" title="削除">×</button></td></tr>`;
    }).join("");
    let last = null;
    const q = filter.trim();
    const drows = dims.map((d, k) => {
      const f = fById.get(d.fid); if (!f) return "";
      if (q && !(f.name.includes(q) || d.label.includes(q) || String(getAt(f, d.path)).includes(q))) return "";
      const raw = getAt(f, d.path);
      const shown = d.abs && typeof raw === "number" ? Math.abs(raw) : raw;
      const r = val(raw);
      const head = f.id !== last ? `<tr class="ed-fh"><td colspan="4">${esc(f.name)}${f.suppressed ? "（抑制中）" : ""}</td></tr>` : "";
      last = f.id;
      return `${head}<tr><td class="ed-dl">${esc(d.label)}</td><td><input data-d="${k}" value="${esc(String(shown ?? ""))}"/></td><td class="num ${r.err ? "err" : ""}" title="${esc(r.err || "")}">${r.err ? "エラー" : d.abs ? Math.abs(r.v) : r.v}</td><td>${isNum(raw) ? `<button class="btn ed-mk" data-mk="${k}" title="この寸法をパラメータにする（同じ寸法をまとめて変えられる）">P</button>` : ""}</td></tr>`;
    }).join("");
    return `<div class="full ed-sec">パラメータ（自分で決める名前つきの数）</div>
      <div class="full ed-scroll"><table class="grid ed-pt"><tr><th>名前</th><th>式 / 値</th><th class="num">値</th><th>コメント</th><th>使用</th><th></th></tr>${prow}</table></div>
      <div class="full"><button class="btn" id="p-add">＋ パラメータを追加</button></div>
      <div class="full ed-sec">モデルの寸法（手順ごと）<input id="ed-q" placeholder="絞り込み（手順の名前・項目）" value="${esc(filter)}"/></div>
      <div class="full ed-scroll ed-dims"><table class="grid">${drows || `<tr><td>${dims.length ? "当てはまる寸法がありません" : "まだ寸法のある手順がありません"}</td></tr>`}</table></div>
      <div class="dlg-note">寸法の欄には数値のほか、パラメータ名や式（例: 幅/2 - 厚さ）を書けます。「P」でその寸法をパラメータにすると、同じパラメータを書いたほかの寸法と一緒に変えられます。OK で全体を作り直します。</div>`;
  };
  const el = app.panel("パラメータと寸法", render(), async () => {
    const names = params.map((p) => p.name.trim());
    if (names.some((n) => !/^[A-Za-z_぀-ヿ㐀-鿿][A-Za-z0-9_぀-ヿ㐀-鿿]*$/.test(n))) { app.toast("名前は文字で始めてください（記号・空白不可）", true); return false; }
    if (new Set(names).size !== names.length) { app.toast("同じ名前が重複しています", true); return false; }
    const bad = evaluateParams(params).find((p) => p.error);
    if (bad) { app.toast(`パラメータ「${bad.name}」: ${bad.error}`, true); return false; }
    const before = new Set((app.errors || []).map((e) => e.featureId));
    store.commit((p) => {
      p.params = params.map((q) => ({ name: q.name.trim(), expr: q.expr, comment: q.comment }));
      for (const f of p.features) { const g = fById.get(f.id); if (g) Object.assign(f, g); }
    }, { silent: true });
    const errs = (await app.rebuild()) || [];
    store.touch();
    const fresh = errs.filter((e) => !before.has(e.featureId));
    if (fresh.length) app.toast(`⚠ ${fresh.map((e) => `${store.feature(e.featureId)?.name || ""}: ${e.message}`).join(" / ")}（Ctrl+Z で元に戻せます）`, true);
    else app.toast("パラメータと寸法を反映しました");
  }, { wide: true, cls: "ed-params" });
  const body = el.querySelector(".dlg-body");
  const rerender = (focusSel) => {
    const st = body.querySelector(".ed-dims")?.scrollTop || 0;
    body.innerHTML = render(); bind();
    const dd = body.querySelector(".ed-dims"); if (dd) dd.scrollTop = st;
    if (focusSel) { const x = body.querySelector(focusSel); if (x) { x.focus(); if (x.setSelectionRange) x.setSelectionRange(x.value.length, x.value.length); } }
  };
  const bind = () => {
    body.querySelectorAll("input").forEach((i) => i.addEventListener("keydown", (e) => e.stopPropagation()));
    body.querySelectorAll("[data-k]").forEach((i) => i.addEventListener("change", () => { params[+i.dataset.i][i.dataset.k] = i.value; rerender(); }));
    body.querySelectorAll("[data-d]").forEach((i) => i.addEventListener("change", () => {
      const d = dims[+i.dataset.d], f = fById.get(d.fid), raw = getAt(f, d.path);
      let v = i.value.trim(); if (v === "") { rerender(); return; }
      if (isNum(v)) { const n = parseFloat(v); v = typeof raw === "number" || d.path[0] === "entities" ? (d.abs && raw < 0 ? -n : n) : String(n); }
      else if (d.abs && typeof raw === "number" && raw < 0) v = `-(${v})`;
      setAt(f, d.path, v); rerender();
    }));
    body.querySelectorAll("[data-del]").forEach((b) => (b.onclick = () => {
      const p = params[+b.dataset.del]; const us = usersOf(p.name);
      if (us.length && !confirm(`パラメータ「${p.name}」は ${us.join("、")} で使われています。削除すると、その寸法は今の値（数値）に置き換えます。よろしいですか？`)) return;
      // 使っている寸法は今の値に置き換えてから消す（計算できなくならないように）
      if (us.length) { const num = makeEvaluator(params); for (const d of dims) { const f = fById.get(d.fid), raw = getAt(f, d.path); if (typeof raw === "string" && !isNum(raw) && new RegExp(`(^|[^\\p{L}\\p{N}_])${p.name}(?![\\p{L}\\p{N}_])`, "u").test(raw)) { try { const n = +num(raw).toFixed(6); setAt(f, d.path, typeof getAt(f, d.path) === "number" || d.path[0] === "entities" ? n : String(n)); } catch { /* */ } } } for (const q of params) if (q !== p && new RegExp(`(^|[^\\p{L}\\p{N}_])${p.name}(?![\\p{L}\\p{N}_])`, "u").test(q.expr)) { try { q.expr = String(+num(q.expr).toFixed(6)); } catch { /* */ } } }
      params.splice(+b.dataset.del, 1); rerender();
    }));
    body.querySelectorAll("[data-mk]").forEach((b) => (b.onclick = () => {
      const d = dims[+b.dataset.mk], f = fById.get(d.fid), raw = getAt(f, d.path);
      const base = (f.name + "_" + d.label.replace(/[^\p{L}\p{N}_]/gu, "")).replace(/^[^\p{L}_]+/u, "");
      let nm = base, k = 2; while (params.some((p) => p.name === nm)) nm = base + k++;
      const n = prompt("パラメータの名前（文字で始める・空白なし）", nm); if (!n) return;
      if (!/^[A-Za-z_぀-ヿ㐀-鿿][A-Za-z0-9_぀-ヿ㐀-鿿]*$/.test(n.trim())) { app.toast("名前は文字で始めてください（記号・空白不可）", true); return; }
      if (params.some((p) => p.name === n.trim())) { app.toast("同じ名前のパラメータがあります", true); return; }
      params.push({ name: n.trim(), expr: String(Math.abs(+raw)), comment: `${f.name} の${d.label}` });
      setAt(f, d.path, typeof raw === "number" && raw < 0 ? `-${n.trim()}` : n.trim());
      rerender();
    }));
    body.querySelector("#p-add").onclick = () => {
      let k = params.length + 1; while (params.some((p) => p.name === `P${k}`)) k++;
      params.push({ name: `P${k}`, expr: "100", comment: "" });
      rerender(`[data-i="${params.length - 1}"][data-k="name"]`);
    };
    const qi = body.querySelector("#ed-q");
    qi.addEventListener("input", () => { filter = qi.value; const pos = qi.selectionStart; rerender("#ed-q"); const x = body.querySelector("#ed-q"); x.setSelectionRange(pos, pos); });
  };
  bind();
  return el;
}

// 3D 画面の右クリック・長押しメニューに足す項目
export function contextItems(app, sel) {
  const items = [];
  const face = sel.find((x) => x.kind === "face");
  if (face && face.normal) items.push(["プレス/プル（この面を押し引き）", () => { app.preselect = [face]; app.dialog.open("presspull"); app.preselect = null; }]);
  const bid = sel[0]?.bodyId;
  const m = bid && app.meshes.find((x) => x.id === bid);
  const f = m && store.feature(m.src);
  if (f) {
    items.push([`元の手順を編集（${f.name}）`, () => app.editFeature(f.id)]);
    const sk = f.type === "extrude" && (f.sketch || (f.items || []).find((x) => x.sketch)?.sketch);
    if (sk && store.feature(sk)) items.push([`スケッチの寸法を直す（${store.feature(sk).name}）`, () => app.editFeature(sk)]);
  }
  return items;
}

// ------------------------------------------------------------------ 道具バーが画面に収まらないとき（パソコン）
// まず道具を少し詰めて並べ、それでも右端が切れるときは、使う回数の少ない道具（ほかのタブにもあるもの）から
// 「その他」にまとめる。スケッチの終了・押し出し・寸法・AI に頼む・話す などは最後まで残す
const HIDE_ORDER = ["import", "interference", "section", "loft", "align", "cpattern", "combine", "split", "shell", "revolve", "joint", "pattern", "mirror", "chamfer", "params", "measure", "sphere", "component",
  "polygon", "explode", "smirror", "rectc", "point", "project", "c_fix", "c_eq", "c_perp", "c_par", "construction", "offset", "trim", "sfillet", "arc"];
const KEEP = new Set(["finish", "extrude", "c_dim", "sketch", "cmdline", "voice", "select", "line", "rect", "circle", "box", "cylinder", "hole", "presspull", "fillet", "move", "plane"]);
export function fitToolbar(app) {
  const el = document.getElementById("tools");
  const root = document.documentElement;
  if (!el) return;
  // 前に「その他」へ外した道具があるときは、道具バーを作り直してから収め直す
  if (!el.classList.contains("m-arranged") && el.querySelector(".ed-more") && !app._tbRetry) { app._tbRetry = true; try { app.refreshTools(); } finally { app._tbRetry = false; } return; }
  el.querySelectorAll(".ed-more").forEach((x) => x.remove());
  el.querySelectorAll(".ed-hid").forEach((x) => x.classList.remove("ed-hid"));
  root.classList.remove("tb-compact");
  if (el.classList.contains("m-arranged")) return;
  const over = () => el.scrollWidth > el.clientWidth + 1;
  if (!over()) return;
  root.classList.add("tb-compact");
  if (!over()) return;
  let ids = []; try { ids = app.toolDefs().flatMap(([g, items]) => items.map((x) => [x[0], g])); } catch { /* */ }
  const btns = [...el.querySelectorAll(":scope > .tgroup .tool")];
  if (btns.length !== ids.length) { if (!app._tbRetry) { app._tbRetry = true; try { app.refreshTools(); } finally { app._tbRetry = false; } } return; } // 前に外した道具があるときは作り直す
  btns.forEach((b, i) => { b.dataset.tid = ids[i][0]; b.dataset.tg = ids[i][1]; });
  const more = document.createElement("div"); more.className = "tgroup ed-more";
  more.innerHTML = `<div class="items"><button class="tool" title="入りきらない道具"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg><span>その他</span></button></div><div class="glabel">&nbsp;</div>`;
  el.appendChild(more);
  const order = [...HIDE_ORDER.map((id) => btns.find((b) => b.dataset.tid === id)).filter(Boolean), ...btns.slice().reverse().filter((b) => !KEEP.has(b.dataset.tid))];
  const hidden = [];
  for (const b of order) {
    if (!over()) break;
    if (b.classList.contains("ed-hid")) continue;
    b.classList.add("ed-hid"); hidden.push(b);
    const g = b.closest(".tgroup"); if ([...g.querySelectorAll(".tool")].every((x) => x.classList.contains("ed-hid"))) g.classList.add("ed-hid");
  }
  if (!hidden.length) { more.remove(); return; }
  hidden.sort((x, y) => btns.indexOf(x) - btns.indexOf(y));
  // 入りきらない道具はバーから外す（メニューから押す。押す働きはそのまま）
  for (const b of hidden) b.remove();
  el.querySelectorAll(".tgroup.ed-hid").forEach((g) => g.remove());
  more.querySelector("button").onclick = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    app.menu({ clientX: r.right - 200, clientY: r.bottom + 2 }, hidden.map((b) => [`${b.dataset.tg ? b.dataset.tg + "：" : ""}${(b.querySelector("span") || b).textContent.trim()}`, () => b.click()]));
  };
}

// ------------------------------------------------------------------ 複数の板をまとめて伸縮（キャビネットの幅 1800 → 1500 など）
// 選んだ板全体の外形を、ある方向にだけ伸び縮みさせる。板厚は変えない:
//  ・その方向に薄い板（側板・仕切り）は動かすだけ（端の板は端に、途中の板は割合の位置に）
//  ・その方向に長い板（天板・底板・棚板・背板）は、端の板にそろえて長さを変える
export function planResize(list, axis, target) {
  const MN = Math.min(...list.map((b) => b.lo[axis])), MX = Math.max(...list.map((b) => b.hi[axis]));
  const T = MX - MN, d = target - T, tol = 0.01;
  const thinMax = Math.min(100, 0.15 * T);
  const map = new Map(); // 元の座標 → 新しい座標（薄い板の面）
  const plan = list.map((b) => ({ id: b.id, lo: b.lo[axis], hi: b.hi[axis], size: b.hi[axis] - b.lo[axis] }));
  for (const b of plan) {
    b.thin = b.size <= thinMax;
    if (!b.thin) continue;
    let shift;
    if (b.lo - MN < tol) shift = 0;
    else if (MX - b.hi < tol) shift = d;
    else shift = d * ((b.lo + b.hi) / 2 - MN) / T;
    b.nlo = b.lo + shift; b.nhi = b.hi + shift;
    map.set(+b.lo.toFixed(2), b.nlo); map.set(+b.hi.toFixed(2), b.nhi);
  }
  const zone = Math.max(0, ...plan.filter((b) => b.thin).map((b) => b.size)) + tol;
  const g = (x) => {
    const k = +x.toFixed(2); if (map.has(k)) return map.get(k);
    if (x - MN <= zone) return x;
    if (MX - x <= zone) return x + d;
    return MN + (x - MN) * (T + d) / T;
  };
  for (const b of plan) if (!b.thin) { b.nlo = g(b.lo); b.nhi = g(b.hi); }
  return plan.map((b) => ({ ...b, dLo: b.nlo - b.lo, dSize: (b.nhi - b.nlo) - b.size }));
}

export async function bulkResize(app, ids, axis, target) {
  if (!(target > 0)) { app.toast("大きさは 0 より大きくしてください", true); return null; }
  const r = await call("measure", { ids });
  const list = r.list.map((b) => ({ id: b.id, lo: b.bounds[0], hi: b.bounds[1] }));
  const plan = planResize(list, axis, target);
  if (plan.some((b) => b.nhi - b.nlo <= 1e-6)) { app.toast("小さくしすぎて、なくなってしまう板があります", true); return null; }
  const params = store.project.params || [];
  const num = makeEvaluator(params);
  const exprs = [], skipped = [];
  const edits = []; // { fid, path, val } / { box, dLo }
  const moves = [];
  for (const b of plan) {
    const m = app.meshes.find((x) => x.id === b.id);
    const f = m && store.feature(m.src);
    const ownBox = f && f.type === "box" && m.id === (f.bodyId || `B_${f.id}`);
    if (Math.abs(b.dSize) > 1e-9) {
      const dr = sizeDrivers(app, m)[axis];
      if (!dr) { skipped.push(m ? m.name : b.id); continue; }
      const raw = getAt(store.feature(dr.fid), dr.path);
      let v0; try { v0 = num(raw); } catch { skipped.push(m.name); continue; }
      if (!isNum(raw)) exprs.push(`${m.name}（${dr.label} = ${raw}）`);
      const sign = v0 < 0 ? -1 : 1, nv = Math.abs(v0) + b.dSize;
      edits.push({ fid: dr.fid, path: dr.path, val: typeof raw === "number" ? +(sign * nv).toFixed(6) : String(+(sign * nv).toFixed(6)) });
    }
    if (Math.abs(b.dLo) > 1e-9) {
      if (ownBox && isNum((f.position || [])[axis] ?? "0")) edits.push({ fid: f.id, path: ["position", axis], val: String(+(num((f.position || ["0", "0", "0"])[axis]) + b.dLo).toFixed(6)) });
      else moves.push(b);
    }
  }
  if (exprs.length && !confirm(`次の寸法は式・パラメータで決めてあります:\n${exprs.slice(0, 6).join("\n")}\n\nパラメータで組んである場合は、パラメータの値を変えるほうが確実です（ツールバーの「パラメータ」）。\nここでは数値に置き換えて伸縮します。よろしいですか？`)) return null;
  const before = new Set((app.errors || []).map((e) => e.featureId));
  store.commit((p) => {
    for (const e of edits) { const x = p.features.find((y) => y.id === e.fid); if (e.path[0] === "position") { x.position = [...(x.position || ["0", "0", "0"])]; } setAt(x, e.path, e.val); }
  }, { silent: true });
  let errs = (await app.rebuild()) || [];
  // 手順の向きによっては伸びた側がずれるので、測り直して「移動」で合わせる（同じ取り消し 1 回で戻る）
  const r2 = await call("measure", { ids: plan.map((b) => b.id) });
  const byShift = new Map();
  for (const b of plan) {
    const now = r2.list.find((x) => x.id === b.id); if (!now) continue;
    const dv = b.nlo - now.bounds[0][axis];
    if (Math.abs(dv) < 1e-6) continue;
    const k = dv.toFixed(6); if (!byShift.has(k)) byShift.set(k, []); byShift.get(k).push(b.id);
  }
  if (byShift.size) {
    const p = store.project;
    for (const [k, bodies] of byShift) {
      const t = ["0", "0", "0"]; t[axis] = String(+k);
      const at = p.rollback ?? p.features.length;
      p.features.splice(at, 0, { id: newId(), type: "move", name: store.nameFor("move"), bodies, translate: t, rotAxis: "Z", angle: "0", center: ["0", "0", "0"], copy: false });
      if (p.rollback != null) p.rollback = at + 1;
    }
    errs = (await app.rebuild()) || [];
  }
  const fresh = errs.filter((e) => !before.has(e.featureId));
  if (fresh.length) { store.undo(); app.toast(`伸縮できませんでした: ${fresh[0].message}`, true); return null; }
  store.touch();
  const msg = `${plan.length} 個のボディの${["幅（X）", "奥行（Y）", "高さ（Z）"][axis]}を ${fmt(target)} mm に伸縮しました（板厚はそのまま）${skipped.length ? `。寸法の手順が見つからず長さを変えられなかったもの: ${skipped.join("、")}` : ""}`;
  app.toast(msg, !!skipped.length);
  return msg;
}

export function installEdit(app) {
  const ed = {
    sizeDrivers: (m) => sizeDrivers(app, m),
    applySize: (m, axis, target, cur, mn) => applySize(app, m, axis, target, cur, mn),
    bulkResize: (ids, axis, target) => bulkResize(app, ids, axis, target),
    moveFeature: (id, to) => moveFeature(app, id, to),
    moveCheck, paramUsers,
    featureMenuItems: (id) => featureMenuItems(app, id),
    bindTimeline: (el) => bindTimeline(app, el),
    contextItems: (sel) => contextItems(app, sel),
  };
  app.edit = ed;
  app.openParams = () => openParamsDialog(app); // パラメータ画面を「パラメータと寸法」に
  try { bindTwist(app); } catch (e) { console.warn(e); }
  // 道具バー: 作り直すたび・画面の大きさが変わるたびに収める（スマホの並べ替えの後で）
  const rt = app.refreshTools.bind(app);
  app.refreshTools = (...a) => { const r = rt(...a); setTimeout(() => fitToolbar(app), 0); return r; };
  let ft = 0; addEventListener("resize", () => { clearTimeout(ft); ft = setTimeout(() => app.refreshTools(), 120); });
  setTimeout(() => app.refreshTools(), 0);
  try { document.fonts && document.fonts.ready.then(() => app.refreshTools()); } catch { /* */ }
  return ed;
}
