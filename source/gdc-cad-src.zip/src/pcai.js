// 自分のパソコンの AI（OpenAI 互換の /v1/chat/completions）につなぐ
// Ollama・LM Studio・llama.cpp・vLLM・自作のサーバーなど、OpenAI 互換で受けるものなら何でもよい。
// 大きいモデル向けなので、Claude と同じ詳しい説明（SYSTEM）と JSON スキーマで答えさせる。
import { SYSTEM, SCHEMA, buildUserMessage } from "./ai.js";
import { extractCommands } from "./pasteai.js";

const ls = (k, d = "") => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } };
const ss = (k, v) => { try { if (v) localStorage.setItem(k, v); else localStorage.removeItem(k); } catch { /* */ } };

export function pcConfig() {
  return { url: ls("gdc-pc-url"), model: ls("gdc-pc-model"), header: ls("gdc-pc-header") };
}
export function setPcConfig({ url, model, header }) {
  if (url !== undefined) ss("gdc-pc-url", String(url).trim());
  if (model !== undefined) ss("gdc-pc-model", String(model).trim());
  if (header !== undefined) ss("gdc-pc-header", String(header).trim());
}

// 入力された URL → …/v1（http://localhost:11434 でも …/v1/ でも …/v1/chat/completions でもよい）
export function baseUrl(u) {
  let s = String(u || "").trim();
  if (!s) return "";
  if (!/^https?:\/\//i.test(s)) s = (/^(localhost|127\.|\[::1\])/.test(s) ? "http://" : "https://") + s;
  s = s.replace(/\/+$/, "").replace(/\/(chat\/completions|models)$/, "").replace(/\/+$/, "");
  if (!/\/v\d+$/.test(s)) s += "/v1";
  return s;
}
// 任意のヘッダー「名前: 値」（例 Authorization: Bearer xxx）。空ならなし
export function headersOf(h) {
  const out = { "Content-Type": "application/json" };
  for (const line of String(h || "").split(/\n/)) { const m = line.match(/^\s*([A-Za-z0-9_-]+)\s*:\s*(.+?)\s*$/); if (m) out[m[1]] = m[2]; }
  return out;
}
// テスト用: window.__pageHttps = true で「https のページ」として扱う
const pageIsHttps = () => (typeof window !== "undefined" && window.__pageHttps) || (typeof location !== "undefined" && location.protocol === "https:");
const isLocalHost = (h) => /^(localhost|127\.\d+\.\d+\.\d+|\[::1\])$/i.test(h);
// 家・会社の中の住所（192.168.x.x など）。Chrome は https のページからでも、許可を聞いたうえでつなげることがある
const isPrivateHost = (h) => /^(10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.\d+\.\d+|[^.]+\.local)$/i.test(h);

// つながらない理由を見分けて、日本語で（kind: mixed / unreachable / cors / auth / notfound / model / http / timeout / format）
export class PcError extends Error { constructor(kind, message) { super(message); this.kind = kind; } }
function mixedCheck(url) {
  let u; try { u = new URL(url); } catch { throw new PcError("url", "URL の書き方が正しくありません（例: https://my-pc.tailxxxx.ts.net または http://localhost:11434）"); }
  if (pageIsHttps() && u.protocol === "http:" && !isLocalHost(u.hostname) && !isPrivateHost(u.hostname)) {
    throw new PcError("mixed", `このページは https なので、http の住所（${u.host}）にはブラウザがつなぎません（混在コンテンツ）。パソコン側を https にしてください（おすすめ: Tailscale Serve。手順は「iPhone から自分のパソコンの AI を使う.txt」）。`);
  }
  return u;
}
async function why(url, e) {
  if (e && e.name === "AbortError") return new PcError("timeout", "パソコンの AI から返事がありません（時間切れ）。パソコンが起動しているか、AI が読み込み中でないか確認してください。");
  const u = new URL(url);
  // 届くかどうかを、中身を読まない問い合わせ（no-cors）で確かめる → 届くのに読めないなら CORS
  let reach = false;
  try { await fetch(u.origin + "/", { mode: "no-cors", cache: "no-store" }); reach = true; } catch { /* */ }
  if (reach) return new PcError("cors", `パソコンの AI（${u.host}）には届きましたが、ブラウザからの利用が許可されていません（CORS）。Ollama は OLLAMA_ORIGINS、LM Studio は「CORS を有効にする」を設定してください（手順書を参照）。`);
  if (pageIsHttps() && u.protocol === "http:") return new PcError("mixed", `このページは https なので、http の住所（${u.host}）にはつなげないことがあります（Safari では localhost でも止まります）。Tailscale Serve などで https にしてください。`);
  return new PcError("unreachable", `パソコンの AI（${u.host}）に届きません。パソコンが起動しているか、AI のサーバーが動いているか、URL（ポート番号まで）が正しいか、同じ Tailscale につながっているかを確認してください。`);
}
async function req(url, opts = {}, ms = 15000, signal = null) {
  mixedCheck(url);
  const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), ms);
  // 「やめる」・電波が切れたとき（呼び出し側の signal）も止める
  if (signal) { if (signal.aborted) ac.abort(); else signal.addEventListener("abort", () => ac.abort(), { once: true }); }
  let r;
  // Chrome の「ローカル ネットワークへのアクセス」: 家の中の住所へは、その旨を伝えて許可を求める（ほかのブラウザは無視する）
  const h = new URL(url).hostname, space = isLocalHost(h) ? { targetAddressSpace: "loopback" } : isPrivateHost(h) ? { targetAddressSpace: "local" } : {};
  try { r = await fetch(url, { ...opts, ...(new URL(url).protocol === "http:" ? space : {}), signal: ac.signal }); } catch (e) { clearTimeout(tm); if (signal && signal.aborted) throw (signal.reason instanceof Error ? signal.reason : new Error("AI への依頼をやめました")); throw await why(url, e); }
  clearTimeout(tm);
  return r;
}
async function httpError(r, what) {
  let body = ""; try { body = (await r.text()).slice(0, 300); } catch { /* */ }
  if (r.status === 401 || r.status === 403) return new PcError("auth", `パソコンの AI に断られました（${r.status}）。キーが要る設定なら「ヘッダー」に Authorization: Bearer … を入れてください。`);
  if (r.status === 404) return new PcError("notfound", `${what}が見つかりません（404）。URL が正しいか（OpenAI 互換の /v1 で受けているか）確認してください。${body ? "（" + body.replace(/\s+/g, " ").slice(0, 120) + "）" : ""}`);
  return new PcError("http", `パソコンの AI のエラー（${r.status}）: ${body.replace(/\s+/g, " ").slice(0, 160)}`);
}

// モデルの一覧（/v1/models）
export async function listModels(cfg = pcConfig()) {
  const base = baseUrl(cfg.url); if (!base) throw new PcError("url", "URL を入れてください（例: https://my-pc.tailxxxx.ts.net）");
  const r = await req(base + "/models", { headers: headersOf(cfg.header) });
  if (!r.ok) throw await httpError(r, "モデルの一覧");
  let j; try { j = await r.json(); } catch { throw new PcError("format", "モデルの一覧を読み取れませんでした（OpenAI 互換の形ではないようです）"); }
  const arr = Array.isArray(j) ? j : j.data || j.models || [];
  return arr.map((m) => (typeof m === "string" ? m : m.id || m.name || m.model)).filter(Boolean);
}

// 接続テスト: 一覧 → モデルがあるか → 短い頼みで返事が来るか
export async function testConnection(cfg = pcConfig()) {
  let models = [];
  try { models = await listModels(cfg); } catch (e) { if (!(e instanceof PcError) || e.kind !== "notfound") throw e; }
  if (cfg.model && models.length && !models.includes(cfg.model)) throw new PcError("model", `モデル「${cfg.model}」がパソコンの AI にありません。一覧から選んでください（${models.slice(0, 8).join("、")}）`);
  const model = cfg.model || models[0];
  if (!model) throw new PcError("model", "モデル名を入れてください（パソコンの AI に入っているモデルの名前）");
  const t0 = Date.now();
  const r = await req(baseUrl(cfg.url) + "/chat/completions", { method: "POST", headers: headersOf(cfg.header), body: JSON.stringify({ model, messages: [{ role: "user", content: "「はい」とだけ答えてください" }], max_tokens: 20, temperature: 0, stream: false }) }, 60000);
  if (!r.ok) { const e = await httpError(r, `モデル「${model}」`); if (e.kind === "notfound") e.kind = "model"; throw e; }
  let j; try { j = await r.json(); } catch { throw new PcError("format", "返事を読み取れませんでした（OpenAI 互換の形ではないようです）"); }
  const text = j.choices?.[0]?.message?.content ?? j.choices?.[0]?.text ?? "";
  return { ok: true, models, model, ms: Date.now() - t0, reply: String(text).slice(0, 60) };
}

// 返事の形は、使えるものを順に試す（json_schema → json_object → 指定なし）。一度通った形は覚えておく
let fmtMode = null;
const FORMATS = [
  ["schema", { type: "json_schema", json_schema: { name: "cad_commands", strict: true, schema: SCHEMA } }],
  ["object", { type: "json_object" }],
  ["none", null],
];
export async function askPC({ instruction, context, retry, results, history = [], cfg = pcConfig(), signal = null }) {
  const base = baseUrl(cfg.url);
  if (!base) throw new PcError("url", "⚙ 設定で、パソコンの AI の URL を入れてください");
  if (!cfg.model) throw new PcError("model", "⚙ 設定で、パソコンの AI のモデルを選んでください（「一覧」で選べます）");
  const user = buildUserMessage({ instruction, context, retry, results }) + "\n\n答えは JSON（commands・explanation・question の 3 つ）だけで返してください。";
  const messages = [{ role: "system", content: SYSTEM }, ...history.map((m) => ({ role: m.role, content: String(m.content) })), { role: "user", content: user }];
  const order = fmtMode ? FORMATS.filter(([k]) => k === fmtMode).concat(FORMATS.filter(([k]) => k !== fmtMode)) : FORMATS;
  let last;
  for (const [k, rf] of order) {
    const body = { model: cfg.model, messages, temperature: 0, stream: false, ...(rf ? { response_format: rf } : {}) };
    const r = await req(base + "/chat/completions", { method: "POST", headers: headersOf(cfg.header), body: JSON.stringify(body) }, 180000, signal);
    if (!r.ok) {
      const e = await httpError(r, `モデル「${cfg.model}」`);
      // 返事の形の指定に対応していないサーバー → 次の形で
      if ((r.status === 400 || r.status === 422 || r.status === 500 || r.status === 501) && rf && /response_format|json_schema|json_object|schema|grammar|format/i.test(e.message)) { last = e; continue; }
      if (e.kind === "notfound") e.kind = "model";
      throw e;
    }
    let j; try { j = await r.json(); } catch { throw new PcError("format", "パソコンの AI の返事を読み取れませんでした"); }
    const text = String(j.choices?.[0]?.message?.content ?? j.choices?.[0]?.text ?? "");
    const out = extractCommands(text.replace(/<think>[\s\S]*?<\/think>/g, ""));
    fmtMode = k;
    return { ...out, raw: text, model: j.model || cfg.model };
  }
  throw last || new PcError("format", "パソコンの AI が返事の形に対応していません");
}
