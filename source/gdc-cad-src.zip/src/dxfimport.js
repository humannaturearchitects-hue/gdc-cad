// DXF（2D 図面）をスケッチとして読み込む: 線・円・円弧・ポリライン（ふくらみ＝円弧つき）・点
const UNIT = { 1: 25.4, 2: 304.8, 4: 1, 5: 10, 6: 1000 }; // $INSUNITS → mm

export function parseDXF(text) {
  const lines = text.split(/\r?\n/);
  const pairs = [];
  for (let i = 0; i + 1 < lines.length; i += 2) pairs.push([parseInt(lines[i].trim(), 10), lines[i + 1].trim()]);
  let scale = 1;
  for (let i = 0; i < pairs.length; i++) if (pairs[i][0] === 9 && pairs[i][1] === "$INSUNITS" && pairs[i + 1]) scale = UNIT[parseInt(pairs[i + 1][1], 10)] || 1;
  // ENTITIES セクションだけ
  let s = pairs.findIndex((p, i) => p[0] === 2 && p[1] === "ENTITIES" && pairs[i - 1] && pairs[i - 1][1] === "SECTION");
  if (s < 0) s = 0;
  const ents = [], skipped = {};
  const r6 = (v) => +(+v * scale).toFixed(6);
  let i = s + 1;
  const readEntity = () => { const type = pairs[i][1]; const props = []; i++; while (i < pairs.length && pairs[i][0] !== 0) { props.push(pairs[i]); i++; } return { type, props }; };
  const g = (props, code) => { const p = props.find((x) => x[0] === code); return p ? parseFloat(p[1]) : undefined; };
  const bulgeArc = (a, b, bulge) => {
    const cx = b[0] - a[0], cy = b[1] - a[1], L = Math.hypot(cx, cy); if (L < 1e-12) return null;
    const nx = -cy / L, ny = cx / L, sag = bulge * L / 2;
    const m = [(a[0] + b[0]) / 2 - nx * sag, (a[1] + b[1]) / 2 - ny * sag];
    return { type: "arc", x1: +a[0].toFixed(6), y1: +a[1].toFixed(6), x2: +b[0].toFixed(6), y2: +b[1].toFixed(6), xm: +m[0].toFixed(6), ym: +m[1].toFixed(6) };
  };
  const seg = (a, b, bulge) => {
    if (Math.hypot(a[0] - b[0], a[1] - b[1]) < 1e-9) return;
    if (bulge && Math.abs(bulge) > 1e-9) { const e = bulgeArc(a, b, bulge); if (e) ents.push(e); }
    else ents.push({ type: "line", x1: +a[0].toFixed(6), y1: +a[1].toFixed(6), x2: +b[0].toFixed(6), y2: +b[1].toFixed(6) });
  };
  while (i < pairs.length) {
    if (pairs[i][0] !== 0) { i++; continue; }
    if (pairs[i][1] === "ENDSEC" || pairs[i][1] === "EOF") break;
    const { type, props } = readEntity();
    if (type === "LINE") seg([r6(g(props, 10)), r6(g(props, 20))], [r6(g(props, 11)), r6(g(props, 21))], 0);
    else if (type === "CIRCLE") ents.push({ type: "circle", cx: r6(g(props, 10)), cy: r6(g(props, 20)), d: r6(2 * g(props, 40)) });
    else if (type === "ARC") {
      const c = [g(props, 10), g(props, 20)], r = g(props, 40); let a0 = g(props, 50) * Math.PI / 180, a1 = g(props, 51) * Math.PI / 180;
      if (a1 <= a0) a1 += Math.PI * 2;
      const P = (t) => [r6(c[0] + r * Math.cos(t)), r6(c[1] + r * Math.sin(t))];
      const [p0, pm, p1] = [P(a0), P((a0 + a1) / 2), P(a1)];
      ents.push({ type: "arc", x1: p0[0], y1: p0[1], x2: p1[0], y2: p1[1], xm: pm[0], ym: pm[1] });
    } else if (type === "LWPOLYLINE") {
      const closed = (g(props, 70) || 0) & 1;
      const vs = []; for (const [code, v] of props) { if (code === 10) vs.push({ x: r6(v), y: 0, b: 0 }); else if (code === 20 && vs.length) vs[vs.length - 1].y = r6(v); else if (code === 42 && vs.length) vs[vs.length - 1].b = parseFloat(v); }
      for (let k = 1; k < vs.length; k++) seg([vs[k - 1].x, vs[k - 1].y], [vs[k].x, vs[k].y], vs[k - 1].b);
      if (closed && vs.length > 2) seg([vs[vs.length - 1].x, vs[vs.length - 1].y], [vs[0].x, vs[0].y], vs[vs.length - 1].b);
    } else if (type === "POLYLINE") {
      const closed = (g(props, 70) || 0) & 1; const vs = [];
      while (i < pairs.length && pairs[i][0] === 0 && pairs[i][1] === "VERTEX") { const v = readEntity(); vs.push({ x: r6(g(v.props, 10)), y: r6(g(v.props, 20)), b: g(v.props, 42) || 0 }); }
      if (i < pairs.length && pairs[i][1] === "SEQEND") readEntity();
      for (let k = 1; k < vs.length; k++) seg([vs[k - 1].x, vs[k - 1].y], [vs[k].x, vs[k].y], vs[k - 1].b);
      if (closed && vs.length > 2) seg([vs[vs.length - 1].x, vs[vs.length - 1].y], [vs[0].x, vs[0].y], vs[vs.length - 1].b);
    } else if (type === "POINT") ents.push({ type: "point", x: r6(g(props, 10)), y: r6(g(props, 20)) });
    else skipped[type] = (skipped[type] || 0) + 1;
  }
  return { entities: ents, skipped, scale };
}
