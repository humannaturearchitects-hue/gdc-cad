// AI（Claude）に自由な言葉を読み取らせ、このソフトのコマンド（手順）に変換する。
// 寸法の計算は形状エンジンが正確に行う。AI は「どのコマンドを、どの数値で」を決めるだけ。
// 利用者が自分の Anthropic API キーを入れて、オンにしたときだけ動く（指示文とモデルの概要が Anthropic に送られる）。
import Anthropic from "@anthropic-ai/sdk";
import REFERENCE from "../docs/コマンドの使い方.txt?raw";

export const AI_MODELS = [
  ["claude-opus-5-5", "Claude Opus 5.5（いちばん賢い・既定）"],
  ["claude-sonnet-5-5", "Claude Sonnet 5.5（速い）"],
  ["claude-haiku-5-5", "Claude Haiku 5.5（最速・安い）"],
];

const SYSTEM = `あなたは 3D CAD「GDC GOOD DESIGN CAD」の操作アシスタントです。
利用者が日本語で自由に話した・書いた指示を、このソフトの「コマンド」（1 行に 1 つの指示）に変換します。

守ること:
- 寸法は利用者が言った数値を正確に使う（単位は mm）。勝手に丸めたり、言われていない寸法を作らない。
- 形を作るのに欠かせない寸法が足りないときは、commands を空にして question で短く聞き返す。
- 既にある部品を変えるときは、作り直さずに「直す」コマンド（例: 床板 厚さ 30 ／ 穴1 径 10 ／ 押し出し2 距離 40）を使う。
- 全体や部品の大きさを何倍・何分の一にする指示は「スケール 倍率 [ボディ名]」を使う（例: 全部を 10 分の 1 → スケール 0.1）。
- ボディ名・タイムラインの名前は「現在のモデル」にある名前をそのまま使う。
- 書けるのは下の「コマンドの使い方」にある書き方だけ。できない操作は commands に入れず、explanation でできないことを伝える。
- 座標は「x,y」「x,y,z」のようにカンマでつなぎ、空白を入れない。数値の前のキーワード（幅・奥行・厚さ・直径 など）を省かない。
- commands はそのまま上から順に実行される。説明やメモは commands に書かない（# の行は使ってよい）。
- explanation には、何をするのかを日本語で 1〜2 文で書く。

===== コマンドの使い方 =====
${REFERENCE}`;

const SCHEMA = {
  type: "object",
  properties: {
    commands: { type: "string", description: "実行するコマンド。1 行に 1 つ。聞き返すときは空文字" },
    explanation: { type: "string", description: "何をするかの短い説明（日本語）" },
    question: { type: "string", description: "寸法などが足りず聞き返すときの質問。不要なら空文字" },
  },
  required: ["commands", "explanation", "question"],
  additionalProperties: false,
};

// instruction: 利用者の言葉, context: 今のモデルの概要, retry: 前回の実行でのエラー（直してもらうとき）
export async function askAI({ apiKey, model = "claude-opus-5-5", instruction, context, retry }) {
  if (!apiKey) throw new Error("AI を使うには Anthropic の API キーを設定してください");
  const client = new Anthropic({ apiKey, dangerouslyAllowBrowser: true });
  let user = `現在のモデル:\n${context}\n\n利用者の指示:\n${instruction}`;
  if (retry) user += `\n\n前回の手順:\n${retry.commands}\n\n実行したところ、次の行で止まりました:\n${retry.line}\n理由: ${retry.message}\n\n直した手順を返してください（成功した行は繰り返さない）。`;
  const params = {
    model,
    max_tokens: 16000,
    system: [{ type: "text", text: SYSTEM, cache_control: { type: "ephemeral" } }],
    messages: [{ role: "user", content: user }],
    // 返事の形を決める（JSON）。変換の作業なので考えすぎず速く
    output_config: { format: { type: "json_schema", schema: SCHEMA }, effort: "low" },
  };
  // 安全上の理由で断られたときに別のモデルで続ける（Haiku には無い）
  const withFallback = model !== "claude-haiku-5-5";
  let res;
  try {
    res = withFallback
      ? await client.beta.messages.create({ ...params, betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" })
      : await client.messages.create(params);
  } catch (e) {
    if (e instanceof Anthropic.AuthenticationError) throw new Error("API キーが正しくありません（設定し直してください）");
    if (e instanceof Anthropic.PermissionDeniedError) throw new Error("この API キーでは使えません（Anthropic のコンソールで権限を確認してください）");
    if (e instanceof Anthropic.RateLimitError) throw new Error("AI の利用が混み合っています。少し待ってからもう一度");
    if (e instanceof Anthropic.BadRequestError) throw new Error("AI への依頼に問題がありました: " + e.message);
    if (e instanceof Anthropic.APIConnectionError) throw new Error("AI につながりません（インターネット接続を確認してください）");
    if (e instanceof Anthropic.APIError) throw new Error(`AI のエラー（${e.status}）: ${e.message}`);
    throw e;
  }
  if (res.stop_reason === "refusal") throw new Error("AI がこの指示を処理できませんでした（言い方を変えてみてください）");
  if (res.stop_reason === "max_tokens") throw new Error("AI の返事が長すぎて途中で切れました。指示を分けてください");
  const text = res.content.filter((b) => b.type === "text").map((b) => b.text).join("");
  let out;
  try { out = JSON.parse(text); } catch { throw new Error("AI の返事を読み取れませんでした。もう一度試してください"); }
  return { commands: String(out.commands || "").trim(), explanation: String(out.explanation || ""), question: String(out.question || ""), model: res.model, usage: res.usage };
}
