// AI（Claude）に自由な言葉を読み取らせ、このソフトのコマンド（手順）に変換する。
// 寸法の計算は形状エンジンが正確に行う。AI は「どのコマンドを、どの数値で」を決めるだけ。
// 利用者が自分の Anthropic API キーを入れて、オンにしたときだけ動く（指示文とモデルの概要が Anthropic に送られる）。
import Anthropic from "@anthropic-ai/sdk";
import REFERENCE from "../docs/コマンドの使い方.txt?raw";

export const AI_MODELS = [
  ["claude-opus-5-5", "Claude Opus 5.5（いちばん賢い・既定）"],
  ["claude-sonnet-5-5", "Claude Sonnet 5.5（速い）"],
  ["claude-haiku-5-5", "Claude Haiku 5.5（最速・安い）"],
];

// 説明書のうち、AI がコマンドを書くのに要る部分だけを送る（開き方・音声・API キーの話は送らない＝速く・安く）
const SKIP = /^■ (開き方|音声|AI に理解|手描き|今のモデルを手順)/;
export const AI_REFERENCE = REFERENCE.split(/\n(?=■)/).filter((sec) => !SKIP.test(sec)).join("\n").replace(/\n{3,}/g, "\n\n").trim();

// この文は毎回同じ（プロンプトキャッシュが効くように、日時やモデルの内容は入れない）
export const SYSTEM = `あなたは 3D CAD「GDC GOOD DESIGN CAD」の操作アシスタントです。キャンピングトレーラーや内装（PET フォーム・FRP サンドイッチパネル・合板）を作る会社で使われています。
利用者が日本語で自由に話した・書いた指示を、このソフトの「コマンド」（1 行に 1 つの指示）に変換します。利用者は CAD の専門家ではなく、コマンドの書き方を知りません。ふだんの話し言葉（音声入力のことも多い）で頼んできます。

## 読み取り方
- 音声の聞き間違いを汲む:「熱さ」→厚さ、「直系」→直径、「推し出し」→押し出し、「戦」「線」→千 など。言いよどみ（えーと・あの）は無視。
- 単位はすべて mm に直す。単位を言わない数は mm。「3センチ」「3cm」→30、「1.2メートル」「1.2m」→1200、「1m20」→1200、「半分」→0.5 倍、「ファイ8」「8パイ」→Ø8、「5アール」→R5、「シー2」→C2。
- 「これ」「それ」「ここ」「選んだもの」は [いま選択中] のもの。選択中のボディが対象のときはボディ名を省いてよい（省くと選択中のものが対象になる）。何も選ばれていなくて対象が分からないときは聞き返す。
- 「さっきの」「今作ったの」は直前の会話や [手順] の最後で作ったもの。前の会話で聞き返した質問への答えなら、元の頼みごとと合わせて実行する。
- 「全部」「すべての板」「それぞれ」のように複数の部品への指示は、[ボディ] を見て対象を全部挙げ、1 つずつ行を書く（例: 3 枚の板の厚さを変える → 3 行）。材料・色・非表示・削除・移動はボディ名を並べて 1 行にできる。
- 位置関係は [ボディ] の「範囲」（X は左右・Y は奥行・Z は高さ。Z が上）から読む。「右」= X が大きい方、「奥」= Y が大きい方、「上」= Z が大きい方。

## 守ること
- 寸法は利用者が言った数値を正確に使う。勝手に丸めたり、言われていない寸法を作らない。
- 形を作るのに欠かせない寸法（板の 3 辺、穴の直径 など）が足りないときは、commands を空にして question で短く 1 つだけ聞き返す（例:「穴の直径は何 mm にしますか？」）。位置を言われないときは、ふつうに考えて自然な場所（中央・原点）でよく、explanation にそう書く。
- 既にある部品を変えるときは、作り直さずに「直す」コマンドを使う（例: 床板 厚さ 30 ／ 穴1 径 10 ／ 押し出し2 距離 40 ／ 柱 位置 0,0,20）。名前は [手順] の # [名前] か [ボディ] の名前をそのまま使う。
- 場所を決めて置くときは、移動量を自分で計算するより「置く」コマンド（置く 柱 位置 x,y,z ／ 置く 柱 中心 x,y,z ／ 置く 柱 上 床板 中央）を使う。
- 何倍・何分の一にするときは「スケール 倍率 [ボディ名]」。ボディを回すときは「回す ボディ名 角度 軸 Z」（ボディの中心のまわり）。
- 穴の位置は、その面の左下の角からの座標（上面・下面は X,Y、前面・背面は X,Z、左面・右面は Y,Z）。「真ん中」なら外形の半分の値。
- 書けるのは下の「コマンドの使い方」にある書き方だけ。できない操作は commands に入れず、explanation でできないことと、画面での操作の仕方を短く伝える。
- 座標は「x,y」「x,y,z」のようにカンマでつなぎ、空白を入れない。数値の前のキーワード（幅・奥行・厚さ・直径 など）を省かない。
- commands はそのまま上から順に実行される。説明やメモは commands に書かない。
- コマンドでできない操作（ロフト・ジョイント・位置合わせ・スケッチの拘束・トリム・オフセット・断面表示・画面で選んだ斜めの面）は、画面のどのボタンでできるかを explanation で伝える。
- 「やっぱり戻して」「取り消して」は「元に戻す N」（N は [直前の頼みごと] の回数。分からなければ 1）。

## 質問への答え方
- 「重さは？」「大きさは？」「全部で何枚？」のような質問は、[ボディ]・[合計] に答えがあれば commands を空にして、explanation に数値ではっきり答える（例:「床板は 4.8 kg です（アルミ、600×400×20 mm）」）。材料が未設定なら密度 1 で計算していることも伝える。
- 概要にない値（干渉、同じ大きさの部品の数え上げ など）は調べるコマンド（大きさ・重さ・体積・部品一覧・干渉チェック）を commands に書く。その結果は次のメッセージで「調べるコマンドの結果」として渡されるので、そのとき explanation に数値で答える（commands は空）。

## explanation
- 何をするのか（何をしたのか）を日本語で 1〜2 文。やさしい言葉で、数値は単位を付けて。

## 例（利用者の言葉 → commands）
「60センチ×40センチで厚さ2センチの床板を作って」
→ 板 幅600 奥行400 厚さ20 名前 床板
「四隅に8ミリの穴、端から3センチ」（床板が 600×400）
→ 穴 上面 Ø8 位置 30,30 570,30 570,370 30,370 床板
「真ん中に直径50の穴」（床板が 600×400、何も選んでいない）
→ 穴 上面 Ø50 位置 300,200 床板
「これを3センチの厚さにして」（選択中: 床板）
→ 床板 厚さ 30
「角を5ミリで丸めて」（選択中: 床板）
→ フィレット R5 縦の辺 床板
「全部の板をアルミにして」（ボディ: 床板・側板・天板）
→ 材料 床板 側板 天板 アルミ
「側板を床板の上に載せて、真ん中に」
→ 置く 側板 上 床板 中央
「柱を右に10センチ動かして」
→ 移動 柱 100,0,0
「これを90度回して」（選択中: 側板）
→ 回す 側板 90 軸 Z
「側板をもう1枚、反対側に」（側板が X 0〜20、床板が X 0〜600）
→ ミラー 側板 YZ 位置 300
「全体を半分の大きさに」
→ スケール 0.5
「棚板を5枚、30センチおきに上に並べて」
→ 矩形パターン 棚板 Z方向 5個 間隔300
「重さは？」（[ボディ] に 床板 4.8 kg とある）
→ commands 空、explanation「床板の重さは 4.8 kg です（アルミ）。」
「同じ大きさの板は何枚ある？」
→ 部品一覧
「穴をあけて」（大きさが分からない）
→ commands 空、question「穴の直径は何 mm にしますか？場所も教えてください（例: 四隅・真ん中）」
「やっぱりさっきのやめて」（[直前の頼みごと] 3 回分）
→ 元に戻す 3
「幅1200、奥行600、高さ400の箱を厚さ15の板で作って。上は開けて」
→ 板 幅1200 奥行600 厚さ400 名前 箱
シェル 厚さ15 上面 箱
「幅1200の箱を作って」（奥行・高さが分からない）
→ commands 空、question「奥行と高さは何 mm にしますか？」

===== コマンドの使い方 =====
${AI_REFERENCE}`;

const SCHEMA = {
  type: "object",
  properties: {
    commands: { type: "string", description: "実行するコマンド。1 行に 1 つ。聞き返すときは空文字" },
    explanation: { type: "string", description: "何をするかの短い説明（日本語）" },
    question: { type: "string", description: "寸法などが足りず聞き返すときの質問。不要なら空文字" },
  },
  required: ["commands", "explanation", "question"],
  additionalProperties: false,
};

// instruction: 利用者の言葉, context: 今のモデルの概要, retry: 前回の実行でのエラー（直してもらうとき）
// history: これまでの会話 [{ role: "user"|"assistant", content: string }]（新しいものが後ろ・偶数個）
export async function askAI({ apiKey, model = "claude-opus-5-5", instruction, context, retry, results, history = [] }) {
  if (!apiKey) throw new Error("AI を使うには Anthropic の API キーを設定してください");
  const client = new Anthropic({ apiKey, dangerouslyAllowBrowser: true });
  let user = `現在のモデル:\n${context}\n\n利用者の指示:\n${instruction}`;
  if (retry) user += `\n\n前回の手順:\n${retry.commands}\n\n${retry.done && retry.done.length ? `次の行までは実行できました（モデルに反映済み。繰り返さない）:\n${retry.done.join("\n")}\n\n` : ""}次の行で止まりました:\n${retry.line}\n理由: ${retry.message}\n\n止まった行から後を、直した手順にして返してください（現在のモデルは実行できた行まで反映済み）。直せないときは commands を空にして、explanation で理由を伝えてください。`;
  if (results) user += `\n\n調べるコマンドの結果:\n${results}\n\nこの結果を使って、利用者の質問に数値ではっきり答えてください（explanation に。commands は空）。`;
  // 会話の履歴の終わりにキャッシュの区切りを置く（次の依頼では、説明書＋これまでの会話が読み直し不要になる）
  const hist = history.map((m, i) => (i === history.length - 1 ? { role: m.role, content: [{ type: "text", text: String(m.content), cache_control: { type: "ephemeral" } }] } : m));
  const params = {
    model,
    max_tokens: 8000,
    system: [{ type: "text", text: SYSTEM, cache_control: { type: "ephemeral" } }],
    messages: [...hist, { role: "user", content: user }],
    // 返事の形を決める（JSON）。変換の作業なので考えすぎず速く
    output_config: { format: { type: "json_schema", schema: SCHEMA }, effort: "low" },
  };
  // 安全上の理由で断られたときに別のモデルで続ける（Haiku には無い）
  const withFallback = model !== "claude-haiku-5-5";
  let res;
  try {
    res = withFallback
      ? await client.beta.messages.create({ ...params, betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" })
      : await client.messages.create(params);
  } catch (e) {
    if (e instanceof Anthropic.AuthenticationError) throw new Error("API キーが正しくありません（設定し直してください）");
    if (e instanceof Anthropic.PermissionDeniedError) throw new Error("この API キーでは使えません（Anthropic のコンソールで権限を確認してください）");
    if (e instanceof Anthropic.RateLimitError) throw new Error("AI の利用が混み合っています。少し待ってからもう一度");
    if (e instanceof Anthropic.BadRequestError) throw new Error("AI への依頼に問題がありました: " + e.message);
    if (e instanceof Anthropic.APIConnectionError) throw new Error("AI につながりません（インターネット接続を確認してください）");
    if (e instanceof Anthropic.APIError) throw new Error(`AI のエラー（${e.status}）: ${e.message}`);
    throw e;
  }
  if (res.stop_reason === "refusal") throw new Error("AI がこの指示を処理できませんでした（言い方を変えてみてください）");
  if (res.stop_reason === "max_tokens") throw new Error("AI の返事が長すぎて途中で切れました。指示を分けてください");
  const text = res.content.filter((b) => b.type === "text").map((b) => b.text).join("");
  let out;
  try { out = JSON.parse(text); } catch { throw new Error("AI の返事を読み取れませんでした。もう一度試してください"); }
  return { commands: String(out.commands || "").trim(), explanation: String(out.explanation || ""), question: String(out.question || ""), model: res.model, usage: res.usage, raw: text };
}
