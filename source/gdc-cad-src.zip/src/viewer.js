// 3Dビューア（three.js）: Z上向き、平行投影
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { STD_PLANES, sketchPlaneFrame, sampleArc, resolveEntity, loopContains } from "./shared/sketchgeom.js";

export const COARSE = typeof matchMedia !== "undefined" && matchMedia("(pointer: coarse)").matches;
const COL = { edge: 0x1d2228, hover: 0xf2a33a, sel: 0x2f7de1, sketch: 0x2f6fd0, profile: 0x7fb0f0, profileSel: 0x2f7de1, construction: 0xe8732a };

export class Viewer {
  constructor(canvas, overlay, cubeEl) {
    this.canvas = canvas;
    this.overlay = overlay;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true });
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.localClippingEnabled = true;
    this.clipPlanes = [];
    this.scene = new THREE.Scene();
    this.camera = new THREE.OrthographicCamera(-100, 100, 100, -100, -1e6, 1e6);
    this.camera.up.set(0, 0, 1);
    this.camera.position.set(600, -800, 500);
    this.controls = new OrbitControls(this.camera, canvas);
    this.controls.enableDamping = false;
    this.controls.mouseButtons = { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.PAN, RIGHT: THREE.MOUSE.PAN };
    this.controls.zoomToCursor = true;
    this.controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };
    this.controls.screenSpacePanning = true;
    this.controls.addEventListener("change", () => { this.dirty = true; this.onCameraChange && this.onCameraChange(); });

    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x8890a0, 1.6));
    const dl = new THREE.DirectionalLight(0xffffff, 1.6);
    dl.position.set(1, -2, 3);
    this.camLight = dl;
    this.scene.add(dl);

    this.root = new THREE.Group(); this.scene.add(this.root);
    this.sketchGroup = new THREE.Group(); this.scene.add(this.sketchGroup);
    this.helperGroup = new THREE.Group(); this.scene.add(this.helperGroup);
    this.hlGroup = new THREE.Group(); this.scene.add(this.hlGroup);

    this.showEdges = true;
    this.showGrid = true;
    this.bodies = new Map(); // id -> {mesh, edges, data}
    this.raycaster = new THREE.Raycaster();
    this.makeGrid(1000);
    this.makeOrigin();
    this.cube = new ViewCube(cubeEl, this);
    this.dirty = true;
    new ResizeObserver(() => this.resize()).observe(canvas.parentElement);
    this.resize();
    const loop = () => {
      if (this.dirty) { this.render(); this.dirty = false; }
      requestAnimationFrame(loop);
    };
    loop();
  }

  resize() {
    const el = this.canvas.parentElement;
    const w = el.clientWidth, h = el.clientHeight;
    this.renderer.setSize(w, h, false);
    const aspect = w / Math.max(1, h);
    const half = this.viewHalf || 400;
    this.camera.left = -half * aspect; this.camera.right = half * aspect;
    this.camera.top = half; this.camera.bottom = -half;
    this.camera.updateProjectionMatrix();
    this.dirty = true;
  }

  render() {
    this.camLight.position.copy(this.camera.position).sub(this.controls.target).normalize().add(new THREE.Vector3(0.3, 0.2, 0.6));
    this.onBeforeRender && this.onBeforeRender();
    this.renderer.render(this.scene, this.camera);
    this.cube.sync();
    this.onRender && this.onRender();
  }

  // ------------------------------------------------ grid / origin
  makeGrid(size) {
    if (this.grid) this.helperGroup.remove(this.grid);
    const div = 20;
    const g = new THREE.GridHelper(size, div, 0x9aa4b2, 0xc4cbd5);
    g.rotation.x = Math.PI / 2;
    g.material.transparent = true; g.material.opacity = 0.6; g.material.depthWrite = false;
    g.visible = this.showGrid;
    this.grid = g;
    this.helperGroup.add(g);
  }

  makeOrigin() {
    const axes = new THREE.Group();
    const mk = (dir, color) => {
      const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(...dir).multiplyScalar(80)]);
      axes.add(new THREE.Line(geo, new THREE.LineBasicMaterial({ color, depthTest: false })));
    };
    mk([1, 0, 0], 0xd23b3b); mk([0, 1, 0], 0x2a9a3a); mk([0, 0, 1], 0x2f6fd0);
    axes.renderOrder = 10;
    this.axes = axes;
    this.helperGroup.add(axes);
    // 原点平面（スケッチ平面選択用）
    this.planeMeshes = [];
    for (const [name, p] of Object.entries(STD_PLANES)) {
      const f = sketchPlaneFrame({ type: "std", name });
      const geo = new THREE.PlaneGeometry(1, 1);
      // 基準平面は原点を中心に広げる（Fusion と同じ）。モデルより奥の部分はモデルに隠れる
      const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0xf0b070, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false, depthTest: true }));
      m.renderOrder = 12;
      const basis = new THREE.Matrix4().makeBasis(new THREE.Vector3(...f.xDir), new THREE.Vector3(...f.yDir), new THREE.Vector3(...f.normal));
      m.quaternion.setFromRotationMatrix(basis);
      m.userData = { kind: "plane", name };
      m.visible = false;
      const edge = new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({ color: 0xd08a40 }));
      edge.renderOrder = 13;
      m.add(edge);
      this.planeMeshes.push(m);
      this.helperGroup.add(m);
      void p;
    }
  }

  // 構築平面（Fusion の「構築」で作った平面）
  setCPlanes(list) {
    this.cplaneMeshes = this.cplaneMeshes || [];
    for (const m of this.cplaneMeshes) { this.helperGroup.remove(m); m.geometry.dispose(); }
    this.cplaneMeshes = [];
    const box = this.sceneBox(); const c = box.getCenter(new THREE.Vector3());
    const s = Math.max(120, box.getSize(new THREE.Vector3()).length() * 1.1);
    for (const it of list) {
      const f = it.frame;
      const geo = new THREE.PlaneGeometry(1, 1);
      const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0xe0b040, transparent: true, opacity: 0.2, side: THREE.DoubleSide, depthWrite: false }));
      m.renderOrder = 12;
      m.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3(...f.xDir), new THREE.Vector3(...f.yDir), new THREE.Vector3(...f.normal)));
      // モデルの中心を平面に投影した位置に置く
      const n = new THREE.Vector3(...f.normal), o = new THREE.Vector3(...f.origin);
      const pc = c.clone().sub(n.clone().multiplyScalar(c.clone().sub(o).dot(n)));
      m.position.copy(pc); m.scale.set(s, s, 1);
      m.userData = { kind: "plane", name: it.id, frame: f, label: it.name };
      m.visible = it.visible;
      const edge = new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({ color: 0xc09020 }));
      m.add(edge);
      m.updateMatrixWorld(true);
      this.cplaneMeshes.push(m); this.helperGroup.add(m);
    }
    this.dirty = true;
  }

  showPlanes(on) {
    // 画面の高さの 4 割ほどの大きさで原点に置く（モデルを覆い隠さない）
    const viewH = (this.camera.top - this.camera.bottom) / (this.camera.zoom || 1);
    const s = Math.max(40, viewH * 0.42);
    for (const m of this.planeMeshes) {
      m.visible = on;
      m.scale.set(s, s, 1);
      m.position.set(0, 0, 0);
      m.updateMatrixWorld(true); // 描画前にクリックされても当たるように
    }
    this.dirty = true;
  }

  // スケッチ中は 1 本指ドラッグを「移動」に（描画と回転が混ざらないように）
  setTouchSketch(on) { this.controls.touches = { ONE: on ? THREE.TOUCH.PAN : THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN }; }

  // スケッチ中は左ドラッグで回転しない（描画に使う）。右・中ドラッグで移動
  setSketchMouse(on) { this.controls.mouseButtons = { LEFT: on ? -1 : THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.PAN, RIGHT: THREE.MOUSE.PAN }; }

  // 断面表示: 軸方向の平面で切って中を見る（null で解除）
  setSection(sec) {
    this.clipPlanes.length = 0;
    if (sec) {
      const n = { X: [1, 0, 0], Y: [0, 1, 0], Z: [0, 0, 1] }[sec.axis].map((v) => v * (sec.flip ? 1 : -1));
      this.clipPlanes.push(new THREE.Plane(new THREE.Vector3(...n), sec.flip ? -sec.pos : sec.pos));
    }
    for (const b of this.bodies.values()) { b.mesh.material.needsUpdate = true; b.edges.material.needsUpdate = true; }
    this.dirty = true;
  }

  setGrid(on) { this.showGrid = on; this.grid.visible = on; this.dirty = true; }
  setEdges(on) { this.showEdges = on; for (const b of this.bodies.values()) b.edges.visible = on && b.mesh.visible; this.dirty = true; }

  // ------------------------------------------------ bodies
  setBodies(meshes) {
    // 形状が変わっていないボディは GPU の形状データを使い回す（meshKey が同じ）
    this.geoCache = this.geoCache || new Map();
    const keep = new Set(meshes.map((m) => m.meshKey).filter(Boolean));
    for (const b of this.bodies.values()) {
      this.root.remove(b.mesh); this.root.remove(b.edges);
      b.mesh.material.dispose(); b.edges.material.dispose();
    }
    for (const [k, g] of this.geoCache) if (!keep.has(k)) { g.geo.dispose(); g.eg.dispose(); this.geoCache.delete(k); }
    this.bodies.clear();
    for (const m of meshes) {
      let cached = m.meshKey ? this.geoCache.get(m.meshKey) : null;
      if (!cached) {
        const geo = new THREE.BufferGeometry();
        geo.setAttribute("position", new THREE.BufferAttribute(m.vertices, 3));
        geo.setAttribute("normal", new THREE.BufferAttribute(m.normals, 3));
        geo.setIndex(new THREE.BufferAttribute(m.triangles, 1));
        geo.computeBoundingSphere(); geo.computeBoundingBox();
        const eg0 = new THREE.BufferGeometry();
        eg0.setAttribute("position", new THREE.BufferAttribute(m.lines, 3));
        cached = { geo, eg: eg0 };
        if (m.meshKey) this.geoCache.set(m.meshKey, cached);
      }
      const geo = cached.geo;
      const mat = new THREE.MeshStandardMaterial({ color: new THREE.Color(m.color), metalness: 0.05, roughness: 0.6, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1, side: THREE.DoubleSide, clippingPlanes: this.clipPlanes });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.userData = { kind: "body", id: m.id };
      const eg = cached.eg;
      const edges = new THREE.LineSegments(eg, new THREE.LineBasicMaterial({ color: COL.edge, clippingPlanes: this.clipPlanes }));
      edges.userData = { kind: "edges", id: m.id };
      mesh.visible = !m.hidden;
      edges.visible = !m.hidden && this.showEdges;
      this.root.add(mesh); this.root.add(edges);
      this.bodies.set(m.id, { mesh, edges, data: m });
    }
    this.dirty = true;
  }

  setBodyVisible(id, vis) {
    const b = this.bodies.get(id);
    if (!b) return;
    b.mesh.visible = vis; b.edges.visible = vis && this.showEdges;
    this.dirty = true;
  }

  setBodyOpacity(id, op) {
    const b = this.bodies.get(id);
    if (!b) return;
    b.mesh.material.transparent = op < 1; b.mesh.material.opacity = op; b.mesh.material.depthWrite = op >= 1;
    this.dirty = true;
  }

  sceneBox() {
    const box = new THREE.Box3();
    for (const b of this.bodies.values()) if (b.mesh.visible) box.expandByObject(b.mesh);
    this.sketchGroup.traverse((o) => { if (o.isLine || o.isLineSegments) box.expandByObject(o); });
    if (box.isEmpty()) box.set(new THREE.Vector3(-100, -100, -100), new THREE.Vector3(100, 100, 100));
    return box;
  }
  sceneRadius() { const s = new THREE.Sphere(); this.sceneBox().getBoundingSphere(s); return s.radius; }

  // 点がすべて画面に収まっていなければ、収まるように引いて表示する
  ensureVisible(points) {
    if (!points.length) return false;
    this.camera.updateMatrixWorld();
    const out = points.some((p) => { const v = new THREE.Vector3(...p).project(this.camera); return Math.abs(v.x) > 0.92 || Math.abs(v.y) > 0.9; });
    if (!out) return false;
    const box = this.sceneBox().clone();
    for (const p of points) box.expandByPoint(new THREE.Vector3(...p));
    this.fit(box);
    return true;
  }

  fit(box) {
    box = box || this.sceneBox();
    const sphere = new THREE.Sphere();
    box.getBoundingSphere(sphere);
    const dir = this.camera.position.clone().sub(this.controls.target).normalize();
    this.controls.target.copy(sphere.center);
    this.camera.position.copy(sphere.center).add(dir.multiplyScalar(sphere.radius * 4 + 100));
    this.viewHalf = sphere.radius * 1.15 + 1;
    this.camera.zoom = 1;
    this.resize();
    const gs = Math.pow(10, Math.ceil(Math.log10(sphere.radius * 4 + 10)));
    this.makeGrid(gs);
    this.controls.update();
  }

  setView(dir, up = [0, 0, 1], animate = true) {
    const d = new THREE.Vector3(...dir).normalize();
    const target = this.controls.target.clone();
    const dist = this.camera.position.distanceTo(target) || 1000;
    const endPos = target.clone().add(d.multiplyScalar(dist));
    const endUp = new THREE.Vector3(...up);
    if (!animate) { this.camera.position.copy(endPos); this.camera.up.copy(endUp); this.controls.update(); return; }
    const sPos = this.camera.position.clone(), sUp = this.camera.up.clone();
    const t0 = performance.now();
    const step = () => {
      const t = Math.min(1, (performance.now() - t0) / 350);
      const e = t * t * (3 - 2 * t);
      const p = sPos.clone().sub(target).lerp(endPos.clone().sub(target), e);
      p.setLength(dist);
      this.camera.position.copy(target).add(p);
      this.camera.up.copy(sUp.clone().lerp(endUp, e).normalize());
      this.controls.update();
      if (t < 1) requestAnimationFrame(step);
    };
    step();
  }

  home() { this.camera.up.set(0, 0, 1); this.setView([1, -1.3, 0.9], [0, 0, 1], false); this.fit(); }

  // ------------------------------------------------ picking
  ndc(ev) {
    const r = this.canvas.getBoundingClientRect();
    return new THREE.Vector2(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
  }
  worldPerPixel() {
    const h = this.canvas.clientHeight || 1;
    return (this.camera.top - this.camera.bottom) / this.camera.zoom / h;
  }

  pick(ev, kinds) {
    this.raycaster.setFromCamera(this.ndc(ev), this.camera);
    const wpp = this.worldPerPixel();
    this.raycaster.params.Line.threshold = wpp * (COARSE ? 14 : 6);
    const res = [];
    let planeHit = null;
    // 押し出し等のプレビュー中の新しい形はクリックの対象にしない
    const vis = [...this.bodies.values()].filter((b) => b.mesh.visible && !(this.pickExclude && b.data.src === this.pickExclude));
    if (kinds.includes("plane")) {
      const hits = this.raycaster.intersectObjects([...this.planeMeshes, ...(this.cplaneMeshes || [])].filter((m) => m.visible), false);
      // ボディをクリックしたらボディの面を優先（基準平面は下のボタンでいつでも選べる）
      // 構築平面は手前にあれば選ぶ（原点の基準平面はボタンでも選べるので、モデルの面を優先）
      if (hits.length) { const h = hits[0]; planeHit = { kind: "plane", name: h.object.userData.name, frame: h.object.userData.frame, dist: h.object.userData.frame && this.cplaneFirst ? h.distance - wpp * 2 : 1e12 + h.distance }; }
    }
    if (kinds.includes("profile") && this.profileMeshes) {
      const hits = this.raycaster.intersectObjects(this.profileMeshes, false);
      if (hits.length) {
        hits.sort((a, b) => a.object.userData.area - b.object.userData.area);
        const h = hits[0];
        res.push({ kind: "profile", sketch: h.object.userData.sketch, loop: h.object.userData.loop, dist: h.distance - 2e-3 });
      }
    }
    const faceHits = this.raycaster.intersectObjects(vis.map((b) => b.mesh), false);
    const nearestFace = faceHits[0];
    if (kinds.includes("edge")) {
      const eh = this.raycaster.intersectObjects(vis.filter((b) => b.edges.visible || true).map((b) => b.edges), false);
      for (const h of eh) {
        if (nearestFace && h.distance > nearestFace.distance + wpp * 4) continue;
        const body = this.bodies.get(h.object.userData.id);
        const g = body.data.edgeGroups.find((gr) => h.index >= gr.start && h.index < gr.start + gr.count);
        if (!g) continue;
        res.push({ kind: "edge", bodyId: body.data.id, group: g, point: edgePoint(body.data.lines, g), dir: edgeDir(body.data.lines, g), dist: h.distance - wpp * 3 });
        break;
      }
    }
    if (nearestFace && (kinds.includes("face") || kinds.includes("body"))) {
      const body = this.bodies.get(nearestFace.object.userData.id);
      const tri = nearestFace.faceIndex * 3;
      const g = body.data.faceGroups.find((gr) => tri >= gr.start && tri < gr.start + gr.count);
      const p = nearestFace.point;
      if (kinds.includes("face")) res.push({ kind: "face", bodyId: body.data.id, group: g, point: [p.x, p.y, p.z], normal: nearestFace.face ? [nearestFace.face.normal.x, nearestFace.face.normal.y, nearestFace.face.normal.z] : null, dist: nearestFace.distance });
      if (kinds.includes("body")) res.push({ kind: "body", bodyId: body.data.id, point: [p.x, p.y, p.z], dist: nearestFace.distance + 1e-3 });
    }
    if (planeHit) res.push(planeHit);
    res.sort((a, b) => a.dist - b.dist);
    // 曲面をクリックしたときの代わりに使えるよう、奥の基準平面も添える
    if (res[0] && res[0].kind === "face" && planeHit) res[0].behindPlane = planeHit;
    return res[0] || null;
  }

  // 平面上の点（スケッチ用）
  planePoint(ev, frame) {
    this.raycaster.setFromCamera(this.ndc(ev), this.camera);
    const n = new THREE.Vector3(...frame.normal);
    const o = new THREE.Vector3(...frame.origin);
    const pl = new THREE.Plane().setFromNormalAndCoplanarPoint(n, o);
    const p = new THREE.Vector3();
    if (!this.raycaster.ray.intersectPlane(pl, p)) {
      // 平面がカメラに平行な場合
      return null;
    }
    const d = p.clone().sub(o);
    return [d.dot(new THREE.Vector3(...frame.xDir)), d.dot(new THREE.Vector3(...frame.yDir))];
  }

  toScreen(p3) {
    const v = new THREE.Vector3(...p3).project(this.camera);
    const r = this.canvas.getBoundingClientRect();
    return [(v.x + 1) / 2 * r.width, (1 - v.y) / 2 * r.height];
  }

  // ボディ上の点がどの面（表示用のグループ）にあるか: 一番近い三角形の面
  faceGroupAt(bodyId, p) {
    const b = this.bodies.get(bodyId);
    if (!b || !b.data.faceGroups) return null;
    const v = b.data.vertices, t = b.data.triangles;
    let best = -1, bd = Infinity;
    for (let i = 0; i < t.length; i += 3) {
      let cx = 0, cy = 0, cz = 0;
      for (let k = 0; k < 3; k++) { const j = t[i + k] * 3; cx += v[j]; cy += v[j + 1]; cz += v[j + 2]; }
      // 三角形の重心と、頂点までの距離の小さい方
      let dmin = Math.hypot(cx / 3 - p[0], cy / 3 - p[1], cz / 3 - p[2]);
      for (let k = 0; k < 3; k++) { const j = t[i + k] * 3; dmin = Math.min(dmin, Math.hypot(v[j] - p[0], v[j + 1] - p[1], v[j + 2] - p[2]) + 1e-6); }
      if (dmin < bd) { bd = dmin; best = i; }
    }
    if (best < 0) return null;
    return b.data.faceGroups.find((g) => best >= g.start && best < g.start + g.count) || null;
  }

  // ------------------------------------------------ highlight
  clearHighlight(tag) {
    for (const o of [...this.hlGroup.children]) {
      if (!tag || o.userData.tag === tag) { this.hlGroup.remove(o); o.geometry && o.geometry.dispose(); }
    }
    this.dirty = true;
  }

  highlight(item, tag, color) {
    if (!item) return;
    const c = color ?? (tag === "hover" ? COL.hover : COL.sel);
    if (item.kind === "edge") {
      const b = this.bodies.get(item.bodyId);
      if (!b) return;
      const g = item.group;
      const arr = b.data.lines.slice(g.start * 3, (g.start + g.count) * 3);
      const geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.BufferAttribute(arr, 3));
      const l = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: c, depthTest: false, linewidth: 2 }));
      l.renderOrder = 20; l.userData.tag = tag;
      this.hlGroup.add(l);
    } else if (item.kind === "face" && item.group) {
      const b = this.bodies.get(item.bodyId);
      if (!b) return;
      const g = item.group;
      const idx = b.data.triangles.slice(g.start, g.start + g.count);
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", b.mesh.geometry.getAttribute("position"));
      geo.setIndex(new THREE.BufferAttribute(idx, 1));
      const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.55, depthTest: true, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, side: THREE.DoubleSide }));
      m.userData.tag = tag; m.renderOrder = 15;
      this.hlGroup.add(m);
    } else if (item.kind === "body") {
      const b = this.bodies.get(item.bodyId);
      if (!b) return;
      const m = new THREE.Mesh(b.mesh.geometry, new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.35, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, side: THREE.DoubleSide }));
      m.userData.tag = tag; m.renderOrder = 15;
      m.geometry = b.mesh.geometry; m.userData.shared = true;
      this.hlGroup.add(m);
    } else if (item.kind === "plane") {
      const pm = [...this.planeMeshes, ...(this.cplaneMeshes || [])].find((m) => m.userData.name === item.name);
      if (pm) {
        const m = pm.clone(); m.material = pm.material.clone(); m.material.color.set(c); m.material.opacity = 0.45;
        m.userData.tag = tag; this.hlGroup.add(m);
      }
    } else if (item.kind === "profile" && this.profileMeshes) {
      const pm = this.profileMeshes.find((m) => m.userData.sketch === item.sketch && m.userData.loop === item.loop);
      if (pm) {
        const m = new THREE.Mesh(pm.geometry, new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.6, side: THREE.DoubleSide, depthTest: false }));
        m.position.copy(pm.position); m.quaternion.copy(pm.quaternion);
        m.userData.tag = tag; m.userData.shared = true; m.renderOrder = 16;
        this.hlGroup.add(m);
      }
    }
    this.dirty = true;
  }

  // ------------------------------------------------ sketches (表示)
  setSketches(list, opts = {}) {
    // list: [{id, frame, entities(raw), loops, visible}]
    for (const o of [...this.sketchGroup.children]) { this.sketchGroup.remove(o); o.traverse((x) => x.geometry && x.geometry.dispose()); }
    this.profileMeshes = [];
    for (const sk of list) {
      if (!sk.visible) continue;
      const grp = sketchObject(sk.frame, sk.entities, sk.num, { color: COL.sketch });
      this.sketchGroup.add(grp);
      if (opts.profiles && sk.loops) {
        sk.loops.forEach((loop, i) => {
          const m = profileMesh(sk.frame, sk.loops, i);
          if (!m) return;
          m.userData = { kind: "profile", sketch: sk.id, loop: i, area: loop.area };
          this.sketchGroup.add(m);
          this.profileMeshes.push(m);
        });
      }
    }
    this.dirty = true;
  }
}

function edgePoint(lines, g) {
  const n = g.count;
  const at = (k) => [lines[(g.start + k) * 3], lines[(g.start + k) * 3 + 1], lines[(g.start + k) * 3 + 2]];
  if (n <= 2) {
    const a = at(0), b = at(Math.max(0, n - 1));
    return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2];
  }
  // 線分ペアの並び: 中央付近の頂点（曲線上の点）
  let k = Math.floor(n / 2);
  if (k % 2 === 0 && k > 0) k -= 1;
  return at(k);
}

function edgeDir(lines, g) {
  const a = [lines[g.start * 3], lines[g.start * 3 + 1], lines[g.start * 3 + 2]];
  const k = g.start + g.count - 1;
  const b = [lines[k * 3], lines[k * 3 + 1], lines[k * 3 + 2]];
  const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const L = Math.hypot(...d) || 1;
  return d.map((x) => +(x / L).toFixed(5));
}

export function frameMatrix(frame) {
  const m = new THREE.Matrix4().makeBasis(new THREE.Vector3(...frame.xDir), new THREE.Vector3(...frame.yDir), new THREE.Vector3(...frame.normal));
  m.setPosition(new THREE.Vector3(...frame.origin));
  return m;
}

export function entityPolyline(e) {
  if (e.type === "line") return [[e.x1, e.y1], [e.x2, e.y2]];
  if (e.type === "rect") return [[e.x, e.y], [e.x + e.w, e.y], [e.x + e.w, e.y + e.h], [e.x, e.y + e.h], [e.x, e.y]];
  if (e.type === "circle") { const p = []; const r = Math.abs(e.d) / 2; for (let i = 0; i <= 64; i++) { const t = i / 64 * Math.PI * 2; p.push([e.cx + r * Math.cos(t), e.cy + r * Math.sin(t)]); } return p; }
  if (e.type === "arc") return sampleArc([e.x1, e.y1], [e.x2, e.y2], [e.xm, e.ym], 32);
  if (e.type === "point") return [[e.x, e.y], [e.x, e.y]];
  return [];
}

export function sketchObject(frame, entities, num, { color = 0x2f6fd0, selected = new Set(), hover = -1 } = {}) {
  const grp = new THREE.Group();
  grp.applyMatrix4(frameMatrix(frame));
  entities.forEach((raw, i) => {
    let e;
    try { e = resolveEntity(raw, num || ((x) => +x || 0)); } catch { return; }
    const pts = entityPolyline(e).map((p) => new THREE.Vector3(p[0], p[1], 0));
    if (pts.length < 2) return;
    const geo = new THREE.BufferGeometry().setFromPoints(pts);
    let c = raw.construction ? COL.construction : raw.proj ? 0x9b4dca : color;
    if (selected.has(i)) c = COL.sel;
    if (hover === i) c = COL.hover;
    if (e.type === "point") {
      // スケッチ点（穴の位置などに使う）: 画面上で一定の大きさの点
      const pm = new THREE.Points(new THREE.BufferGeometry().setFromPoints([pts[0]]), new THREE.PointsMaterial({ color: c, size: COARSE ? 11 : 8, sizeAttenuation: false, depthTest: false }));
      pm.renderOrder = 31; pm.userData = { entity: i };
      grp.add(pm);
      return;
    }
    const mat = raw.construction
      ? new THREE.LineDashedMaterial({ color: c, dashSize: 4, gapSize: 3, depthTest: false })
      : new THREE.LineBasicMaterial({ color: c, depthTest: false });
    const line = new THREE.Line(geo, mat);
    if (raw.construction) line.computeLineDistances();
    line.renderOrder = 30;
    line.userData = { entity: i };
    grp.add(line);
  });
  return grp;
}

function profileMesh(frame, loops, i) {
  const loop = loops[i];
  const contains = loopContains;
  const shape = new THREE.Shape(loop.poly.map((p) => new THREE.Vector2(p[0], p[1])));
  const children = loops.filter((o, j) => j !== i && contains(loop, o) && !loops.some((k, kk) => kk !== i && kk !== j && contains(loop, k) && contains(k, o)));
  for (const c of children) shape.holes.push(new THREE.Path(c.poly.map((p) => new THREE.Vector2(p[0], p[1]))));
  const geo = new THREE.ShapeGeometry(shape);
  const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: COL.profile, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false, depthTest: false }));
  m.applyMatrix4(frameMatrix(frame));
  m.renderOrder = 25;
  return m;
}

// ------------------------------------------------ ViewCube
class ViewCube {
  constructor(el, viewer) {
    this.viewer = viewer;
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.setSize(110, 110);
    el.appendChild(this.renderer.domElement);
    this.scene = new THREE.Scene();
    this.camera = new THREE.OrthographicCamera(-1.7, 1.7, 1.7, -1.7, 0.1, 100);
    const faces = [
      ["右", [1, 0, 0]], ["左", [-1, 0, 0]], ["後", [0, 1, 0]], ["前", [0, -1, 0]], ["上", [0, 0, 1]], ["下", [0, 0, -1]],
    ];
    // BoxGeometry を X 軸回りに 90° 回して Z 上向きにする: 面順 → +x,-x,+z,-z,-y,+y
    const order = ["右", "左", "上", "下", "前", "後"];
    const mats = order.map((t) => new THREE.MeshBasicMaterial({ map: labelTex(t) }));
    const geo = new THREE.BoxGeometry(2, 2, 2); geo.rotateX(Math.PI / 2);
    this.cube = new THREE.Mesh(geo, mats);
    this.cube.add(new THREE.LineSegments(new THREE.EdgesGeometry(this.cube.geometry), new THREE.LineBasicMaterial({ color: 0x8892a0 })));
    // 上面・下面のテクスチャ向き補正は不要（ラベルのみ）
    this.scene.add(this.cube);
    this.faces = faces;
    const ray = new THREE.Raycaster();
    this.renderer.domElement.addEventListener("click", (ev) => {
      const r = this.renderer.domElement.getBoundingClientRect();
      const v = new THREE.Vector2(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
      ray.setFromCamera(v, this.camera);
      const h = ray.intersectObject(this.cube, false)[0];
      if (!h) return;
      // クリック位置に応じて面・稜・角を判定
      const p = h.point;
      const s = (x) => (Math.abs(x) > 0.55 ? Math.sign(x) : 0);
      const dir = [s(p.x), s(p.y), s(p.z)];
      const up = dir[2] !== 0 && dir[0] === 0 && dir[1] === 0 ? [0, 1, 0] : [0, 0, 1];
      viewer.setView(dir, up);
    });
    this.renderer.domElement.style.cursor = "pointer";
  }
  sync() {
    const v = this.viewer;
    const dir = v.camera.position.clone().sub(v.controls.target).normalize();
    this.camera.position.copy(dir.multiplyScalar(10));
    this.camera.up.copy(v.camera.up);
    this.camera.lookAt(0, 0, 0);
    this.renderer.render(this.scene, this.camera);
  }
}

function labelTex(text) {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d");
  g.fillStyle = "#eef1f5"; g.fillRect(0, 0, 128, 128);
  g.strokeStyle = "#b8c0cc"; g.lineWidth = 4; g.strokeRect(2, 2, 124, 124);
  g.fillStyle = "#3a4250"; g.font = "bold 54px sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
  g.fillText(text, 64, 68);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
