// 書き出し: DXF / SVG / PDF / OBJ / GLB
import * as THREE from "three";
import fontUrl from "./assets/NotoSansJP-sub.ttf?url";

const IS_IOS = typeof navigator !== "undefined" && (/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1));

// PDF 用フォントを先に取得しておく（オフラインでも PDF を作れるように）
export function warmFont() { fetch(fontUrl).catch(() => {}); }

// ファイルを渡す: iPhone/iPad（とスマホ）は共有シート（「"ファイル"に保存」で iCloud Drive・AirDrop・メール等）、
// それ以外はダウンロード。作るのに時間がかかって共有シートを出せなかったときは「共有・保存」ボタンを出して押してもらう
const IS_MOBILE = IS_IOS || (typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent));
export const safeFileName = (n) => String(n || "無題").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/^\.+/, "").slice(0, 150) || "無題";
// .kcad などブラウザが知らない形式は、名前の後ろに .json などを付け足されないよう汎用の種類で渡す
const mimeFor = (name, given) => /\.(kcad|gdcbackup|step|stp|brep)$/i.test(name) ? "application/octet-stream" : given;
function anchorDownload(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
}
// 押して共有するための小さな案内（共有は「押した直後」でないと出せないため）
function offerShare(file, blob) {
  document.getElementById("share-offer")?.remove();
  const el = document.createElement("div");
  el.id = "share-offer";
  el.innerHTML = `<div class="so-msg">「${file.name.replace(/[<>&]/g, "")}」の準備ができました</div><div class="so-btns"><button class="btn primary" data-a="share">共有・保存…</button><button class="btn" data-a="dl">ダウンロード</button><button class="btn" data-a="x">閉じる</button></div>`;
  document.body.appendChild(el);
  return new Promise((res) => {
    const done = (r) => { el.remove(); res(r); };
    el.querySelector('[data-a="share"]').onclick = async () => {
      try { await navigator.share({ files: [file], title: file.name }); done("shared"); }
      catch (e) { if (e && e.name === "AbortError") return done("cancel"); anchorDownload(blob, file.name); done("downloaded"); }
    };
    el.querySelector('[data-a="dl"]').onclick = () => { anchorDownload(blob, file.name); done("downloaded"); };
    el.querySelector('[data-a="x"]').onclick = () => done("cancel");
  });
}
// 結果: "shared" | "downloaded" | "cancel"
// 書き出す前に名前を決める仕組み（job.js が「無題」のときに名前を聞く）
export const downloadHooks = { rename: null };
export async function download(data, name, mime = "application/octet-stream") {
  try { if (downloadHooks.rename) name = downloadHooks.rename(name) || name; } catch { /* */ }
  name = safeFileName(name);
  const type = mimeFor(name, (data instanceof Blob && data.type) || mime);
  const blob = data instanceof Blob ? (data.type === type ? data : new Blob([data], { type })) : new Blob([data], { type });
  if (IS_MOBILE && navigator.canShare && navigator.share) {
    let file = null;
    try { file = new File([blob], name, { type }); } catch { /* */ }
    if (file && navigator.canShare({ files: [file] })) {
      try { await navigator.share({ files: [file], title: name }); return "shared"; }
      catch (e) {
        if (e && e.name === "AbortError") return "cancel";
        if (e && e.name === "NotAllowedError") return offerShare(file, blob);
        /* それ以外の失敗は通常のダウンロードへ */
      }
    }
  }
  anchorDownload(blob, name);
  return "downloaded";
}

// 共有シートを開くためのボタン（iPhone: 共有はタップの直後にしか開けない）
export function shareLater(file, name) {
  return new Promise((resolve) => {
    document.querySelectorAll(".share-later").forEach((x) => x.remove());
    const box = document.createElement("div");
    box.className = "share-later";
    box.style.cssText = "position:fixed;left:12px;right:12px;bottom:calc(16px + env(safe-area-inset-bottom));z-index:9999;background:#fff;color:#222;border-radius:14px;box-shadow:0 6px 30px rgba(0,0,0,.3);padding:14px;display:flex;flex-direction:column;gap:10px;font-size:15px;max-width:420px;margin:0 auto";
    box.innerHTML = `<div><b>${escXml(name)}</b> ができました</div><div style="display:flex;gap:8px"><button class="btn primary" data-sh style="flex:1;min-height:44px">共有・保存（ファイルに保存・AirDrop・メール）</button><button class="btn" data-cl style="min-height:44px">閉じる</button></div>`;
    document.body.appendChild(box);
    box.querySelector("[data-cl]").onclick = () => { box.remove(); resolve(); };
    box.querySelector("[data-sh]").onclick = async () => {
      try { await navigator.share({ files: [file], title: name }); } catch { /* キャンセル */ }
      box.remove(); resolve();
    };
  });
}

// ---------------------------------------------------------------- SVGパス → 2D図形（ワールド座標, y上向き）
// prim: {t:'line',a,b} | {t:'arc',c,r,s,d} (s:開始角, d:符号付き掃引角) | {t:'poly',pts}
export function parseSvgPath(d) {
  const toks = d.match(/[MLAZCQHVmlazcqhv]|-?\d*\.?\d+(?:e[-+]?\d+)?/g) || [];
  const prims = [];
  let i = 0, cmd = null, cur = [0, 0], start = [0, 0];
  const n = () => parseFloat(toks[i++]);
  while (i < toks.length) {
    if (/[A-Za-z]/.test(toks[i])) cmd = toks[i++];
    const rel = cmd === cmd.toLowerCase() && cmd !== "z" && cmd !== "Z";
    const C = cmd.toUpperCase();
    const off = (p) => (rel ? [p[0] + cur[0], p[1] + cur[1]] : p);
    if (C === "M") { cur = off([n(), n()]); start = cur; cmd = rel ? "l" : "L"; }
    else if (C === "L") { const p = off([n(), n()]); prims.push({ t: "line", a: cur, b: p }); cur = p; }
    else if (C === "H") { const x = n(); const p = [rel ? cur[0] + x : x, cur[1]]; prims.push({ t: "line", a: cur, b: p }); cur = p; }
    else if (C === "V") { const y = n(); const p = [cur[0], rel ? cur[1] + y : y]; prims.push({ t: "line", a: cur, b: p }); cur = p; }
    else if (C === "Z") { if (Math.hypot(cur[0] - start[0], cur[1] - start[1]) > 1e-9) prims.push({ t: "line", a: cur, b: start }); cur = start; }
    else if (C === "A") {
      const rx = n(), ry = n(), rot = n(), large = n(), sweep = n();
      const p = off([n(), n()]);
      prims.push(svgArc(cur, p, rx, ry, rot, large, sweep));
      cur = p;
    } else if (C === "C") {
      const c1 = off([n(), n()]), c2 = off([n(), n()]), p = off([n(), n()]);
      const pts = [];
      for (let k = 0; k <= 16; k++) { const t = k / 16, u = 1 - t; pts.push([u * u * u * cur[0] + 3 * u * u * t * c1[0] + 3 * u * t * t * c2[0] + t * t * t * p[0], u * u * u * cur[1] + 3 * u * u * t * c1[1] + 3 * u * t * t * c2[1] + t * t * t * p[1]]); }
      prims.push({ t: "poly", pts }); cur = p;
    } else if (C === "Q") {
      const c1 = off([n(), n()]), p = off([n(), n()]);
      const pts = [];
      for (let k = 0; k <= 12; k++) { const t = k / 12, u = 1 - t; pts.push([u * u * cur[0] + 2 * u * t * c1[0] + t * t * p[0], u * u * cur[1] + 2 * u * t * c1[1] + t * t * p[1]]); }
      prims.push({ t: "poly", pts }); cur = p;
    } else { i++; }
  }
  // SVG(y下) → ワールド(y上)
  return prims.map(flipY);
}

function flipY(p) {
  if (p.t === "line") return { t: "line", a: [p.a[0], -p.a[1]], b: [p.b[0], -p.b[1]] };
  if (p.t === "poly") return { t: "poly", pts: p.pts.map((q) => [q[0], -q[1]]) };
  if (p.t === "arc") return { t: "arc", c: [p.c[0], -p.c[1]], r: p.r, s: -p.s, d: -p.d };
  if (p.t === "ellipse") return { t: "poly", pts: p.pts.map((q) => [q[0], -q[1]]) };
  return p;
}

function svgArc(p1, p2, rx, ry, rotDeg, large, sweep) {
  const phi = (rotDeg * Math.PI) / 180;
  const cp = Math.cos(phi), sp = Math.sin(phi);
  const dx = (p1[0] - p2[0]) / 2, dy = (p1[1] - p2[1]) / 2;
  const x1 = cp * dx + sp * dy, y1 = -sp * dx + cp * dy;
  rx = Math.abs(rx); ry = Math.abs(ry);
  const lam = (x1 * x1) / (rx * rx) + (y1 * y1) / (ry * ry);
  if (lam > 1) { rx *= Math.sqrt(lam); ry *= Math.sqrt(lam); }
  const num = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1;
  const den = rx * rx * y1 * y1 + ry * ry * x1 * x1;
  let co = Math.sqrt(Math.max(0, num / den));
  if (large === sweep) co = -co;
  const cxp = (co * rx * y1) / ry, cyp = (-co * ry * x1) / rx;
  const cx = cp * cxp - sp * cyp + (p1[0] + p2[0]) / 2;
  const cy = sp * cxp + cp * cyp + (p1[1] + p2[1]) / 2;
  const ang = (u, v) => Math.atan2(u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1]);
  const t1 = ang([1, 0], [(x1 - cxp) / rx, (y1 - cyp) / ry]);
  let dt = ang([(x1 - cxp) / rx, (y1 - cyp) / ry], [(-x1 - cxp) / rx, (-y1 - cyp) / ry]);
  if (!sweep && dt > 0) dt -= 2 * Math.PI;
  if (sweep && dt < 0) dt += 2 * Math.PI;
  if (Math.abs(rx - ry) < 1e-6 * Math.max(rx, 1)) return { t: "arc", c: [cx, cy], r: rx, s: t1 + phi, d: dt };
  const pts = [];
  for (let k = 0; k <= 32; k++) {
    const t = t1 + (dt * k) / 32;
    const ex = rx * Math.cos(t), ey = ry * Math.sin(t);
    pts.push([cp * ex - sp * ey + cx, sp * ex + cp * ey + cy]);
  }
  return { t: "ellipse", pts };
}

export function primsBBox(prims) {
  const b = { min: [Infinity, Infinity], max: [-Infinity, -Infinity] };
  const add = (p) => { b.min[0] = Math.min(b.min[0], p[0]); b.min[1] = Math.min(b.min[1], p[1]); b.max[0] = Math.max(b.max[0], p[0]); b.max[1] = Math.max(b.max[1], p[1]); };
  for (const p of prims) {
    if (p.t === "line") { add(p.a); add(p.b); }
    else if (p.t === "poly") p.pts.forEach(add);
    else if (p.t === "arc") { for (let k = 0; k <= 16; k++) { const t = p.s + (p.d * k) / 16; add([p.c[0] + p.r * Math.cos(t), p.c[1] + p.r * Math.sin(t)]); } }
  }
  if (!isFinite(b.min[0])) { b.min = [0, 0]; b.max = [0, 0]; }
  return b;
}

// 変換 (x,y) -> (ox + s*x, oy + s*y)  ※シート座標は y 上向き（mm, 左下原点）
export function transformPrims(prims, s, ox, oy) {
  const T = (p) => [ox + s * p[0], oy + s * p[1]];
  return prims.map((p) => {
    if (p.t === "line") return { ...p, a: T(p.a), b: T(p.b) };
    if (p.t === "poly") return { ...p, pts: p.pts.map(T) };
    if (p.t === "arc") return { ...p, c: T(p.c), r: p.r * s };
    return p;
  });
}

// ---------------------------------------------------------------- シート → SVG
// sheet: {w,h, layers: {name: {prims, color, dash, width}}, texts:[{x,y,text,size,anchor,rot,layer}], fills:[{pts,layer}]}
export function sheetToSVG(sheet, { font = "NotoSansJP, 'Noto Sans JP', sans-serif" } = {}) {
  const H = sheet.h;
  const Y = (y) => +(H - y).toFixed(4);
  const X = (x) => +x.toFixed(4);
  const out = [];
  out.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${sheet.w}mm" height="${sheet.h}mm" viewBox="0 0 ${sheet.w} ${sheet.h}">`);
  out.push(`<rect x="0" y="0" width="${sheet.w}" height="${sheet.h}" fill="white"/>`);
  // 下塗り（線より先に描く塗り: 壁のハッチなど）
  for (const f of sheet.fills || []) if (f.under) out.push(`<path d="M${f.pts.map((q) => `${X(q[0])} ${Y(q[1])}`).join("L")}Z" fill="${f.color || "#000"}" stroke="none"/>`);
  for (const [name, L] of Object.entries(sheet.layers)) {
    const d = [];
    for (const p of L.prims) {
      if (p.t === "line") d.push(`M${X(p.a[0])} ${Y(p.a[1])}L${X(p.b[0])} ${Y(p.b[1])}`);
      else if (p.t === "poly") d.push("M" + p.pts.map((q) => `${X(q[0])} ${Y(q[1])}`).join("L"));
      else if (p.t === "arc") {
        const full = Math.abs(p.d) >= 2 * Math.PI - 1e-6;
        if (full) {
          d.push(`M${X(p.c[0] + p.r)} ${Y(p.c[1])}A${p.r} ${p.r} 0 1 0 ${X(p.c[0] - p.r)} ${Y(p.c[1])}A${p.r} ${p.r} 0 1 0 ${X(p.c[0] + p.r)} ${Y(p.c[1])}`);
        } else {
          const a = [p.c[0] + p.r * Math.cos(p.s), p.c[1] + p.r * Math.sin(p.s)];
          const e = [p.c[0] + p.r * Math.cos(p.s + p.d), p.c[1] + p.r * Math.sin(p.s + p.d)];
          const large = Math.abs(p.d) > Math.PI ? 1 : 0;
          const sweep = p.d > 0 ? 0 : 1; // y反転のため
          d.push(`M${X(a[0])} ${Y(a[1])}A${+p.r.toFixed(4)} ${+p.r.toFixed(4)} 0 ${large} ${sweep} ${X(e[0])} ${Y(e[1])}`);
        }
      }
    }
    if (d.length) out.push(`<path d="${d.join("")}" fill="none" stroke="${L.color || "#000"}" stroke-width="${L.width || 0.35}" ${L.dash ? `stroke-dasharray="${L.dash}"` : ""} stroke-linecap="round" stroke-linejoin="round"/>`);
  }
  for (const f of sheet.fills || []) if (!f.under) out.push(`<path d="M${f.pts.map((q) => `${X(q[0])} ${Y(q[1])}`).join("L")}Z" fill="${f.color || "#000"}" stroke="none"/>`);
  for (const t of sheet.texts || []) {
    const anchor = t.anchor || "start";
    const tr = t.rot ? ` transform="rotate(${-t.rot} ${X(t.x)} ${Y(t.y)})"` : "";
    out.push(`<text x="${X(t.x)}" y="${Y(t.y)}" font-size="${t.size || 3.5}" font-family="${font}" text-anchor="${anchor}" fill="${t.color || "#000"}"${tr}>${escXml(t.text)}</text>`);
  }
  out.push(`</svg>`);
  return out.join("\n");
}

function escXml(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

// ---------------------------------------------------------------- DXF (R12, mm)
const LAYER_DEF = {
  OUTLINE: { color: 7, ltype: "CONTINUOUS" },
  HIDDEN: { color: 8, ltype: "HIDDEN" },
  CENTER: { color: 1, ltype: "CENTER" },
  DIM: { color: 3, ltype: "CONTINUOUS" },
  TEXT: { color: 7, ltype: "CONTINUOUS" },
  BORDER: { color: 7, ltype: "CONTINUOUS" },
  SKETCH: { color: 5, ltype: "CONTINUOUS" },
  CONSTRUCTION: { color: 30, ltype: "DASHED" },
};

function dxfText(s) {
  return String(s).replace(/[^\x20-\x7e]/g, (c) => "\\U+" + c.codePointAt(0).toString(16).toUpperCase().padStart(4, "0"));
}

export function sheetToDXF(sheet) {
  const L = [];
  const g = (code, val) => { L.push(String(code)); L.push(String(val)); };
  const f = (v) => (+v).toFixed(6).replace(/\.?0+$/, "") || "0";
  g(0, "SECTION"); g(2, "HEADER");
  g(9, "$ACADVER"); g(1, "AC1009");
  g(9, "$INSUNITS"); g(70, 4);
  g(9, "$MEASUREMENT"); g(70, 1);
  g(9, "$EXTMIN"); g(10, 0); g(20, 0); g(30, 0);
  g(9, "$EXTMAX"); g(10, f(sheet.w)); g(20, f(sheet.h)); g(30, 0);
  g(0, "ENDSEC");
  g(0, "SECTION"); g(2, "TABLES");
  g(0, "TABLE"); g(2, "LTYPE"); g(70, 4);
  const lt = (name, desc, pat) => {
    g(0, "LTYPE"); g(2, name); g(70, 0); g(3, desc); g(72, 65); g(73, pat.length);
    g(40, f(pat.reduce((s, x) => s + Math.abs(x), 0)));
    for (const x of pat) g(49, f(x));
  };
  lt("CONTINUOUS", "Solid line", []);
  lt("HIDDEN", "Hidden __ __ __", [3, -1.5]);
  lt("DASHED", "Dashed __  __", [5, -2.5]);
  lt("CENTER", "Center ____ _ ____", [12, -3, 3, -3]);
  g(0, "ENDTAB");
  const layerNames = new Set(["0", ...Object.keys(sheet.layers), "TEXT"]);
  g(0, "TABLE"); g(2, "LAYER"); g(70, layerNames.size);
  for (const n of layerNames) {
    const d = LAYER_DEF[n] || { color: 7, ltype: "CONTINUOUS" };
    g(0, "LAYER"); g(2, n); g(70, 0); g(62, d.color); g(6, d.ltype);
  }
  g(0, "ENDTAB");
  g(0, "TABLE"); g(2, "STYLE"); g(70, 1);
  g(0, "STYLE"); g(2, "STANDARD"); g(70, 0); g(40, 0); g(41, 1); g(50, 0); g(71, 0); g(42, 2.5); g(3, "txt"); g(4, "");
  g(0, "ENDTAB");
  g(0, "ENDSEC");
  g(0, "SECTION"); g(2, "ENTITIES");
  const line = (layer, a, b) => { g(0, "LINE"); g(8, layer); g(10, f(a[0])); g(20, f(a[1])); g(30, 0); g(11, f(b[0])); g(21, f(b[1])); g(31, 0); };
  for (const [name, Ly] of Object.entries(sheet.layers)) {
    for (const p of Ly.prims) {
      if (p.t === "line") line(name, p.a, p.b);
      else if (p.t === "poly") for (let k = 0; k < p.pts.length - 1; k++) line(name, p.pts[k], p.pts[k + 1]);
      else if (p.t === "arc") {
        if (Math.abs(p.d) >= 2 * Math.PI - 1e-6) { g(0, "CIRCLE"); g(8, name); g(10, f(p.c[0])); g(20, f(p.c[1])); g(30, 0); g(40, f(p.r)); continue; }
        let s = p.s, e = p.s + p.d;
        if (p.d < 0) [s, e] = [e, s];
        g(0, "ARC"); g(8, name); g(10, f(p.c[0])); g(20, f(p.c[1])); g(30, 0); g(40, f(p.r));
        g(50, f((s * 180) / Math.PI)); g(51, f((e * 180) / Math.PI));
      }
    }
  }
  for (const fl of sheet.fills || []) {
    if (fl.pts.length === 3) { g(0, "SOLID"); g(8, fl.layer || "DIM"); const p = fl.pts; g(10, f(p[0][0])); g(20, f(p[0][1])); g(30, 0); g(11, f(p[1][0])); g(21, f(p[1][1])); g(31, 0); g(12, f(p[2][0])); g(22, f(p[2][1])); g(32, 0); g(13, f(p[2][0])); g(23, f(p[2][1])); g(33, 0); }
  }
  for (const t of sheet.texts || []) {
    if (t.text === "" || t.text == null) continue; // 空の文字は書かない
    g(0, "TEXT"); g(8, t.layer || "TEXT"); g(10, f(t.x)); g(20, f(t.y)); g(30, 0); g(40, f(t.size || 3.5)); g(1, dxfText(t.text));
    if (t.rot) g(50, f(t.rot));
    const h = t.anchor === "middle" ? 1 : t.anchor === "end" ? 2 : 0;
    if (h) { g(72, h); g(11, f(t.x)); g(21, f(t.y)); g(31, 0); }
  }
  g(0, "ENDSEC"); g(0, "EOF");
  return L.join("\r\n") + "\r\n";
}

// ---------------------------------------------------------------- PDF
let fontB64 = null;
async function loadFont() {
  if (fontB64) return fontB64;
  const res = await fetch(fontUrl);
  const buf = new Uint8Array(await res.arrayBuffer());
  let s = "";
  for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  fontB64 = btoa(s);
  return fontB64;
}

export async function sheetsToPDF(sheets) {
  const [{ jsPDF }, { svg2pdf }] = await Promise.all([import("jspdf"), import("svg2pdf.js")]);
  const b64 = await loadFont();
  const first = sheets[0];
  const doc = new jsPDF({ orientation: first.w > first.h ? "landscape" : "portrait", unit: "mm", format: [first.w, first.h], compress: true });
  doc.addFileToVFS("NotoSansJP.ttf", b64);
  doc.addFont("NotoSansJP.ttf", "NotoSansJP", "normal");
  doc.setFont("NotoSansJP");
  for (let i = 0; i < sheets.length; i++) {
    const sh = sheets[i];
    if (i > 0) doc.addPage([sh.w, sh.h], sh.w > sh.h ? "landscape" : "portrait");
    const holder = document.createElement("div");
    holder.style.cssText = "position:fixed;left:-99999px;top:0";
    holder.innerHTML = sheetToSVG(sh, { font: "NotoSansJP" });
    document.body.appendChild(holder);
    await svg2pdf(holder.firstElementChild, doc, { x: 0, y: 0, width: sh.w, height: sh.h });
    holder.remove();
  }
  return doc.output("blob");
}

// ---------------------------------------------------------------- 3D メッシュ形式
export async function exportOBJ(viewer) {
  const { OBJExporter } = await import("three/examples/jsm/exporters/OBJExporter.js");
  const grp = meshGroup(viewer);
  return new OBJExporter().parse(grp);
}

export async function exportGLB(viewer) {
  const { GLTFExporter } = await import("three/examples/jsm/exporters/GLTFExporter.js");
  const grp = meshGroup(viewer);
  return new Promise((res, rej) => new GLTFExporter().parse(grp, (r) => res(r), rej, { binary: true }));
}

function meshGroup(viewer) {
  const g = new THREE.Group();
  g.rotation.x = -Math.PI / 2; // Z上 → Y上 (glTF)
  for (const b of viewer.bodies.values()) {
    if (!b.mesh.visible) continue;
    const m = new THREE.Mesh(b.mesh.geometry, new THREE.MeshStandardMaterial({ color: b.mesh.material.color, roughness: 0.6 }));
    m.name = b.data.name;
    g.add(m);
  }
  g.scale.setScalar(0.001); // mm → m
  g.updateMatrixWorld(true);
  return g;
}
