// 図面: 穴以外の加工（矩形の欠き込み・角の切り欠き・角穴・矩形の彫り）の寸法
// 板の展開データ（kernel/panel.js の panelFlat）を使う。flat の座標 (u, v) → 3D: frame で戻す
import { project2D } from "./drawingholes.js";

const TOL = 1e-3;
const f1 = (v) => (+(+v).toFixed(1)).toString();

export function flatToWorld(fr, u, v) {
  const a = u + fr.off[0], b = v + fr.off[1];
  return [0, 1, 2].map((k) => fr.xd[k] * a + fr.yd[k] * b + fr.n[k] * fr.hi);
}

// 外形（直線だけ）を順につないだ頂点の列。直線以外があれば null
function loopOf(prims) {
  if (!prims.length || prims.some((p) => p.t !== "line")) return null;
  const segs = prims.map((p) => [p.a, p.b]);
  const same = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]) < TOL;
  const pts = [segs[0][0], segs[0][1]];
  const left = segs.slice(1);
  while (left.length) {
    const end = pts[pts.length - 1];
    const i = left.findIndex((s) => same(s[0], end) || same(s[1], end));
    if (i < 0) return null;
    const [s] = left.splice(i, 1);
    pts.push(same(s[0], end) ? s[1] : s[0]);
  }
  if (!same(pts[0], pts[pts.length - 1])) return null;
  pts.pop();
  // 一直線上の途中の点は除く
  const out = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[(i - 1 + pts.length) % pts.length], b = pts[i], c = pts[(i + 1) % pts.length];
    const cr = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    if (Math.abs(cr) > 1e-6) out.push(b);
  }
  return out;
}

// 外形の欠き込み: 外形の箱から内側に入り込んでいる部分（直角の線だけでできたもの）
export function findNotches(flat) {
  const pts = loopOf(flat.outer);
  if (!pts || pts.length < 5) return [];
  const W = flat.w, H = flat.h;
  const sideOf = (p) => (Math.abs(p[1]) < TOL ? "B" : Math.abs(p[1] - H) < TOL ? "T" : Math.abs(p[0]) < TOL ? "L" : Math.abs(p[0] - W) < TOL ? "R" : null);
  const n = pts.length;
  const start = pts.findIndex((p) => sideOf(p));
  if (start < 0) return [];
  const out = [];
  let i = 0;
  while (i < n) {
    const k = (start + i) % n;
    const nx = (k + 1) % n;
    if (sideOf(pts[k]) && !sideOf(pts[nx])) {
      // 箱の辺から離れる → 次に辺に戻るまでが 1 つの欠き込み
      const run = [pts[k]];
      let j = 1;
      while (j < n && !sideOf(pts[(k + j) % n])) { run.push(pts[(k + j) % n]); j++; }
      run.push(pts[(k + j) % n]);
      i += j;
      // 直角の線だけ
      let ok = true;
      for (let q = 0; q < run.length - 1; q++) if (Math.abs(run[q][0] - run[q + 1][0]) > TOL && Math.abs(run[q][1] - run[q + 1][1]) > TOL) ok = false;
      if (!ok) continue;
      const xs = run.map((p) => p[0]), ys = run.map((p) => p[1]);
      const box = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
      const s0 = sideOf(run[0]), s1 = sideOf(run[run.length - 1]);
      out.push({ box, sides: [s0, s1], corner: s0 !== s1 });
    } else i++;
  }
  return out;
}

// 欠き込み 1 つの寸法（flat 座標）: [{a, b, dir:"x"|"y", side:"B"|"T"|"L"|"R", value}]
export function notchDims(flat, nt) {
  const W = flat.w, H = flat.h;
  const [x0, y0, x1, y1] = nt.box;
  const dims = [];
  const has = (s) => nt.sides.includes(s);
  const hSide = has("B") ? "B" : has("T") ? "T" : (y0 + y1) / 2 < H / 2 ? "B" : "T";
  const vSide = has("L") ? "L" : has("R") ? "R" : (x0 + x1) / 2 < W / 2 ? "L" : "R";
  const yS = hSide === "B" ? 0 : H, xS = vSide === "L" ? 0 : W;
  if (!nt.corner && (has("B") || has("T"))) {
    // 辺の途中の欠き込み（下辺・上辺）: 幅・深さ・端からの位置
    dims.push({ a: [x0, yS], b: [x1, yS], dir: "x", side: hSide, value: x1 - x0 });
    const near = x0 <= W - x1 ? [[0, yS], [x0, yS]] : [[x1, yS], [W, yS]];
    if (Math.abs(near[1][0] - near[0][0]) > TOL) dims.push({ a: near[0], b: near[1], dir: "x", side: hSide, value: Math.abs(near[1][0] - near[0][0]), level: 1 });
    const yd = hSide === "B" ? y1 : y0;
    dims.push({ a: [x1, yS], b: [x1, yd], dir: "y", side: "R", value: Math.abs(yd - yS), local: true });
  } else if (!nt.corner) {
    // 左辺・右辺の途中
    dims.push({ a: [xS, y0], b: [xS, y1], dir: "y", side: vSide, value: y1 - y0 });
    const near = y0 <= H - y1 ? [[xS, 0], [xS, y0]] : [[xS, y1], [xS, H]];
    if (Math.abs(near[1][1] - near[0][1]) > TOL) dims.push({ a: near[0], b: near[1], dir: "y", side: vSide, value: Math.abs(near[1][1] - near[0][1]), level: 1 });
    const xd = vSide === "L" ? x1 : x0;
    dims.push({ a: [xS, y1], b: [xd, y1], dir: "x", side: "T", value: Math.abs(xd - xS), local: true });
  } else {
    // 角の切り欠き: 横・縦の大きさ
    dims.push({ a: [x0, yS], b: [x1, yS], dir: "x", side: hSide, value: x1 - x0 });
    dims.push({ a: [xS, y0], b: [xS, y1], dir: "y", side: vSide, value: y1 - y0 });
  }
  return dims;
}

// 角穴（抜き）・矩形の彫り: 直線 4 本の長方形
function rectOf(prims) {
  if (prims.length !== 4 || prims.some((p) => p.t !== "line")) return null;
  const xs = prims.flatMap((p) => [p.a[0], p.b[0]]), ys = prims.flatMap((p) => [p.a[1], p.b[1]]);
  if (prims.some((p) => Math.abs(p.a[0] - p.b[0]) > TOL && Math.abs(p.a[1] - p.b[1]) > TOL)) return null;
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}

export function rectCutouts(flat) {
  const out = [];
  for (const h of flat.holes) { const r = rectOf(h.prims); if (r) out.push({ box: r, through: true }); }
  for (const e of flat.engrave) {
    if (e.kind !== "pocket") continue;
    const r = rectOf(e.prims); if (r) out.push({ box: r, through: false, depth: e.depth, side: e.side });
  }
  return out;
}

// そのビューで見たときの、角穴・彫りを穴と同じ扱いの項目に（位置寸法・穴表に入る）
export function rectItemsForView(flat, v, viewDir) {
  const fr = flat.frame;
  if (!fr || !viewDir) return [];
  const d = viewDir; const L = Math.hypot(...d);
  const dn = Math.abs((fr.n[0] * d[0] + fr.n[1] * d[1] + fr.n[2] * d[2]) / L);
  if (Math.abs(dn - 1) > 1e-4) return [];
  return rectCutouts(flat).map((r) => {
    const [u0, v0, u1, v1] = r.box;
    const P = (u, w) => project2D(v, flatToWorld(fr, u, w));
    const a = P(u0, v0), b = P(u1, v1), c = P((u0 + u1) / 2, (v0 + v1) / 2);
    const rw = Math.abs(b[0] - a[0]), rh = Math.abs(b[1] - a[1]);
    return { p: c, h: { rect: [+rw.toFixed(3), +rh.toFixed(3)], through: r.through, depth: r.depth, side: r.side, dia: 0 } };
  });
}

// そのビューで描く欠き込みの寸法（ビューの 2D 座標）
export function notchDimsForView(flat, v, viewDir) {
  const fr = flat.frame;
  if (!fr || !viewDir) return [];
  const L = Math.hypot(...viewDir);
  const dn = Math.abs((fr.n[0] * viewDir[0] + fr.n[1] * viewDir[1] + fr.n[2] * viewDir[2]) / L);
  if (Math.abs(dn - 1) > 1e-4) return [];
  const out = [];
  const P = (q) => project2D(v, flatToWorld(fr, q[0], q[1]));
  for (const nt of findNotches(flat)) {
    const c = P([(nt.box[0] + nt.box[2]) / 2, (nt.box[1] + nt.box[3]) / 2]);
    for (const dm of notchDims(flat, nt)) {
      const a = P(dm.a), b = P(dm.b);
      const dir = Math.abs(a[0] - b[0]) >= Math.abs(a[1] - b[1]) ? "h" : "v";
      // 寸法線を置く側（ビューの中で、欠き込みに近い外側）
      const sideP = P(dm.side === "B" ? [dm.a[0], -1] : dm.side === "T" ? [dm.a[0], flat.h + 1] : dm.side === "L" ? [-1, dm.a[1]] : [flat.w + 1, dm.a[1]]);
      const ref = P(dm.side === "B" ? [dm.a[0], 0] : dm.side === "T" ? [dm.a[0], flat.h] : dm.side === "L" ? [0, dm.a[1]] : [flat.w, dm.a[1]]);
      let sgn = dir === "h" ? Math.sign(sideP[1] - ref[1]) || -1 : Math.sign(sideP[0] - ref[0]) || -1;
      // 深さの寸法は欠き込みのすぐ横（欠き込みの外側の材料の上）に置く
      if (dm.local) sgn = dir === "h" ? Math.sign(a[1] - c[1]) || 1 : Math.sign(a[0] - c[0]) || 1;
      out.push({ a, b, dir, sgn, local: !!dm.local, value: dm.value, level: dm.level || 0, text: f1(dm.value), center: c });
    }
  }
  return out;
}
