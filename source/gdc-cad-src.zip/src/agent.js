// AI エージェント接続（MCP）— 画面と同じ操作を、外部の AI エージェントから実行する入口（v0.18）
//
// しくみ: パソコンで「node mcp/gdc-mcp.mjs」を動かすと、この端末の中だけ（127.0.0.1）で小さなサーバーが立つ。
//   AI エージェント（Claude Code など）は MCP でそのサーバーに道具（ツール）を頼み、
//   サーバーは開いている GDC の画面（このファイル）に渡す。画面は「AI に頼む」と同じ実行役（commandline.js）で
//   形を作り、結果を返す。だから AI の操作は画面のタイムラインに 1 手ずつ残り、人が後から直したり取り消したりできる。
// 約束:
//   ・つなぐ先は 127.0.0.1 / localhost だけ（それ以外の住所は受け付けない）。設計データを外部に送らない
//   ・1 回の道具 = 元に戻す 1 回。失敗した道具は、頼まれる前の状態に完全に戻してからエラーを返す（履歴を壊さない）
//   ・AI が作った手順には印（by: "ai"）を付け、タイムラインに 🤖 で表示する
import { store } from "./store.js";
import { call } from "./kernel.js";
import { makeEvaluator } from "./shared/expr.js";
import { analyzeSketch, entityNames } from "./shared/constraintcheck.js";
import { solveSketch, normalizeSketch } from "./shared/solver.js";

export const AGENT_VERSION = "0.18.0";
const FACES = ["上面", "下面", "前面", "背面", "左面", "右面"];
const isLoopback = (u) => { try { const h = new URL(u).hostname; return /^(127\.\d+\.\d+\.\d+|localhost|\[::1\])$/i.test(h); } catch { return false; } };

// URL の ?agent=<合言葉>（&agenthost=http://127.0.0.1:47830）から接続先を読む
export function agentParams(loc = typeof location !== "undefined" ? location : null) {
  if (!loc) return null;
  const q = new URLSearchParams(loc.search);
  const token = q.get("agent");
  if (!token || !/^[0-9a-f]{16,64}$/i.test(token)) return null;
  const host = q.get("agenthost") || loc.origin;
  if (!isLoopback(host)) return { error: "AI 接続の住所は、この端末（127.0.0.1 / localhost）だけにできます: " + host };
  return { token, host: host.replace(/\/+$/, "") };
}

// ---- 値の確認
function numArg(v, what, { min = -1e7, max = 1e7, positive = false } = {}) {
  const n = typeof v === "string" && /^\s*-?\d+(\.\d+)?\s*$/.test(v) ? +v : v;
  if (typeof n !== "number" || !isFinite(n)) throw new Error(`${what} は数値で指定してください（受け取った値: ${JSON.stringify(v)}）`);
  if (positive && !(n > 0)) throw new Error(`${what} は 0 より大きい値にしてください（${n}）`);
  if (n < min || n > max) throw new Error(`${what} が大きすぎるか小さすぎます（${n}）`);
  return +n;
}
// 数値かパラメータ式（「幅/2」など）
function exprArg(v, what, opts) {
  if (typeof v === "string" && !/^\s*-?\d+(\.\d+)?\s*$/.test(v)) {
    const s = v.trim();
    if (!s || /[\n\r;`]/.test(s) || s.length > 200) throw new Error(`${what} の式が正しくありません`);
    try { makeEvaluator(store.project.params || [])(s); } catch (e) { throw new Error(`${what} の式を計算できません: ${e.message}`); }
    return s;
  }
  return numArg(v, what, opts);
}
function nameArg(v, what = "名前") {
  if (v === undefined || v === null || v === "") return null;
  const s = String(v).trim();
  if (!s || /\s/.test(s) || s.length > 40 || /[,#]/.test(s)) throw new Error(`${what} は空白・カンマ・# を含まない 40 文字までにしてください（${JSON.stringify(v)}）`);
  return s;
}
const r6 = (v) => +(+v).toFixed(6);

export class AgentBridge {
  constructor(app, { stepUnicode } = {}) {
    this.app = app;
    this.stepUnicode = stepUnicode || ((b) => b);
    this.log = []; // 最近の操作（画面の表示用）
    this.state = "off";
  }

  // ---- 接続（ロングポーリング）
  start({ token, host }) {
    this.token = token; this.host = host;
    this.tabId = Math.random().toString(36).slice(2, 12);
    this.showChip();
    this.loop();
  }
  async loop() {
    let wait = 500;
    for (;;) {
      try {
        const r = await fetch(`${this.host}/gdc-agent/poll?token=${this.token}&tab=${this.tabId}&v=${AGENT_VERSION}`, { cache: "no-store" });
        if (r.status === 403) { this.setState("denied"); return; }
        if (r.status === 409) { this.setState("other"); await new Promise((res) => setTimeout(res, 5000)); continue; } // 別のタブがつながっている
        if (!r.ok && r.status !== 204) throw new Error("HTTP " + r.status);
        this.setState("on"); wait = 500;
        if (r.status === 204) continue;
        const job = await r.json();
        const out = await this.handle(job);
        await fetch(`${this.host}/gdc-agent/result?token=${this.token}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(out) });
      } catch {
        this.setState("lost");
        await new Promise((res) => setTimeout(res, wait));
        wait = Math.min(wait * 2, 5000);
      }
    }
  }
  async handle(job) {
    const { id, tool, args } = job || {};
    const t0 = performance.now();
    try {
      const result = await this.exec(tool, args || {});
      this.note(tool, true, result && result.summary);
      return { id, ok: true, result, ms: Math.round(performance.now() - t0) };
    } catch (e) {
      this.note(tool, false, e.message);
      return { id, ok: false, error: e.message || String(e) };
    }
  }

  // ---- 画面の表示（ツールバーの「🤖 AI 接続」）
  showChip() {
    if (typeof document === "undefined" || document.getElementById("agent-chip")) return;
    const b = document.createElement("button");
    b.id = "agent-chip"; b.className = "agent-chip";
    b.onclick = () => this.showLog();
    const row = document.querySelector("#topbar .tb-row1");
    const ws = row && row.querySelector(".ws-switch");
    if (row) row.insertBefore(b, ws || null); else document.body.appendChild(b);
    this.chip = b;
    this.setState("connecting");
  }
  setState(st) {
    if (this.state === st) return;
    this.state = st;
    if (!this.chip) return;
    const t = { connecting: "🤖 AI 接続中…", on: "🤖 AI 接続", lost: "🤖 AI 接続 切断", denied: "🤖 AI 接続 拒否", other: "🤖 別のタブが AI 接続中" }[st] || st;
    this.chip.textContent = t;
    this.chip.dataset.state = st;
    this.chip.title = `AI エージェント接続（MCP）: ${this.host}\nこの端末の中（127.0.0.1）だけでやり取りします。設計データを外部には送りません。\nクリックで AI の操作の記録`;
  }
  note(tool, ok, msg) {
    const e = { t: new Date().toLocaleTimeString(), tool, ok, msg: String(msg || "") };
    this.log.push(e); if (this.log.length > 100) this.log.shift();
    if (this.chip) this.chip.classList.toggle("err", !ok);
    if (tool !== "get_state" && this.app.toast) this.app.toast(`🤖 AI: ${ok ? "" : "失敗 — "}${e.msg || tool}`, !ok);
    // 「AI に頼む」と同じ記録欄にも残す
    try { if (tool !== "get_state" && this.app.cmdline && this.app.cmdline.log) this.app.cmdline.log(`<span class="${ok ? "ok" : "ng"}">${ok ? "✓" : "✗"}</span> 🤖 AI 接続 <code>${tool}</code> ${escapeHtml(e.msg)}`, "res"); } catch { /* */ }
  }
  showLog() {
    const rows = this.log.slice().reverse().map((e) => `<tr><td>${e.t}</td><td>${e.ok ? "✓" : "✗"}</td><td><code>${escapeHtml(e.tool)}</code></td><td>${escapeHtml(e.msg)}</td></tr>`).join("");
    this.app.panel("AI エージェント接続（MCP）", `<div class="full" style="font-size:12px;line-height:1.6">
      状態: <b>${escapeHtml(this.chip ? this.chip.textContent : this.state)}</b>（${escapeHtml(this.host || "")}）<br>
      AI の操作はタイムラインに 🤖 付きで残ります。ダブルクリックで直す、Ctrl+Z で 1 手ずつ取り消せます。<br>
      やり取りはこの端末の中（127.0.0.1）だけで、設計データを外部に送りません。
      <table class="agent-log" style="margin-top:6px;width:100%">${rows || "<tr><td>まだ操作はありません</td></tr>"}</table></div>`, null, { noCancel: true, okLabel: "閉じる" });
  }

  // ---- 1 回の道具 = 1 つの取り消し単位。失敗したら頼まれる前の状態へ完全に戻す
  async tx(fn) {
    if (this.app.mode === "sketch") throw new Error("画面でスケッチを編集中です。「スケッチを終了」してからもう一度実行してください（人の作業を壊さないため）");
    if (store.conflict) throw new Error("別のタブとの保存のぶつかりを解決してから実行してください");
    const snap = store.snapshot();
    const u0 = store.undoStack.length;
    const redo = store.redoStack.slice();
    const before = new Set(store.project.features.map((f) => f.id));
    const ctx0 = { ...(this.app.cmdline ? this.app.cmdline.ctx : {}) };
    try {
      const out = await fn();
      const added = store.project.features.filter((f) => !before.has(f.id));
      for (const f of added) f.by = "ai";
      if (store.undoStack.length > u0 + 1) store.undoStack.splice(u0 + 1);
      store.emit();
      await this.app.rebuild();
      return { ...out, addedFeatures: added.map((f) => f.name) };
    } catch (e) {
      store.project = store.fromSnapshot(snap);
      store.undoStack.splice(u0);
      store.redoStack = redo;
      if (this.app.cmdline) this.app.cmdline.ctx = ctx0;
      store.emit();
      try { await this.app.rebuild(); } catch { /* */ }
      throw e;
    }
  }
  async rebuildCheck(featureIds = null) {
    const errs = (await this.app.rebuild()) || [];
    const bad = featureIds ? errs.filter((x) => featureIds.includes(x.featureId)) : errs;
    if (bad.length) {
      const f = store.feature(bad[0].featureId);
      throw new Error(`${f ? f.name : "手順"} を計算できませんでした: ${bad[0].message}`);
    }
    return errs;
  }
  async runLine(line) {
    const cl = this.app.cmdline;
    if (!cl) throw new Error("コマンドの実行役がありません");
    return cl.run(line);
  }
  body(name) {
    const ms = this.app.meshes || [];
    const b = ms.find((m) => m.name === name) || ms.find((m) => m.id === name);
    if (!b) throw new Error(`ボディ「${name}」がありません（いまあるボディ: ${ms.map((m) => m.name).join("・") || "なし"}）`);
    return b;
  }

  // ---- 道具
  async exec(tool, a) {
    switch (tool) {
      case "get_state": return this.getState(a);
      case "create_box": return this.tx(() => this.createBox(a));
      case "create_sketch_extrude": return this.tx(() => this.sketchExtrude(a));
      case "create_hole": return this.tx(() => this.createHole(a));
      case "modify_feature": return this.tx(() => this.modifyFeature(a));
      case "run_commands": return this.tx(() => this.runCommands(a));
      case "undo": return this.undo(a);
      case "export_file": return this.exportFile(a);
      case "save_project": return this.saveProject(a);
      default: throw new Error(`知らない道具です: ${tool}`);
    }
  }

  async getState({ bodies: only } = {}) {
    const ms = (this.app.meshes || []).filter((m) => !only || only.includes(m.name));
    let list = [];
    if (ms.length) { const r = await call("measure", { ids: ms.map((m) => m.id), density: 1 }); list = r.list; }
    const props = store.project.bodyProps || {};
    const num = makeEvaluator(store.project.params || []);
    const bodies = list.map((b) => {
      const m = ms.find((x) => x.id === b.id) || {};
      const src = store.feature(m.src);
      return {
        name: b.name, id: b.id, createdBy: src ? src.name : null, hidden: !!m.hidden, material: (props[b.id] && props[b.id].material) || null,
        volume_mm3: +b.volume.toFixed(3), area_mm2: +b.area.toFixed(3),
        centroid_mm: b.com ? b.com.map((v) => +v.toFixed(4)) : null,
        bbox_mm: { min: b.bounds[0].map((v) => +v.toFixed(4)), max: b.bounds[1].map((v) => +v.toFixed(4)) },
        size_mm: b.bounds[1].map((v, i) => +(v - b.bounds[0][i]).toFixed(4)),
      };
    });
    const errs = new Map((this.app.errors || []).map((e) => [e.featureId, e.message]));
    const DIMS = { box: ["w", "d", "h", "position"], cylinder: ["d", "h", "position", "axis"], sphere: ["d", "position"], extrude: ["distance", "operation", "direction", "extent", "bodyName"], hole: ["d", "depth", "through", "pos", "cboreD", "cboreDepth", "csinkD"], fillet: ["radius"], chamfer: ["radius"], shell: ["thickness"], revolve: ["angle"] };
    const features = store.project.features.map((f, i) => {
      const o = { index: i, name: f.name, type: f.type, by: f.by || "human" };
      for (const k of DIMS[f.type] || []) if (f[k] !== undefined) o[k] = f[k];
      if (f.bodyName) o.bodyName = f.bodyName;
      if (f.suppressed) o.suppressed = true;
      if (errs.has(f.id)) o.error = errs.get(f.id);
      if (f.type === "sketch") {
        try {
          const an = analyzeSketch(f.entities || [], f.constraints || [], num, { checkConflict: true });
          o.plane = f.plane && (f.plane.type === "std" ? f.plane.name : f.plane.type);
          o.constraintStatus = { status: { full: "完全拘束", under: "拘束不足", over: "過拘束", conflict: "矛盾", empty: "図形なし" }[an.status] || an.status, dof: an.dof, constraints: an.count, missing: an.missing.map((m) => `${m.name}: ${m.what.join("・")}`) };
          const names = entityNames(f.entities || []);
          o.entities = (f.entities || []).map((e, k) => ({ name: names[k], type: e.type, ...Object.fromEntries(["x", "y", "w", "h", "cx", "cy", "d", "x1", "y1", "x2", "y2"].filter((q) => e[q] !== undefined).map((q) => [q, e[q]])) }));
        } catch { /* */ }
      }
      return o;
    });
    return { app: "GDC GOOD DESIGN CAD", version: AGENT_VERSION, units: "mm", document: store.project.name, params: store.project.params || [], bodies, features, undoSteps: store.undoStack.length, rollback: store.project.rollback };
  }

  async createBox(a) {
    const w = exprArg(a.width, "width（幅）", { positive: true }), d = exprArg(a.depth, "depth（奥行）", { positive: true }), h = exprArg(a.height, "height（高さ・厚さ）", { positive: true });
    const p = a.position || [0, 0, 0];
    if (!Array.isArray(p) || p.length !== 3) throw new Error("position は [x, y, z] で指定してください");
    const name = nameArg(a.name);
    if (name && (this.app.meshes || []).some((m) => m.name === name)) throw new Error(`「${name}」という名前のボディはもうあります`);
    const { newId } = await import("./store.js");
    const f = { id: newId(), type: "box", name: store.nameFor("box"), position: p.map((v, i) => exprArg(v, `position[${i}]`)), w, d, h, operation: "new", ...(name ? { bodyName: name } : {}), ...(store.project.activeComponent ? { component: store.project.activeComponent } : {}) };
    await this.app.cmdline.commitFeature(f);
    this.app.cmdline.ctx.lastBody = `B_${f.id}`;
    return { summary: `直方体 ${w}×${d}×${h} を作りました${name ? `（${name}）` : ""}`, feature: f.name, body: name || null };
  }

  async sketchExtrude(a) {
    const cl = this.app.cmdline;
    const shapes = a.profiles || a.shapes;
    if (!Array.isArray(shapes) || !shapes.length) throw new Error("profiles に長方形・円を 1 つ以上指定してください（例: [{\"type\":\"rect\",\"x\":0,\"y\":0,\"width\":60,\"height\":40}]）");
    const dist = a.through_all ? null : exprArg(a.distance, "distance（押し出す距離）");
    const op = a.operation || "new";
    if (!["new", "join", "cut", "intersect"].includes(op)) throw new Error("operation は new / join / cut / intersect のどれかです");
    const name = nameArg(a.name);
    if (name && op === "new" && (this.app.meshes || []).some((m) => m.name === name)) throw new Error(`「${name}」という名前のボディはもうあります`);
    // 1) スケッチ（平面 XY/XZ/YZ か、ボディの面）
    let planeLine;
    if (typeof a.plane === "string" || !a.plane) {
      const pl = String(a.plane || "XY").toUpperCase();
      if (!["XY", "XZ", "YZ"].includes(pl)) throw new Error("plane は XY / XZ / YZ、または {\"face\":\"上面\",\"body\":\"ボディ名\"} です");
      planeLine = `スケッチ ${pl}` + (a.offset ? ` オフセット ${numArg(a.offset, "offset")}` : "");
    } else {
      if (!FACES.includes(a.plane.face)) throw new Error(`面は ${FACES.join("・")} のどれかです`);
      this.body(a.plane.body);
      planeLine = `スケッチ ${a.plane.face} ${a.plane.body}`;
    }
    await this.runLine(planeLine);
    const skId = cl.ctx.sketch;
    // 2) 図形（数値は寸法拘束として記録。位置も固定 → 開くと「完全拘束」）
    const { newId } = await import("./store.js");
    const ents = [], cons = [];
    for (const [k, s] of shapes.entries()) {
      const id = newId("e");
      if (s.type === "rect") {
        const w = numArg(s.width, `profiles[${k}].width`, { positive: true }), h = numArg(s.height, `profiles[${k}].height`, { positive: true });
        let x = numArg(s.x ?? 0, `profiles[${k}].x`), y = numArg(s.y ?? 0, `profiles[${k}].y`);
        if (s.center) { x -= w / 2; y -= h / 2; }
        ents.push({ id, type: "rect", x: r6(x), y: r6(y), w, h });
        cons.push({ type: "dim", a: id, key: "w" }, { type: "dim", a: id, key: "h" }, { type: "fix", a: id, at: {} });
      } else if (s.type === "circle") {
        const d = numArg(s.diameter ?? (s.radius !== undefined ? numArg(s.radius, "radius", { positive: true }) * 2 : undefined), `profiles[${k}].diameter`, { positive: true });
        const cx = numArg(s.cx ?? s.x ?? 0, `profiles[${k}].cx`), cy = numArg(s.cy ?? s.y ?? 0, `profiles[${k}].cy`);
        ents.push({ id, type: "circle", cx, cy, d });
        cons.push({ type: "dim", a: id, key: "d" }, { type: "fix", a: id, at: { cx, cy } });
      } else throw new Error(`profiles[${k}].type は rect か circle です`);
    }
    store.commit((p) => { const sk = p.features.find((x) => x.id === skId); const n = normalizeSketch([...(sk.entities || []), ...ents], [...(sk.constraints || []), ...cons]); sk.entities = n.entities; sk.constraints = n.constraints; }, { silent: true });
    await this.rebuildCheck([skId]);
    // 3) 押し出し（「押し出し」コマンドと同じ実行役）
    const opWord = { new: "新規", join: "結合", cut: "切り取り", intersect: "交差" }[op];
    const line = a.through_all ? `押し出し 切り取り 全体` : `押し出し ${dist} ${opWord}` + (a.symmetric ? " 対称" : a.reverse ? " 反対" : "") + (name ? ` 名前 ${name}` : "");
    const msg = await this.runLine(line);
    const sk = store.feature(skId);
    const ex = [...store.project.features].reverse().find((f) => f.type === "extrude" && f.sketch === skId);
    if (!ex) throw new Error("押し出しを作れませんでした: " + msg);
    return { summary: `${sk.name} を描いて ${msg}`, sketch: sk.name, extrude: ex.name, body: ex.bodyName || null };
  }

  async createHole(a) {
    const b = this.body(a.body);
    const face = a.face || "上面";
    if (!FACES.includes(face)) throw new Error(`face は ${FACES.join("・")} のどれかです`);
    const d = numArg(a.diameter, "diameter（穴の直径）", { positive: true });
    const ps = a.positions;
    if (!Array.isArray(ps) || !ps.length || ps.some((p) => !Array.isArray(p) || p.length !== 2)) throw new Error("positions は [[x, y], ...]（面の角からの座標 mm）で指定してください");
    const pts = ps.map((p, k) => [numArg(p[0], `positions[${k}][0]`), numArg(p[1], `positions[${k}][1]`)]);
    const depth = a.depth !== undefined && a.depth !== null ? numArg(a.depth, "depth（深さ）", { positive: true }) : null;
    const line = `穴 ${face} Ø${d}${depth ? ` 深さ${depth}` : ""}${a.from === "origin" ? " 基準 原点" : ""} 位置 ${pts.map((p) => p.join(",")).join(" ")} ${b.name}`;
    const n0 = store.project.features.length;
    const msg = await this.runLine(line);
    const hf = store.project.features.slice(n0).find((f) => f.type === "hole");
    if (!hf) throw new Error("穴を作れませんでした: " + msg);
    return { summary: msg, feature: hf.name };
  }

  // 既にある手順の寸法を変えて、計算し直す
  async modifyFeature(a) {
    const target = String(a.target || a.feature || a.name || "");
    const set = a.set || a.changes;
    if (!target) throw new Error("target に手順の名前（押し出し1・穴1 など）かボディ名を指定してください");
    if (!set || typeof set !== "object" || !Object.keys(set).length) throw new Error("set に変える値を指定してください（例: {\"thickness\": 8}）");
    let f = store.project.features.find((x) => x.name === target);
    if (!f) { const m = (this.app.meshes || []).find((x) => x.name === target); if (m) f = store.feature(m.src); }
    if (!f) f = store.project.features.find((x) => x.bodyName === target);
    if (!f) throw new Error(`「${target}」という手順・ボディがありません（手順: ${store.project.features.map((x) => x.name).join("・")}）`);
    if (f.type === "sketch") return this.modifySketch(f, a);
    const ALIAS = {
      box: { width: "w", 幅: "w", w: "w", depth: "d", 奥行: "d", d: "d", height: "h", thickness: "h", 高さ: "h", 厚さ: "h", h: "h", position: "position", 位置: "position" },
      cylinder: { diameter: "d", 直径: "d", d: "d", height: "h", 高さ: "h", h: "h", position: "position" },
      sphere: { diameter: "d", 直径: "d", d: "d", position: "position" },
      extrude: { distance: "distance", thickness: "distance", height: "distance", 距離: "distance", 厚さ: "distance", 高さ: "distance" },
      hole: { diameter: "d", 直径: "d", d: "d", depth: "depth", 深さ: "depth", through: "through", 貫通: "through", positions: "pos", 位置: "pos" },
      fillet: { radius: "radius", R: "radius", 半径: "radius" }, chamfer: { distance: "radius", radius: "radius", C: "radius" },
      shell: { thickness: "thickness", 厚さ: "thickness" }, revolve: { angle: "angle", 角度: "angle" },
    }[f.type];
    if (!ALIAS) throw new Error(`「${f.name}」（${f.type}）の寸法はこの道具では変えられません。run_commands を使ってください`);
    const changes = {};
    for (const [k, v] of Object.entries(set)) {
      const fld = ALIAS[k];
      if (!fld) throw new Error(`「${f.name}」で変えられる項目: ${[...new Set(Object.keys(ALIAS).filter((q) => /^[a-z]/i.test(q)))].join(", ")}（受け取った: ${k}）`);
      if (fld === "through") { changes.through = !!v; continue; }
      if (fld === "position") { if (!Array.isArray(v) || v.length !== 3) throw new Error("position は [x, y, z]"); changes.position = v.map((q, i) => exprArg(q, `position[${i}]`)); continue; }
      if (fld === "pos") { if (!Array.isArray(v) || !v.length) throw new Error("positions は [[x, y], ...]"); changes.pos = v.map((p, i) => [numArg(p[0], `positions[${i}][0]`), numArg(p[1], `positions[${i}][1]`)]); continue; }
      changes[fld] = exprArg(v, k, { positive: fld !== "angle" });
    }
    if (f.type === "hole" && changes.depth !== undefined) changes.through = false;
    const before = Object.fromEntries(Object.keys(changes).map((k) => [k, f[k]]));
    store.commit((p) => { Object.assign(p.features.find((x) => x.id === f.id), changes); }, { silent: true });
    await this.rebuildCheck(); // どの手順でもエラーが出たら元に戻す
    return { summary: `${f.name}: ` + Object.entries(changes).map(([k, v]) => `${k} ${JSON.stringify(before[k])} → ${JSON.stringify(v)}`).join("、"), feature: f.name, before, after: changes };
  }

  // スケッチの図形の寸法（長方形の幅・高さ・位置、円の直径・中心）を変えて解き直す
  async modifySketch(f, a) {
    const names = entityNames(f.entities || []);
    const i = names.indexOf(String(a.entity || ""));
    if (i < 0) throw new Error(`entity に図形の名前を指定してください（${names.join("・") || "図形なし"}）`);
    const e = f.entities[i];
    const KEY = { width: "w", 幅: "w", height: "h", 高さ: "h", x: "x", y: "y", diameter: "d", 直径: "d", cx: "cx", cy: "cy" };
    const patch = {};
    for (const [k, v] of Object.entries(a.set)) { const fld = KEY[k]; if (!fld || e[fld] === undefined) throw new Error(`${names[i]}（${e.type}）で変えられる項目: ${Object.keys(KEY).filter((q) => /^[a-z]/.test(q) && e[KEY[q]] !== undefined).join(", ")}`); patch[fld] = exprArg(v, k, { positive: ["w", "h", "d"].includes(fld) }); }
    const ents = f.entities.map((x, k) => (k === i ? { ...x, ...patch } : x));
    // 位置を変えたときは固定の値も合わせる
    let cons = (f.constraints || []).map((c) => (c.type === "fix" && c.a === e.id && c.at && (patch.cx !== undefined || patch.cy !== undefined) ? { ...c, at: { ...c.at, ...(patch.cx !== undefined ? { cx: +patch.cx } : {}), ...(patch.cy !== undefined ? { cy: +patch.cy } : {}) } } : c));
    const num = makeEvaluator(store.project.params || []);
    const r = solveSketch(ents, cons, num);
    if (!r.ok) throw new Error("スケッチの拘束を満たせません（拘束が矛盾するか、寸法が無理な値です）");
    store.commit((p) => { const sk = p.features.find((x) => x.id === f.id); sk.entities = r.entities; sk.constraints = cons; }, { silent: true });
    await this.rebuildCheck();
    return { summary: `${f.name} の ${names[i]}: ` + Object.entries(patch).map(([k, v]) => `${k} → ${v}`).join("、"), feature: f.name };
  }

  // 「AI に頼む」と同じコマンド（1 行 1 指示）をまとめて実行。途中で失敗したら全部取り消す
  async runCommands(a) {
    const text = String(a.text || a.commands || "");
    if (!text.trim()) throw new Error("text にコマンドを書いてください（例: 板 幅600 奥行400 厚さ20 名前 床板）");
    const lines = text.split(/\r?\n/).map((s) => s.trim()).filter((s) => s && !s.startsWith("#"));
    if (lines.some((l) => /^(元に戻す|やり直し|undo|redo)/i.test(l))) throw new Error("取り消しは undo の道具を使ってください");
    const results = [];
    for (const l of lines) {
      try { results.push({ line: l, ok: true, msg: await this.runLine(l) }); }
      catch (e) { results.push({ line: l, ok: false, msg: e.message }); throw Object.assign(new Error(`「${l}」で止まりました: ${e.message}（この道具の操作はすべて取り消しました）`), { results }); }
    }
    return { summary: `${lines.length} 行を実行しました`, results };
  }

  async undo(a) {
    if (this.app.mode === "sketch") throw new Error("画面でスケッチを編集中です");
    const n = Math.max(1, Math.min(50, Math.round(+a.steps || 1)));
    let k = 0; for (; k < n && store.undoStack.length; k++) store.undo();
    await this.app.rebuild();
    return { summary: k ? `${k} 手取り消しました` : "取り消せる操作がありません", undone: k };
  }

  async exportFile(a) {
    const fmt = String(a.format || "").toLowerCase();
    if (!["step", "stl"].includes(fmt)) throw new Error("format は step か stl です");
    const ids = Array.isArray(a.bodies) && a.bodies.length ? a.bodies.map((n) => this.body(n).id) : [];
    if (!(this.app.meshes || []).length) throw new Error("書き出すボディがありません");
    let buf = await call("export", { ids, format: fmt });
    if (fmt === "step") buf = this.stepUnicode(buf);
    const bytes = new Uint8Array(await new Blob([buf]).arrayBuffer());
    const base = (nameArg(a.file_name, "file_name") || store.project.name || "model").replace(/[\\/:*?"<>|]/g, "_");
    const out = { summary: `${fmt.toUpperCase()} を書き出しました（${bytes.length} バイト）`, format: fmt, file: { name: `${base}.${fmt}`, base64: toBase64(bytes) }, bytes: bytes.length };
    if (fmt === "step" && a.verify !== false) {
      // 書き出した STEP を形状エンジンで読み戻し、体積が元と一致するか確かめる
      const ab = bytes.slice().buffer;
      const r = await call("verifyStep", { buffer: ab, ids }, [ab]);
      out.verify = { ok: !!r.ok, readback_volume_mm3: +(+r.volume).toFixed(3), model_volume_mm3: +(+r.expected).toFixed(3), diff_percent: r.expected ? +(Math.abs(r.volume - r.expected) / r.expected * 100).toFixed(5) : 0 };
      out.summary += out.verify.ok ? "。読み戻して体積の一致を確認しました" : "。注意: 読み戻した体積が一致しません";
    }
    return out;
  }

  async saveProject(a) {
    const base = (nameArg(a.file_name, "file_name") || store.project.name || "無題").replace(/[\\/:*?"<>|]/g, "_");
    const json = JSON.stringify(store.project);
    return { summary: `${base}.kcad を書き出しました（${store.project.features.length} 手順）`, file: { name: `${base}.kcad`, base64: toBase64(new TextEncoder().encode(json)) }, features: store.project.features.length };
  }
}

function toBase64(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
function escapeHtml(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
