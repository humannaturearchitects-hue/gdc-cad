// 図面: 穴の位置寸法（累進寸法）・穴記号・穴表
// 穴の情報は形状エンジン（kernel/panel.js の holesOf）から受け取る

const CAMS = { front: [[0, -1, 0], [1, 0, 0]], top: [[0, 0, 1], [1, 0, 0]], right: [[1, 0, 0], [0, 1, 0]], iso: [[1, -1, 1], [1, 1, 0]] };
const BLUE = "#1a5fb4";
export const viewDir = (v) => (CAMS[v] && v !== "iso" ? CAMS[v][0] : null);

// 3D 点 → 各ビューの 2D 座標（投影と同じ向き）
export function project2D(v, p) {
  const [d0, x0] = CAMS[v] || CAMS.front;
  const n = (a) => { const L = Math.hypot(...a); return a.map((c) => c / L); };
  const d = n(d0), x = n(x0);
  const y = n([d[1] * x[2] - d[2] * x[1], d[2] * x[0] - d[0] * x[2], d[0] * x[1] - d[1] * x[0]]);
  return [p[0] * x[0] + p[1] * x[1] + p[2] * x[2], p[0] * y[0] + p[1] * y[1] + p[2] * y[2]];
}

// そのビューで円に見える穴（軸が視線と平行）
export function holesInView(holes, v) {
  const d = CAMS[v] && CAMS[v][0];
  if (!d || v === "iso") return [];
  const out = [];
  for (const h of holes) {
    const a = h.axis;
    if (Math.abs(Math.abs(a[0] * d[0] + a[1] * d[1] + a[2] * d[2]) - 1) > 1e-4) continue;
    const p = project2D(v, h.p0);
    if (out.some((q) => Math.hypot(q.p[0] - p[0], q.p[1] - p[1]) < 1e-3 && q.h.dia === h.dia)) continue;
    out.push({ p, h, fromView: (a[0] * d[0] + a[1] * d[1] + a[2] * d[2]) < 0 });
  }
  return out;
}

const f1 = (v) => (+(+v).toFixed(1)).toString();

// 穴の呼び: Ø8 貫通 / Ø10 深さ10 / Ø6.6 貫通 ざぐりØ11 深さ6.5
export function holeSpec(h) {
  if (h.rect) return `□${f1(h.rect[0])}×${f1(h.rect[1])} ${h.through ? "貫通" : `${h.side === "裏" ? "裏から" : ""}深さ${h.depth == null ? "?" : f1(h.depth)}`}`;
  let s = `Ø${f1(h.dia)} ${h.through ? "貫通" : "深さ" + f1(h.cbore ? h.depth - h.cbore.depth : h.depth)}`;
  if (h.cbore) s += ` ざぐりØ${f1(h.cbore.dia)} 深さ${f1(h.cbore.depth)}`;
  if (h.csink) s += ` 皿Ø${f1(h.csink.dia)}`;
  return s;
}
const specKey = (h) => holeSpec(h);

// 穴の種類ごとに記号 A, B, C …、同じ種類の中で番号 A1, A2 …
export function labelHoles(list) {
  const kinds = [];
  for (const it of list) { const k = specKey(it.h); if (!kinds.includes(k)) kinds.push(k); }
  const letter = (i) => (i < 26 ? String.fromCharCode(65 + i) : "H" + (i + 1));
  const sorted = [...list].sort((a, b) => kinds.indexOf(specKey(a.h)) - kinds.indexOf(specKey(b.h)) || a.p[1] - b.p[1] || a.p[0] - b.p[0]);
  const cnt = {};
  for (const it of sorted) { const k = specKey(it.h); const L = letter(kinds.indexOf(k)); cnt[L] = (cnt[L] || 0) + 1; it.label = L + cnt[L]; it.kind = L; }
  return { sorted, kinds: kinds.map((k, i) => ({ letter: letter(i), spec: k, n: list.filter((it) => specKey(it.h) === k).length })) };
}

// 図面上の穴の半径（角穴は対角の半分）
export const holeRadius = (h) => (h.rect ? Math.hypot(h.rect[0], h.rect[1]) / 2 : (h.cbore ? h.cbore.dia : h.dia) / 2);

// 穴の呼び（引出線）: 種類ごとに 1 つ「4×Ø8 貫通」
export function holeCallouts(sheet, items, info) {
  const groups = new Map();
  for (const it of items) { const k = specKey(it.h); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(it); }
  const D = sheet.layers.DIM.prims;
  for (const [spec, g] of groups) {
    // 右上にある穴から引き出す
    const it = g.slice().sort((a, b) => (b.p[0] + b.p[1]) - (a.p[0] + a.p[1]))[0];
    const r = holeRadius(it.h) * info.sc;
    const cx = info.ox + it.p[0] * info.sc, cy = info.oy + it.p[1] * info.sc;
    const lx = it.h.rect ? cx + it.h.rect[0] / 2 * info.sc : cx + r * 0.7071, ly = it.h.rect ? cy + it.h.rect[1] / 2 * info.sc : cy + r * 0.7071;
    const text = `${g.length > 1 ? g.length + "×" : ""}${spec}`;
    const tw = text.length * 2.2;
    D.push({ t: "line", a: [lx, ly], b: [lx + 4, ly + 4] }, { t: "line", a: [lx + 4, ly + 4], b: [lx + 6 + tw, ly + 4] });
    sheet.texts.push({ x: lx + 5, y: ly + 4.8, text, size: 2.5, color: BLUE, layer: "DIM" });
  }
}

// 穴記号（A1 …）を穴の横に
export function holeTags(sheet, items, info) {
  for (const it of items) {
    const r = (it.h.rect ? it.h.rect[0] / 2 : holeRadius(it.h)) * info.sc;
    const ry = (it.h.rect ? it.h.rect[1] / 2 : holeRadius(it.h)) * info.sc;
    const cx = info.ox + it.p[0] * info.sc, cy = info.oy + it.p[1] * info.sc;
    sheet.texts.push({ x: cx - r - 0.6, y: cy - ry - 2.2, text: it.label, size: 2, anchor: "end", color: BLUE, layer: "DIM" });
  }
}

// 累進寸法（基準 = ビューの左下の角）: 上側に X、右側に Y
export function ordinateDims(sheet, items, info, bb) {
  const D = sheet.layers.DIM.prims;
  const xs = uniq(items.map((it) => it.p[0] - bb.min[0]));
  const ys = uniq(items.map((it) => it.p[1] - bb.min[1]));
  const X = (x) => info.ox + (bb.min[0] + x) * info.sc, Y = (y) => info.oy + (bb.min[1] + y) * info.sc;
  const top = Y(bb.max[1] - bb.min[1]), right = X(bb.max[0] - bb.min[0]);
  const yl = top + 8, xl = right + 8;
  // X 方向
  if (xs.length) {
    const all = [0, ...xs.filter((x) => x > 1e-6)];
    const xmax = Math.max(...all);
    D.push({ t: "line", a: [X(0), yl], b: [X(xmax), yl] });
    D.push({ t: "arc", c: [X(0), yl], r: 0.9, s: 0, d: Math.PI * 2 });
    D.push({ t: "line", a: [X(0), top + 1], b: [X(0), yl + 1.5] });
    sheet.texts.push({ x: X(0) - 1.5, y: yl + 1.5, text: "0", size: 2.5, anchor: "end", color: BLUE, layer: "DIM" });
    for (const x of all.slice(1)) {
      const pts = items.filter((it) => Math.abs(it.p[0] - bb.min[0] - x) < 1e-3).map((it) => it.p[1]);
      const from = info.oy + Math.max(...pts) * info.sc;
      D.push({ t: "line", a: [X(x), from + 1], b: [X(x), yl + 1.5] });
      arrow(sheet, [X(x), yl], [1, 0]);
      sheet.texts.push({ x: X(x) - 0.7, y: yl + 2, text: f1(x), size: 2.5, rot: 90, color: BLUE, layer: "DIM" });
    }
  }
  if (ys.length) {
    const all = [0, ...ys.filter((y) => y > 1e-6)];
    const ymax = Math.max(...all);
    D.push({ t: "line", a: [xl, Y(0)], b: [xl, Y(ymax)] });
    D.push({ t: "arc", c: [xl, Y(0)], r: 0.9, s: 0, d: Math.PI * 2 });
    D.push({ t: "line", a: [right + 1, Y(0)], b: [xl + 1.5, Y(0)] });
    sheet.texts.push({ x: xl + 2, y: Y(0) - 3, text: "0", size: 2.5, color: BLUE, layer: "DIM" });
    for (const y of all.slice(1)) {
      const pts = items.filter((it) => Math.abs(it.p[1] - bb.min[1] - y) < 1e-3).map((it) => it.p[0]);
      const from = info.ox + Math.max(...pts) * info.sc;
      D.push({ t: "line", a: [from + 1, Y(y)], b: [xl + 1.5, Y(y)] });
      arrow(sheet, [xl, Y(y)], [0, 1]);
      sheet.texts.push({ x: xl + 2, y: Y(y) - 0.9, text: f1(y), size: 2.5, color: BLUE, layer: "DIM" });
    }
  }
  return { xs: xs.length, ys: ys.length };
}

function uniq(a) {
  const out = [];
  for (const v of a.sort((x, y) => x - y)) if (!out.length || Math.abs(out[out.length - 1] - v) > 1e-3) out.push(v);
  return out;
}

export function uniqueCounts(items, bb) {
  return [uniq(items.map((it) => it.p[0] - bb.min[0])).length, uniq(items.map((it) => it.p[1] - bb.min[1])).length];
}

function arrow(sheet, tip, dir) {
  const L = 2.2, Wd = 0.55;
  const n = [-dir[1], dir[0]];
  const b = [tip[0] - dir[0] * L, tip[1] - dir[1] * L];
  sheet.fills.push({ pts: [tip, [b[0] + n[0] * Wd, b[1] + n[1] * Wd], [b[0] - n[0] * Wd, b[1] - n[1] * Wd]], color: BLUE, layer: "DIM" });
}

// 穴表（下端 y0 から上へ）。rows: [{label, x, y, spec}]
export const HOLE_TABLE_W = 120;
export function holeTable(sheet, rows, x0, y0, title = "穴表（基準: 左下の角, mm）") {
  const B = sheet.layers.BORDER.prims;
  const rh = 5, w = HOLE_TABLE_W, cols = [0, 14, 34, 54, w];
  const heads = ["記号", "X", "Y", "穴"];
  const n = rows.length, h = (n + 1) * rh;
  for (let k = 0; k <= n + 1; k++) B.push({ t: "line", a: [x0, y0 + k * rh], b: [x0 + w, y0 + k * rh] });
  for (const c of cols) B.push({ t: "line", a: [x0 + c, y0], b: [x0 + c, y0 + h] });
  const rowY = (k) => y0 + h - (k + 1) * rh + 1.5;
  heads.forEach((t, k) => sheet.texts.push({ x: x0 + cols[k] + 1.5, y: rowY(0), text: t, size: 2.4 }));
  rows.forEach((r, k) => {
    const y = rowY(k + 1);
    [r.label, f1(r.x), f1(r.y), r.spec].forEach((t, c) => sheet.texts.push({ x: x0 + cols[c] + 1.5, y, text: t, size: 2.4 }));
  });
  sheet.texts.push({ x: x0, y: y0 + h + 1.8, text: title, size: 2.8 });
  return h + 6;
}
