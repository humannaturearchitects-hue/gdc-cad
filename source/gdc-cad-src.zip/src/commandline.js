// 言葉で操作するコマンド入力（ソフトの中だけで動く。外部には何も送らない）
// 1 行に 1 つの指示。複数行は上から順に実行（手描きスケッチから作った「手順」を貼り付けて立体にできる）
import { store, newId } from "./store.js";
import { call } from "./kernel.js";
import { esc } from "./commands.js";
import { Voice } from "./voice.js";
import { AI_MODELS } from "./ai.js";
import { panelCommand } from "./panelfurn.js";
import { interpret, buildContext } from "./nlu.js";
import { looksLikeCommand } from "./pasteai.js";
import { getBrain, setBrain, askBrain, brainCan, prepareLocal, offerLocal, nluUnderstands, runPaste, brainSettingsHTML, wireBrainSettings } from "./brains.js";

const HELP = `【形を作る】
板 幅600 奥行400 厚さ20 [位置 0,0,0] [名前 床板]      （直方体 600x400x20 でも可）
円柱 直径50 高さ100 [位置 100,100,0] [軸 Z]
【スケッチ】
スケッチ XY | XZ | YZ | 上面 | 下面 | 前面 | 背面 | 左面 | 右面 [ボディ名] [オフセット 50]
長方形 0,0 600,400   /   長方形 中心 300,200 幅100 高さ50   /   長方形 10,10 幅100 高さ50
円 100,100 直径50   /   円 中心 100,100 半径25
線 0,0 100,0 100,50 0,50 閉じる
円弧 0,0 50,20 100,0（始点 通過点 終点）   /   点 30,25 270,25
押し出し 20 [結合 | 切り取り | 交差 | 新規] [対称 | 反対] [全体] [名前 天板]
【加工】
穴 上面 Ø8 位置 30,25 270,25 270,175 30,175 [深さ10 | 貫通] [ざぐり径14 ざぐり深さ5 | 皿径16] [基準 原点] [ボディ名]
フィレット R5 縦の辺 | 上の辺 | 下の辺 | 水平の辺 | すべての辺 [ボディ名]
面取り C3 上の辺 [ボディ名]
ビス接合 側板 棚板 [Ø4] [皿径8] [下穴Ø3 深さ30] [個数3]（突き当たる板に同じ位置の穴）／ 板厚 18 を 20 に [ボディ名]
【直す（言葉で修正）】
床板 厚さ 30 ／ 床板の厚さを30に ／ 柱 高さ 150 ／ 穴1 径 10 ／ 穴1 深さ 5 ／ フィレット1 R 8
押し出し2 距離 40 ／ 穴1 位置 40,30 260,30（ボディ名・タイムラインの名前で指定）
【書き出し】
STEP で書き出し ／ STL で書き出し ／ 図面 PDF ／ 図面 DXF（そのまま他の人に渡せるデータ）
【その他】
移動 床板 0,0,100   /   コピー 床板 0,500,0   /   削除 床板
置く 柱 位置 100,100,20 ／ 置く 側板 上 床板 中央 ／ 回す 柱 90 軸 Z
部品一覧（同じ部品を数える）／ 色 青 床板 側板 ／ 視点 上 ／ 元に戻す 3
パラメータ 幅 = 600（以後 幅 や 幅/2 を数値の代わりに使える）
コンポーネント 天井ユニット（作って有効に）
元に戻す　　　# から始まる行はメモ（実行しない）`;

// 全角→半角、記号のゆれをそろえる
function norm(s) {
  return s.replace(/[０-９Ａ-Ｚａ-ｚ]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0))
    .replace(/[，、]/g, ",").replace(/．/g, ".").replace(/[＝]/g, "=").replace(/[：]/g, ":").replace(/[（]/g, "(").replace(/[）]/g, ")")
    .replace(/[－−ー](?=\d)/g, "-").replace(/[×＊]/g, "x").replace(/[Øøφ⌀]/g, "Ø")
    // 単位: cm・m は mm に直す（60cm → 600、1.2m → 1200）
    .replace(/(\d+(?:\.\d+)?)\s*(?:cm|センチ)(?![A-Za-z])/gi, (_, n) => String(+(n * 10).toFixed(6)))
    .replace(/mm/gi, "")
    .replace(/(\d+(?:\.\d+)?)\s*(?:m|メートル)(?![A-Za-z])/g, (_, n) => String(+(n * 1000).toFixed(6))).replace(/　/g, " ").trim();
}
const NUMX = "[-+]?[0-9.]+|[^\\s,()=:]+";
// キーワードの後ろの値（数値・式・パラメータ名）
function kv(line, keys) {
  const m = line.match(new RegExp(`(?:${keys})\\s*[:=を]?\\s*(${NUMX})`));
  return m ? m[1].replace(/(に|へ)$/, "") : null;
}
// 座標のならび "x,y" または "x,y,z"
function pairs(s) {
  // 数値・パラメータ名・式（幅-穴位置、幅/2 など）を「,」区切りで
  const out = []; const re = /(?:^|\s)([^\s,]+)\s*,\s*([^\s,]+)(?:\s*,\s*([^\s,]+))?(?=\s|$)/g;
  const ok = (v) => /^[-+*/().0-9\p{L}_]+$/u.test(v) && /[0-9\p{L}]/u.test(v) && !/^(位置|中心|座標|原点|基準)/.test(v);
  let m; while ((m = re.exec(s))) { const p = m[3] !== undefined ? [m[1], m[2], m[3]] : [m[1], m[2]]; if (p.every(ok)) out.push(p); re.lastIndex = m.index + m[0].length; }
  return out;
}
const COL = { 赤: "#d23b3b", 青: "#2f6fd0", 緑: "#2e9e5b", 黄: "#e8c22a", 黄色: "#e8c22a", 白: "#f2f2f2", 黒: "#2b2b2b", 灰: "#8a929c", グレー: "#8a929c", 灰色: "#8a929c", オレンジ: "#e8732a", 茶: "#8a5a32", 茶色: "#8a5a32", 木: "#c8a06a", 木目: "#c8a06a", 紫: "#8a4dca", 水色: "#5fb2e8", ピンク: "#e87aa8" };
const COLOR_HELP = "色の名前（赤・青・緑・黄・白・黒・グレー・オレンジ・茶・木・紫・水色・ピンク）か #3366cc のように書いてください";
function colorOf(L) { return (L.match(/#[0-9a-fA-F]{6}/) || [])[0] || Object.entries(COL).sort((a, b) => b[0].length - a[0].length).find(([k]) => L.includes(k))?.[1] || null; }
const FACES = { 上面: [2, 1], 下面: [2, -1], 前面: [1, -1], 背面: [1, 1], 後面: [1, 1], 左面: [0, -1], 右面: [0, 1] };

const OFFLINE_EX = ["幅60センチ奥行き40で厚さ2センチの床板を作って", "それの四隅に8ミリの穴を端から3センチで", "全部の角をR5で", "床板の重さは？", "さっきの取り消して"];
export class CommandLine {
  constructor(app) { this.app = app; this.ctx = { sketch: null, lastBody: null }; this.history = []; this.voice = new Voice(); this.queryOut = []; }
  aiKey() { try { return localStorage.getItem("gdc-ai-key") || ""; } catch { return ""; } }
  aiModel() { try { return localStorage.getItem("gdc-ai-model") || AI_MODELS[0][0]; } catch { return AI_MODELS[0][0]; } }
  // AI に渡す「今のモデル」の概要（手順・ボディの外形と位置・材料と重さ・パラメータ・選択中のもの）
  // 短く・決まった形で（AI への送信量を抑え、返事を速く）
  async aiContext() {
    const p = store.project, ms = this.app.meshes, N = (v) => +(+v).toFixed(1);
    const lines = [];
    if ((p.params || []).length) lines.push("[パラメータ] " + p.params.map((q) => `${q.name}=${q.expr}`).join("、"));
    if ((p.components || []).length) lines.push("[コンポーネント] " + p.components.map((c) => c.name + (c.id === p.activeComponent ? "（有効・新しい形はここに入る）" : "")).join("、"));
    lines.push("[手順]（# [名前] はタイムラインの名前。直すときはこの名前かボディ名を使う）", this.toScript({ annotate: true }));
    if (ms.length) {
      try {
        const r = await call("measure", { ids: ms.map((m) => m.id), density: 1 });
        lines.push("[ボディ] 名前: 外形 X×Y×Z mm、範囲 X x0〜x1 Y y0〜y1 Z z0〜z1、体積、材料、重さ");
        let tw = 0;
        for (const b of r.list) {
          const m = ms.find((x) => x.id === b.id) || {}, dens = (m.material && m.material.density) || 1, kg = b.volume / 1e6 * dens; tw += kg;
          const [lo, hi] = b.bounds;
          const comp = m.component && (p.components || []).find((c) => c.id === m.component);
          lines.push(`${b.name}: ${N(hi[0] - lo[0])}×${N(hi[1] - lo[1])}×${N(hi[2] - lo[2])}、範囲 X ${N(lo[0])}〜${N(hi[0])} Y ${N(lo[1])}〜${N(hi[1])} Z ${N(lo[2])}〜${N(hi[2])}、${N(b.volume / 1000)} cm³、${m.material && m.material.name ? m.material.name : "材料未設定"}（密度 ${dens}）、${+kg.toFixed(3)} kg${m.hidden ? "、非表示" : ""}${comp ? "、" + comp.name + " の中" : ""}`);
        }
        lines.push(`[合計] ボディ ${r.list.length} 個、重さ ${+tw.toFixed(3)} kg`);
      } catch { lines.push("[ボディ] " + ms.map((m) => m.name).join("、")); }
    } else lines.push("[ボディ] まだありません");
    // 画面で選んでいるもの（「これ」「ここ」）
    const sel = this.app.selection || [], nm = (id) => ms.find((m) => m.id === id)?.name || "?";
    const sb = [...new Set(sel.filter((x) => x.kind === "body").map((x) => nm(x.bodyId)))];
    const sf = sel.filter((x) => x.kind === "face").map((x) => { const fp = this.selectedFace(ms.find((m) => m.id === x.bodyId)) || {}; return `${nm(x.bodyId)} の${fp.name || "面"}（面上の点 ${x.point.map(N).join(",")}）`; });
    const se = sel.filter((x) => x.kind === "edge").map((x) => `${nm(x.bodyId)} の辺（${x.dir && Math.abs(x.dir[2]) > 0.99 ? "縦" : x.dir && Math.abs(x.dir[2]) < 0.01 ? "水平" : "斜め"}、点 ${x.point.map(N).join(",")}）`);
    const sp = sel.filter((x) => x.kind === "profile").length;
    if (sb.length || sf.length || se.length || sp) lines.push("[いま選択中]（「これ」「ここ」「選んだもの」はこれ。コマンドでボディ名を省くと、これが対象になる） " + [sb.length ? "ボディ " + sb.join("、") : "", sf.length ? "面 " + sf.join("、") : "", se.length ? `辺 ${se.length} 本: ` + se.slice(0, 6).join("、") : "", sp ? `スケッチの領域 ${sp} 個` : ""].filter(Boolean).join("／"));
    else lines.push("[いま選択中] なし");
    if (this.ctx.sketch && store.feature(this.ctx.sketch)) lines.push(`[描いている途中のスケッチ] ${store.feature(this.ctx.sketch).name}（長方形・円などを足すと、ここに入る）`);
    if (this.lastBatch && this.lastBatch.end === store.undoStack.length && this.lastBatch.n) lines.push(`[直前の頼みごと] ${this.lastBatch.n} 回分の変更をしました（全部取り消すなら「元に戻す ${this.lastBatch.n}」）`);
    return lines.join("\n");
  }
  // 自由な言葉 → AI → コマンド → 実行（止まったら 1 回だけ AI に直してもらう）
  // 直前までの会話（this.chat）も AI に渡すので、「それを 2 倍に」「（聞き返しへの答え）30 で」が通じる
  // 「重さは？」のように調べるコマンドを使ったときは、その結果を AI に返して、数値で答えてもらう
  async runAI(text, { autoRun = true } = {}) {
    const instruction = String(text || "").trim(); if (!instruction) return [];
    this.chat = this.chat || [];
    this.log(esc(instruction), "me");
    // どの頭脳に聞くか（⚙ 設定の「AI の種類」）。端末内 AI が使えない・まだ無い・準備中なら、端末の中の読み取り（nlu.js）で
    const brain = getBrain(), can = brainCan(brain);
    if (brain === "nlu") return this.runNLU(instruction, { echo: false });
    if (brain === "paste") return runPaste(this, instruction);
    if (brain === "local" && looksLikeCommand(instruction)) return this.runText(instruction, { compact: true }); // 決まった書き方ならそのまま
    // 端末内 AI: まず端末の中の読み取り（nlu）。そのまま実行できるならそれで（速く確実）。聞き返し・分からないときだけ AI に
    const nr = brain === "local" ? await nluUnderstands(this, instruction) : null;
    if (nr && nr.sure) return this.runNLU(instruction, { echo: false });
    if (brain === "local") {
      const r = await prepareLocal(this, { wait: false, ask: false });
      if (!r.ok) { const res = await this.runNLU(instruction, { echo: false, note: r.offer ? "" : r.reason + (r.pending ? "" : "（AI を使わずに読み取って実行します）") }); if (r.offer && nr.unknown) offerLocal(this); return res; }
    }
    if (brain === "claude" && typeof navigator !== "undefined" && navigator.onLine === false) return this.runNLU(instruction, { echo: false, note: "インターネットにつながっていないため、AI を使わずに読み取って実行します" });
    const thinking = document.createElement("div"); thinking.className = "cmd-item ai thinking"; thinking.textContent = brain === "local" ? "🤖 考えています…（端末内 AI）" : brain === "pc" ? "🤖 考えています…（パソコンの AI）" : "🤖 考えています…";
    document.getElementById("cmd-log")?.appendChild(thinking);
    // 返事を待っている間は「やめる」で止められる。電波が切れたらすぐ知らせる（待たせたままにしない）
    const ac = new AbortController(); this.aiAbort = ac;
    const stopBtn = document.createElement("button"); stopBtn.className = "btn ai-stop"; stopBtn.textContent = "やめる";
    stopBtn.onclick = () => ac.abort(new Error("AI への依頼をやめました"));
    const onOffline = () => ac.abort(new Error("インターネット接続が切れたため、AI への依頼を止めました。つながってからもう一度送ってください（入力した言葉は残っています）"));
    window.addEventListener("offline", onOffline);
    const showStop = (el) => { el.append(" ", stopBtn); };
    showStop(thinking);
    const busy = (on) => { document.getElementById("cmd-run")?.toggleAttribute("disabled", on); if (!on) thinking.remove(); };
    busy(true);
    const ask = async (extra) => askBrain(this, brain, { instruction, history: can.history ? this.chat.slice(-12) : [], signal: ac.signal, ...extra });
    try { return await this.runAIInner(instruction, { autoRun, ask, busy, showStop, nr, can }); }
    finally { window.removeEventListener("offline", onOffline); if (this.aiAbort === ac) this.aiAbort = null; }
  }
  async runAIInner(instruction, { autoRun, ask, busy, showStop, nr, can }) {
    let ans;
    try { ans = await ask(); } catch (e) {
      busy(false); this.log("✗ " + esc(e.message), "ai err");
      // 利用者が「やめる」を押した・電波が切れたときは、読み取りで勝手に実行しない（入力した言葉は入力欄に戻す）
      if (e && (e.name === "AbortError" || /やめました|止めました/.test(e.message || ""))) return [{ ok: false, line: instruction, error: e.message }];
      // AI が使えないときは、端末の中の読み取り（nlu.js）で続ける
      return this.runNLU(instruction, { echo: false, note: "AI が使えないため、AI を使わずに読み取って実行します" });
    }
    busy(false);
    // 端末内 AI も聞き返す・数値が怪しいときで、読み取りが聞き返せるなら、読み取りの質問を使う（会話の続きもそちらで）
    if (nr && nr.asks && (ans.question || ans.confirm || !ans.commands)) return this.runNLU(instruction, { echo: false });
    this.chat.push({ role: "user", content: instruction }, { role: "assistant", content: ans.raw || JSON.stringify({ commands: ans.commands, explanation: ans.explanation, question: ans.question }) });
    const showCmds = (c) => c ? `<details class="ai-cmds"><summary>行った操作</summary><pre class="cmd-help">${esc(c)}</pre></details>` : "";
    if (ans.question) { this.log("🤖 " + esc(ans.question), "ai q"); return [{ line: instruction, ok: false, msg: ans.question, question: true }]; }
    this.log("🤖 " + esc(ans.explanation || "") + showCmds(ans.commands), "ai");
    if (!ans.commands) return [{ line: instruction, ok: true, msg: ans.explanation }];
    const ta = document.getElementById("cmd-in");
    if (!autoRun || ans.confirm) {
      this.pendingAI = ans.commands;
      this.log(`<button class="btn primary" data-ai-go>この内容で実行</button>`, "ai");
      const b = [...document.querySelectorAll("[data-ai-go]")].pop();
      if (b) b.onclick = async () => { b.disabled = true; const u0 = store.undoStack.length; this.queryOut = []; await this.runText(ans.commands, { compact: true }); this.afterBatch(u0); };
      return [{ line: instruction, ok: true, msg: "確認待ち" }];
    }
    const u0 = store.undoStack.length;
    this.queryOut = [];
    let r = await this.runText(ans.commands, { compact: true });
    const bad = r.find((x) => !x.ok);
    if (bad && can.fix) {
      const t2 = document.createElement("div"); t2.className = "cmd-item ai thinking"; t2.textContent = "🤖 うまくいかなかったところを直しています…"; showStop(t2);
      document.getElementById("cmd-log")?.appendChild(t2);
      try {
        const done = r.filter((x) => x.ok).map((x) => x.line);
        const fix = await ask({ retry: { commands: ans.commands, line: bad.line, message: bad.msg, done } });
        t2.remove();
        this.chat.push({ role: "user", content: `（実行したら「${bad.line}」で止まりました: ${bad.msg}）` }, { role: "assistant", content: fix.raw || fix.commands });
        if (fix.question) { this.log("🤖 " + esc(fix.question), "ai q"); this.afterBatch(u0, true); return r; }
        this.log("🤖 " + esc(fix.explanation || "") + showCmds(fix.commands), "ai");
        if (fix.commands) r = [...r.filter((x) => x.ok), ...(await this.runText(fix.commands, { compact: true, keepQuery: true }))];
      } catch (e) { t2.remove(); this.log("✗ " + esc(e.message), "ai err"); }
    }
    const failed = r.some((x) => !x.ok);
    // 調べた結果（重さ・大きさ・数 など）を AI に返して、質問にはっきり答えてもらう
    if (!failed && this.queryOut.length && can.summarize) {
      const results = this.queryOut.join("\n"); this.queryOut = [];
      const t3 = document.createElement("div"); t3.className = "cmd-item ai thinking"; t3.textContent = "🤖 結果をまとめています…"; showStop(t3);
      document.getElementById("cmd-log")?.appendChild(t3);
      try {
        const a = await ask({ results });
        t3.remove();
        this.chat.push({ role: "user", content: `（調べた結果）\n${results}` }, { role: "assistant", content: a.raw || a.explanation });
        if (a.explanation) this.log("🤖 " + esc(a.explanation), "ai answer");
      } catch (e) { t3.remove(); this.log("✗ " + esc(e.message), "ai err"); }
    }
    this.afterBatch(u0, failed);
    if (ta) ta.value = "";
    return r;
  }
  // AI を使わない読み取り（src/nlu.js）: ふだんの言葉 → 決まった書き方のコマンド → 実行。返事・聞き返しを会話に出す
  // 無料・即時・オフライン（何も外に送らない）。決まった書き方の行はそのまま通る
  async runNLU(text, { echo = true, note = "" } = {}) {
    const t = String(text || "").trim(); if (!t) return [];
    const btn = document.getElementById("cmd-run"); btn?.setAttribute("disabled", "");
    try { return await this.runNLUInner(t, { echo, note }); } finally { btn?.removeAttribute("disabled"); }
  }
  async runNLUInner(t, { echo, note }) {
    if (echo) this.log(esc(t), "me");
    if (note) this.log(esc(note), "ai note");
    const useNlu = this.ctx.lastBody && this.ctx.lastBody !== this.nluSeenId ? null : this.nluLast;
    const context = await buildContext({ app: this.app, store, call, ctx: this.ctx, pending: this.nluPending, lastName: useNlu });
    let r;
    try { r = interpret(t, context); } catch (e) { r = { lines: [], ask: "うまく読み取れませんでした（" + e.message + "）" }; }
    this.nluPending = r.pending || null;
    const cmds = r.lines.join("\n");
    if (r.reply || r.lines.length) this.log("💬 " + esc(r.reply || "") + (cmds ? `<details class="ai-cmds"><summary>行った操作</summary><pre class="cmd-help">${esc(cmds)}</pre></details>` : ""), "ai nlu");
    let res = [];
    if (r.lines.length) {
      const u0 = store.undoStack.length;
      res = await this.runText(cmds, { compact: true });
      this.afterBatch(u0, res.some((x) => !x.ok));
    }
    if (r.ask) { this.log("💬 " + esc(r.ask), "ai q"); res.push({ line: t, ok: false, msg: r.ask, question: true }); }
    this.nluLast = r.last || null; this.nluSeenId = this.ctx.lastBody;
    return res;
  }
  // 頼みごと 1 回分の変更を覚えて「↩ 取り消す」ボタンを出す（途中で止まったときも、元の状態に戻せる）
  afterBatch(u0, failed = false) {
    const n = Math.max(0, store.undoStack.length - u0);
    this.lastBatch = { n, end: store.undoStack.length };
    if (!n) return;
    this.log(`<button class="btn ai-undo" data-ai-undo>↩ ${failed ? "途中までの変更を取り消す" : "この頼みごとを取り消す"}（${n} 手順）</button>`, "ai");
    const b = [...document.querySelectorAll("[data-ai-undo]")].pop();
    const batch = this.lastBatch;
    if (b) b.onclick = async () => {
      if (store.undoStack.length !== batch.end) { this.log("このあとに別の変更をしたため、ここからは取り消せません（Ctrl+Z で 1 つずつ戻せます）", "ai err"); return; }
      b.disabled = true; for (let k = 0; k < batch.n; k++) store.undo(); await this.app.rebuild(); batch.n = 0;
      this.log(`✓ ${n} 手順を取り消して、頼む前の状態に戻しました`, "res");
    };
  }

  vget(k, d) { try { const v = localStorage.getItem("gdc-voice-" + k); return v === null ? d : v === "1"; } catch { return d; } }
  vset(k, v) { try { localStorage.setItem("gdc-voice-" + k, v ? "1" : "0"); } catch { /* */ } }

  // 今のモデル（タイムライン）を、コマンドの手順（テキスト）に書き起こす。
  // その手順を新しいファイルで実行すると同じ形ができる（コマンドで表せない部分は # で注記）
  toScript({ annotate = false } = {}) {
    const p = store.project, out = annotate ? [] : [`# ${p.name || "モデル"}（GDC GOOD DESIGN CAD で書き出した手順）`];
    const V = (v) => String(v ?? "").replace(/\s+/g, "");
    const meshName = new Map(this.app.meshes.map((m) => [m.id, m.name]));
    const names = new Map(); let k = 0;
    const nameOf = (id) => { if (!names.has(id)) names.set(id, meshName.get(id) || `部品${++k}`); return names.get(id); };
    const FN = (n) => { const a = n.map((x) => Math.round(x * 1000) / 1000); for (const [nm, [ax, sg]] of Object.entries(FACES)) { if (nm === "後面") continue; const e = [0, 0, 0]; e[ax] = sg; if (a.every((x, i) => Math.abs(x - e[i]) < 1e-3)) return nm; } return null; };
    if (!annotate) for (const q of p.params || []) out.push(`パラメータ ${q.name} = ${V(q.expr)}`);
    const comps = new Map((p.components || []).map((c) => [c.id, c]));
    let curComp = null;
    const sketchName = new Map();
    for (const f of p.features) {
      if (f.suppressed) { out.push(`# （抑制中のため省略）${f.name}`); continue; }
      if (annotate) out.push(`# [${f.name}]${p.rollback != null && p.features.indexOf(f) >= p.rollback ? "（ロールバック中で無効）" : ""}`);
      const comp = f.component || null;
      if (comp && comp !== curComp && comps.get(comp)) { out.push(`コンポーネント ${comps.get(comp).name}`); curComp = comp; }
      const nb = (id) => `名前 ${nameOf(id)}`;
      const opw = (op) => ({ join: " 結合", cut: " 切り取り", intersect: " 交差" }[op] || "");
      try {
        switch (f.type) {
          case "box": out.push(`板 幅 ${V(f.w)} 奥行 ${V(f.d)} 厚さ ${V(f.h)} 位置 ${(f.position || [0, 0, 0]).map(V).join(",")}${opw(f.operation)}${f.operation === "new" || !f.operation ? " " + nb(`B_${f.id}`) : ""}`); break;
          case "cylinder": out.push(`円柱 直径 ${V(f.d)} 高さ ${V(f.h)} 位置 ${(f.position || [0, 0, 0]).map(V).join(",")} 軸 ${f.axis || "Z"}${opw(f.operation)}${f.operation === "new" ? " " + nb(`B_${f.id}`) : ""}`); break;
          case "sphere": out.push(`球 直径 ${V(f.d)} 位置 ${(f.position || [0, 0, 0]).map(V).join(",")}${opw(f.operation)}${f.operation === "new" ? " " + nb(`B_${f.id}`) : ""}`); break;
          case "plane": {
            if ((f.kind || "offset") !== "offset") { out.push(`# ${f.name}: 角度・中間の構築平面は画面で作ってください`); break; }
            const n = (f.base || []).slice(3, 6), fn = FN(n);
            if (f.basePlane) out.push(`# ${f.name}: 構築平面からのオフセットは画面で作ってください`);
            else if (f.baseRef && fn) out.push(`構築平面 ${fn} ${nameOf(f.baseRef.body)} オフセット ${V(f.distance)}`);
            else { const std = Object.entries({ XY: [0, 0, 1], XZ: [0, -1, 0], YZ: [1, 0, 0] }).find(([, e]) => e.every((x, i) => Math.abs(x - (n[i] || 0)) < 1e-6)); if (std) out.push(`構築平面 ${std[0]} オフセット ${V(f.distance)}`); else out.push(`# ${f.name}: この構築平面は画面で作ってください`); }
            sketchName.set(f.id, f.name); break;
          }
          case "sketch": {
            const pl = f.plane || {};
            if (pl.type === "std") out.push(`スケッチ ${pl.name}${pl.offset && V(pl.offset) !== "0" ? " オフセット " + V(pl.offset) : ""}`);
            else if (pl.type === "cplane") out.push(`スケッチ ${sketchName.get(pl.ref) || "構築平面1"}`);
            else { const fn = FN(pl.normal || []); if (fn && pl.ref) out.push(`スケッチ ${fn} ${nameOf(pl.ref.body)}`); else { out.push(`# ${f.name}: 斜めの面へのスケッチは画面で作ってください（下の図形は XY に描きます）`); out.push("スケッチ XY"); } }
            if ((f.constraints || []).length) out.push(`# （拘束 ${f.constraints.length} 個は手順には含まれません。形は今の寸法で書き出しています）`);
            for (const e of f.entities || []) {
              if (e.construction) continue;
              if (e.type === "rect") out.push(`長方形 ${V(e.x)},${V(e.y)} 幅 ${V(e.w)} 高さ ${V(e.h)}`);
              else if (e.type === "circle") out.push(`円 ${V(e.cx)},${V(e.cy)} 直径 ${V(e.d)}`);
              else if (e.type === "line") out.push(`線 ${V(e.x1)},${V(e.y1)} ${V(e.x2)},${V(e.y2)}`);
              else if (e.type === "arc") out.push(`円弧 ${V(e.x1)},${V(e.y1)} ${V(e.xm)},${V(e.ym)} ${V(e.x2)},${V(e.y2)}`);
              else if (e.type === "point") out.push(`点 ${V(e.x)},${V(e.y)}`);
            }
            break;
          }
          case "extrude": {
            if (Array.isArray(f.items) && f.items.some((it) => it.face)) out.push(`# ${f.name}: 面の押し出しを含むため、プレスプルで近い形にしています`);
            if (Array.isArray(f.items) && new Set(f.items.filter((it) => it.sketch).map((it) => it.sketch)).size > 1) out.push(`# ${f.name}: 複数のスケッチをまとめた押し出しは、直前のスケッチ全体を押し出します`);
            const dir = { symmetric: " 対称", reverse: " 反対" }[f.direction] || "";
            const ext = f.extent === "all" ? " 全体" : "";
            out.push(`押し出し ${f.extent === "all" ? "" : "距離 " + V(f.distance)}${opw(f.operation)}${f.operation === "new" ? " 新規" : ""}${dir}${ext}${f.operation === "new" ? " " + nb(f.bodyId || `B_${f.id}`) : ""}`.replace(/\s+/g, " "));
            if (f.extent === "to") out.push(`# ${f.name}: 「対象まで」は距離に置き換えてください`);
            break;
          }
          case "revolve": out.push(`回転 ${V(f.angle)} 軸 ${f.axis === "u" ? "X" : "Y"}${opw(f.operation)}${f.operation === "new" ? " " + nb(`B_${f.id}`) : ""}`); break;
          case "hole": {
            const fn = FN((f.face || []).slice(3, 6));
            if ((f.placement || "single") !== "coords" || !fn) { out.push(`# ${f.name}: この穴（${f.placement === "sketch" ? "スケッチの点から" : "画面で配置"}）は手順に書き出せません`); break; }
            const rows = (f.pos || []).filter((r) => String(r[0]).trim() !== "").map((r) => `${V(r[0])},${V(r[1])}`).join(" ");
            const extra = f.style === "cbore" ? ` ざぐり径${V(f.cboreD)} ざぐり深さ${V(f.cboreDepth)}` : f.style === "csink" ? ` 皿径${V(f.csinkD)}` : "";
            // 画面で置いた穴は面そのものの座標（下面・背面・左面では向きが逆）なので「面座標」を付ける
            // 画面で置いた新しい穴（axes: "up"）は、背面・左面を外から見た向き（上が +Z）の座標
            const faceAxes = f.axes === "up" && ["背面", "左面"].includes(fn) ? " 外から見た座標" : f.axes !== "global" && f.axes !== "up" && ["下面", "背面", "左面"].includes(fn) ? " 面座標" : "";
            out.push(`穴 ${fn} Ø${V(f.d)}${f.through ? "" : " 深さ" + V(f.depth)}${extra}${f.ref === "origin" ? " 基準 原点" : ""}${faceAxes} 位置 ${rows} ${nameOf(f.body)}`);
            if (f.ref === "edges" || f.ref === "circle") out.push(`# ${f.name}: 辺・丸い辺を基準にした位置は、面の角からの座標に直してください`);
            break;
          }
          case "fillet": case "chamfer": {
            const kind = { vertical: "縦の辺", top: "上の辺", bottom: "下の辺", horizontal: "水平の辺", all: "すべての辺" }[f.edgeKind];
            // 画面で選んだ辺がすべて縦なら「縦の辺」で近似
            if (!kind && (f.edges || []).length && f.edges.every((e) => e.length >= 6 && Math.abs(e[5]) > 0.999)) { out.push(`# ${f.name}: 画面で選んだ縦の辺 ${f.edges.length} 本 → 「縦の辺」（すべての縦の辺）で近似`); out.push(`${f.type === "fillet" ? "フィレット R" : "面取り C"}${V(f.radius)} 縦の辺 ${nameOf(f.body)}`); break; }
            if (!kind) { out.push(`# ${f.name}: 画面で選んだ辺の${f.type === "fillet" ? "フィレット" : "面取り"}（${f.type === "fillet" ? "R" : "C"}${V(f.radius)}）は、手順では辺の種類で指定し直してください`); break; }
            out.push(`${f.type === "fillet" ? "フィレット R" : "面取り C"}${V(f.radius)} ${kind} ${nameOf(f.body)}`); break;
          }
          case "shell": {
            const fs = (f.faces || []).map((a) => FN(a.slice(3, 6))).filter(Boolean);
            out.push(`シェル 厚さ${V(f.thickness)} ${fs.join(" ")} ${nameOf(f.body)}`.replace(/\s+/g, " ")); break;
          }
          case "move": {
            if (V(f.angle) !== "0" && V(f.angle) !== "") out.push(`# ${f.name}: 回転（${V(f.angle)}°）は画面で指定してください`);
            for (const b of f.bodies || []) out.push(`${f.copy ? "コピー" : "移動"} ${nameOf(b)} ${(f.translate || [0, 0, 0]).map(V).join(",")}`);
            break;
          }
          case "mirror": out.push(`ミラー ${(f.bodies || []).map(nameOf).join(" ")} ${f.plane || "YZ"} 位置 ${V(f.offset || 0)}${f.join ? " 結合" : ""}`); break;
          case "pattern": out.push(`矩形パターン ${(f.bodies || []).map(nameOf).join(" ")} ${f.dir || "X"}方向 ${V(f.count)}個 間隔${V(f.spacing)}${f.dir2 ? ` ${f.dir2}方向 ${V(f.count2)}個 間隔${V(f.spacing2)}` : ""}${f.join ? " 結合" : ""}`); break;
          case "cpattern": out.push(`円形パターン ${(f.bodies || []).map(nameOf).join(" ")} ${V(f.count)}個 軸 ${f.axis || "Z"} 中心 ${(f.center || [0, 0, 0]).map(V).join(",")} 角度 ${V(f.angle)}${f.join ? " 結合" : ""}`); break;
          case "split": if (f.plane === "face") out.push(`# ${f.name}: 面での分割は画面で行ってください`); else out.push(`分割 ${nameOf(f.body)} ${f.plane} 位置 ${V(f.offset || 0)}`); break;
          case "combine": out.push(`結合 ${nameOf(f.target)} ${(f.tools || []).map(nameOf).join(" ")}${{ cut: " 切り取り", intersect: " 交差" }[f.op] || ""}${f.keepTools ? " 保持" : ""}`); break;
          case "presspull": { const fn = FN((f.face || []).slice(3, 6)); if (fn) out.push(`プレスプル ${fn} ${V(f.distance)} ${nameOf(f.body)}${f.operation === "new" ? " 新規" : ""}`); else out.push(`# ${f.name}: 斜めの面のプレスプルは画面で行ってください`); break; }
          case "remove": for (const b of f.bodies || []) out.push(`削除 ${nameOf(b)}`); break;
          case "scale": out.push(`スケール ${V(f.factor)} ${(f.bodies || []).map(nameOf).join(" ")}${f.about === "body" ? " 中心" : ""}`.trim()); break;
          default: out.push(`# ${f.name}（${f.type}）は手順に書き出せません。画面で作ってください`);
        }
      } catch (e) { out.push(`# ${f.name}: 書き出せませんでした（${e.message}）`); }
    }
    // 名前・色・材料・表示
    for (const [id, bp] of Object.entries(p.bodyProps || {})) {
      if (!names.has(id) && !meshName.has(id)) continue;
      const n = nameOf(id);
      if (bp.color) out.push(`${n} 色 ${bp.color}`);
      if (bp.material && bp.material.name) out.push(`材料 ${n} ${bp.material.name}`); else if (bp.material && bp.material.density) out.push(`材料 ${n} 密度 ${bp.material.density}`);
      if (bp.hidden) out.push(`非表示 ${n}`);
    }
    return out.join("\n");
  }

  // 手順ファイル（.txt）を開いて実行
  async runFile(file) {
    const text = await file.text();
    this.open();
    const ta = document.getElementById("cmd-in"); if (ta) ta.value = text;
    this.log(`<b>手順ファイル「${esc(file.name)}」を実行</b>`);
    const r = await this.runText(text);
    if (ta && r.every((x) => x.ok)) ta.value = "";
    return r;
  }

  // AI と話す画面（v0.14）: ふだんの言葉で頼む → AI が読み取って形を作る・直す
  // 「⚙ 設定」で AI を使わない（決まった書き方で動かす・オフライン用）こともできる
  aiMode() { return this.vget("ai", true); }
  open() {
    const app = this.app;
    const mobile = matchMedia("(max-width: 700px)").matches;
    const ex = ["床板を幅600、奥行400、厚さ20で作って", "四隅に直径8の穴を、端から30のところに", "全部のサイズを10分の1にして", "これを右に100動かして", "全部で何枚？重さは？"];
    const el = app.panel("🤖 言葉で操作", `
      <div class="full cmd-wrap chat">
        <div id="cmd-log" class="cmd-log">${this.history.join("") || (this.aiMode() ? `<div class="cmd-item hint">ふだんの言葉で頼んでください。寸法は言ったとおりに正確に作ります。<br>例）${ex.map((t) => `<a href="#" class="ex">「${esc(t)}」</a>`).join(" ")}</div>` : `<div class="cmd-item hint">いまは「AI を使わない」設定です（無料・この端末の中だけで読み取ります）。ふだんの言葉で頼めます。分からないときは聞き返すので、答えてください。決まった書き方（⚙ 設定 →「決まった書き方の一覧」）もそのまま使えます。<br>例）${OFFLINE_EX.map((t) => `<a href="#" class="ex">「${esc(t)}」</a>`).join(" ")}</div>`)}</div>
        <div id="vc-live" class="vc-live hidden"></div>
        <textarea id="cmd-in" rows="${mobile ? 2 : 3}" placeholder="例）床板を厚さ30にして、角を丸めて（Enter で送る・Shift+Enter で改行）"></textarea>
        <span id="vc-st" class="vc-st"></span>
        <details class="cmd-set"><summary>⚙ 設定</summary>
          <div class="voice-bar">
            ${brainSettingsHTML(this)}
            <label><input type="checkbox" id="ai-confirm" ${this.vget("aiauto", true) ? "" : "checked"}/> 実行する前に確認する</label>
            <label><input type="checkbox" id="vc-auto" ${this.vget("auto", true) ? "checked" : ""}/> 話し終えたらすぐ送る</label>
            <label><input type="checkbox" id="ai-off" ${this.aiMode() ? "" : "checked"}/> AI を使わない（無料・オフライン。ふだんの言葉もある程度わかります）</label>
            <button class="btn" id="cmd-export" title="今のモデルを手順（テキスト）に書き起こします">今のモデルを手順に</button>
            <button class="btn" id="cmd-help">決まった書き方の一覧</button>
            <button class="btn" id="cmd-clear">会話を消す</button>
          </div>
          <div class="dlg-note">音声は、iPhone の Safari などでは Apple・Google の音声認識で文字にします。</div>
        </details>
      </div>`, null, { okLabel: "閉じる", noCancel: true, wide: true, cls: "cmd-panel",
      foot: `<button class="btn mic" id="vc-talk">🎤 話す</button><button class="btn primary" id="cmd-run">送る</button><span class="foot-gap"></span>` });
    const ta = el.querySelector("#cmd-in"), logEl = el.querySelector("#cmd-log");
    logEl.scrollTop = logEl.scrollHeight;
    if (!mobile) ta.focus(); // iPhone ではキーボードが画面を隠すので、自動では出さない
    const confirmEl = el.querySelector("#ai-confirm"), offEl = el.querySelector("#ai-off");
    const autoRun = () => !confirmEl.checked;
    // ---- AI の準備（初めてのとき: 同意 → API キー）
    const askKey = () => {
      const k = window.prompt("Anthropic の API キーを貼り付けてください（console.anthropic.com で作れます。sk-ant- で始まる文字列）。\nこの端末のブラウザの中だけに保存されます。共用のパソコンでは使わないでください。", this.aiKey());
      if (k === null) return false;
      try { if (k.trim()) localStorage.setItem("gdc-ai-key", k.trim()); else localStorage.removeItem("gdc-ai-key"); } catch { /* */ }
      el.querySelector("#ai-key").textContent = this.aiKey() ? "API キー設定済み ✓（変更）" : "API キーを設定";
      return !!this.aiKey();
    };
    const ensureAI = () => {
      if (getBrain() !== "claude") return true; // 端末内 AI・パソコンの AI・貼り付けは、キーも利用料も不要
      if (!this.vget("aiconsent", false)) {
        const ok = window.confirm("AI（Claude）で言葉を読み取ります\n\n頼んだ言葉と「今のモデルの概要」（手順・部品名・外形の大きさと位置・材料・選択中のもの）が Anthropic の Claude に送られます。形そのもののデータ（STEP など）は送りません。\n費用は、あなたの Anthropic API の利用料として 1 回ごとにかかります。\n\n使いますか？");
        if (!ok) return false;
        this.vset("aiconsent", true);
      }
      if (!this.aiKey() && !askKey()) { this.log("AI を使うには API キーが必要です。下の「⚙ 設定」→「API キーを設定」から入れてください（作り方は「AIで操作する.txt」）", "ai err"); return false; }
      return true;
    };
    const send = (t) => {
      t = String(t || "").trim(); if (!t) { ta.focus(); return; }
      if (!this.aiMode()) return this.runNLU(t).then((r) => { if (r.every((x) => x.ok || x.question)) ta.value = ""; });
      if (!ensureAI()) { ta.value = ""; return this.runNLU(t, { note: "AI の準備ができていないため、AI を使わずに読み取って実行します" }); }
      ta.value = "";
      // AI に届かなかった（電波が切れた・やめた・時間切れ）ときは、入力した言葉を欄に戻す（打ち直さなくてよいように）
      return this.runAI(t, { autoRun: autoRun() }).then((r) => { if (r && r.length === 1 && !r[0].ok && !r[0].question && r[0].line === t && !ta.value) ta.value = t; return r; });
    };
    const go = () => send(ta.value);
    ta.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229 && (!e.shiftKey || e.ctrlKey || e.metaKey)) { e.preventDefault(); go(); }
    });
    el.querySelector("#cmd-run").onclick = go;
    logEl.addEventListener("click", (e) => { const a = e.target.closest("a.ex"); if (a) { e.preventDefault(); ta.value = a.textContent.replace(/^「|」$/g, ""); ta.focus(); } });
    el.querySelector("#ai-key").onclick = askKey;
    wireBrainSettings(this, el);
    el.querySelector("#ai-model").onchange = (e) => { try { localStorage.setItem("gdc-ai-model", e.target.value); } catch { /* */ } };
    confirmEl.onchange = () => this.vset("aiauto", !confirmEl.checked);
    offEl.onchange = () => { this.vset("ai", !offEl.checked); if (offEl.checked) setBrain("nlu"); else if (getBrain() === "nlu") setBrain("local"); const bp = el.querySelector("#ai-brain"); if (bp) { bp.value = getBrain(); bp.dispatchEvent(new Event("sync")); } this.log(offEl.checked ? "AI を使わない設定にしました。この端末の中で言葉を読み取ります（無料・オフライン）。例）「幅60センチ奥行き40で厚さ2センチの床板を作って」" : "AI を使う設定にしました。ふだんの言葉で頼めます", "ai"); };
    el.querySelector("#cmd-export").onclick = () => {
      const t = this.toScript();
      const blob = new Blob([t + "\n"], { type: "text/plain;charset=utf-8" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${(store.project.name || "モデル").replace(/[\\/:*?"<>|]/g, "_")}_手順.txt`; a.click();
      this.log(`今のモデルを手順に書き起こしました（ファイルに保存）<pre class="cmd-help">${esc(t)}</pre>`, "ai");
    };
    el.querySelector("#cmd-help").onclick = () => this.log(`<pre class="cmd-help">${esc(HELP)}</pre>`);
    el.querySelector("#cmd-clear").onclick = () => { this.history = []; this.chat = []; logEl.innerHTML = ""; };
    // ---- 音声（「🎤 話す」を押す → 話す → 黙ると自動で終わって AI へ）
    const talk = el.querySelector("#vc-talk"), auto = el.querySelector("#vc-auto"), st = el.querySelector("#vc-st"), live = el.querySelector("#vc-live");
    const setSt = (t, cls = "") => { st.textContent = t; st.className = "vc-st " + cls; };
    if (!this.voice.supported) { talk.disabled = true; talk.title = "このブラウザでは使えません（キーボードのマイクで入力欄に話しても同じです）"; }
    auto.onchange = () => this.vset("auto", auto.checked);
    const listen = () => {
      talk.classList.add("rec"); talk.textContent = "■ 終わる"; setSt("話してください…（黙ると自動で終わります）", "live");
      live.classList.remove("hidden"); live.textContent = "🎤 …";
      this.voice.start({
        onInterim: (t) => { live.textContent = "🎤 " + t; },
        onFinal: (t) => { if (auto.checked) send(t); else { ta.value = t; setSt("内容を確かめて「送る」を押してください"); } },
        onEnd: () => { talk.classList.remove("rec"); talk.textContent = "🎤 話す"; live.classList.add("hidden"); if (!/送る/.test(st.textContent) && !st.classList.contains("err")) setSt(""); },
        onError: (m) => { setSt(m, "err"); },
      });
    };
    talk.onclick = async () => {
      if (this.voice.listening) { this.voice.stop(); return; }
      if (!this.voice.supported) return;
      // AI の準備を先に（話し終えてから API キーを聞かれないように）
      if (this.aiMode() && !ensureAI()) return;
      if (!this.vget("on", false)) {
        // iPhone の Safari は確かめる手段がないので、待たずに（ボタンを押した直後のうちに）聞き始める
        const loc = this.voice.canCheckLocal ? await this.voice.checkLocal() : false;
        if (!loc && !this.vget("consent", false)) {
          const ok = window.confirm("音声入力について\n\nこのブラウザでは、話した音声を文字にするために Apple（Safari）または Google（Chrome）の音声認識サービスに送ります。設計データそのものは送りませんが、話した内容（寸法や部品名）は送られます。\n\n使いますか？");
          if (!ok) return;
          this.vset("consent", true);
        }
        this.vset("on", true); this.vset("local", loc);
      } else this.voice.local = this.vget("local", false);
      listen();
    };
    this.talkBtn = talk;
  }

  log(html, kind = "") {
    const h = `<div class="cmd-item ${kind}">${html}</div>`;
    this.history.push(h);
    const l = document.getElementById("cmd-log");
    if (l) { l.insertAdjacentHTML("beforeend", h); l.scrollTop = l.scrollHeight; }
  }

  // 複数行をまとめて実行。結果を 1 行ずつ表示。戻り値: [{line, ok, msg}]
  async runText(text, { compact = false, keepQuery = false } = {}) {
    if (!keepQuery) this.queryOut = [];
    const lines = String(text || "").split(/\r?\n/).map((s) => s.trim()).filter((s) => s && !s.startsWith("#") && !s.startsWith("//"));
    const results = [];
    for (const raw of lines) {
      let ok = true, msg;
      try { msg = await this.run(raw); } catch (e) { ok = false; msg = e.message; }
      results.push({ line: raw, ok, msg });
      if (compact) this.log(`<span class="${ok ? "ok" : "ng"}">${ok ? "✓" : "✗"}</span> ${esc(msg || raw)}`, "res");
      else this.log(`<span class="${ok ? "ok" : "ng"}">${ok ? "✓" : "✗"}</span> <code>${esc(raw)}</code><br><small>${esc(msg || "")}</small>`);
      if (!ok) break; // 失敗したらそこで止める（後の手順がずれないように）
    }
    store.emit();
    return results;
  }

  // ---- 共通
  async commitFeature(f, at = null) {
    store.commit((p) => {
      const i = at ?? p.rollback ?? p.features.length;
      p.features.splice(i, 0, f);
      if (p.rollback != null) p.rollback = i + 1;
    }, { silent: true });
    const errs = (await this.app.rebuild()) || [];
    const e = errs.find((x) => x.featureId === f.id);
    if (e) { store.undo(); await this.app.rebuild(); throw new Error(e.message); }
  }
  body(line) {
    const ms = this.app.meshes;
    for (const m of [...ms].sort((a, b) => b.name.length - a.name.length)) if (line.includes(m.name)) return m;
    // 名前が無いとき: 画面で選んでいるもの（「これ」）→ 直前に作ったもの → 最後のボディ
    const sel = this.selectedBodies()[0]; if (sel) return sel;
    return (this.ctx.lastBody && ms.find((m) => m.id === this.ctx.lastBody)) || ms[ms.length - 1] || null;
  }
  // 画面で選んでいるボディ（面・辺を選んでいるときは、その持ち主）
  selectedBodies() {
    const ms = this.app.meshes, ids = [...new Set((this.app.selection || []).map((x) => x.bodyId).filter(Boolean))];
    return ids.map((id) => ms.find((m) => m.id === id)).filter(Boolean);
  }
  // 行に書かれたボディ（「すべて」「全部」なら全部、「これ」「選択」なら選んでいるもの）
  bodiesIn(s, { fallbackSel = true } = {}) {
    const ms = this.app.meshes;
    if (/すべて|全部|全ボディ|全て/.test(s)) return ms.filter((m) => !m.hidden);
    // 長い名前から順に探して消していく（「側板」と「側板B」が両方あっても取り違えない）
    let rest = s; const named = [];
    for (const m of [...ms].sort((a, b) => b.name.length - a.name.length)) if (m.name && rest.includes(m.name)) { named.push([s.indexOf(m.name), m]); rest = rest.split(m.name).join(" "); }
    named.sort((a, b) => a[0] - b[0]); for (let i = 0; i < named.length; i++) named[i] = named[i][1];
    if (named.length) return named;
    return fallbackSel || /これ|それ|選択|選んだ/.test(s) ? this.selectedBodies() : [];
  }
  // 画面で選んでいる面（「この面に」）
  selectedFace(b) {
    const f = (this.app.selection || []).find((x) => x.kind === "face" && x.point && x.normal && (!b || x.bodyId === b.id));
    if (!f) return null;
    const n = f.normal.map((v) => (Math.abs(v) < 1e-6 ? 0 : +v.toFixed(6)));
    const nm = Object.entries(FACES).find(([k, [ax, sg]]) => k !== "後面" && Math.abs(n[ax] - sg) < 1e-3)?.[0] || "選んだ面";
    return { p: f.point.map((v) => +v.toFixed(4)), n, name: nm, bodyId: f.bodyId };
  }
  async bounds(id) { const r = await call("measure", { ids: [id], density: 1 }); return r.list[0].bounds; }
  // 面の名前 → 面の上の点と向き（角から少し内側の点を使う）
  async facePoint(line, b) {
    const k = Object.keys(FACES).find((n) => line.includes(n) || line.includes(n.replace("面", ""))); if (!k) return null;
    const [ax, sg] = FACES[k];
    const [lo, hi] = await this.bounds(b.id);
    const p = [0, 1, 2].map((i) => lo[i] + (hi[i] - lo[i]) * 0.013 + 0.01);
    p[ax] = sg > 0 ? hi[ax] : lo[ax];
    const n = [0, 0, 0]; n[ax] = sg;
    return { p: p.map((v) => +v.toFixed(4)), n, name: k };
  }
  sketchFeature() {
    const id = this.ctx.sketch || [...store.project.features].reverse().find((f) => f.type === "sketch")?.id;
    const f = id && store.feature(id);
    if (!f) throw new Error("先に「スケッチ XY」などでスケッチを始めてください");
    return f;
  }
  addEntities(ents) {
    const f = this.sketchFeature();
    store.commit((p) => { const sk = p.features.find((x) => x.id === f.id); sk.entities = [...(sk.entities || []), ...ents.map((e) => ({ ...e, id: newId("e") }))]; }, { silent: true });
    return this.app.rebuild();
  }

  // 名前（ボディ名・タイムラインの名前）から、直す手順を探す
  findTarget(line) {
    const L = line.replace(/^(変更|修正|直す|変える)\s*/, "");
    const feats = store.project.features;
    const cand = [];
    for (const f of feats) if (f.name && L.includes(f.name)) cand.push({ f, n: f.name });
    for (const m of this.app.meshes) if (L.includes(m.name)) { const f = feats.find((x) => x.id === m.src); if (f) cand.push({ f, n: m.name, body: m }); }
    cand.sort((a, b) => b.n.length - a.n.length);
    return cand[0] || null;
  }
  async modify({ f, n, body }, line) {
    const L = line.replace(n, " ");
    // 「床板 材料 アルミ」「床板 名前 天板」「柱 非表示」なども受け付ける
    if (/\d\s*倍|分の|\d\s*(%|パーセント)|スケール/.test(L)) return this.run(`スケール ${line}`);
    if (body && /材料|材質|密度/.test(L)) return this.run(`材料 ${line}`);
    if (body && /名前/.test(L)) return this.run(`名前変更 ${n} ${L.replace(/名前|を|に|へ|変更/g, " ").trim()}`);
    if (body && /非表示|隠す/.test(L)) return this.run(`非表示 ${n}`);
    if (body && /^\s*表示/.test(L)) return this.run(`表示 ${n}`);
    // 色: 「床板 色 赤」「床板 色 #3366cc」
    if (body && /色/.test(L)) {
      const hex = colorOf(L);
      if (!hex) throw new Error(COLOR_HELP);
      store.commit((p) => { p.bodyProps = p.bodyProps || {}; p.bodyProps[body.id] = { ...(p.bodyProps[body.id] || {}), color: hex }; }, { silent: true });
      await this.app.rebuild();
      return `${n} の色を ${hex} に`;
    }
    const PROPS = {
      box: [["幅|横|W", "w"], ["奥行き?|縦|D", "d"], ["厚さ|厚み|高さ|H", "h"]],
      cylinder: [["直径|径|Ø", "d"], ["高さ|長さ", "h"]], sphere: [["直径|径|Ø", "d"]],
      extrude: [["距離|高さ|厚さ|厚み|長さ", "distance"]],
      hole: [["穴径|直径|径|Ø", "d"], ["深さ", "depth"], ["ざぐり径", "cboreD"], ["ざぐり深さ", "cboreDepth"], ["皿径", "csinkD"]],
      fillet: [["R|半径", "radius"]], chamfer: [["C|距離", "radius"]],
      move: [["回転|角度", "angle"]],
    }[f.type] || [];
    const changes = {};
    for (const [keys, field] of PROPS) { const v = kv(L, keys); if (v !== null && v !== "") changes[field] = v; }
    if (f.type === "hole" && /貫通/.test(L)) changes.through = true;
    if (f.type === "hole" && changes.depth) changes.through = false;
    if (f.type === "hole" && /位置|座標/.test(L)) { const ps = pairs(L.slice(L.search(/位置|座標/))).map((p) => [p[0], p[1]]); if (ps.length) changes.pos = ps; }
    if (f.type === "move" && /移動量|位置/.test(L)) { const t = pairs(L)[0]; if (t && t.length === 3) changes.translate = t; }
    if (["box", "cylinder", "sphere"].includes(f.type) && /位置/.test(L)) { const t = pairs(L)[0]; if (t) changes.position = [t[0], t[1], t[2] ?? "0"]; }
    if (!Object.keys(changes).length) {
      const can = [...PROPS.map(([k]) => k.split("|")[0].replace(/\?/g, "")), ...(body ? ["色"] : [])].join("・");
      throw new Error(`「${n}」で直せる項目: ${can || "（この手順は言葉では直せません。パラメータを使ってください）"}`);
    }
    const before = JSON.stringify(f);
    store.commit((p) => { const x = p.features.find((y) => y.id === f.id); Object.assign(x, changes); }, { silent: true });
    const errs = (await this.app.rebuild()) || [];
    const e = errs.find((x) => x.featureId === f.id);
    if (e) { store.undo(); await this.app.rebuild(); throw new Error(e.message); }
    void before;
    const lab = Object.fromEntries(PROPS.map(([k, fld]) => [fld, k.split("|")[0].replace(/\?/g, "")]));
    Object.assign(lab, { pos: "位置", through: "貫通", translate: "移動量", position: "位置" });
    return `${n}（${f.name}）: ` + Object.entries(changes).map(([k, v]) => k === "through" ? "貫通" : `${lab[k] || k} → ${Array.isArray(v) ? v.map((q) => (Array.isArray(q) ? q.join(",") : q)).join(" ") : v}`).join("、");
  }

  // ---- 1 行の実行
  async run(raw) {
    const line = norm(raw);
    const app = this.app;
    const opOf = (s, def = "new") => /切り?取り|カット|くり抜|削る/.test(s) ? "cut" : /結合|足す|追加/.test(s) ? "join" : /交差/.test(s) ? "intersect" : /新規/.test(s) ? "new" : def;
    const name = kv(line, "名前|名称|ボディ名");

    // 既にある名前（穴1・押し出し2・床板 など）で始まる行は「直す」
    { const r = await panelCommand(this, line); if (r !== undefined) return r; } // パネル家具（ビス接合・板厚の一括変更）
    { const t = this.findTarget(line); if (t && line.replace(/^(変更|修正|直す|変える)\s*/, "").startsWith(t.n)) return this.modify(t, line); }
    if (/^(ヘルプ|help|使い方|\?)/i.test(line)) { this.log(`<pre class="cmd-help">${esc(HELP)}</pre>`); return "使い方を表示しました"; }
    if (/^(元に戻す|アンドゥ|undo|取り消)/i.test(line)) {
      const n = Math.max(1, Math.min(200, Math.round(+(line.match(/(\d+)/) || [, 1])[1])));
      let k = 0; for (; k < n && store.undoStack.length; k++) store.undo();
      await app.rebuild(); return k ? `${k} つ前に戻しました` : "戻せる操作がありません";
    }
    if (/^(やり直し|redo)/i.test(line)) {
      const n = Math.max(1, Math.round(+(line.match(/(\d+)/) || [, 1])[1]));
      let k = 0; for (; k < n && store.redoStack.length; k++) store.redo();
      await app.rebuild(); return k ? `${k} つやり直しました` : "やり直せる操作がありません";
    }

    if (/^(パラメータ|変数)/.test(line)) {
      const m = line.replace(/^(パラメータ|変数)\s*/, "").match(/^([^\s=:]+)\s*[=:]?\s*(.+)$/);
      if (!m) throw new Error("書き方: パラメータ 幅 = 600");
      store.commit((p) => { p.params = p.params || []; const q = p.params.find((x) => x.name === m[1]); if (q) q.expr = m[2].trim(); else p.params.push({ name: m[1], expr: m[2].trim() }); }, { silent: true });
      await app.rebuild();
      return `パラメータ ${m[1]} = ${m[2].trim()}`;
    }

    if (/^コンポーネント/.test(line)) {
      const nm = line.replace(/^コンポーネント\s*/, "").trim() || `コンポーネント${(store.project.components || []).length + 1}`;
      const id = newId("C");
      store.commit((p) => { p.components = p.components || []; p.components.push({ id, name: nm, parent: p.activeComponent || null }); p.activeComponent = id; }, { silent: true });
      await app.rebuild();
      return `コンポーネント「${nm}」を作って有効にしました（この後の形はここに入ります）`;
    }

    if (/^(板|直方体|箱|ボックス|ブロック)/.test(line)) {
      const m = line.match(/([0-9.]+)\s*x\s*([0-9.]+)\s*x\s*([0-9.]+)/);
      const w = m ? m[1] : kv(line, "幅|横|W|w"), d = m ? m[2] : kv(line, "奥行き?|縦|D"), h = m ? m[3] : kv(line, "厚さ|厚み|高さ|H|T|t");
      if (!w || !d || !h) throw new Error("幅・奥行・厚さ（または 600x400x20）を書いてください");
      const pos = (kv(line, "位置|原点|基準") && pairs(line.slice(line.search(/位置|原点|基準/)))[0]) || ["0", "0", "0"];
      const f = { id: newId(), type: "box", name: store.nameFor("box"), position: [pos[0], pos[1], pos[2] ?? "0"], w, d, h, operation: opOf(line), ...(name ? { bodyName: name } : {}), ...(store.project.activeComponent ? { component: store.project.activeComponent } : {}) };
      await this.commitFeature(f);
      this.ctx.lastBody = `B_${f.id}`;
      return `直方体 ${w}×${d}×${h} を作りました${name ? `（${name}）` : ""}`;
    }

    if (/^円柱/.test(line)) {
      const dd = kv(line, "直径|Ø|径|D"), r = kv(line, "半径|R"), h = kv(line, "高さ|長さ|H");
      const dia = dd || (r ? `(${r})*2` : null);
      if (!dia || !h) throw new Error("直径と高さを書いてください（例: 円柱 直径50 高さ100）");
      const pos = pairs(line.slice(Math.max(0, line.search(/位置|中心/))))[0] || ["0", "0", "0"];
      const ax = (line.match(/軸\s*([XYZxyz])/) || [, "Z"])[1].toUpperCase();
      const f = { id: newId(), type: "cylinder", name: store.nameFor("cylinder"), position: [pos[0], pos[1], pos[2] ?? "0"], axis: ax, d: dia, h, operation: opOf(line), ...(name ? { bodyName: name } : {}) };
      await this.commitFeature(f);
      this.ctx.lastBody = `B_${f.id}`;
      return `円柱 Ø${dia} 高さ ${h} を作りました`;
    }

    if (/^(スケッチ終了|終了)/.test(line)) { this.ctx.sketch = null; return "スケッチを終えました"; }

    if (/^スケッチ/.test(line)) {
      let plane;
      const std = (line.match(/\b(XY|XZ|YZ)\b/i) || [])[1];
      const off = kv(line, "オフセット|高さ|離れ");
      const cp = store.project.features.filter((x) => x.type === "plane" && line.includes(x.name)).sort((a, b) => b.name.length - a.name.length)[0];
      if (cp) plane = { type: "cplane", ref: cp.id, offset: off || "0" };
      else if (std) plane = { type: "std", name: std.toUpperCase(), offset: off || "0" };
      else {
        const b = this.body(line); if (!b) throw new Error("ボディがありません。「スケッチ XY」のように平面を指定してください");
        const fp = await this.facePoint(line, b) || this.selectedFace(b); if (!fp) throw new Error("平面（XY/XZ/YZ）か面（上面・前面など）を書いてください");
        const r = await call("facePlane", { bodyId: b.id, point: fp.p });
        plane = { type: "face", origin: r.origin.map((v) => +v.toFixed(6)), xDir: r.xDir, normal: r.normal, offset: off || "0", ref: { body: b.id, point: fp.p } };
      }
      const f = { id: newId(), type: "sketch", name: store.nameFor("sketch"), plane, entities: [], ...(store.project.activeComponent ? { component: store.project.activeComponent } : {}) };
      await this.commitFeature(f);
      this.ctx.sketch = f.id;
      return `${f.name} を ${plane.type === "std" ? plane.name + " 平面" : "面"} に作りました（続けて 長方形・円・線 などを書けます）`;
    }

    if (/^(長方形|四角形?|矩形)(?!パターン)/.test(line)) {
      const ps = pairs(line); const w = kv(line, "幅|横|W"), h = kv(line, "高さ|縦|H");
      let e;
      if (/中心/.test(line) && ps[0] && w && h) e = { type: "rect", x: `${ps[0][0]}-(${w})/2`, y: `${ps[0][1]}-(${h})/2`, w, h };
      else if (ps.length >= 2) e = { type: "rect", x: ps[0][0], y: ps[0][1], w: `${ps[1][0]}-(${ps[0][0]})`, h: `${ps[1][1]}-(${ps[0][1]})` };
      else if (ps[0] && w && h) e = { type: "rect", x: ps[0][0], y: ps[0][1], w, h };
      else throw new Error("書き方: 長方形 0,0 600,400 ／ 長方形 10,10 幅100 高さ50 ／ 長方形 中心 300,200 幅100 高さ50");
      for (const k of ["x", "y", "w", "h"]) if (/^[-+0-9.()*/ ]+$/.test(e[k])) e[k] = +eval(e[k]).toFixed(6);
      await this.addEntities([e]);
      return `長方形を追加しました`;
    }

    if (/^円弧/.test(line)) {
      const ps = pairs(line); if (ps.length < 3) throw new Error("書き方: 円弧 始点 通過点 終点（例: 円弧 0,0 50,20 100,0）");
      await this.addEntities([{ type: "arc", x1: ps[0][0], y1: ps[0][1], xm: ps[1][0], ym: ps[1][1], x2: ps[2][0], y2: ps[2][1] }]);
      return "円弧を追加しました";
    }

    if (/^円(?!柱|形パターン|弧)/.test(line)) {
      const ps = pairs(line); const dd = kv(line, "直径|Ø|径"), r = kv(line, "半径|R");
      if (!ps[0] || (!dd && !r)) throw new Error("書き方: 円 100,100 直径50 ／ 円 中心 100,100 半径25");
      await this.addEntities(ps.map((p) => ({ type: "circle", cx: p[0], cy: p[1], d: dd || `(${r})*2` })));
      return `円を ${ps.length} 個追加しました`;
    }

    if (/^(線|ライン|折れ線)/.test(line)) {
      const ps = pairs(line); if (ps.length < 2) throw new Error("書き方: 線 0,0 100,0 100,50（「閉じる」で最初の点へ戻る）");
      const pts = [...ps]; if (/閉じ/.test(line)) pts.push(ps[0]);
      const ents = []; for (let i = 1; i < pts.length; i++) ents.push({ type: "line", x1: pts[i - 1][0], y1: pts[i - 1][1], x2: pts[i][0], y2: pts[i][1] });
      await this.addEntities(ents);
      return `線を ${ents.length} 本追加しました`;
    }

    if (/^点/.test(line)) {
      const ps = pairs(line); if (!ps.length) throw new Error("書き方: 点 30,25 270,25");
      await this.addEntities(ps.map((p) => ({ type: "point", x: p[0], y: p[1] })));
      return `点を ${ps.length} 個追加しました`;
    }

    if (/^押し?出/.test(line)) {
      const sk = this.sketchFeature();
      const dist = kv(line, "距離") || kv(line, "高さ|厚さ") || (line.replace(/^押し?出し?\s*/, "").match(/^(-?[0-9.]+|[^\s]+?)(?=\s|$)/) || [])[1];
      const all = /全体|貫通/.test(line);
      let op = opOf(line, "");
      const ref = sk.plane && sk.plane.type === "face" && sk.plane.ref;
      if (!op) op = ref ? "join" : "new";
      const neg = dist && /^-/.test(dist);
      if (neg && op === "new" && ref) op = "cut";
      const dir = /対称|両側/.test(line) ? "symmetric" : /反対|下向き|裏/.test(line) ? "reverse" : "one";
      if (!dist && !all) throw new Error("距離を書いてください（例: 押し出し 20）");
      const f = { id: newId(), type: "extrude", name: store.nameFor("extrude"), sketch: sk.id, profiles: [], direction: op === "cut" && all && ref ? "reverse" : dir, extent: all ? "all" : "dist", distance: dist || "10", start: "profile", startOffset: "0", operation: op,
        ...(op === "join" && ref ? { target: ref.body } : {}), ...(name ? { bodyName: name } : {}), ...(store.project.activeComponent && op === "new" ? { component: store.project.activeComponent } : {}) };
      // 切り取り・交差が当たらないときは、向きを変えて試す（平面の表裏は利用者や AI には分かりにくい）
      let flipped = "";
      try { await this.commitFeature(f); } catch (e) {
        const explicit = /対称|両側|反対|下向き|裏/.test(line);
        if (explicit || (op !== "cut" && op !== "intersect") || !/当たっていません|交わって|ありません/.test(e.message)) throw e;
        let ok = false;
        for (const d of f.direction === "reverse" ? ["one", "symmetric"] : ["reverse", "symmetric"]) {
          try { await this.commitFeature({ ...f, id: newId(), direction: d }); ok = true; flipped = d === "reverse" ? "（向きを反対にしました）" : "（両側に切りました）"; break; } catch { /* 次の向き */ }
        }
        if (!ok) throw e;
      }
      if (op === "new") this.ctx.lastBody = `B_${f.id}`;
      this.ctx.sketch = null;
      return `押し出し ${all ? "全体" : dist}（${{ new: "新規ボディ", join: "結合", cut: "切り取り", intersect: "交差" }[op]}）${flipped}`;
    }

    if (/^穴/.test(line)) {
      const b = this.body(line); if (!b) throw new Error("穴をあけるボディがありません");
      const fp = await this.facePoint(line, b) || this.selectedFace(b) || await this.facePoint("上面", b);
      const at = line.search(/位置|座標/); if (at < 0) throw new Error("位置を書いてください（例: 穴 上面 Ø8 位置 30,25 270,25）");
      const pos = pairs(line.slice(at)).map((p) => [p[0], p[1]]);
      const d = kv(line, "Ø|直径|径|穴径|M") ;
      if (!pos.length || !d) throw new Error("穴径（Ø8）と位置（30,25 …）を書いてください");
      const depth = kv(line, "(?<!ざぐり)深さ");
      const cb = kv(line, "ざぐり径"), cbd = kv(line, "ざぐり深さ"), cs = kv(line, "皿径"), csa = kv(line, "皿角度");
      const f = { id: newId(), type: "hole", name: store.nameFor("hole"), placement: "coords", face: [...fp.p, ...fp.n], faceRef: { body: b.id, point: fp.p }, body: b.id, ref: /基準\s*原点|原点から/.test(line) ? "origin" : "corner", pos, ...(/外から見た座標/.test(line) ? { axes: "up" } : /面座標/.test(line) ? {} : { axes: "global" }),
        style: cb ? "cbore" : cs ? "csink" : "simple", d, through: !depth, depth: depth || "10", cboreD: cb || "18", cboreDepth: cbd || "6", csinkD: cs || "20", csinkAngle: csa || "90", useCircles: true, flip: false, points: [] };
      await this.commitFeature(f);
      return `${b.name} の${fp.name}に Ø${d} の穴を ${pos.length} 個（${depth ? "深さ " + depth : "貫通"}、${f.ref === "origin" ? "原点" : "面の角"}から）`;
    }

    if (/^(フィレット|角を?丸|丸め|面取り)/.test(line)) {
      const cham = /面取り/.test(line);
      const r = cham ? kv(line, "C|距離") : kv(line, "R|半径");
      if (!r) throw new Error(cham ? "書き方: 面取り C3 上の辺" : "書き方: フィレット R5 縦の辺");
      const b = this.body(line); if (!b) throw new Error("ボディがありません");
      const named = /縦|垂直|上|下|水平|横|すべて|全部/.test(line.replace(b.name, ""));
      const selEdges = (app.selection || []).filter((x) => x.kind === "edge" && x.bodyId === b.id && x.point);
      if (!named && selEdges.length) {
        const f = { id: newId(), type: cham ? "chamfer" : "fillet", name: store.nameFor(cham ? "chamfer" : "fillet"), body: b.id, edges: selEdges.map((e) => [...e.point, ...(e.dir || [])]), radius: r };
        await this.commitFeature(f);
        return `${b.name} の選んだ辺 ${selEdges.length} 本を ${cham ? "C" : "R"}${r}`;
      }
      const kind = /縦|垂直/.test(line) ? "vertical" : /上/.test(line) ? "top" : /下/.test(line) ? "bottom" : /水平|横/.test(line) ? "horizontal" : "all";
      const edges = await call("edgesQuery", { bodyId: b.id, kind });
      const KN = { vertical: "縦の辺", top: "上の辺", bottom: "下の辺", horizontal: "水平の辺", all: "すべての辺" };
      if (!edges.length) throw new Error(`${b.name} に${KN[kind]}がありません（もう丸めてある・円柱など）。辺の種類（縦の辺・上の辺・下の辺・水平の辺・すべての辺）を変えてください`);
      const f = { id: newId(), type: cham ? "chamfer" : "fillet", name: store.nameFor(cham ? "chamfer" : "fillet"), body: b.id, edges, edgeKind: kind, radius: r };
      await this.commitFeature(f);
      return `${b.name} の${KN[kind]} ${edges.length} 本を ${cham ? "C" : "R"}${r}`;
    }

    if (/^(移動|コピー|複製)/.test(line)) {
      let bs = this.bodiesIn(line); if (!bs.length) { const b = this.body(line); if (b) bs = [b]; }
      if (!bs.length) throw new Error("ボディがありません");
      const t = pairs(line)[0]; if (!t || t.length < 3) throw new Error("書き方: 移動 床板 0,0,100（X,Y,Z の移動量。動かさない向きは 0）");
      const copy = /コピー|複製/.test(line);
      const f = { id: newId(), type: "move", name: store.nameFor("move"), bodies: bs.map((b) => b.id), translate: t, rotAxis: "Z", angle: kv(line, "回転|角度") || "0", center: ["0", "0", "0"], copy };
      await this.commitFeature(f);
      return `${bs.map((b) => b.name).join("・")} を ${copy ? "コピー" : "移動"}（${t.join(", ")}）`;
    }

    if (/^削除/.test(line)) {
      const bs = this.bodiesIn(line, { fallbackSel: false }); if (!bs.length) throw new Error("消すボディの名前を書いてください（例: 削除 ボディ2）");
      const f = { id: newId(), type: "remove", name: store.nameFor("remove"), bodies: bs.map((b) => b.id) };
      await this.commitFeature(f);
      return `${bs.map((b) => b.name).join("・")} を削除しました`;
    }

    // ================= 追加の操作（Fusion の操作を一通り）
    const bodiesIn = (s) => this.bodiesIn(s, { fallbackSel: false });
    const axisOf = (s, def = "Z") => ((s.match(/(?:軸|方向)\s*([XYZ])/i) || s.match(/\b([XYZ])\s*(?:軸|方向)/i) || [, def])[1]).toUpperCase();

    // 尺度: 「スケール 0.1」「全部のサイズを10分の1に」「床板を2倍に」
    {
      const frac = line.match(/(\d+(?:\.\d+)?)\s*分の\s*(\d+(?:\.\d+)?)/), mul = line.match(/(\d+(?:\.\d+)?)\s*倍/), pct = line.match(/(\d+(?:\.\d+)?)\s*(?:%|パーセント)/);
      const isScale = /^(スケール|尺度|拡大|縮小)/.test(line) || ((frac || mul || pct) && /サイズ|大きさ|全体|全部|すべて|縮小|拡大|倍/.test(line) && !/^(押し?出|穴|移動|コピー|板|円|線|長方形)/.test(line));
      if (isScale) {
        const k = frac ? +frac[2] / +frac[1] : mul ? +mul[1] : pct ? +pct[1] / 100 : +(kv(line, "倍率|スケール|尺度|拡大|縮小") || NaN);
        if (!(k > 0)) throw new Error("書き方: スケール 0.1 ／ 全部のサイズを10分の1に ／ 床板を2倍に");
        const bs = bodiesIn(line);
        const f = { id: newId(), type: "scale", name: store.nameFor("scale"), bodies: bs.map((b) => b.id), factor: String(+k.toFixed(9)), about: /中心|その場/.test(line) ? "body" : "origin", center: ["0", "0", "0"] };
        await this.commitFeature(f);
        return `${bs.length ? bs.map((b) => b.name).join("・") : "すべてのボディ"} を ${+k.toFixed(6)} 倍に（${f.about === "body" ? "それぞれの中心" : "原点"}を基準。寸法は正確に ${+k.toFixed(6)} 倍）`;
      }
    }

    if (/^球/.test(line)) {
      const dia = kv(line, "直径|Ø|径") || (kv(line, "半径|R") ? `(${kv(line, "半径|R")})*2` : null);
      if (!dia) throw new Error("書き方: 球 直径100 位置 0,0,0");
      const pos = pairs(line.slice(Math.max(0, line.search(/位置|中心/))))[0] || ["0", "0", "0"];
      const f = { id: newId(), type: "sphere", name: store.nameFor("sphere"), position: [pos[0], pos[1], pos[2] ?? "0"], d: dia, operation: opOf(line), ...(name ? { bodyName: name } : {}) };
      await this.commitFeature(f); this.ctx.lastBody = `B_${f.id}`;
      return `球 Ø${dia} を作りました`;
    }

    // ボディを回す: 「回す 柱 90 軸 Z」「回転 柱 90」（ボディ名があればボディを回す。無ければスケッチの回転）
    if (/^(回す|ボディ回転|向きを変え)/.test(line) || (/^回転(?!角)/.test(line) && this.bodiesIn(line, { fallbackSel: false }).length)) {
      let bs = this.bodiesIn(line); if (!bs.length) throw new Error("書き方: 回す 柱 90 軸 Z（ボディの中心のまわりに。中心 0,0,0 で指定も可）");
      const L2 = bs.reduce((acc, b) => acc.replace(b.name, " "), line);
      const ang = kv(L2, "角度") || (L2.replace(/^\S+/, "").match(/(-?[0-9.]+)\s*(?:度|°)?/) || [])[1];
      if (!ang) throw new Error("角度を書いてください（例: 回す 柱 90 軸 Z）");
      const ax = axisOf(L2);
      let c = /中心/.test(L2) && pairs(L2.slice(L2.search(/中心/)))[0];
      if (!c) { const bb = await call("measure", { ids: bs.map((b) => b.id), density: 1 }); const lo = [0, 1, 2].map((i) => Math.min(...bb.list.map((x) => x.bounds[0][i]))), hi = [0, 1, 2].map((i) => Math.max(...bb.list.map((x) => x.bounds[1][i]))); c = lo.map((v, i) => String(+((v + hi[i]) / 2).toFixed(4))); }
      const f = { id: newId(), type: "move", name: store.nameFor("move"), bodies: bs.map((b) => b.id), translate: ["0", "0", "0"], rotAxis: ax, angle: ang, center: [c[0], c[1], c[2] ?? "0"], copy: /コピー/.test(line) };
      await this.commitFeature(f);
      return `${bs.map((b) => b.name).join("・")} を ${ax} 軸のまわりに ${ang}° 回しました（中心 ${f.center.join(",")}）`;
    }

    // 置く（場所を直接指定）: 「置く 柱 位置 100,100,20」（外形の最小の角をそこへ）／「置く 柱 中心 300,200,50」／「置く 柱 上 床板 [中央]」
    if (/^(置く|配置|載せる|乗せる)/.test(line)) {
      const all = this.bodiesIn(line, { fallbackSel: false });
      // 「上 床板」「床板の上」: 向きの言葉と、基準にするボディ
      let onM = null, refB = null;
      for (const m of all) {
        const re = new RegExp(`(?:^|\\s)(上|下|右|左|前|後ろ|後|奥)(?:に|へ|側)?\\s*${m.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}|${m.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*の\\s*(上|下|右|左|前|後ろ|後|奥)`);
        const mm = line.match(re); if (mm) { onM = [mm[0], mm[1] || mm[2]]; refB = m; break; }
      }
      let bs = all.filter((m) => m !== refB); if (!bs.length) bs = this.selectedBodies().filter((m) => m !== refB);
      if (!bs.length) throw new Error("書き方: 置く 柱 位置 100,100,20 ／ 置く 柱 中心 300,200,50 ／ 置く 柱 上 床板 [中央]");
      const r = await call("measure", { ids: [...bs, ...(refB ? [refB] : [])].map((b) => b.id), density: 1 });
      const B = (ids) => { const L = r.list.filter((x) => ids.includes(x.id)); return [[0, 1, 2].map((i) => Math.min(...L.map((x) => x.bounds[0][i]))), [0, 1, 2].map((i) => Math.max(...L.map((x) => x.bounds[1][i])))]; };
      const [lo, hi] = B(bs.map((b) => b.id));
      const N = (v) => +(+v).toFixed(4);
      let d;
      if (refB && onM) {
        const [rlo, rhi] = B([refB.id]); d = [0, 0, 0];
        const side = onM[1];
        const ax = /上|下/.test(side) ? 2 : /右|左/.test(side) ? 0 : 1, pos = /上|右|後|奥/.test(side);
        d[ax] = pos ? rhi[ax] - lo[ax] : rlo[ax] - hi[ax];
        if (/中央|真ん中|中心/.test(line)) for (const i of [0, 1, 2]) if (i !== ax) d[i] = (rlo[i] + rhi[i]) / 2 - (lo[i] + hi[i]) / 2;
      } else {
        const at = line.search(/位置|中心|座標/); const t = at >= 0 && pairs(line.slice(at))[0];
        if (!t) throw new Error("書き方: 置く 柱 位置 100,100,20（外形の最小の角をその点へ）／ 置く 柱 中心 300,200,50");
        const v = t.map((x) => (/^[-+0-9.]+$/.test(x) ? +x : NaN)); if (v.some((x) => !isFinite(x))) throw new Error("置く の座標は数値で書いてください");
        while (v.length < 3) v.push(lo[v.length]);
        d = /中心/.test(line) ? v.map((x, i) => x - (lo[i] + hi[i]) / 2) : v.map((x, i) => x - lo[i]);
      }
      d = d.map(N);
      if (d.every((x) => Math.abs(x) < 1e-6)) return `${bs.map((b) => b.name).join("・")} はもうその位置にあります`;
      const f = { id: newId(), type: "move", name: store.nameFor("move"), bodies: bs.map((b) => b.id), translate: d.map(String), rotAxis: "Z", angle: "0", center: ["0", "0", "0"], copy: false };
      await this.commitFeature(f);
      return `${bs.map((b) => b.name).join("・")} を置きました（移動量 ${d.join(", ")}）`;
    }

    // 部品の一覧と数（同じ大きさ・材料のものをまとめて数える）「部品一覧」「何枚」
    if (/^(部品一覧|部品表|一覧|数|個数|枚数|何枚|何個|全部で)/.test(line)) {
      const bs = this.bodiesIn(line, { fallbackSel: false }).length ? this.bodiesIn(line, { fallbackSel: false }) : this.app.meshes.filter((m) => !m.hidden);
      if (!bs.length) { this.queryOut.push("ボディはありません（0 個）"); return "ボディはありません"; }
      const r = await call("measure", { ids: bs.map((b) => b.id), density: 1 });
      const groups = new Map();
      let total = 0;
      for (const b of r.list) {
        const m = this.app.meshes.find((x) => x.id === b.id), dens = (m && m.material && m.material.density) || 1, mat = (m && m.material && m.material.name) || "";
        const dims = [0, 1, 2].map((i) => +(b.bounds[1][i] - b.bounds[0][i]).toFixed(1)).sort((p, q) => q - p);
        const key = dims.join("×") + "|" + mat + "|" + (b.volume / 1000).toFixed(0);
        const g = groups.get(key) || { dims, mat, names: [], kg: 0 }; g.names.push(b.name); g.kg += b.volume / 1e6 * dens; groups.set(key, g); total += b.volume / 1e6 * dens;
      }
      const rows = [...groups.values()].map((g) => `${g.dims.join("×")} mm${g.mat ? "・" + g.mat : ""} … ${g.names.length} 個（${g.names.join("、")}）計 ${+g.kg.toFixed(3)} kg`);
      const sum = `合計 ${bs.length} 個（${groups.size} 種類）、重さの合計 ${+total.toFixed(3)} kg`;
      this.log(`<pre class="cmd-help">${esc(rows.join("\n") + "\n" + sum)}</pre>`);
      this.queryOut.push(...rows, sum);
      return sum;
    }

    // 視点: 「視点 上」「正面から見せて」「全体を表示」
    if (/^(視点|ビュー|見る|全体表示|ズーム|画面に合わせ)/.test(line) || /から見/.test(line)) {
      const v = app.viewer;
      const VIEWS = [["上", [0, 0, 1], [0, 1, 0]], ["下", [0, 0, -1], [0, -1, 0]], ["正面|前", [0, -1, 0], [0, 0, 1]], ["背面|後ろ|後", [0, 1, 0], [0, 0, 1]], ["右", [1, 0, 0], [0, 0, 1]], ["左", [-1, 0, 0], [0, 0, 1]]];
      const hit = VIEWS.find(([k]) => new RegExp(k).test(line.replace(/^\S*(視点|ビュー)/, "")));
      if (hit && v) { v.setView(hit[1], hit[2]); setTimeout(() => v.fit(), 50); return `${hit[0].split("|")[0]}から見た向きにしました`; }
      if (v) { if (/ホーム|斜め|等角|元/.test(line)) v.home(); else v.fit(); }
      return "全体が見えるようにしました";
    }

    // 色: 「色 赤 床板 柱」「色 青 すべて」
    if (/^色/.test(line)) {
      const bs = this.bodiesIn(line); if (!bs.length) throw new Error("書き方: 色 赤 床板 ／ 色 青 すべて");
      const hex = colorOf(line); if (!hex) throw new Error(COLOR_HELP);
      store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const b of bs) p.bodyProps[b.id] = { ...(p.bodyProps[b.id] || {}), color: hex }; }, { silent: true });
      await app.rebuild();
      return `${bs.map((b) => b.name).join("・")} の色を ${hex} に`;
    }

    if (/^回転(?!角)/.test(line)) {
      const sk = this.sketchFeature();
      const ang = kv(line, "角度") || (line.match(/^回転\s*(-?[0-9.]+)/) || [, "360"])[1];
      const ax = /横|X/i.test((line.match(/軸\s*(\S+)/) || [, ""])[1]) ? "u" : "v";
      const f = { id: newId(), type: "revolve", name: store.nameFor("revolve"), sketch: sk.id, profiles: [], axis: ax, angle: ang, operation: opOf(line), ...(name ? { bodyName: name } : {}) };
      await this.commitFeature(f); if (f.operation === "new") this.ctx.lastBody = `B_${f.id}`; this.ctx.sketch = null;
      return `回転 ${ang}°（スケッチの${ax === "v" ? "縦（Y）" : "横（X）"}軸のまわり）`;
    }

    if (/^シェル/.test(line)) {
      const b = this.body(line); if (!b) throw new Error("ボディがありません");
      const t = kv(line, "厚さ|厚み|肉厚|T") || (line.match(/^シェル\s*(-?[0-9.]+)/) || [])[1];
      if (!t) throw new Error("書き方: シェル 厚さ2 上面 [ボディ名]（取り除く面を書く。なければ中を空洞に）");
      const faces = [];
      for (const k of Object.keys(FACES)) if (line.includes(k)) { const fp = await this.facePoint(k, b); faces.push([...fp.p, ...fp.n]); }
      const f = { id: newId(), type: "shell", name: store.nameFor("shell"), body: b.id, faces, thickness: t };
      await this.commitFeature(f);
      return `${b.name} をシェル（厚さ ${t}${faces.length ? "、開ける面 " + faces.length : "、中を空洞に"}）`;
    }

    if (/^ミラー|^鏡/.test(line)) {
      const bs = bodiesIn(line); if (!bs.length) throw new Error("書き方: ミラー 柱 YZ（YZ・XZ・XY）[位置 300] [結合]");
      const pl = (line.match(/\b(YZ|XZ|XY)\b/i) || [, "YZ"])[1].toUpperCase();
      const f = { id: newId(), type: "mirror", name: store.nameFor("mirror"), bodies: bs.map((b) => b.id), plane: pl, offset: kv(line, "位置|オフセット") || "0", join: /結合/.test(line) };
      await this.commitFeature(f);
      return `${bs.map((b) => b.name).join("・")} を ${pl} 平面でミラー`;
    }

    if (/^(矩形パターン|並べる|パターン)/.test(line)) {
      const bs = bodiesIn(line); if (!bs.length) throw new Error("書き方: 矩形パターン 柱 X方向 5個 間隔100 [Y方向 3個 間隔200]");
      const segs = [...line.matchAll(/([XYZ])\s*方向\s*(\S+?)\s*個\s*間隔\s*(\S+)/gi)];
      if (!segs.length) throw new Error("書き方: 矩形パターン 柱 X方向 5個 間隔100");
      const f = { id: newId(), type: "pattern", name: store.nameFor("pattern"), bodies: bs.map((b) => b.id), dir: segs[0][1].toUpperCase(), count: segs[0][2], spacing: segs[0][3], dir2: segs[1] ? segs[1][1].toUpperCase() : "", count2: segs[1] ? segs[1][2] : "2", spacing2: segs[1] ? segs[1][3] : "100", join: /結合/.test(line) };
      await this.commitFeature(f);
      return `${bs.map((b) => b.name).join("・")} を ${segs.map((s) => `${s[1]} 方向に ${s[2]} 個（間隔 ${s[3]}）`).join("、")}`;
    }

    if (/^円形パターン/.test(line)) {
      const bs = bodiesIn(line); if (!bs.length) throw new Error("書き方: 円形パターン 柱 6個 軸 Z 中心 0,0,0 [角度 360]");
      const cnt = (line.match(/(\S+?)\s*個/) || [, "6"])[1];
      const c = pairs(line.slice(Math.max(0, line.search(/中心/))))[0] || ["0", "0", "0"];
      const f = { id: newId(), type: "cpattern", name: store.nameFor("cpattern"), bodies: bs.map((b) => b.id), axis: axisOf(line), center: [c[0], c[1], c[2] ?? "0"], count: cnt, angle: kv(line, "角度") || "360", join: /結合/.test(line) };
      await this.commitFeature(f);
      return `${bs.map((b) => b.name).join("・")} を ${f.axis} 軸のまわりに ${cnt} 個`;
    }

    if (/^分割/.test(line)) {
      const b = this.body(line); if (!b) throw new Error("ボディがありません");
      const pl = (line.match(/\b(YZ|XZ|XY)\b/i) || [])[1];
      if (!pl) throw new Error("書き方: 分割 床板 YZ 位置 300（YZ・XZ・XY 平面で 2 つに）");
      const f = { id: newId(), type: "split", name: store.nameFor("split"), body: b.id, plane: pl.toUpperCase(), offset: kv(line, "位置|オフセット") || "0", face: null };
      await this.commitFeature(f);
      return `${b.name} を ${pl.toUpperCase()} 平面（位置 ${f.offset}）で 2 つに分割`;
    }

    if (/^(結合|合体|くっつけ|ボディ結合)/.test(line)) {
      const bs = bodiesIn(line); if (bs.length < 2) throw new Error("書き方: 結合 床板 柱 [切り取り | 交差]（最初のボディに、後のボディを）");
      const op = /切り?取り|カット|引く/.test(line) ? "cut" : /交差/.test(line) ? "intersect" : "join";
      const f = { id: newId(), type: "combine", name: store.nameFor("combine"), target: bs[0].id, tools: bs.slice(1).map((b) => b.id), op, keepTools: /保持|残す/.test(line) };
      await this.commitFeature(f);
      return `${bs[0].name} に ${bs.slice(1).map((b) => b.name).join("・")} を${{ join: "結合", cut: "切り取り", intersect: "交差" }[op]}`;
    }

    if (/^(プレス\/?プル|プレスプル|面を押し出|面を押し込)/.test(line)) {
      const b = this.body(line); if (!b) throw new Error("ボディがありません");
      const fp = await this.facePoint(line, b); if (!fp) throw new Error("書き方: プレスプル 上面 10 [ボディ名]（マイナスで押し込み）");
      const dist = kv(line, "距離") || (line.replace(/^\S+\s*/, "").match(/(-?[0-9.]+)/) || [])[1];
      if (!dist) throw new Error("距離を書いてください（例: プレスプル 上面 10）");
      const f = { id: newId(), type: "presspull", name: store.nameFor("presspull"), body: b.id, face: [...fp.p, ...fp.n], distance: dist, operation: /新規/.test(line) ? "new" : "join" };
      await this.commitFeature(f);
      return `${b.name} の${fp.name}を ${dist} ${+dist < 0 ? "押し込み" : "押し出し"}`;
    }

    if (/^構築平面|^作業平面/.test(line)) {
      const off = kv(line, "オフセット|距離|高さ|離れ") || "0";
      const std = (line.match(/\b(XY|XZ|YZ)\b/i) || [])[1];
      let base, baseRef = null;
      if (std) { const n = { XY: [0, 0, 1], XZ: [0, -1, 0], YZ: [1, 0, 0] }[std.toUpperCase()]; base = [0, 0, 0, ...n]; }
      else { const b = this.body(line); const fp = b && await this.facePoint(line, b); if (!fp) throw new Error("書き方: 構築平面 XY オフセット 100 ／ 構築平面 上面 床板 オフセット 80"); base = [...fp.p, ...fp.n]; baseRef = { body: b.id, point: fp.p }; }
      const f = { id: newId(), type: "plane", name: store.nameFor("plane"), kind: "offset", base, ...(baseRef ? { baseRef } : {}), distance: off };
      await this.commitFeature(f);
      return `${f.name}（オフセット ${off}）を作りました。「スケッチ ${f.name}」でその平面にスケッチできます`;
    }

    if (/^(名前変更|名前を変更|改名)/.test(line)) {
      const b = bodiesIn(line)[0]; if (!b) throw new Error("書き方: 名前変更 ボディ1 床板");
      const nn = line.replace(/^\S+\s*/, "").replace(b.name, "").replace(/[をにへ→]|変更|する/g, " ").trim().split(/\s+/).pop();
      if (!nn) throw new Error("新しい名前を書いてください");
      store.commit((p) => { p.bodyProps = p.bodyProps || {}; p.bodyProps[b.id] = { ...(p.bodyProps[b.id] || {}), name: nn }; }, { silent: true });
      await this.app.rebuild();
      return `${b.name} → ${nn}`;
    }

    if (/^(非表示|隠す|表示|すべて表示|全部表示)/.test(line)) {
      if (/^(すべて|全部)表示/.test(line)) { store.commit((p) => { for (const k of Object.keys(p.bodyProps || {})) p.bodyProps[k].hidden = false; for (const c of p.components || []) c.hidden = false; }, { silent: true }); await this.app.rebuild(); return "すべて表示しました"; }
      const hide = /^(非表示|隠す)/.test(line);
      const bs = bodiesIn(line); if (!bs.length) throw new Error("書き方: 非表示 柱 ／ 表示 柱 ／ すべて表示");
      store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const b of bs) p.bodyProps[b.id] = { ...(p.bodyProps[b.id] || {}), hidden: hide }; }, { silent: true });
      await this.app.rebuild();
      return `${bs.map((b) => b.name).join("・")} を${hide ? "非表示" : "表示"}`;
    }

    if (/^(抑制解除|抑制を解除|抑制|無効|有効)/.test(line)) {
      const on = !/解除|有効/.test(line);
      const f = store.project.features.filter((x) => line.includes(x.name)).sort((a, b) => b.name.length - a.name.length)[0];
      if (!f) throw new Error("書き方: 抑制 穴1 ／ 抑制解除 穴1（タイムラインの名前）");
      store.commit((p) => { p.features.find((x) => x.id === f.id).suppressed = on; }, { silent: true });
      await this.app.rebuild();
      return `${f.name} を${on ? "抑制（一時的に無効）" : "有効"}にしました`;
    }

    if (/^(材料|材質)/.test(line) || /材料|材質/.test(line) && bodiesIn(line).length) {
      const bs = bodiesIn(line); if (!bs.length) throw new Error("書き方: 材料 床板 PETフォーム（または 床板 材料 アルミ）");
      const M = (this.app.MATERIALS || []).filter((m) => m[0]).sort((a, b) => b[0].length - a[0].length).find((m) => line.includes(m[0]));
      const dens = kv(line, "密度");
      if (!M && !dens) throw new Error("材料名（" + (this.app.MATERIALS || []).filter((m) => m[0]).map((m) => m[0]).join("・") + "）か 密度 0.5 を書いてください");
      store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const b of bs) p.bodyProps[b.id] = { ...(p.bodyProps[b.id] || {}), material: { name: M ? M[0] : "", density: dens ? +dens : M[2] } }; }, { silent: true });
      await this.app.rebuild();
      return `${bs.map((b) => b.name).join("・")} の材料を ${M ? M[0] : "密度 " + dens}`;
    }

    if (/^(体積|重さ|重量|質量|大きさ|寸法|物理プロパティ|外形)/.test(line)) {
      const bs = bodiesIn(line).length ? bodiesIn(line) : this.app.meshes.filter((m) => !m.hidden);
      const r = await call("measure", { ids: bs.map((b) => b.id), density: 1 });
      const f = (v, d = 1) => (+v.toFixed(d)).toLocaleString();
      const rows = r.list.map((b) => { const m = this.app.meshes.find((x) => x.id === b.id); const dens = (m && m.material && m.material.density) || 1; return `${b.name}: ${f(b.bounds[1][0] - b.bounds[0][0])}×${f(b.bounds[1][1] - b.bounds[0][1])}×${f(b.bounds[1][2] - b.bounds[0][2])} mm、体積 ${f(b.volume / 1000)} cm³、重さ ${f(b.volume / 1e6 * dens, 3)} kg（密度 ${dens}）`; });
      this.log(`<pre class="cmd-help">${esc(rows.join("\n"))}</pre>`);
      this.queryOut.push(...rows);
      if (bs.length > 1) { const tv = r.list.reduce((a, b) => a + b.volume, 0), tw = r.list.reduce((a, b) => { const m = this.app.meshes.find((x) => x.id === b.id); return a + b.volume / 1e6 * ((m && m.material && m.material.density) || 1); }, 0); this.queryOut.push(`合計: ${bs.length} 個、体積 ${f(tv / 1000)} cm³、重さ ${f(tw, 3)} kg`); }
      return rows.length === 1 ? rows[0] : `${bs.length} 個のボディを計測しました`;
    }

    if (/^干渉/.test(line)) {
      const ids = this.app.meshes.filter((m) => !m.hidden).map((m) => m.id);
      const r = await call("interference", { ids });
      if (!r.length) { this.queryOut.push("干渉はありません"); return "干渉はありません"; }
      this.log(`<pre class="cmd-help">${esc(r.map((x) => `${x.an} × ${x.bn}: ${(x.volume / 1000).toFixed(2)} cm³`).join("\n"))}</pre>`);
      this.queryOut.push(...r.map((x) => `干渉 ${x.an} × ${x.bn}: ${(x.volume / 1000).toFixed(2)} cm³`));
      return `${r.length} 組の干渉があります`;
    }

    if (/^(多角形|六角形|正多角形)/.test(line)) {
      const ps = pairs(line); const dd = kv(line, "直径|Ø|径"); const n = +(line.match(/(\d+)\s*(角|辺)/) || [, /六角/.test(line) ? 6 : 6])[1];
      if (!ps[0] || !dd) throw new Error("書き方: 多角形 中心 100,100 直径80 6角（外接円の直径）");
      const r = +eval(dd) / 2, c = ps[0].map(Number), ents = [];
      const P = (k) => [+(c[0] + r * Math.cos(Math.PI / 2 + k * 2 * Math.PI / n)).toFixed(6), +(c[1] + r * Math.sin(Math.PI / 2 + k * 2 * Math.PI / n)).toFixed(6)];
      for (let k = 0; k < n; k++) { const a = P(k), b = P(k + 1); ents.push({ type: "line", x1: a[0], y1: a[1], x2: b[0], y2: b[1] }); }
      await this.addEntities(ents);
      return `${n} 角形を追加しました`;
    }

    if (/^(長穴|スロット)/.test(line)) {
      const ps = pairs(line); const w = kv(line, "幅|W|太さ");
      if (ps.length < 2 || !w) throw new Error("書き方: 長穴 0,0 100,0 幅20（両端の中心と幅）");
      const a = ps[0].map(Number), b = ps[1].map(Number), r = +eval(w) / 2;
      const d = [b[0] - a[0], b[1] - a[1]], L = Math.hypot(...d); if (L < 1e-9) throw new Error("両端の中心が同じです");
      const n = [-d[1] / L * r, d[0] / L * r], u = [d[0] / L * r, d[1] / L * r], R = (v) => +v.toFixed(6);
      await this.addEntities([
        { type: "line", x1: R(a[0] + n[0]), y1: R(a[1] + n[1]), x2: R(b[0] + n[0]), y2: R(b[1] + n[1]) },
        { type: "arc", x1: R(b[0] + n[0]), y1: R(b[1] + n[1]), xm: R(b[0] + u[0]), ym: R(b[1] + u[1]), x2: R(b[0] - n[0]), y2: R(b[1] - n[1]) },
        { type: "line", x1: R(b[0] - n[0]), y1: R(b[1] - n[1]), x2: R(a[0] - n[0]), y2: R(a[1] - n[1]) },
        { type: "arc", x1: R(a[0] - n[0]), y1: R(a[1] - n[1]), xm: R(a[0] - u[0]), ym: R(a[1] - u[1]), x2: R(a[0] + n[0]), y2: R(a[1] + n[1]) },
      ]);
      return `長穴（中心間 ${+L.toFixed(3)}、幅 ${w}）を追加しました`;
    }

    if (/^(元に戻すまで|ここまで戻る|ロールバック)/.test(line)) {
      const f = store.project.features.filter((x) => line.includes(x.name)).sort((a, b) => b.name.length - a.name.length)[0];
      store.commit((p) => { p.rollback = f ? p.features.findIndex((x) => x.id === f.id) : null; }, { silent: true });
      await this.app.rebuild();
      return f ? `${f.name} の手前まで戻しました（ここに新しい手順が入ります。「ロールバック解除」で最後へ）` : "最後まで進めました";
    }
    if (/^(ロールバック解除|最後まで)/.test(line)) { store.commit((p) => { p.rollback = null; }, { silent: true }); await this.app.rebuild(); return "最後まで進めました"; }

    if (/^(手順を?書き出|手順に|手順として)/.test(line)) {
      const t = this.toScript();
      const blob = new Blob([t + "\n"], { type: "text/plain;charset=utf-8" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${(store.project.name || "モデル").replace(/[\\/:*?"<>|]/g, "_")}_手順.txt`; a.click();
      this.log(`<pre class="cmd-help">${esc(t)}</pre>`);
      return `今のモデルを手順（${t.split("\n").length} 行）に書き起こし、ファイルに保存しました`;
    }

    // ---- 書き出し（そのまま渡せるデータに）
    if (/書き?出|エクスポート|保存/.test(line) || /^図面/.test(line)) {
      const ids = app.meshes.filter((m) => !m.hidden).map((m) => m.id);
      if (/図面/.test(line)) {
        const kind = /DXF/i.test(line) ? "dxfall" : /SVG/i.test(line) ? "svg" : "pdf";
        app.setWorkspace("drawing"); await new Promise((r) => setTimeout(r, 600));
        await app.drawing.export(kind);
        app.setWorkspace("design");
        return `図面を ${kind === "dxfall" ? "DXF" : kind.toUpperCase()} で書き出しました（ダウンロード）`;
      }
      const fmt = /STL/i.test(line) ? "stl" : /OBJ/i.test(line) ? "obj" : /GLB/i.test(line) ? "glb" : /BREP/i.test(line) ? "brep" : /STEP|STP/i.test(line) ? "step" : null;
      if (!fmt) throw new Error("形式を書いてください（STEP・STL・OBJ・GLB・図面 PDF・図面 DXF）");
      if (!ids.length) throw new Error("書き出すボディがありません");
      await app.export3D(fmt, ids);
      return `${ids.length} 個のボディを ${fmt.toUpperCase()} で書き出しました（ダウンロード）`;
    }

    // ---- 直す: 「床板 厚さ 30」「穴1 径 10」など
    const mod = this.findTarget(line);
    if (mod) return this.modify(mod, line);

    throw new Error("分からない指示です。「使い方」で書き方を確認してください");
  }
}
