// iPhone・タッチ操作向けの調整（main.js からは installMobile(app) を呼ぶだけ）
// - よく使う道具だけを前に並べ、残りは「その他」シートにまとめる
// - ダイアログが画面の下（縦）／右（横）を覆っても、モデルが見える位置にずらして表示
// - 数字の入力: 数字キーボード（inputmode）＋ − + × ÷ 確定 の補助ボタン
// - キーボードが出たら画面を見える範囲に縮め、入力欄やボタンが隠れないように
// - ページ自体の拡大・スクロール（ピンチ・ダブルタップ・引っぱり）を止める
// - タイムライン・部品ツリーは タップ／長押しでメニュー、ダブルタップで編集
import { ICON } from "./icons.js";

const MQ = "(max-width: 820px), (pointer: coarse) and (max-height: 500px)";
const mql = window.matchMedia(MQ);
export const isMobileLayout = () => mql.matches;
const COARSE = window.matchMedia("(pointer: coarse)").matches;

// 前に並べる道具（この順）。それ以外は「その他」へ
const FRONT = {
  solid: ["sketch", "extrude", "hole", "fillet", "move", "cmdline"],
  sketch: ["finish", "line", "rect", "circle", "c_dim", "select"],
};
// 横向き（高さが足りない）では縦に並べるので少なめに。AI は上の帯のボタンから
const FRONT_LAND = {
  solid: ["sketch", "extrude", "hole", "fillet", "move"],
  sketch: ["finish", "line", "rect", "circle", "c_dim", "select"],
};
const landMQ = window.matchMedia("(orientation: landscape) and (max-height: 500px)");
const MORE_ICON = `<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="5" y="5" width="9" height="9" rx="2" stroke="#2f7de1"/><rect x="18" y="5" width="9" height="9" rx="2" stroke="#2f7de1"/><rect x="5" y="18" width="9" height="9" rx="2" stroke="#2f7de1"/><path d="M22.5 18v9M18 22.5h9" stroke="#e8732a"/></svg>`;

export function installMobile(app) {
  const root = document.documentElement;
  if (COARSE) root.classList.add("touch");
  if (window.navigator.standalone || window.matchMedia("(display-mode: standalone)").matches) root.classList.add("standalone");

  // ---------------------------------------------------------------- 道具の並び
  const origRefresh = app.refreshTools.bind(app);
  app.refreshTools = () => { origRefresh(); arrangeTools(app); };
  mql.addEventListener?.("change", () => { closeSheet(); app.refreshTools(); applyInset(); });
  landMQ.addEventListener?.("change", () => { closeSheet(); app.refreshTools(); });
  const ai = document.createElement("button");
  ai.className = "icon-btn m-ai"; ai.title = "AI に頼む"; ai.textContent = "AI に頼む";
  ai.onclick = () => app.runTool("cmdline");
  document.querySelector(".tb-row1 .ws-switch")?.before(ai);
  app.refreshTools();

  // ---------------------------------------------------------------- ページの拡大・スクロールを止める
  // iOS の Safari は user-scalable=no を無視するので、ピンチ（gesture*）とダブルタップを自前で止める
  for (const t of ["gesturestart", "gesturechange", "gestureend"]) document.addEventListener(t, (e) => e.preventDefault(), { passive: false });
  document.addEventListener("touchmove", (e) => {
    if (e.touches.length > 1) { if (!e.target.closest || !e.target.closest("#view3d")) e.preventDefault(); return; }
    if (!scrollableParent(e.target)) e.preventDefault();
  }, { passive: false });
  // ダブルタップでの拡大は CSS の touch-action: manipulation で止める（素早い連続タップは邪魔しない）

  // ---------------------------------------------------------------- ダイアログ: 縮める・モデルの見える位置
  const dlg = document.getElementById("dialog");
  let minimized = false, wasHidden = dlg.classList.contains("hidden");
  const syncDialog = () => {
    const hidden = dlg.classList.contains("hidden");
    if (hidden && !wasHidden) minimized = false;
    wasHidden = hidden;
    const want = minimized && !hidden && isMobileLayout();
    if (dlg.classList.contains("m-min") !== want) dlg.classList.toggle("m-min", want);
    const head = dlg.querySelector(".dlg-head");
    if (head && isMobileLayout() && !head.querySelector(".m-grip")) {
      const g = document.createElement("span"); g.className = "m-grip"; g.setAttribute("aria-hidden", "true");
      head.insertBefore(g, head.firstChild);
    }
    if (head) head.title = isMobileLayout() ? (want ? "タップで広げる" : "タップで小さくする（モデルを広く見る）") : head.title;
    applyInset();
  };
  new MutationObserver(syncDialog).observe(dlg, { childList: true, attributes: true, attributeFilter: ["class"] });
  dlg.addEventListener("click", (e) => {
    if (!isMobileLayout()) return;
    const head = e.target.closest(".dlg-head");
    if (!head || e.target.closest("button,input,select,textarea")) return;
    minimized = !minimized; syncDialog();
  });
  new ResizeObserver(() => applyInset()).observe(dlg);

  // 下（縦向き）／右（横向き）を覆うダイアログのぶん、3D の中心をずらす（モデルが隠れないように）
  const v = app.viewer;
  // 全体表示も、ダイアログに隠れていない範囲に収める
  const origFit = v.fit.bind(v);
  v.fit = (box) => {
    origFit(box);
    const ins = v.viewInset, r = v.canvas.getBoundingClientRect();
    if (ins && (ins.x || ins.y) && r.width && r.height) {
      const f = Math.max(r.width / Math.max(40, r.width - 2 * ins.x), r.height / Math.max(40, r.height - 2 * ins.y));
      v.viewHalf *= f; v.resize(); v.controls.update();
    }
  };
  const origResize = v.resize.bind(v);
  v.resize = () => { origResize(); applyInset(true); };
  function applyInset(fromResize) {
    const root = document.documentElement;
    const cam = v.camera, cv = v.canvas;
    const r = cv.getBoundingClientRect();
    let ox = 0, oy = 0, coverX = 0, coverY = 0;
    const dws = document.getElementById("drawing-ws");
    if (isMobileLayout() && !dlg.classList.contains("hidden") && (!dws || dws.classList.contains("hidden")) && r.width && r.height) {
      const d = dlg.getBoundingClientRect();
      if (d.width && d.height) {
        if (d.width >= r.width * 0.85) { coverY = Math.max(0, r.bottom - d.top); oy = Math.min(r.height * 0.6, coverY) / 2; }
        else { coverX = Math.max(0, r.right - d.left); ox = Math.min(r.width * 0.6, coverX) / 2; }
      }
    }
    ox = Math.round(ox); oy = Math.round(oy);
    const cur = cam.view && cam.view.enabled ? cam.view : null;
    const w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height));
    if (!ox && !oy) {
      if (cur) { cam.clearViewOffset(); v.dirty = true; }
    } else if (!cur || cur.offsetX !== ox || cur.offsetY !== oy || cur.fullWidth !== w || cur.fullHeight !== h) {
      cam.setViewOffset(w, h, ox, oy, w, h); v.dirty = true;
    } else if (fromResize) cam.updateProjectionMatrix();
    v.viewInset = { x: ox, y: oy };
    // ダイアログが出ている間は、下のナビ（ホーム・全体表示）を左上へ（ダイアログにもモデルにも重ならないように）
    root.classList.toggle("dlg-cover", !!(coverX || coverY));
  }

  // ---------------------------------------------------------------- キーボード
  const vv = window.visualViewport;
  let simKb = null; // テスト用: キーボードの高さを模擬
  const onViewport = () => {
    const H = window.innerHeight;
    const vh = simKb != null ? H - simKb : vv ? vv.height : H;
    const open = H - vh > 80;
    root.classList.toggle("kb-open", open);
    if (open) root.style.setProperty("--vvh", Math.round(vh) + "px"); else root.style.removeProperty("--vvh");
    if (open && vv && simKb == null && (vv.offsetTop || window.scrollY)) window.scrollTo(0, 0);
    placeNumbar();
    const a = document.activeElement;
    if (open && a && a.matches && a.matches("input,textarea")) setTimeout(() => { try { a.scrollIntoView({ block: "nearest" }); } catch { /* */ } }, 50);
  };
  if (vv) { vv.addEventListener("resize", onViewport); vv.addEventListener("scroll", onViewport); }
  window.addEventListener("orientationchange", () => setTimeout(onViewport, 300));

  // ---------------------------------------------------------------- 数字の入力
  const isNumInput = (el) => el && el.tagName === "INPUT" && (el.type === "text" || el.type === "" || el.type === "number") && (
    el.matches("#dialog input[data-k]:not([placeholder='自動']), #dialog input[data-pt], .inbox input, .xbox input, #overlay > input, input[data-num]"));
  const markNum = (scope) => {
    for (const el of scope.querySelectorAll ? scope.querySelectorAll("input:not([data-numchk])") : []) {
      el.setAttribute("data-numchk", "1");
      if (!isNumInput(el)) continue;
      el.setAttribute("data-num", "1");
      if (!el.hasAttribute("inputmode")) el.setAttribute("inputmode", "decimal");
      el.setAttribute("enterkeyhint", "done");
      el.setAttribute("autocomplete", "off"); el.setAttribute("autocorrect", "off"); el.setAttribute("autocapitalize", "off"); el.setAttribute("spellcheck", "false");
    }
  };
  new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1) { if (n.tagName === "INPUT") markNum(n.parentNode || n); else markNum(n); } })
    .observe(document.getElementById("app"), { childList: true, subtree: true });
  markNum(document);

  // スケッチの寸法入力（長方形の幅・高さ など）には Enter キーが無いので「確定」ボタンを付ける
  new MutationObserver(() => {
    for (const box of document.querySelectorAll("#overlay .inbox:not(.ask):not([data-okbtn])")) {
      box.setAttribute("data-okbtn", "1");
      if (!COARSE && !isMobileLayout()) continue;
      const b = document.createElement("button"); b.className = "btn primary m-inbox-ok"; b.textContent = "確定";
      // 押しても入力欄からフォーカスを外さない（外すと入力が消えることがある）。指を離したときに確定
      b.addEventListener("pointerdown", (e) => e.preventDefault());
      b.addEventListener("mousedown", (e) => e.preventDefault());
      onRelease(b, () => { const inp = box.querySelector("input"); if (inp) pressEnter(inp); });
      box.appendChild(b);
    }
  }).observe(document.getElementById("overlay"), { childList: true });

  const bar = document.createElement("div");
  bar.id = "numbar"; bar.className = "hidden";
  bar.innerHTML = `<button data-ins="-" title="マイナス">−</button><button data-ins="+" title="たす">＋</button><button data-ins="*" title="かける">×</button><button data-ins="/" title="わる">÷</button><button data-kbd="1" title="文字（パラメータ名）を入力">あA</button><button data-ok="1" class="ok">確定</button>`;
  document.body.appendChild(bar);
  let numTarget = null;
  const showBar = (on) => {
    bar.classList.toggle("hidden", !on);
    root.classList.toggle("numbar-on", on);
    placeNumbar();
  };
  function placeNumbar() {
    if (bar.classList.contains("hidden")) return;
    const H = window.innerHeight;
    const vh = simKb != null ? H - simKb : vv ? vv.height : H;
    const top = (vv && simKb == null ? vv.offsetTop : 0) + vh - bar.offsetHeight;
    bar.style.top = Math.max(0, top) + "px";
  }
  document.addEventListener("focusin", (e) => {
    const t = e.target;
    if (!(COARSE || isMobileLayout()) || !isNumInput(t)) { numTarget = null; showBar(false); return; }
    numTarget = t; showBar(true);
  });
  document.addEventListener("focusout", () => { setTimeout(() => { if (!document.activeElement || document.activeElement !== numTarget) { numTarget = null; showBar(false); } }, 0); });
  // ボタンを押しても入力欄からフォーカスを外さない（キーボードを閉じない）
  bar.addEventListener("pointerdown", (e) => { e.preventDefault(); });
  bar.addEventListener("mousedown", (e) => e.preventDefault());
  onRelease(bar, (e) => {
    const b = e.target.closest("button"); const t = numTarget;
    if (!b || !t) return;
    if (b.dataset.ins) {
      const s = t.selectionStart ?? t.value.length, en = t.selectionEnd ?? t.value.length;
      t.setRangeText(b.dataset.ins, s, en, "end");
      t.dispatchEvent(new Event("input", { bubbles: true }));
      t.focus();
    } else if (b.dataset.kbd) {
      // 文字入力に切り替え（もう一度押すと数字に戻る）。キーボードの種類は入れ直したときに変わる
      const txt = t.getAttribute("inputmode") === "text";
      t.setAttribute("inputmode", txt ? "decimal" : "text");
      b.classList.toggle("on", !txt);
      t.blur(); t.focus();
    } else if (b.dataset.ok) {
      pressEnter(t);
      if (document.activeElement === t) t.blur();
    }
  });

  // ---------------------------------------------------------------- タイムライン: 最新（現在位置）が見えるように
  const tl = document.getElementById("timeline");
  new MutationObserver(() => {
    if (!isMobileLayout()) return;
    const mk = tl.querySelector(".tl-marker"); if (!mk) return;
    const r = mk.getBoundingClientRect(), t = tl.getBoundingClientRect();
    if (r.right > t.right - 8 || r.left < t.left) tl.scrollLeft += r.left - (t.left + t.width * 0.6);
  }).observe(tl, { childList: true });

  // ---------------------------------------------------------------- タイムライン・ツリー: タップ／長押し
  bindTouchMenus();

  // ---------------------------------------------------------------- 右クリックメニューを画面内に収める
  const cm = document.getElementById("ctxmenu");
  new MutationObserver(() => {
    if (cm.classList.contains("hidden")) return;
    const r = cm.getBoundingClientRect();
    const W = window.innerWidth, H = window.innerHeight;
    let x = r.left, y = r.top;
    if (r.right > W - 4) x = Math.max(4, W - r.width - 4);
    if (r.bottom > H - 4) y = Math.max(4, H - r.height - 4);
    if (r.height > H - 8 || y < 4) y = 4; // 項目が多いときは上から（中はスクロール）
    if (x < 4) x = 4;
    if (x !== r.left) cm.style.left = x + "px";
    if (y !== r.top) cm.style.top = y + "px";
  }).observe(cm, { attributes: true, attributeFilter: ["class", "style"], childList: true });
  // 指で別の場所に触れたら閉じる（mousedown が来ないことがある）
  document.addEventListener("pointerdown", (e) => {
    if (e.pointerType !== "touch" || cm.classList.contains("hidden") || cm.contains(e.target)) return;
    setTimeout(() => cm.classList.add("hidden"), 0);
  }, true);

  // ---------------------------------------------------------------- 下のナビ: よく使うものだけ並べ、残りは「⋯」に
  // （ux.js が後から足すボタンも対象。スマホ以外では ⋯ を出さず、中身はそのまま並ぶ）
  const nav = document.getElementById("navbar");
  if (nav) {
    const more = document.createElement("button");
    more.className = "m-navmore"; more.textContent = "⋯"; more.title = "ほかの表示ボタン（グリッド・エッジ・視点・選んだものに合わせる など）";
    const pop = document.createElement("div"); pop.className = "m-navpop";
    nav.append(more, pop);
    const MOVE = "[data-nav=grid], [data-nav=edges], [data-ux=views], [data-ux=fitsel], [data-ux=keys]";
    const tidy = () => {
      for (const b of nav.querySelectorAll(`:scope > :is(${MOVE})`)) pop.appendChild(b);
      for (const sp of nav.querySelectorAll(":scope > .ux-sep")) sp.classList.add("m-sep");
      if (more.nextSibling !== pop || nav.lastElementChild !== pop) nav.append(more, pop); // 常に右端
    };
    new MutationObserver(tidy).observe(nav, { childList: true });
    tidy();
    more.addEventListener("click", (e) => { e.stopPropagation(); nav.classList.toggle("m-pop-open"); });
    pop.addEventListener("click", (e) => { if (e.target.closest("button") && !e.target.closest("[data-ux=views]")) nav.classList.remove("m-pop-open"); });
    document.addEventListener("pointerdown", (e) => { if (!nav.contains(e.target)) nav.classList.remove("m-pop-open"); }, true);
  }

  // ---------------------------------------------------------------- テスト用
  window.__mobile = {
    keyboard(h) { simKb = h ? h : null; onViewport(); },
    inset: () => ({ ...(v.viewInset || { x: 0, y: 0 }) }),
    isMobile: isMobileLayout,
  };
  applyInset();
}

// タッチでは pointerdown を止めると click が来ないので、指を離したとき（pointerup）に実行する
function onRelease(el, fn) {
  let downAt = null;
  el.addEventListener("pointerdown", (e) => { downAt = { x: e.clientX, y: e.clientY, t: e.target }; });
  el.addEventListener("pointerup", (e) => {
    if (!downAt) return;
    const ok = Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) < 20;
    const tg = downAt.t; downAt = null;
    if (ok) fn({ target: tg });
  });
  // キーボード操作（Enter / Space）での押下
  el.addEventListener("click", (e) => { if (e.detail === 0) fn(e); });
}

function pressEnter(inp) {
  const o = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
  inp.dispatchEvent(new KeyboardEvent("keydown", o));
  inp.dispatchEvent(new KeyboardEvent("keyup", o));
}

function scrollableParent(el) {
  for (let e = el; e && e !== document.body && e.nodeType === 1; e = e.parentElement) {
    if (e.id === "view3d") return null;
    const s = getComputedStyle(e);
    const oy = s.overflowY, ox = s.overflowX;
    if ((oy === "auto" || oy === "scroll") && e.scrollHeight > e.clientHeight + 1) return e;
    if ((ox === "auto" || ox === "scroll") && e.scrollWidth > e.clientWidth + 1) return e;
  }
  return null;
}

// ------------------------------------------------------------------ 道具の並び（スマホ）
function arrangeTools(app) {
  const el = document.getElementById("tools");
  closeSheet();
  if (!isMobileLayout()) { el.classList.remove("m-arranged"); return; }
  const front = (landMQ.matches ? FRONT_LAND : FRONT)[app.tab === "sketch" ? "sketch" : app.mode === "sketch" ? "sketch" : "solid"];
  // ボタンと道具 ID の対応（refreshTools は toolDefs の順に並べる）
  const ids = app.toolDefs().flatMap(([, items]) => items.map((x) => x[0]));
  const btns = [...el.querySelectorAll(".tool")];
  if (btns.length !== ids.length) return;
  btns.forEach((b, i) => { b.dataset.tool = ids[i]; });
  el.classList.add("m-arranged");
  const g = document.createElement("div"); g.className = "tgroup m-front";
  const items = document.createElement("div"); items.className = "items"; g.appendChild(items);
  const tabIsFront = app.tab === "solid" || app.tab === "sketch";
  if (tabIsFront) {
    for (const id of front) { const b = btns.find((x) => x.dataset.tool === id); if (b) items.appendChild(b); }
  } else {
    for (const b of btns) items.appendChild(b);
  }
  const more = document.createElement("button");
  more.className = "tool more"; more.innerHTML = MORE_ICON + "<span>その他</span>"; more.title = "ほかの道具（検査・書き出し など）";
  more.onclick = () => openSheet(app);
  items.appendChild(more);
  for (const og of el.querySelectorAll(".tgroup")) og.classList.add("m-rest");
  g.classList.remove("m-rest");
  el.prepend(g);
  el.scrollLeft = 0; el.scrollTop = 0;
}

// 「その他」: 今のタブ以外も含めて、すべての道具を大きなボタンで
function openSheet(app) {
  closeSheet();
  const shown = new Set([...document.querySelectorAll("#tools .m-front .tool[data-tool]")].map((b) => b.dataset.tool));
  const tabs = app.mode === "sketch" ? ["sketch", "inspect"] : ["solid", "inspect", "io"];
  const tabName = { sketch: "スケッチ", solid: "ソリッド", inspect: "検査", io: "挿入・書き出し" };
  const cur = app.tab;
  const groups = [];
  const seen = new Set(shown);
  for (const t of tabs) {
    app.tab = t;
    let defs; try { defs = app.toolDefs(); } finally { app.tab = cur; }
    for (const [gl, items] of defs) {
      const list = items.filter(([id]) => !seen.has(id));
      list.forEach(([id]) => seen.add(id));
      if (!list.length) continue;
      const name = gl || tabName[t];
      const same = groups.find((g) => g[0] === name);
      if (same) same[1].push(...list); else groups.push([name, list]);
    }
  }
  const sh = document.createElement("div");
  sh.id = "msheet";
  sh.innerHTML = `<div class="ms-back"></div><div class="ms-panel" role="dialog" aria-label="その他の道具"><div class="ms-head"><span>道具</span><button class="ms-x" aria-label="閉じる">×</button></div><div class="ms-body">${groups.map(([gl, list]) => `<div class="ms-g"><div class="ms-gl">${gl}</div><div class="ms-items">${list.map(([id, label]) => `<button data-tool="${id}">${ICON[id] || ICON.sketch}<span>${label}</span></button>`).join("")}</div></div>`).join("")}</div></div>`;
  document.body.appendChild(sh);
  const close = () => closeSheet();
  sh.querySelector(".ms-back").addEventListener("click", close);
  sh.querySelector(".ms-x").addEventListener("click", close);
  sh.querySelectorAll("[data-tool]").forEach((b) => b.addEventListener("click", () => { close(); app.runTool(b.dataset.tool); }));
}
function closeSheet() { document.getElementById("msheet")?.remove(); }

// ------------------------------------------------------------------ タイムライン・ツリーのタッチ操作
// iPhone の Safari は長押しで contextmenu を出さず、dblclick も来ないことがあるので、自前で作る
function bindTouchMenus() {
  const SEL = "#timeline [data-f], #browser .tree-node";
  let st = null;
  let lastTap = { t: 0, el: null };
  const fire = (el, type, x, y) => el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, button: type === "contextmenu" ? 2 : 0 }));
  document.addEventListener("pointerdown", (e) => {
    if (e.pointerType !== "touch") return;
    const el = e.target.closest && e.target.closest(SEL);
    if (!el) return;
    const x = e.clientX, y = e.clientY;
    const tg = e.target;
    st = { el, tg, x, y, long: false, timer: setTimeout(() => { if (st) { st.long = true; fire(tg, "contextmenu", x, y); } }, 520) };
  }, true);
  document.addEventListener("pointermove", (e) => {
    if (!st || e.pointerType !== "touch") return;
    if (Math.hypot(e.clientX - st.x, e.clientY - st.y) > 10) { clearTimeout(st.timer); st = null; }
  }, true);
  document.addEventListener("pointercancel", () => { if (st) { clearTimeout(st.timer); st = null; } }, true);
  document.addEventListener("pointerup", (e) => {
    if (!st || e.pointerType !== "touch") return;
    const s = st; st = null; clearTimeout(s.timer);
    if (s.long) return;
    const now = performance.now();
    if (lastTap.el === s.el && now - lastTap.t < 380) {
      clearTimeout(lastTap.single); lastTap = { t: 0, el: null };
      s.el.__synthDbl = performance.now();
      fire(document.contains(s.tg) ? s.tg : s.el, "dblclick", s.x, s.y);
      return;
    }
    const tl = s.el.matches("#timeline [data-f]");
    // タイムラインは 1 回タップでメニュー（編集・名前・削除…）を出す（ダブルタップと区別するため少し待つ）
    const single = tl ? setTimeout(() => { if (document.contains(s.tg)) fire(s.tg, "contextmenu", s.x, s.y); }, 400) : 0;
    lastTap = { t: now, el: s.el, single };
  }, true);
  // ブラウザが本物の dblclick も出した場合は、二重にならないように捨てる
  document.addEventListener("dblclick", (e) => {
    const el = e.target.closest && e.target.closest(SEL);
    if (el && el.__synthDbl && e.isTrusted && performance.now() - el.__synthDbl < 600) { e.stopImmediatePropagation(); e.preventDefault(); }
  }, true);
  // 長押しで文字選択・コールアウトが出ないように（CSS でも指定）
  document.addEventListener("contextmenu", (e) => { if (e.isTrusted && e.target.closest && e.target.closest(SEL) && COARSE) { /* 自前の長押しメニューを使う */ e.preventDefault(); e.stopImmediatePropagation(); } }, true);
}
