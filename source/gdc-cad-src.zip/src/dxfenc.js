// DXF の文字コード
//  標準: 日本語を \U+XXXX で書く（AutoCAD・BricsCAD・Fusion など。ファイル自体は英数字だけ）
//  Shift_JIS: 日本語をそのまま Shift_JIS で書く（Jw_cad・古い国産 CAD/CAM 向け。$DWGCODEPAGE = ANSI_932）
const KEY = "gdc.dxf.encoding";

export const DXF_ENCODINGS = [
  ["std", "標準（AutoCAD など）"],
  ["sjis", "Shift_JIS（Jw_cad 向け）"],
];

export function dxfEncoding() {
  try { return localStorage.getItem(KEY) === "sjis" ? "sjis" : "std"; } catch { return "std"; }
}
export function setDxfEncoding(v) {
  try { localStorage.setItem(KEY, v === "sjis" ? "sjis" : "std"); } catch { /* 保存できなくても今回の書き出しには使える */ }
}

export function dxfEncodingSelect(id = "dxf-enc") {
  const cur = dxfEncoding();
  return `<select id="${id}" class="dxf-enc">${DXF_ENCODINGS.map(([k, n]) => `<option value="${k}" ${cur === k ? "selected" : ""}>${n}</option>`).join("")}</select>`;
}
// select を押したら覚える
export function bindDxfEncoding(root, id = "dxf-enc") {
  const el = root.querySelector("#" + id);
  if (el) el.addEventListener("change", () => setDxfEncoding(el.value));
}

// Unicode → Shift_JIS の表（ブラウザの Shift_JIS 読み込み機能から逆に作る。最初の 1 回だけ）
let table = null;
function sjisTable() {
  if (table) return table;
  table = new Map();
  let dec;
  try { dec = new TextDecoder("shift_jis"); } catch { return table; }
  const buf = new Uint8Array(2);
  const leads = [];
  for (let b = 0x81; b <= 0x9f; b++) leads.push(b);
  for (let b = 0xe0; b <= 0xfc; b++) leads.push(b);
  for (const a of leads) {
    for (let b = 0x40; b <= 0xfc; b++) {
      if (b === 0x7f) continue;
      buf[0] = a; buf[1] = b;
      const s = dec.decode(buf);
      if (s.length === 1 && s !== "�" && !table.has(s)) table.set(s, (a << 8) | b);
    }
  }
  return table;
}

// Shift_JIS に無い文字の言い換え（図面でよく使うもの）
const SUBST = { "Ø": "φ", "ø": "φ", "⌀": "φ", "²": "2", "³": "3", "—": "―", "–": "-", "°": "°", " ": " " };

export function toShiftJIS(str) {
  const t = sjisTable();
  const out = [];
  for (let ch of str) {
    if (SUBST[ch]) ch = SUBST[ch];
    const c = ch.codePointAt(0);
    if (c < 0x80) { out.push(c); continue; }
    if (c >= 0xff61 && c <= 0xff9f) { out.push(c - 0xff61 + 0xa1); continue; }
    const v = t.get(ch);
    if (v != null) { out.push(v >> 8, v & 0xff); continue; }
    for (const b of `\\U+${c.toString(16).toUpperCase().padStart(4, "0")}`) out.push(b.charCodeAt(0));
  }
  return new Uint8Array(out);
}

// 書き上がった DXF（\U+ 形式）を、選ばれた文字コードのデータにする
export function encodeDXF(text, enc = dxfEncoding()) {
  if (enc !== "sjis") return text;
  let s = text.replace(/\\U\+([0-9A-Fa-f]{4})/g, (_, h) => String.fromCodePoint(parseInt(h, 16)));
  // 文字コードの宣言（$ACADVER の後ろ）
  s = s.replace(/(\r?\n)\$ACADVER(\r?\n)\s*1(\r?\n)([^\r\n]*)(\r?\n)/, (m, a, b, c, ver, e) => `${a}$ACADVER${b}1${c}${ver}${e}9${e}$DWGCODEPAGE${e}3${e}ANSI_932${e}`);
  return toShiftJIS(s);
}
