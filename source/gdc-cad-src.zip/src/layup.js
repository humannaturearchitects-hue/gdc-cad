// サンドイッチパネル（FRP 表皮 + コア）の積層設定と材料集計
import { store } from "./store.js";
import { call } from "./kernel.js";
import { download } from "./exporters.js";
import { esc } from "./commands.js";

export const CORES = [
  ["PETフォーム", 100], ["PETフォーム（高密度）", 135], ["PVCフォーム", 80], ["PUフォーム", 40],
  ["バルサ", 150], ["ハニカム（PP）", 80], ["合板", 550], ["なし（単板 FRP）", 0],
];
export const FABRICS = [
  ["ガラス チョップドマット 450g", 450], ["ガラス ロービングクロス 580g", 580], ["ガラス ロービングクロス 600g", 600],
  ["ガラス 二軸 800g", 800], ["ガラス クロス 200g", 200], ["カーボン クロス 200g", 200], ["その他（g/m²を入力）", 0],
];

export const DEFAULT_LAYUP = {
  core: "PETフォーム", coreDensity: 100, // kg/m³
  fabric: "ガラス ロービングクロス 600g", gsm: 600, plies: 2, // 片面あたり
  skinThk: 1.0, // 片面の表皮厚さ mm
  resinRatio: 1.0, // 樹脂重量 ÷ ガラス重量（ハンドレイアップ 1.0〜1.5、インフュージョン 0.6〜0.8）
  resinName: "不飽和ポリエステル",
  waste: 10, // 材料ロス %
};

export function layupSpec(L) {
  if (!L) return "";
  const t = `${L.plies}×${L.gsm}g`;
  return L.coreDensity > 0 ? `FRP(${t})/${L.core}/FRP(${t})` : `FRP 単板 ${t}`;
}

// 体積・外形から、平らなパネルとして材料量を概算
export function computeLayup(L, { volume, bounds }) {
  const dims = [0, 1, 2].map((k) => bounds[1][k] - bounds[0][k]).sort((a, b) => a - b);
  const thk = dims[0];                       // 板厚（一番薄い方向）
  const area = thk > 0 ? volume / thk : 0;   // 片面の面積 mm²（穴は体積に反映済み）
  const A = area / 1e6;                      // m²
  const skin = Math.min(L.skinThk, thk / 2);
  const coreThk = L.coreDensity > 0 ? Math.max(0, thk - 2 * skin) : 0;
  const glassM2 = A * L.plies * 2;           // 両面
  const glassKg = glassM2 * L.gsm / 1000;
  const resinKg = glassKg * L.resinRatio;
  const coreM3 = A * coreThk / 1000;
  const coreKg = coreM3 * L.coreDensity;
  const w = 1 + (L.waste || 0) / 100;
  return {
    thk, coreThk, area: A, glassM2, glassKg, resinKg, coreM2: L.coreDensity > 0 ? A : 0, coreM3, coreKg,
    weight: glassKg + resinKg + coreKg,
    order: { glassM2: glassM2 * w, resinKg: resinKg * w, coreM2: (L.coreDensity > 0 ? A : 0) * w },
  };
}

export function openLayupPanel(app, bodyIds) {
  if (!bodyIds.length) return app.toast("ボディを選択してください", true);
  const first = app.meshes.find((m) => m.id === bodyIds[0]);
  const L = { ...DEFAULT_LAYUP, ...(first?.layup || {}) };
  const el = app.panel(`積層（サンドイッチパネル）設定 — ${bodyIds.length} 個`, `
    <label>コア材</label><select id="ly-core">${CORES.map(([n, d]) => `<option value="${esc(n)}" data-d="${d}" ${n === L.core ? "selected" : ""}>${esc(n)}${d ? `（${d} kg/m³）` : ""}</option>`).join("")}</select>
    <label>コア密度 kg/m³</label><input type="text" id="ly-cd" value="${L.coreDensity}"/>
    <label>表皮の布</label><select id="ly-fab">${FABRICS.map(([n, g]) => `<option value="${esc(n)}" data-g="${g}" ${n === L.fabric ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
    <label>目付 g/m²</label><input type="text" id="ly-gsm" value="${L.gsm}"/>
    <label>片面の枚数</label><input type="text" id="ly-pl" value="${L.plies}"/>
    <label>片面の表皮厚 mm</label><input type="text" id="ly-st" value="${L.skinThk}"/>
    <label>樹脂</label><input type="text" id="ly-rn" value="${esc(L.resinName)}"/>
    <label>樹脂/ガラス比</label><input type="text" id="ly-rr" value="${L.resinRatio}"/>
    <label>材料ロス %</label><input type="text" id="ly-ws" value="${L.waste}"/>
    <div class="dlg-note">板厚はボディの一番薄い方向から自動で読み取り、コア厚 = 板厚 − 表皮×2 で計算します。樹脂/ガラス比の目安: ハンドレイアップ 1.0〜1.5、真空・インフュージョン 0.6〜0.8。</div>
    <div class="full"><button class="btn danger" id="ly-clear">積層設定を外す</button></div>`, () => {
    const g = (id) => el.querySelector(id).value;
    const v = {
      core: g("#ly-core"), coreDensity: parseFloat(g("#ly-cd")) || 0, fabric: g("#ly-fab"), gsm: parseFloat(g("#ly-gsm")) || 0,
      plies: Math.max(0, Math.round(parseFloat(g("#ly-pl")) || 0)), skinThk: parseFloat(g("#ly-st")) || 0, resinName: g("#ly-rn"),
      resinRatio: parseFloat(g("#ly-rr")) || 0, waste: parseFloat(g("#ly-ws")) || 0,
    };
    store.commit((p) => { p.bodyProps = p.bodyProps || {}; for (const id of bodyIds) p.bodyProps[id] = { ...(p.bodyProps[id] || {}), layup: v }; });
    app.toast(`${bodyIds.length} 個のボディに積層を設定しました（検査 → 材料集計 で確認）`);
  }, { okLabel: "設定" });
  el.querySelector("#ly-core").onchange = (e) => { el.querySelector("#ly-cd").value = e.target.selectedOptions[0].dataset.d; };
  el.querySelector("#ly-fab").onchange = (e) => { const gg = e.target.selectedOptions[0].dataset.g; if (+gg) el.querySelector("#ly-gsm").value = gg; };
  el.querySelector("#ly-clear").onclick = () => {
    store.commit((p) => { for (const id of bodyIds) if (p.bodyProps?.[id]) delete p.bodyProps[id].layup; });
    el.classList.add("hidden"); app.panelOpen = false;
  };
}

export async function openTakeoff(app) {
  const r = await call("measure", { ids: [] });
  const rows = [];
  const tot = { weight: 0, glassM2: 0, glassKg: 0, resinKg: 0, coreM2: 0, coreKg: 0, oGlass: 0, oResin: 0, oCore: 0 };
  for (const b of r.list) {
    const m = app.meshes.find((x) => x.id === b.id);
    if (!m || !m.layup) continue;
    const c = computeLayup(m.layup, b);
    rows.push({ name: m.name, spec: layupSpec(m.layup), ...c, L: m.layup });
    tot.weight += c.weight; tot.glassM2 += c.glassM2; tot.glassKg += c.glassKg; tot.resinKg += c.resinKg; tot.coreM2 += c.coreM2; tot.coreKg += c.coreKg;
    tot.oGlass += c.order.glassM2; tot.oResin += c.order.resinKg; tot.oCore += c.order.coreM2;
  }
  const f = (v, d = 2) => (+v).toLocaleString("ja-JP", { maximumFractionDigits: d, minimumFractionDigits: d });
  if (!rows.length) {
    return app.panel("材料集計", `<div class="full">積層が設定されたボディがありません。<br>ボディ（またはコンポーネント）を右クリック →「積層（サンドイッチパネル）設定」で設定してください。</div>`, null, { noCancel: true, okLabel: "閉じる" });
  }
  const sheet = 1.22 * 2.44;
  const html = `<div class="full" style="max-height:45vh;overflow:auto"><table class="grid">
    <tr><th>部品</th><th>積層</th><th class="num">板厚</th><th class="num">面積 m²</th><th class="num">ガラス m²</th><th class="num">樹脂 kg</th><th class="num">コア m²</th><th class="num">重量 kg</th></tr>
    ${rows.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.spec)}</td><td class="num">${f(x.thk, 1)}</td><td class="num">${f(x.area)}</td><td class="num">${f(x.glassM2)}</td><td class="num">${f(x.resinKg)}</td><td class="num">${f(x.coreM2)}</td><td class="num">${f(x.weight)}</td></tr>`).join("")}
    <tr><td><b>合計</b></td><td></td><td></td><td></td><td class="num"><b>${f(tot.glassM2)}</b></td><td class="num"><b>${f(tot.resinKg)}</b></td><td class="num"><b>${f(tot.coreM2)}</b></td><td class="num"><b>${f(tot.weight)}</b></td></tr></table></div>
    <div class="full" style="margin-top:6px"><b>発注の目安（ロス込み）</b>：ガラス ${f(tot.oGlass, 1)} m²（${f(tot.glassKg * (1 + (rows[0].L.waste || 0) / 100), 1)} kg）／ 樹脂 ${f(tot.oResin, 1)} kg ／ コア ${f(tot.oCore, 1)} m²（1220×2440 で約 ${Math.ceil(tot.oCore / sheet)} 枚）</div>
    <div class="dlg-note">平らなパネルとして概算（面積 = 体積 ÷ 板厚）。曲面・リング部品は目安です。</div>`;
  app.panel("材料集計（サンドイッチパネル）", html, () => {
    const head = ["部品", "積層", "板厚mm", "コア厚mm", "面積m2", "ガラスm2", "ガラスkg", "樹脂kg", "コアm2", "コアkg", "重量kg"];
    const lines = [head, ...rows.map((x) => [x.name, x.spec, x.thk.toFixed(1), x.coreThk.toFixed(1), x.area.toFixed(3), x.glassM2.toFixed(3), x.glassKg.toFixed(3), x.resinKg.toFixed(3), x.coreM2.toFixed(3), x.coreKg.toFixed(3), x.weight.toFixed(3)]),
      ["合計", "", "", "", "", tot.glassM2.toFixed(3), tot.glassKg.toFixed(3), tot.resinKg.toFixed(3), tot.coreM2.toFixed(3), tot.coreKg.toFixed(3), tot.weight.toFixed(3)]];
    const csv = "﻿" + lines.map((l) => l.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\r\n");
    download(new Blob([csv], { type: "text/csv" }), `${store.project.name || "材料集計"}_材料集計.csv`);
    return false;
  }, { okLabel: "CSV で保存（Excel 用）", wide: true });
}
