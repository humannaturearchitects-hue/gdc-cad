// 端末内 AI（小さな言語モデル）用の「短い説明・例・文法・数値の照合」
// 小さなモデルでも正しく動くように:
//  1) 利用者の言葉を先に整える（全角→半角、3センチ→30、1.2m→1200、半分→0.5倍 など）→ モデルは数を「写すだけ」
//  2) 出力は決まった書き方のコマンドだけに文法（EBNF）で縛る。ボディ名は今あるものから選ばせる
//  3) 計算が要るところ（四隅・真ん中・右へ 100）は「短い書き方」で書かせ、ここで座標に直す
//  4) 出てきた数値を、利用者の言葉・今のモデルの数値と照らし合わせ、合わないものは直す／確認に回す
// このファイルはブラウザにも Node にも依存しない（評価用のテストからも使う）

// ---- 利用者の言葉を整える ------------------------------------------------
const KD = { 〇: 0, 零: 0, 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
function kanjiToNum(s) {
  if (!/[十百千万]/.test(s)) return +[...s].map((c) => KD[c]).join("");
  let total = 0, sec = 0, cur = 0;
  for (const c of s) {
    if (c in KD) cur = KD[c];
    else if (c === "十" || c === "百" || c === "千") { sec += (cur || 1) * { 十: 10, 百: 100, 千: 1000 }[c]; cur = 0; }
    else if (c === "万") { total += (sec + cur || 1) * 10000; sec = 0; cur = 0; }
  }
  return total + sec + cur;
}
function kanjiNumbers(s) {
  return s.replace(/[〇零一二三四五六七八九十百千万]+/g, (m, i, all) => {
    const next = all.slice(i + m.length), prev = all.slice(0, i);
    if (/^(隅|つ|通|時|番|方|緒|部|般|応|旦|気|斉|体|角形|切|度目|列目|覧|面|周|括|直線|致|層|重)/.test(next)) return m;
    if (/^角/.test(next) && /(^|\n)\s*$/.test(prev)) return m;
    if (m === "万" || m === "千" && !/^\s*[\d.]/.test(next) && /[一-龥]$/.test(prev)) return m;
    if (/[一-龥]$/.test(prev) && m.length === 1 && !/^\s*(ミリ|センチ|メートル|mm|cm|m|度|個|枚|本|倍|つ|か所|箇所|列|段|分)/.test(next)) return m; // 統一・同一 など
    return String(kanjiToNum(m));
  });
}
const R6 = (v) => String(+(+v).toFixed(6));
export function normalizeRequest(text) {
  let s = String(text || "").normalize("NFKC");
  s = s.replace(/(?:^|\s|、)(?:えー+と?|えっと|あのー?|えー|うーん|まあ)(?=\s|、|$)/g, " ");
  s = s.replace(/熱さ|暑さ|厚み/g, "厚さ").replace(/直系|直経/g, "直径").replace(/推し出し/g, "押し出し");
  s = kanjiNumbers(s);
  s = s.replace(/(\d),(\d{3})(?!\d)/g, "$1$2"); // 1,200 → 1200
  s = s.replace(/(\d)\s*(?:てん|点)\s*(\d)/g, "$1.$2");
  // 1m20 → 1200、1メートル20 → 1200
  s = s.replace(/(\d+)\s*(?:m|メートル)\s*(\d{1,2})(?!\d|\s*(?:mm|ミリ|cm|センチ))/gi, (_, a, b) => R6(+a * 1000 + +b.padEnd(2, "0") * 10));
  s = s.replace(/(\d+(?:\.\d+)?)\s*(?:センチメートル|センチ|cm)/gi, (_, n) => R6(n * 10))
    .replace(/(\d+(?:\.\d+)?)\s*(?:ミリメートル|ミリ|mm)/gi, "$1")
    .replace(/(\d+(?:\.\d+)?)\s*(?:メートル|m)(?![a-z])/gi, (_, n) => R6(n * 1000));
  s = s.replace(/(?:ファイ|φ|⌀|ø)\s*(?=\d)/gi, "Ø").replace(/(\d+(?:\.\d+)?)\s*パイ/g, "Ø$1").replace(/パイ\s*(?=\d)/g, "Ø")
    .replace(/アール\s*(?=\d)/g, "R").replace(/シー\s*(?=\d)/g, "C").replace(/マイナス\s*(?=\d)/g, "-");
  // 倍率: 半分 → 0.5倍、10分の1 → 0.1倍、50% → 0.5倍
  s = s.replace(/(\d+(?:\.\d+)?)\s*分の\s*(\d+(?:\.\d+)?)/g, (_, a, b) => R6(+b / +a) + "倍")
    .replace(/半分/g, "0.5倍")
    .replace(/(\d+(?:\.\d+)?)\s*(?:%|パーセント)/g, (_, n) => R6(n / 100) + "倍");
  s = s.replace(/(\d)\s*(?:かける|掛ける|×|x|X|\*)\s*(?=\d)/g, "$1x").replace(/(\d)\s*(?:かける|掛ける|×|x|X|\*)\s*(?=\d)/g, "$1x");
  return s.replace(/[ \t]+/g, " ").trim();
}

// 文の中の数（整えたあと）
export function numbersIn(s) {
  return (String(s).match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
}

// ---- 今のモデルの短い概要 --------------------------------------------------
// bodies: [{ name, size:[x,y,z], min:[x,y,z], max:[x,y,z], material }]、features: タイムラインの名前（穴1 など）
export function localContext({ bodies = [], features = [], selected = [] } = {}) {
  const N = (v) => R6(Math.round(v * 10) / 10);
  const L = [];
  if (bodies.length) L.push("部品: " + bodies.map((b) => `${b.name}(${b.size.map(N).join("x")}${b.min.some((v) => Math.abs(v) > 0.05) ? " 位置" + b.min.map(N).join(",") : ""})`).join(" "));
  else L.push("部品: なし");
  const fs = features.filter((f) => /^(穴|フィレット|面取り|押し出し)\d+$/.test(f));
  if (fs.length) L.push("手順: " + fs.slice(-8).join(" "));
  L.push("選択中: " + (selected.length ? selected.join(" ") : "なし"));
  return L.join("\n");
}

// ---- 短い説明と例 -------------------------------------------------------------
export const LOCAL_RULES = `あなたは3D CADの操作係です。利用者の頼みを、下の書き方のコマンドに変えて、コマンドだけを1行ずつ出します。数は頼みの中の数をそのまま写します（単位はmm。計算しない）。部品名は[部品]にある名前をそのまま使います。必要な数が足りないときだけ「質問: 」で聞き返します。
書き方:
板 幅W 奥行D 厚さT 名前 N（箱・板・直方体）
円柱 直径D 高さH
穴 上面 ØD 中央 部品 ／ 穴 上面 ØD 四隅 端からの距離 部品 ／ 穴 上面 ØD 位置 X,Y 部品
フィレット R半径 縦の辺 部品（縦の辺・上の辺・すべての辺）／ 面取り C距離 上の辺 部品
部品 厚さ T ／ 部品 幅 W ／ 部品 高さ H ／ 穴1 径 D（今ある部品・穴の寸法を変える）
移動 部品 右 量（右・左・奥・前・上・下）／ コピー 部品 右 量
置く 部品 上 部品 中央 ／ 回す 部品 角度 軸 Z ／ スケール 倍率 ／ 削除 部品
材料 部品 アルミ（合板・PETフォーム・FRPサンドイッチ・杉・鋼・ステンレス）／ 色 赤 部品
矩形パターン 部品 Z方向 個数個 間隔L ／ ミラー 部品 YZ 位置 X
ビス接合 部品 部品（板と板をビスで留める穴）／ 板厚 18 を 20 に（その厚さの板をまとめて）
重さ ／ 大きさ ／ 部品一覧 ／ 元に戻す ／ 視点 上 ／ 非表示 部品`;

// 例（[今ある部品, 頼み, 答え]）。同じ形の会話として渡すと、小さなモデルでも書き方をまねしやすい
const P = (name, size, min = [0, 0, 0]) => ({ name, size, min, max: size.map((v, i) => v + min[i]) });
const F = P("床板", [600, 400, 20]), H = P("柱", [50, 50, 300], [0, 0, 20]);
export const LOCAL_SHOTS = [
  [[], "床板を幅600奥行400厚さ20で", "板 幅600 奥行400 厚さ20 名前 床板"],
  [[], "1200x600x15の天板", "板 幅1200 奥行600 厚さ15 名前 天板"],
  [[], "直径30高さ200の丸棒", "円柱 直径30 高さ200 名前 丸棒"],
  [[F], "四隅に直径8の穴、端から30", "穴 上面 Ø8 四隅 30 床板"],
  [[F], "真ん中にØ50の穴", "穴 上面 Ø50 中央 床板"],
  [[F], "床板を厚さ30に", "床板 厚さ 30"],
  [[F], "角を半径5で丸めて", "フィレット R5 縦の辺 床板"],
  [[F, H], "柱を右に100動かして", "移動 柱 右 100"],
  [[F, H], "柱を床板の上の真ん中に", "置く 柱 上 床板 中央"],
  [[F, H], "柱を90度回して", "回す 柱 90 軸 Z"],
  [[F, H], "全部アルミにして", "材料 すべて アルミ"],
  [[F], "全体を0.5倍に", "スケール 0.5"],
  [[F, H], "柱を消して", "削除 柱"],
  [[F, P("側板", [18, 400, 300], [0, 0, 20])], "側板と床板をビスで留めて", "ビス接合 側板 床板"],
  [[F], "厚さ20の板を全部25にして", "板厚 20 を 25 に"],
  [[F], "穴をあけて", "質問: 穴の直径は何mmにしますか？"],
  [[F], "重さは？", "重さ"],
  [[F], "やっぱりやめて", "元に戻す"],
];
export const LOCAL_SYSTEM = LOCAL_RULES + "\n例:\n" + LOCAL_SHOTS.map(([b, t, a]) => `[部品: ${b.length ? b.map((x) => x.name).join(" ") : "なし"}] ${t} → ${a}`).join("\n");

// 利用者 1 回分の文（モデルに渡す）
export function localUserMessage(normText, ctx) {
  return `${ctx}\n頼み: ${normText}`;
}
// モデルに渡す会話。variant "shots": 例を会話のやりとりとして渡す（既定）／ "sys": 例を説明の中に書く
export function localMessages(normText, model, variant = "shots") {
  const user = localUserMessage(normText, localContext(model));
  if (variant === "sys") return [{ role: "system", content: LOCAL_SYSTEM }, { role: "user", content: user }];
  const msgs = [{ role: "system", content: LOCAL_RULES }];
  for (const [b, t, a] of LOCAL_SHOTS) msgs.push({ role: "user", content: localUserMessage(t, localContext({ bodies: b })) }, { role: "assistant", content: a });
  msgs.push({ role: "user", content: user });
  return msgs;
}

// ---- 出力の文法（XGrammar の EBNF） ------------------------------------------------
const Q = (s) => '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
export const MATERIAL_NAMES = ["PETフォーム", "FRP(ガラス)", "FRPサンドイッチ", "合板", "杉", "アルミ", "鋼", "ステンレス", "ABS", "アクリル", "ゴム"];
export const COLOR_NAMES = ["赤", "青", "緑", "黄", "白", "黒", "グレー", "オレンジ", "茶", "木", "紫", "水色", "ピンク"];
export function buildGrammar({ bodies = [], features = [] } = {}) {
  const names = [...new Set(bodies.map((b) => b.name).filter(Boolean))].sort((a, b) => b.length - a.length);
  const feats = [...new Set(features.filter((f) => /^(穴|フィレット|面取り|押し出し)\d+$/.test(f)))];
  const has = names.length > 0;
  const R = [];
  R.push(`root ::= ask | cmd ("\\n" cmd)? ("\\n" cmd)? ("\\n" cmd)? ("\\n" cmd)?`);
  R.push(`ask ::= "質問: " [^\\n] [^\\n]*`);
  const cmds = ["board", "cyl", "undo", "view", "query", "scaleall", "hole", "fillet", "chamfer"];
  if (has) cmds.push("screw", "thick", "modify", "move", "copy", "place", "rotate", "scaleb", "mat", "color", "pattern", "mirror", "del", "hide");
  R.push(`cmd ::= ${cmds.join(" | ")}`);
  R.push(`num ::= "-"? [0-9] [0-9]? [0-9]? [0-9]? [0-9]? ("." [0-9] [0-9]?)?`);
  R.push(`pos ::= "-"? [0-9] [0-9]? [0-9]? [0-9]? [0-9]?`);
  R.push(`newname ::= [^ \\n0-9,] [^ \\n,]? [^ \\n,]? [^ \\n,]? [^ \\n,]? [^ \\n,]? [^ \\n,]? [^ \\n,]?`);
  R.push(`board ::= "板 幅" num " 奥行" num " 厚さ" num (" 位置 " num "," num "," num)? (" 名前 " newname)?`);
  R.push(`cyl ::= "円柱 直径" num " 高さ" num (" 位置 " num "," num "," num)? (" 軸 " [XYZ])? (" 名前 " newname)?`);
  R.push(`undo ::= "元に戻す" (" " [1-9])? | "やり直し"`);
  R.push(`view ::= "視点 " ("上" | "下" | "正面" | "背面" | "右" | "左") | "全体表示"`);
  R.push(`query ::= ("重さ" | "大きさ" | "体積")${has ? ` (" " body)?` : ""} | "部品一覧" | "干渉チェック"`);
  R.push(`scaleall ::= "スケール " num`);
  const ob = has ? ` (" " body)?` : "";
  R.push(`face ::= "上面" | "下面" | "前面" | "背面" | "左面" | "右面"`);
  R.push(`edges ::= "縦の辺" | "上の辺" | "下の辺" | "水平の辺" | "すべての辺"`);
  R.push(`hole ::= "穴 " face " Ø" num (" 深さ" num)? (" 中央" | " 四隅 " num | " 位置 " num "," num (" " num "," num)? (" " num "," num)? (" " num "," num)?)${ob}`);
  R.push(`fillet ::= "フィレット R" num " " edges${ob}`);
  R.push(`chamfer ::= "面取り C" num " " edges${ob}`);
  if (has) {
    R.push(`body ::= ${names.map(Q).join(" | ")}`);
    R.push(`bodies ::= body (" " body)? (" " body)? (" " body)? | "すべて"`);
    R.push(`dir ::= "右" | "左" | "奥" | "前" | "上" | "下"`);
    const tg = [...names.map(Q), ...feats.map(Q)].join(" | ");
    R.push(`target ::= ${tg}`);
    R.push(`modify ::= target " " ("厚さ" | "幅" | "奥行" | "高さ" | "直径" | "径" | "深さ" | "距離" | "R" | "C") " " num | target " 位置 " num "," num "," num`);
    R.push(`move ::= "移動 " bodies " " (dir " " num | num "," num "," num)`);
    R.push(`copy ::= "コピー " body " " (dir " " num | num "," num "," num)`);
    R.push(`place ::= "置く " body " " dir " " body (" 中央")? | "置く " body " " ("位置" | "中心") " " num "," num "," num`);
    R.push(`rotate ::= "回す " body " " num " 軸 " [XYZ]`);
    R.push(`scaleb ::= "スケール " num " " bodies (" 中心")?`);
    R.push(`mat ::= "材料 " bodies " " (${MATERIAL_NAMES.map(Q).join(" | ")})`);
    R.push(`color ::= "色 " (${COLOR_NAMES.map(Q).join(" | ")}) " " bodies`);
    R.push(`pattern ::= "矩形パターン " body " " [XYZ] "方向 " pos "個 間隔" num`);
    R.push(`mirror ::= "ミラー " body " " ("YZ" | "XZ" | "XY") " 位置 " num`);
    R.push(`del ::= "削除 " bodies`);
    R.push(`screw ::= "ビス接合 " body " " body (" Ø" num)? (" 個数" pos)?`);
    R.push(`thick ::= "板厚 " num " を " num " に" (" " bodies)?`);
    R.push(`hide ::= ("非表示 " | "表示 ") bodies | "すべて表示"`);
  }
  return R.join("\n");
}

// ---- 出力の後処理（短い書き方 → 座標、数値の照合） ---------------------------------
const FACE_AX = { 上面: [0, 1], 下面: [0, 1], 前面: [0, 2], 背面: [0, 2], 左面: [1, 2], 右面: [1, 2] };
const DIRV = { 右: [1, 0, 0], 左: [-1, 0, 0], 奥: [0, 1, 0], 前: [0, -1, 0], 上: [0, 0, 1], 下: [0, 0, -1] };
function bodyIn(line, bodies, selected = []) {
  for (const b of [...bodies].sort((a, c) => c.name.length - a.name.length)) if (line.includes(b.name)) return b;
  const s = selected.length ? bodies.find((b) => b.name === selected[0]) : null;
  return s || bodies[bodies.length - 1] || null;
}
// 1 行を実行できる形に（四隅・中央・方向つき移動）
export function expandLine(line, { bodies = [], selected = [] } = {}) {
  let m;
  if ((m = line.match(/^穴 (\S+) (Ø\S+(?: 深さ\S+)?) (中央|四隅 (\S+))(?: (.+))?$/))) {
    const b = bodyIn(line, bodies, selected); if (!b) return line;
    const [a1, a2] = FACE_AX[m[1]] || [0, 1];
    const W = b.size[a1], D = b.size[a2], tail = m[5] ? " " + m[5] : "";
    if (m[3] === "中央") return `穴 ${m[1]} ${m[2]} 位置 ${R6(W / 2)},${R6(D / 2)}${tail}`;
    const e = +m[4];
    return `穴 ${m[1]} ${m[2]} 位置 ${[[e, e], [W - e, e], [W - e, D - e], [e, D - e]].map((p) => p.map(R6).join(",")).join(" ")}${tail}`;
  }
  if ((m = line.match(/^(移動|コピー) (.+) (右|左|奥|前|上|下) (-?[0-9.]+)$/))) {
    const v = DIRV[m[3]].map((k) => R6(k * +m[4]));
    return `${m[1]} ${m[2]} ${v.join(",")}`;
  }
  return line;
}

// 数値の照合: 出てきた数が、頼みの言葉・今のモデルの数・その半分 にあるか
// 合わない数が 1 つで、頼みの言葉の数のうち使われていないものが 1 つなら、それに置き換える（桁違い 60→600 も直す）
export function checkNumbers(rawLines, normText, { bodies = [] } = {}) {
  const user = numbersIn(normText);
  const ctx = [];
  for (const b of bodies) for (const v of [...b.size, ...b.min, ...(b.max || [])]) ctx.push(+(+v).toFixed(3));
  const allowed = new Set([...user, ...ctx, ...ctx.map((v) => v / 2), ...user.map((v) => -v), 0, 1, 2, 3, 4, 5, 90, 180, 270].map((v) => +(+v).toFixed(3)));
  const numRe = /-?\d+(?:\.\d+)?/g;
  const fixes = [], suspicious = [];
  // 「個」「元に戻す N」「方向 N 個」 の数、軸名の後ろ（Z 方向 3 個 の 3）は数え方なので見ない
  const out = rawLines.map((line) => {
    if (/^(元に戻す|やり直し|視点)/.test(line)) return line;
    const used = new Set(numbersIn(rawLines.join(" ")).map((v) => +v.toFixed(3)));
    const unusedUser = [...new Set(user)].filter((u) => !used.has(+u.toFixed(3)));
    return line.replace(numRe, (tok, off, all) => {
      const v = +(+tok).toFixed(3);
      if (allowed.has(v)) return tok;
      if (/方向 $/.test(all.slice(0, off)) && Number.isInteger(v) && v <= 50) return tok;
      // 桁違い（60 と 600）
      const tenx = user.find((u) => u !== 0 && [10, 100, 1000, 0.1, 0.01, 0.001].some((k) => Math.abs(v * k - u) < 1e-6));
      if (tenx !== undefined) { fixes.push(`${tok}→${tenx}`); return String(tenx); }
      if (unusedUser.length === 1) { const u = unusedUser[0]; fixes.push(`${tok}→${u}`); unusedUser.length = 0; return String(u); }
      suspicious.push(tok);
      return tok;
    });
  });
  return { lines: out, fixes, suspicious };
}

// モデルの出力（テキスト） → { lines: 実行するコマンド, ask: 聞き返し, fixes, suspicious }
export function postProcess(text, normText, { bodies = [], selected = [] } = {}) {
  const t = String(text || "").trim();
  const q = t.match(/^質問:\s*(.+)/);
  if (q) return { lines: [], ask: q[1].trim(), fixes: [], suspicious: [] };
  const raw = t.split(/\n+/).map((s) => s.trim()).filter(Boolean);
  const { lines, fixes, suspicious } = checkNumbers(raw, normText, { bodies });
  // 新しく付ける名前は、頼みの言葉に出てくるものだけ（小さなモデルが作った名前「圓柱」などは付けない＝既定の名前に）
  const named = lines.map((l) => l.replace(/^((?:板|円柱) .*?) 名前 (\S+)$/, (all, head, nm) => (normText.includes(nm) && !bodies.some((b) => b.name === nm) ? all : head)));
  return { lines: named.map((l) => expandLine(l, { bodies, selected })), raw, ask: "", fixes, suspicious };
}
