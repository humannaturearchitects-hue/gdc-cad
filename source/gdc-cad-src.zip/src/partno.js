// 部品番号: 同じ部品（同じ名前・外形・材料・体積・向き違いでない）をまとめて、モデル全体で 1 つの番号を付ける
//  図面の部品表・部品番号（風船）・部品ごとの図面、パネル加工の切り出し一覧・板取り DXF のラベルで同じ番号になる
import { layupSpec } from "./layup.js";

export const baseName = (n) => String(n || "").replace(/(_\d+(-\d+)?|\((コピー|ミラー)\))+$/, "");
export const materialName = (m) => (m ? (m.layup ? layupSpec(m.layup) : (m.material?.name || "")) : "");

const statCache = new WeakMap();
// メッシュから外形・体積・重心
export function meshStats(m) {
  if (statCache.has(m)) return statCache.get(m);
  const v = m.vertices || [], t = m.triangles;
  const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < v.length; i += 3) for (let k = 0; k < 3; k++) { if (v[i + k] < mn[k]) mn[k] = v[i + k]; if (v[i + k] > mx[k]) mx[k] = v[i + k]; }
  let vol = 0; const c = [0, 0, 0];
  if (t && t.length && isFinite(mn[0])) {
    // 外形の角を原点にして（桁落ちを防ぐ）四面体の体積と重心を足し合わせる
    const P = (i) => [v[3 * i] - mn[0], v[3 * i + 1] - mn[1], v[3 * i + 2] - mn[2]];
    for (let i = 0; i < t.length; i += 3) {
      const a = P(t[i]), b = P(t[i + 1]), d = P(t[i + 2]);
      const w = (a[0] * (b[1] * d[2] - b[2] * d[1]) - a[1] * (b[0] * d[2] - b[2] * d[0]) + a[2] * (b[0] * d[1] - b[1] * d[0])) / 6;
      vol += w;
      for (let k = 0; k < 3; k++) c[k] += w * (a[k] + b[k] + d[k]) / 4;
    }
    if (Math.abs(vol) > 1e-9) for (let k = 0; k < 3; k++) c[k] = c[k] / vol + mn[k];
  }
  const s = { min: mn, max: mx, size: mx.map((x, k) => x - mn[k]), volume: Math.abs(vol), centroid: c };
  statCache.set(m, s);
  return s;
}

// 鏡に映した形（左右違い）を見分ける印: 外形の箱の中での重心のずれの向き。回しても変わらず、鏡に映すと反対になる
function handedness(s) {
  const order = [0, 1, 2].sort((a, b) => s.size[b] - s.size[a] || a - b);
  const sz = order.map((k) => s.size[k]);
  if (Math.abs(sz[0] - sz[1]) < 0.05 || Math.abs(sz[1] - sz[2]) < 0.05) return ""; // 同じ長さの辺があると向きが決まらない
  const off = order.map((k) => s.centroid[k] - (s.min[k] + s.max[k]) / 2);
  if (off.some((o) => Math.abs(o) < 0.05)) return "";
  // 並べ替えの向き（偶置換 +1 / 奇置換 -1）
  const perm = order[0] * 9 + order[1] * 3 + order[2];
  const even = [0 * 9 + 1 * 3 + 2, 1 * 9 + 2 * 3 + 0, 2 * 9 + 0 * 3 + 1].includes(perm);
  const sg = Math.sign(off[0] * off[1] * off[2]) * (even ? 1 : -1);
  return sg > 0 ? "R" : "L";
}

export function partKey(m) {
  const s = meshStats(m);
  const dims = s.size.map((x) => Math.round(x * 10) / 10).sort((a, b) => b - a);
  return [baseName(m.name), dims.join("x"), materialName(m), Math.round(s.volume / 10), handedness(s)].join("|");
}

// モデル全体（隠したボディも含む）での番号。体の並び順（ブラウザの順）で 1, 2, 3 …
export function partNumbers(app) {
  const byKey = new Map(), byId = new Map();
  for (const m of app.meshes || []) {
    const k = partKey(m);
    if (!byKey.has(k)) byKey.set(k, byKey.size + 1);
    byId.set(m.id, byKey.get(k));
  }
  return { byKey, byId };
}

// ids の部品を番号ごとにまとめる: [{ no, name, ids, qty, material, dims }]（番号順）
export function partGroups(app, ids) {
  const { byId } = partNumbers(app);
  const map = new Map();
  for (const id of ids) {
    const m = app.meshes.find((x) => x.id === id);
    if (!m) continue;
    const no = byId.get(id);
    if (!map.has(no)) {
      const s = meshStats(m);
      map.set(no, { no, name: baseName(m.name), ids: [], qty: 0, material: materialName(m), dims: s.size.map((x) => Math.round(x * 10) / 10).sort((a, b) => b - a).join(" × ") });
    }
    const g = map.get(no); g.ids.push(id); g.qty++;
  }
  return [...map.values()].sort((a, b) => a.no - b.no);
}
