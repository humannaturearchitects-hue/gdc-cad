// 内装: 配置を手で直す（上から見た図で、家具をドラッグ・幅を変える・回す・消す・足す）
// 動かすたびに、自動配置と同じ決まり（はみ出し・重なり・ドアの前・窓をふさぐ）で確かめて、赤で知らせる。
import { wallsOf, pointInPoly, rnd } from "./room.js";
import { KINDS, STYLES } from "./policy.js";
import { rectInside } from "./planner.js";

const EPS = 1;
const ov = (a, b) => a.x0 < b.x1 - EPS && b.x0 < a.x1 - EPS && a.y0 < b.y1 - EPS && b.y0 < a.y1 - EPS;
const rect = (x0, y0, x1, y1) => ({ x0: Math.min(x0, x1), y0: Math.min(y0, y1), x1: Math.max(x0, x1), y1: Math.max(y0, y1) });
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// 壁に沿った長方形（壁の始点から t、幅 len、奥行 d0〜d1）
export function wallRect(w, t, len, d0, d1) {
  const p = (tt, dd) => [w.a[0] + w.u[0] * tt + w.n[0] * dd, w.a[1] + w.u[1] * tt + w.n[1] * dd];
  const A = p(t, d0), B = p(t + len, d1);
  return rect(A[0], A[1], B[0], B[1]);
}

// 家具の形（F: 床の上の外形、C: 使うための空き）を、壁・位置・向きから作り直す
export function reshape(it, room) {
  const K = KINDS[it.kind] || {};
  if (it.wall != null) {
    const w = wallsOf(room)[it.wall];
    it.F = wallRect(w, it.t, it.w, 0, it.d);
    it.C = K.clear ? wallRect(w, it.t, it.w, it.d, it.d + K.clear) : null;
    it.dir = w.n;
  } else {
    const cx = (it.F.x0 + it.F.x1) / 2, cy = (it.F.y0 + it.F.y1) / 2;
    const alongX = Math.abs(it.dir?.[1] ?? 1) > 0.5; // 正面が y 向き → 幅は x 方向
    const a = alongX ? it.w : it.d, b = alongX ? it.d : it.w;
    it.F = rect(cx - a / 2, cy - b / 2, cx + a / 2, cy + b / 2);
    const c = K.clear || 0;
    it.C = c ? rect(it.F.x0 - c, it.F.y0 - c, it.F.x1 + c, it.F.y1 + c) : null;
  }
  it.x0 = it.F.x0; it.y0 = it.F.y0; it.x1 = it.F.x1; it.y1 = it.F.y1;
  it.toCeil = !!(KINDS[it.kind]?.tall && it.h >= room.height - 1);
  return it;
}

// 決まりに合っているか（問題の一覧を返す）
export function checkItem(it, items, room) {
  const out = [];
  if (!rectInside(it.F, room.poly)) out.push("部屋からはみ出しています");
  for (const o of items) if (o !== it && ov(it.F, o.F)) out.push(`${o.name}と重なっています`);
  const W = wallsOf(room);
  for (const o of room.openings) {
    const w = W[o.wall]; if (!w) continue;
    if ((o.type === "door" || o.type === "opening") && ov(it.F, wallRect(w, o.pos, o.width, 0, Math.min(Math.max(o.width, 800), 1000)))) out.push("ドアの前をふさいでいます");
    if (o.type === "window" && it.h > o.sill - 20 && ov(it.F, wallRect(w, o.pos, o.width, 0, 60))) out.push(`窓（窓台 ${o.sill}）をふさいでいます`);
  }
  if (it.C) for (const o of items) if (o !== it && ov(it.C, o.F) && !(it.lowOK && o.h <= 450) && !(o.kind === "lowtable")) { out.push(`前の空き（${KINDS[it.kind]?.clear}mm）に${o.name}があります`); break; }
  return [...new Set(out)];
}

// 一番近い壁に背中を付ける（近ければ）
function snapToWall(it, room, cx, cy) {
  let best = null;
  for (const w of wallsOf(room)) {
    if (w.len < it.w - 1) continue;
    const t = (cx - w.a[0]) * w.u[0] + (cy - w.a[1]) * w.u[1];
    const dist = (cx - w.a[0]) * w.n[0] + (cy - w.a[1]) * w.n[1]; // 部屋の内側が +
    if (t < -200 || t > w.len + 200 || dist < -100) continue;
    const back = dist - it.d / 2; // 背中と壁の距離
    if (back > 250) continue;
    if (!best || Math.abs(back) < Math.abs(best.back)) best = { w, t: Math.max(0, Math.min(w.len - it.w, t - it.w / 2)), back };
  }
  return best;
}

export class PlanEditor {
  constructor(ws, host) {
    this.ws = ws; this.host = host;
    this.sel = null;
  }
  get room() { return this.ws.state.room; }
  get items() { return this.ws.plan.items; }

  render() {
    const room = this.room, items = this.items;
    const xs = room.poly.map((p) => p[0]), ys = room.poly.map((p) => p[1]);
    const X0 = Math.min(...xs) - 500, Y0 = Math.min(...ys) - 500, X1 = Math.max(...xs) + 500, Y1 = Math.max(...ys) + 500;
    this.box = { X0, Y0, X1, Y1 };
    const fy = (y) => Y1 + Y0 - y; // 上を y+ に
    const pts = (P) => P.map(([x, y]) => `${x},${fy(y)}`).join(" ");
    const W = wallsOf(room);
    const probs = new Map(items.map((it) => [it, checkItem(it, items, room)]));
    const open = room.openings.map((o) => {
      const w = W[o.wall]; if (!w) return "";
      const a = [w.a[0] + w.u[0] * o.pos, w.a[1] + w.u[1] * o.pos], b = [a[0] + w.u[0] * o.width, a[1] + w.u[1] * o.width];
      if (o.type === "window") return `<line x1="${a[0]}" y1="${fy(a[1])}" x2="${b[0]}" y2="${fy(b[1])}" class="pe-win"/>`;
      const r = o.width, e = [a[0] + w.n[0] * r, a[1] + w.n[1] * r];
      const sweep = (w.u[0] * w.n[1] - w.u[1] * w.n[0]) > 0 ? 0 : 1;
      return `<line x1="${a[0]}" y1="${fy(a[1])}" x2="${b[0]}" y2="${fy(b[1])}" class="pe-doorgap"/><path d="M${e[0]} ${fy(e[1])} A${r} ${r} 0 0 ${sweep} ${b[0]} ${fy(b[1])}" class="pe-door"/><line x1="${a[0]}" y1="${fy(a[1])}" x2="${e[0]}" y2="${fy(e[1])}" class="pe-door"/>`;
    }).join("");
    const its = items.map((it, i) => {
      const bad = probs.get(it).length, F = it.F, C = it.C;
      const cls = `pe-it${it === this.sel ? " sel" : ""}${bad ? " bad" : ""}${it.builtin ? " bi" : ""}`;
      const w = F.x1 - F.x0, h = F.y1 - F.y0;
      const fs = Math.max(90, Math.min(220, Math.min(w, h) / 3.2));
      const vertical = h > w * 1.4;
      const cx = (F.x0 + F.x1) / 2, cy = fy((F.y0 + F.y1) / 2);
      return `${C && it === this.sel ? `<rect x="${C.x0}" y="${fy(C.y1)}" width="${C.x1 - C.x0}" height="${C.y1 - C.y0}" class="pe-clear"/>` : ""}
        <g data-i="${i}" class="${cls}"><rect x="${F.x0}" y="${fy(F.y1)}" width="${w}" height="${h}" style="fill:${it.color || "#bbb"}"/>
        <text x="${cx}" y="${cy}" font-size="${fs}" text-anchor="middle" dominant-baseline="middle" ${vertical ? `transform="rotate(-90 ${cx} ${cy})"` : ""}>${esc(it.mark || "")} ${esc(it.name)}</text></g>`;
    }).join("");
    const body = `<defs><pattern id="pe-grid" width="910" height="910" patternUnits="userSpaceOnUse"><path d="M910 0H0V910" fill="none" stroke="#e3e7ec" stroke-width="8"/></pattern></defs>
        <rect x="${X0}" y="${Y0}" width="${X1 - X0}" height="${Y1 - Y0}" fill="url(#pe-grid)"/>
        <polygon points="${pts(room.poly)}" class="pe-floor"/>${open}${its}
        ${W.map((w) => `<text x="${(w.a[0] + w.b[0]) / 2 - w.n[0] * 260}" y="${fy((w.a[1] + w.b[1]) / 2 - w.n[1] * 260)}" class="pe-wn" text-anchor="middle" dominant-baseline="middle">${w.name} ${Math.round(w.len)}</text>`).join("")}`;
    const vb = `${X0} ${Y0} ${X1 - X0} ${Y1 - Y0}`;
    // ドラッグ中に SVG を作り直すとポインタの捕捉が外れるので、SVG はそのままで中身だけ入れ替える
    if (this.svg && this.svg.isConnected && this.host.contains(this.svg)) {
      if (this.svg.getAttribute("viewBox") !== vb) this.svg.setAttribute("viewBox", vb);
      this.svg.innerHTML = body;
      return;
    }
    this.host.innerHTML = `<div class="pe-wrap"><svg class="pe" viewBox="${vb}" preserveAspectRatio="xMidYMid meet">${body}</svg>
      <div class="pe-hint">家具をドラッグで移動（壁に近づけると背中が壁に付きます）。クリックで選んで、左の欄で寸法・回転・削除。赤は決まりに合っていない物です。</div></div>`;
    this.svg = this.host.querySelector("svg");
    this.bind();
  }

  toMM(e) {
    const p = this.svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY;
    const q = p.matrixTransform(this.svg.getScreenCTM().inverse());
    return [q.x, this.box.Y1 + this.box.Y0 - q.y];
  }

  bind() {
    this.svg.addEventListener("pointerdown", (e) => {
      const g = e.target.closest("[data-i]");
      if (!g) { this.select(null); return; }
      const it = this.items[+g.dataset.i];
      this.select(it, false);
      const start = this.toMM(e), F0 = { ...it.F }, wall0 = it.wall;
      let moved = false;
      this.svg.setPointerCapture(e.pointerId);
      const move = (ev) => {
        const p = this.toMM(ev);
        const dx = p[0] - start[0], dy = p[1] - start[1];
        if (!moved && Math.hypot(dx, dy) < 40) return;
        moved = true;
        const cx = (F0.x0 + F0.x1) / 2 + dx, cy = (F0.y0 + F0.y1) / 2 + dy;
        // 壁に付ける物（造作・ベッドなど）は、近い壁に吸い付ける
        const K = KINDS[it.kind] || {};
        const sn = K.wall !== false && (it.builtin || it.kind === "bed" || it.kind === "officedesk" || wall0 != null) ? snapToWall(it, this.room, cx, cy) : null;
        if (sn) { it.wall = sn.w.i; it.t = rnd(sn.t, 10); }
        else {
          if (it.wall != null) it.dir = wallsOf(this.room)[it.wall].n; // 壁から離したときは、そのときの向きのまま
          it.wall = null;
          if (!it.dir || it.dir.length !== 2) it.dir = [0, 1];
          const x = rnd(cx, 10), y = rnd(cy, 10);
          it.F = rect(x, y, x, y); // 中心だけ決めて、大きさは reshape で
        }
        reshape(it, this.room);
        this.render(); this.ws.renderEditSide?.();
      };
      const up = () => {
        this.svg.removeEventListener("pointermove", move);
        this.svg.removeEventListener("pointerup", up);
        if (moved) this.ws.planEdited(`${it.name}を動かしました`);
        else this.render();
      };
      this.svg.addEventListener("pointermove", move);
      this.svg.addEventListener("pointerup", up);
    });
  }

  select(it, rerender = true) {
    this.sel = it;
    if (rerender) this.render();
    this.ws.renderEditSide?.();
  }

  // 左の欄（選んだ家具の寸法・操作）
  sideHTML() {
    const it = this.sel;
    const kinds = Object.entries(KINDS).filter(([k]) => k !== "sofa_wall");
    const add = `<div class="row"><label>家具を足す</label><select data-pe-add><option value="">選ぶ…</option>${kinds.map(([k, K]) => `<option value="${k}">${K.name}${K.builtin ? "（造作）" : ""}</option>`).join("")}</select></div>`;
    if (!it) return `<p class="dlg-note">右の図で家具をクリックすると、寸法を直したり、回したり、消したりできます。</p>${add}`;
    const probs = checkItem(it, this.items, this.room);
    const W = wallsOf(this.room);
    return `<div class="pe-side">
      <div class="iw-sum"><b>${esc(it.mark || "")} ${esc(it.name)}</b>${it.builtin ? '<em class="pe-tag">造作</em>' : ""} ${it.wall != null ? `・壁 ${W[it.wall].name} の端から ${it.t}` : "・部屋の中"}</div>
      ${probs.map((p) => `<div class="iw-warn">⚠ ${esc(p)}</div>`).join("") || `<div class="pe-ok">✓ 決まりに合っています</div>`}
      <div class="pe-dims">${[["name", "名前", "text"], ["w", "幅", "number"], ["d", "奥行", "number"], ["h", "高さ", "number"], ...(it.wall != null ? [["t", "壁端から", "number"]] : [])].map(([k, n, ty]) => `<label>${n}<input type="${ty}" data-pe="${k}" value="${esc(it[k])}" ${ty === "number" ? 'step="10"' : ""}/></label>`).join("")}</div>
      <div class="btns">
        ${it.wall == null ? `<button class="btn" data-pe-a="rot">↻ 90° 回す</button>` : `<button class="btn" data-pe-a="free">壁から離す</button>`}
        ${it.wall != null && it.builtin ? `<button class="btn" data-pe-a="fill">壁いっぱいに</button>` : ""}
        ${it.h < this.room.height - 1 && KINDS[it.kind]?.tall ? `<button class="btn" data-pe-a="ceil">天井まで</button>` : ""}
        <button class="btn" data-pe-a="del">🗑 消す</button>
      </div>${add}</div>`;
  }

  bindSide(el) {
    el.querySelectorAll("[data-pe]").forEach((i) => (i.onchange = () => {
      const it = this.sel; if (!it) return;
      const k = i.dataset.pe;
      it[k] = k === "name" ? i.value : Math.max(k === "t" ? 0 : 100, +i.value || it[k]);
      if (k === "h") it.h = Math.min(it.h, this.room.height);
      reshape(it, this.room);
      this.ws.planEdited(`${it.name}を直しました`);
    }));
    el.querySelectorAll("[data-pe-a]").forEach((b) => (b.onclick = () => {
      const it = this.sel; if (!it) return;
      const a = b.dataset.peA;
      if (a === "del") { this.items.splice(this.items.indexOf(it), 1); this.sel = null; return this.ws.planEdited(`${it.name}を消しました`); }
      if (a === "rot") { it.dir = Math.abs(it.dir?.[1] ?? 1) > 0.5 ? [1, 0] : [0, 1]; }
      if (a === "free") { const c = [(it.F.x0 + it.F.x1) / 2, (it.F.y0 + it.F.y1) / 2]; const w = wallsOf(this.room)[it.wall]; it.wall = null; it.dir = [Math.abs(w.n[0]) > 0.5 ? 1 : 0, Math.abs(w.n[1]) > 0.5 ? 1 : 0]; it.F = rect(c[0] + w.n[0] * 300, c[1] + w.n[1] * 300, c[0] + w.n[0] * 300, c[1] + w.n[1] * 300); }
      if (a === "fill") {
        // 両隣の物・開口・壁の端まで広げる
        const w = wallsOf(this.room)[it.wall];
        let lo = 0, hi = w.len;
        for (const o of this.items) if (o !== it && o.wall === it.wall) { if (o.t + o.w <= it.t + 1) lo = Math.max(lo, o.t + o.w); else if (o.t >= it.t + it.w - 1) hi = Math.min(hi, o.t); }
        for (const o of this.room.openings) if (o.wall === it.wall && (o.type !== "window" || it.h > o.sill - 20)) { const e0 = o.pos - (o.type === "door" ? 100 : 0), e1 = o.pos + o.width + (o.type === "door" ? 100 : 0); if (e1 <= it.t + 1) lo = Math.max(lo, e1); else if (e0 >= it.t + it.w - 1) hi = Math.min(hi, e0); }
        // 隣の壁の家具（角）
        for (const o of this.items) if (o !== it && o.wall !== it.wall) { const r = wallRect(w, lo, hi - lo, 0, it.d); if (ov(r, o.F)) { const ot0 = (o.F.x0 - w.a[0]) * w.u[0] + (o.F.y0 - w.a[1]) * w.u[1], ot1 = (o.F.x1 - w.a[0]) * w.u[0] + (o.F.y1 - w.a[1]) * w.u[1]; const a0 = Math.min(ot0, ot1), a1 = Math.max(ot0, ot1); if (a1 <= it.t + 1) lo = Math.max(lo, a1); else if (a0 >= it.t + it.w - 1) hi = Math.min(hi, a0); } }
        it.t = rnd(lo); it.w = rnd(hi - lo);
      }
      if (a === "ceil") it.h = this.room.height;
      reshape(it, this.room);
      this.ws.planEdited(`${it.name}を直しました`);
    }));
    const addSel = el.querySelector("[data-pe-add]");
    if (addSel) addSel.onchange = () => { if (addSel.value) this.addItem(addSel.value); };
  }

  // 家具を足す: 空いている所をさがして置く（見つからなければ部屋の真ん中に置いて赤で知らせる）
  addItem(kind) {
    const K = KINDS[kind], room = this.room;
    const style = STYLES[this.ws.brief?.style] || STYLES.natural;
    const it = { id: "I" + Date.now().toString(36), kind, name: K.name, builtin: !!K.builtin, color: K.builtin ? style.body : "#9aa3ad", material: K.builtin ? style.wood : "既製品（参考）", z0: 0, w: K.w[0], d: K.d, h: K.h === "ceil" ? room.height : K.h, dir: [0, 1], wall: null, t: 0 };
    let placed = false;
    if (K.wall) {
      for (const w of wallsOf(room)) {
        for (let t = 0; t + it.w <= w.len && !placed; t += 50) {
          it.wall = w.i; it.t = t; reshape(it, room);
          if (!checkItem(it, this.items, room).length) placed = true;
        }
        if (placed) break;
      }
    }
    if (!placed) {
      it.wall = null;
      const xs = room.poly.map((p) => p[0]), ys = room.poly.map((p) => p[1]);
      for (let x = Math.min(...xs); x < Math.max(...xs) && !placed; x += 100) for (let y = Math.min(...ys); y < Math.max(...ys) && !placed; y += 100) {
        it.F = rect(x, y, x + it.w, y + it.d); reshape(it, room);
        if (!checkItem(it, this.items, room).length && pointInPoly([x, y], room.poly)) placed = true;
      }
    }
    if (!placed) { const c = [(Math.min(...room.poly.map((p) => p[0])) + Math.max(...room.poly.map((p) => p[0]))) / 2, (Math.min(...room.poly.map((p) => p[1])) + Math.max(...room.poly.map((p) => p[1]))) / 2]; it.wall = null; it.F = rect(c[0], c[1], c[0], c[1]); reshape(it, room); }
    this.items.push(it);
    this.sel = it;
    this.ws.planEdited(placed ? `${it.name}を足しました` : `${it.name}を足しました（空いている所がないので重なっています。動かしてください）`);
  }
}
