// 内装: 部屋の形 ＋ 設計条件 → 家具・造作の配置（レイアウト）と、造作の部材表
//
// 置き方の決まり（ルール）:
//  ・ドアの前（開き戸の回転する範囲＋α）には何も置かない
//  ・窓の前には、窓台より低い物だけ置ける（背の高い収納で窓をふさがない）
//  ・収納・デスク・ベッドの前には、使うための空き（引き出し・扉・椅子・通路）を取る
//  ・テレビとソファは向かい合わせ、見る距離 2.0〜3.2m
// 候補の位置を全部試して、点数の一番高い所に置く。seed を変えると別案になる。
import { KINDS, STYLES } from "./policy.js";
import { wallsOf, pointInPoly, rng, rnd } from "./room.js";

const EPS = 1;
const ov = (a, b) => a.x0 < b.x1 - EPS && b.x0 < a.x1 - EPS && a.y0 < b.y1 - EPS && b.y0 < a.y1 - EPS;
const area = (r) => Math.max(0, r.x1 - r.x0) * Math.max(0, r.y1 - r.y0);
const rect = (x0, y0, x1, y1) => ({ x0: Math.min(x0, x1), y0: Math.min(y0, y1), x1: Math.max(x0, x1), y1: Math.max(y0, y1) });

// 長方形が部屋の中に収まっているか（直交多角形用）
export function rectInside(r, poly) {
  const s = 2;
  const pts = [[r.x0 + s, r.y0 + s], [r.x1 - s, r.y0 + s], [r.x1 - s, r.y1 - s], [r.x0 + s, r.y1 - s], [(r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2]];
  if (!pts.every((p) => pointInPoly(p, poly))) return false;
  for (const [x, y] of poly) if (x > r.x0 + s && x < r.x1 - s && y > r.y0 + s && y < r.y1 - s) return false;
  return true;
}

// 壁に沿った長方形（壁の始点から t、幅 w、奥行 d0〜d1）
function wallRect(w, t, len, d0, d1) {
  const p = (tt, dd) => [w.a[0] + w.u[0] * tt + w.n[0] * dd, w.a[1] + w.u[1] * tt + w.n[1] * dd];
  const A = p(t, d0), B = p(t + len, d1);
  return rect(A[0], A[1], B[0], B[1]);
}

const ORDER = ["bed", "tvboard", "desk", "bench", "closet", "storage", "bookshelf", "cupboard", "display", "officedesk", "dining", "counter"];

export function planLayout(room, brief, { seed = 1 } = {}) {
  const R = rng(seed * 7919 + 13);
  const jitter = () => (seed > 1 ? R() * 10 : 0);
  const walls = wallsOf(room);
  const CH = room.height;
  const style = STYLES[brief.style] || STYLES.natural;
  const tallH = brief.toCeil === false ? Math.min(2100, CH) : CH;
  const items = [], notes = [], warn = [];
  const keep = []; // 置いてはいけない範囲 {r, why}
  // ドアの前
  for (const o of room.openings) {
    const w = walls[o.wall]; if (!w) continue;
    if (o.type === "door" || o.type === "opening") {
      const depth = Math.min(Math.max(o.width, 800), 1000) + 100;
      keep.push({ r: wallRect(w, o.pos - 100, o.width + 200, 0, depth), why: "door" });
    }
  }
  if (room.openings.some((o) => o.type === "door")) notes.push("ドアの前は、扉の開閉と出入りのために約 900〜1100mm 何も置いていません");
  // 窓の前の帯（窓台の高さを覚えておく）
  const winStrips = room.openings.filter((o) => o.type === "window" && walls[o.wall]).map((o) => ({ r: wallRect(walls[o.wall], o.pos, o.width, 0, 60), sill: o.sill, o }));

  const fits = (F, C, h, ignore = []) => {
    if (!rectInside(F, room.poly)) return false;
    if (C && area(C) > 0 && !rectInside(C, room.poly)) return false;
    for (const k of keep) if (ov(F, k.r)) return false;
    for (const it of items) {
      if (ignore.includes(it)) continue;
      if (ov(F, it.F)) return false;
      if (it.C && ov(F, it.C) && !(it.lowOK && h <= 450)) return false;
      if (C && ov(C, it.F)) return false;
    }
    if (brief.keepWindow !== false) for (const s of winStrips) if (ov(F, s.r) && h > s.sill - 20) return false;
    return true;
  };
  const doorDist = (x, y) => {
    let m = Infinity;
    for (const o of room.openings) {
      if (o.type !== "door") continue;
      const w = walls[o.wall]; const t = o.pos + o.width / 2;
      m = Math.min(m, Math.hypot(w.a[0] + w.u[0] * t - x, w.a[1] + w.u[1] * t - y));
    }
    return isFinite(m) ? m : 3000;
  };
  const windowsOn = (wi) => room.openings.filter((o) => o.type === "window" && o.wall === wi);
  const add = (kind, it) => {
    const K = KINDS[kind];
    const o = { id: `I${items.length + 1}`, kind, builtin: !!K.builtin, color: K.builtin ? style.body : "#9aa3ad", material: K.builtin ? style.wood : "既製品（参考）", z0: 0, ...it, name: it.name || K.name };
    o.x0 = o.F.x0; o.y0 = o.F.y0; o.x1 = o.F.x1; o.y1 = o.F.y1;
    items.push(o);
    return o;
  };

  // ---------------------------------------------------------- 壁に付ける物
  const placeWall = (kind, opts = {}) => {
    const K = KINDS[kind];
    let h = K.h === "ceil" ? tallH : K.h;
    let d = K.d;
    let [wmin, wmax] = K.w;
    if (kind === "bed") { wmin = wmax = brief.bedW || 1200; }
    if (kind === "storage" && brief.storage === 2) wmax = 6000;
    if (kind === "storage" && brief.storage === 0) wmax = 1800;
    let best = null;
    for (const w of walls) {
      if (w.len < wmin) continue;
      const step = 50;
      for (let t = 0; t <= w.len - wmin + 0.1; t += step) {
        // 幅: 入るだけ大きく（モジュール単位）
        let width = null;
        // 造作は空いている幅いっぱいに（5mm 単位）。置き家具は決まった幅
        const step2 = wmax > wmin ? 50 : 1;
        for (let ww = Math.min(wmax, Math.floor((w.len - t) / 5) * 5); ww >= wmin; ww = ww === Math.min(wmax, Math.floor((w.len - t) / 5) * 5) && ww % step2 ? ww - (ww % step2) : ww - step2) {
          const F = wallRect(w, t, ww, 0, d);
          const C = K.clear ? wallRect(w, t, ww, d, d + K.clear) : null;
          if (fits(F, C, h)) { width = ww; break; }
        }
        if (width == null) continue;
        const F = wallRect(w, t, width, 0, d);
        const C = K.clear ? wallRect(w, t, width, d, d + K.clear) : null;
        const sc = scoreWall(kind, { w, t, width, F, d, h, wmax, wmin }) + jitter();
        if (!best || sc > best.sc) best = { sc, w, t, width, F, C, h, d };
      }
    }
    if (!best) { warn.push(`${opts.name || K.name}を置ける場所が見つかりませんでした（寸法か方針を見直してください）`); return null; }
    const it = add(kind, { name: opts.name, wall: best.w.i, t: rnd(best.t), w: best.width, d: best.d, h: best.h, F: best.F, C: best.C, dir: best.w.n });
    // 窓の下のデスク・ベンチは高さを窓台に合わせて確認
    for (const o of windowsOn(best.w.i)) if (o.pos < best.t + best.width && o.pos + o.width > best.t) {
      if (kind === "desk") notes.push(`デスクカウンターを壁 ${best.w.name} の窓の下に配置（天板 ${it.h}mm ＜ 窓台 ${o.sill}mm）。手元が明るく、外を見ながら作業できます`);
      if (kind === "bench") notes.push(`窓辺ベンチ（座面 ${it.h}mm・中は収納）を壁 ${best.w.name} の窓の下に配置`);
    }
    return it;
  };

  const scoreWall = (kind, c) => {
    const K = KINDS[kind];
    const win = windowsOn(c.w.i);
    const under = win.some((o) => o.pos < c.t + c.width && o.pos + o.width > c.t);
    const cx = (c.F.x0 + c.F.x1) / 2, cy = (c.F.y0 + c.F.y1) / 2;
    let s = 0;
    if (K.w[1] > K.w[0]) s += (10 * (c.width - c.wmin)) / Math.max(1, c.wmax - c.wmin);
    switch (kind) {
      case "storage": case "closet": case "bookshelf": case "cupboard": case "display":
        s += win.length ? 0 : 6;
        s += (8 * c.width) / c.w.len; // 壁一面に近いほど納まりがいい
        if (kind === "closet") s += Math.max(0, 4 - doorDist(cx, cy) / 1000); // 入口の近く
        break;
      case "desk": case "officedesk": {
        if (under) s += 12;
        // 横から光が入る（隣の壁の窓の近く）
        for (const o of room.openings) if (o.type === "window" && o.wall !== c.w.i) {
          const w2 = wallsOf(room)[o.wall]; const t = o.pos + o.width / 2;
          const dd = Math.hypot(w2.a[0] + w2.u[0] * t - cx, w2.a[1] + w2.u[1] * t - cy);
          s += Math.max(0, 5 - dd / 600);
        }
        s += Math.min(4, doorDist(cx, cy) / 800); // 出入口から離れて落ち着く
        break;
      }
      case "bench": s += under ? 20 : -15; break;
      case "tvboard": {
        s += win.length ? -4 : 6; // 窓を背にすると画面が見にくい
        const room2 = depthInFront(c.w, c.t + c.width / 2);
        s += room2 >= 2600 ? 6 : room2 >= 2100 ? 2 : -10;
        break;
      }
      case "bed": {
        s += win.some((o) => o.sill < 900 && o.pos < c.t + c.width && o.pos + o.width > c.t) ? -10 : 4;
        s += Math.min(6, doorDist(cx, cy) / 600); // 入口から離す
        // 横に 500mm 以上の空きがあるか（片側）
        const side = [wallRect(c.w, c.t - 550, 550, 0, c.d), wallRect(c.w, c.t + c.width, 550, 0, c.d)];
        if (!side.some((r) => rectInside(r, room.poly) && fits(r, null, 0))) s -= 12;
        break;
      }
    }
    return s;
  };
  const depthInFront = (w, t) => {
    for (let dd = 100; dd < 12000; dd += 50) {
      const p = [w.a[0] + w.u[0] * t + w.n[0] * dd, w.a[1] + w.u[1] * t + w.n[1] * dd];
      if (!pointInPoly(p, room.poly)) return dd;
      for (const it of items) if (p[0] > it.F.x0 && p[0] < it.F.x1 && p[1] > it.F.y0 && p[1] < it.F.y1 && it.kind !== "tvboard") return dd;
    }
    return 12000;
  };

  // ---------------------------------------------------------- ソファ（テレビの正面）＋ローテーブル
  const placeSofa = (tv, wantTable) => {
    const K = KINDS.sofa;
    if (!tv) return wallSofa();
    const w = wallsOf(room)[tv.wall];
    const tc = tv.t + tv.w / 2;
    let best = null;
    for (let s = 2000; s <= 3400; s += 50) { // テレビ面から ソファの前端まで
      for (const off of [0, -150, 150, -300, 300]) {
        const F = wallRect(w, tc + off - K.w[0] / 2, K.w[0], s, s + K.d);
        if (!fits(F, null, K.h)) continue;
        const behind = wallRect(w, tc + off - K.w[0] / 2, K.w[0], s + K.d, s + K.d + 600);
        const backToWall = !rectInside(wallRect(w, tc + off - K.w[0] / 2, K.w[0], s + K.d, s + K.d + 60), room.poly);
        if (!backToWall && !(rectInside(behind, room.poly) && fits(behind, null, 0))) continue; // 後ろを通れない
        let sc = (backToWall ? 8 : 0) - Math.abs(s - 2500) / 300 - Math.abs(off) / 150 + jitter();
        if (!best || sc > best.sc) best = { sc, F, s, off, backToWall };
      }
    }
    if (!best) { warn.push("テレビの正面にソファを置ける広さがありませんでした"); return null; }
    const dir = [-w.n[0], -w.n[1]];
    const sofa = add("sofa", { F: best.F, w: K.w[0], d: K.d, h: K.h, dir, facing: tv.id, C: wallRect(w, tc + best.off - K.w[0] / 2, K.w[0], best.s - K.clear, best.s), lowOK: true });
    notes.push(`ソファはテレビの正面、画面から約 ${rnd(best.s - 100, 50)}mm（見やすい距離 2.0〜3.0m）${best.backToWall ? "・背を壁に付けて" : "・後ろに通路 600mm を残して"}配置`);
    if (wantTable) {
      const T = KINDS.lowtable;
      const s0 = best.s - 400 - T.d;
      if (s0 > tv.d + 400) {
        const F = wallRect(w, tc + best.off - T.w[0] / 2, T.w[0], s0, s0 + T.d);
        if (fits(F, null, T.h, [sofa])) add("lowtable", { F, w: T.w[0], d: T.d, h: T.h, dir });
      }
    }
    return sofa;
  };

  // テレビがないとき: ソファは壁に背を付けて置く
  function wallSofa() {
    const it = placeWall("sofa_wall", { name: "ソファ" });
    if (it) it.kind = "sofa";
    return it;
  }

  // ---------------------------------------------------------- 部屋の中に置く物（ダイニング・レジ）
  const placeFree = (kind, relax = 1) => {
    const K = KINDS[kind];
    let [tw, td] = [K.w[0], K.d];
    if (kind === "dining") { const p = brief.people || 4; [tw, td] = p <= 2 ? [900, 750] : p <= 4 ? [1400, 800] : p <= 6 ? [1800, 900] : [2400, 900]; }
    const c = Math.round(K.clear * relax);
    const xs = room.poly.map((p) => p[0]), ys = room.poly.map((p) => p[1]);
    const X0 = Math.min(...xs), X1 = Math.max(...xs), Y0 = Math.min(...ys), Y1 = Math.max(...ys);
    let best = null;
    for (const rot of [0, 1]) {
      const a = rot ? td : tw, b = rot ? tw : td;
      for (let x = X0 + c; x + a <= X1 - c + 0.1; x += 50) for (let y = Y0 + c; y + b <= Y1 - c + 0.1; y += 50) {
        const F = rect(x, y, x + a, y + b);
        const C = rect(x - c, y - c, x + a + c, y + b + c);
        if (!fits(F, C, K.h)) continue;
        let sc = jitter();
        if (kind === "counter") sc -= doorDist(x + a / 2, y + b / 2) / 500; // 入口が見える所
        if (kind === "dining") { // 窓に近い・部屋の奥
          for (const o of room.openings) if (o.type === "window") { const w = walls[o.wall]; const t = o.pos + o.width / 2; sc += Math.max(0, 3 - Math.hypot(w.a[0] + w.u[0] * t - x - a / 2, w.a[1] + w.u[1] * t - y - b / 2) / 1000); }
          sc += Math.min(3, doorDist(x + a / 2, y + b / 2) / 1000);
        }
        if (!best || sc > best.sc) best = { sc, F, C, rot, a, b };
      }
    }
    if (!best && relax > 0.7) return placeFree(kind, relax - 0.15);
    if (!best) { warn.push(`${K.name}（${tw}×${td}、周りに ${c}mm の空き）を置ける場所がありませんでした`); return null; }
    const it = add(kind, { F: best.F, C: best.C, w: tw, d: td, h: K.h, dir: best.rot ? [1, 0] : [0, 1] });
    if (kind === "dining") notes.push(`ダイニングテーブル ${tw}×${td}（${brief.people || 4} 人用）。椅子を引いて座れるよう周りに ${c}mm 以上の空き`);
    if (kind === "counter") notes.push(`レジカウンターは入口が見える位置に。周りに ${c}mm 以上の通路`);
    return it;
  };

  // ---------------------------------------------------------- 順番に置く
  const want = [...brief.items];
  const cnt = (k) => want.filter((x) => x === k).length;
  const order = ORDER.filter((k) => want.includes(k));
  let tv = null;
  for (const kind of order) {
    const n = kind === "officedesk" ? (brief.people || cnt(kind)) : cnt(kind);
    for (let i = 0; i < n; i++) {
      if (kind === "dining" || kind === "counter") placeFree(kind);
      else {
        const it = placeWall(kind, { name: n > 1 ? `${KINDS[kind].name}${i + 1}` : undefined });
        if (kind === "tvboard") tv = it;
      }
      if (kind === "tvboard" && want.includes("sofa")) placeSofa(tv, want.includes("lowtable"));
    }
  }
  if (want.includes("sofa") && !want.includes("tvboard")) wallSofa();
  for (const it of items) if (KINDS[it.kind]?.tall && it.h >= CH - 1) it.toCeil = true;
  if (items.some((i) => i.toCeil)) notes.push(`背の高い収納は天井（CH ${CH}mm）まで。上部はフィラー（すき間をふさぐ板）で現場合わせ`);
  notes.push(`造作家具の材料: ${style.wood}・板厚 ${brief.thickness || 18}mm。${style.note}`);
  // 床面積に対する家具の割合
  const floor = Math.abs(room.poly.reduce((s, p, i) => { const q = room.poly[(i + 1) % room.poly.length]; return s + p[0] * q[1] - q[0] * p[1]; }, 0)) / 2;
  const used = items.reduce((s, it) => s + area(it.F), 0);
  notes.push(`家具が占める床: ${(used / 1e6).toFixed(1)}㎡ / ${(floor / 1e6).toFixed(1)}㎡（${Math.round((100 * used) / floor)}%）`);
  return { items, notes, warn, style: brief.style, seed };
}

// 案をいくつか作り、置けなかった物が一番少ない案を選ぶ（seed 1 = 基本の案、2〜 = 別案）
export function designPlan(room, brief, seed = 1) {
  const cands = seed === 1 ? [1, ...Array.from({ length: 8 }, (_, k) => 1000 + k)] : Array.from({ length: 8 }, (_, k) => seed * 37 + k);
  let best = null;
  for (const sd of cands) {
    const p = planLayout(room, brief, { seed: sd });
    if (!best || p.warn.length < best.warn.length) best = p;
    if (!best.warn.length) break;
  }
  best.seed = seed;
  return best;
}

// ---------------------------------------------------------------- 造作家具の部材（板 1 枚ずつの位置と寸法）
// 家具の中の座標: x = 幅方向（壁の始点側が 0）、y = 奥行（壁が 0）、z = 高さ（床が 0）
// 箱組み: 背板 4mm を壁側に、側板で天板・地板をはさむ。台輪（幅木よけ）60mm。扉は前面に全かぶせ
export function builtinParts(it, brief) {
  const T = brief.thickness || 18, BT = 4, mat = (STYLES[brief.style] || STYLES.natural).wood;
  const parts = [], hw = [];
  const W = it.w, D = it.d, H = it.h;
  const P = (part, box, t, note = "", m = mat) => parts.push({ part, box: box.map((v) => Math.round(v * 10) / 10), T: t, mat: m, note });
  if (it.kind === "desk") {
    const TT = 30;
    P("天板", [0, 0, H - TT, W, D, H], TT, "前端 R2・後端は壁に合わせて削り合わせ");
    P("幕板（補強）", [50, D - 50 - T, H - TT - 80, W - 50, D - 50, H - TT], T, "天板の裏");
    const nb = Math.max(2, Math.ceil(W / 900) + 1);
    for (let k = 0; k < nb; k++) { const x = Math.min(W - 40, Math.max(0, (k * (W - 40)) / (nb - 1))); P("受け桟", [x, 0, H - TT - 30, x + 40, D - 20, H - TT], 30, "壁の下地（間柱）にビス留め", "杉 角材"); }
    hw.push({ item: it.name, name: "カウンター受け金物（耐荷重 60kg 程度）", qty: nb });
    return { parts, hw };
  }
  const open = ["bookshelf", "display"].includes(it.kind);
  const DT = open ? 0 : T; // 扉の厚み
  const base = it.kind === "bench" ? 0 : 60;
  const y0 = BT, y1 = D - DT; // 箱（側板など）の奥行の範囲
  const top = it.toCeil ? H - 60 : H; // 天井までの物は上 60mm をフィラーで現場合わせ
  // 幅の広い物は、運べて 4×8 版（2440）から取れる大きさの箱に分けて、現場で連結する
  const nb = Math.max(1, Math.ceil(W / 1800));
  const bw = W / nb;
  let nd = 0, shelves = 0, dhMax = 0;
  for (let b = 0; b < nb; b++) {
    const X = b * bw;
    const n = Math.max(1, Math.ceil(bw / 900)); // 箱の中の区画
    const inW = (bw - 2 * T - (n - 1) * T) / n;
    P("背板", [X + 1, 0, base + 1, X + bw - 1, BT, top - 1], BT, "", "シナ合板 4mm");
    P("側板", [X, y0, base, X + T, y1, top], T);
    P("側板", [X + bw - T, y0, base, X + bw, y1, top], T);
    P("天板", [X + T, y0, top - T, X + bw - T, y1, top], T);
    P("地板", [X + T, y0, base, X + bw - T, y1, base + T], T);
    const xs = [];
    for (let k = 0; k < n; k++) xs.push(X + T + k * (inW + T));
    for (let k = 1; k < n; k++) P("仕切り板", [xs[k] - T, y0, base + T, xs[k], y1, top - T], T);
    if (base) {
      P("台輪", [X + T, y1 - 40 - T, 0, X + bw - T, y1 - 40, base], T, "前（40 下げ）");
      P("台輪", [X + T, y0, 0, X + bw - T, y0 + T, base], T, "後");
    }
    const innerH = top - base - 2 * T;
    if (it.kind === "closet") {
      for (const x of xs) P("枕棚", [x + 1, y0, 1800, x + inW - 1, y1 - 20, 1800 + T], T, "床から 1800");
      hw.push({ item: it.name, name: "ハンガーパイプ φ25", qty: n, note: `長さ ${rnd(inW)}` });
    } else if (it.kind === "tvboard" || it.kind === "bench") {
      for (const x of xs) P("中棚", [x + 1, y0, base + T + innerH / 2 - T / 2, x + inW - 1, y1 - 30, base + T + innerH / 2 + T / 2], T);
    } else {
      const step = it.kind === "bookshelf" ? 330 : it.kind === "display" ? 380 : 400;
      const ns = Math.max(1, Math.round(innerH / step) - 1);
      for (const x of xs) for (let j = 1; j <= ns; j++) {
        const z = base + T + (innerH * j) / (ns + 1) - T / 2;
        P("可動棚板", [x + 1, y0, z, x + inW - 1, y1 - (open ? 10 : 30), z + T], T, `棚ピッチ約 ${Math.round(innerH / (ns + 1))}・ダボ穴 32 ピッチ`);
      }
      shelves += n * ns;
    }
    if (!open) {
      const doorsPer = inW > 600 ? 2 : 1, gap = 3;
      const m = n * doorsPer;
      const dw = (bw - gap * (m + 1)) / m;
      const flap = it.kind === "tvboard" || it.kind === "bench";
      for (let k = 0; k < m; k++) {
        const x = X + gap + k * (dw + gap);
        P(flap ? "フラップ扉" : "扉", [x, y1, base + gap, x + dw, D, top - gap], T, flap ? "" : "スライド丁番・全かぶせ");
      }
      nd += m; dhMax = top - base - 2 * gap;
    }
  }
  if (nb > 1) hw.push({ item: it.name, name: "箱の連結ボルト（ジョイントコネクター）", qty: (nb - 1) * 4 });
  if (shelves) hw.push({ item: it.name, name: "棚ダボ", qty: shelves * 4 });
  if (nd) {
    const flap = it.kind === "tvboard" || it.kind === "bench";
    if (!flap) hw.push({ item: it.name, name: "スライド丁番（全かぶせ）", qty: nd * (dhMax > 1800 ? 4 : dhMax > 900 ? 3 : 2) });
    else hw.push({ item: it.name, name: "フラップステー または スライドレール", qty: nd });
    hw.push({ item: it.name, name: "取手 または プッシュラッチ", qty: nd });
  }
  if (it.toCeil) {
    for (let x = 0, k = 0; x < W - 1; x += 2400, k++) P("天井フィラー", [x, D - DT - T, top, Math.min(W, x + 2400), D - DT, H], T, "現場で天井に合わせてカット");
  }
  // 定尺（4×8 版 2440×1220）を超える板に注意書き
  for (const p of parts) {
    const b = p.box, d = [b[3] - b[0], b[4] - b[1], b[5] - b[2]].sort((x, y) => y - x);
    if (d[0] > 2430 || d[1] > 1210) p.note = [p.note, d[0] > 3020 ? "定尺を超える: 継ぎが必要" : "3×10 版（3030×910）から取る"].filter(Boolean).join("・");
  }
  return { parts, hw };
}

// 板の寸法（長さ・幅・厚み）
export function partSize(p) {
  const b = p.box, d = [b[3] - b[0], b[4] - b[1], b[5] - b[2]].map((v) => Math.round(v));
  const k = d.findIndex((v) => Math.abs(v - p.T) < 0.6);
  const rest = d.filter((_, i) => i !== (k < 0 ? d.indexOf(Math.min(...d)) : k));
  return { L: Math.max(...rest), W: Math.min(...rest), T: p.T };
}

// 部材表（同じ寸法の板はまとめて数量に）
export function cutList(it, brief) {
  const { parts, hw } = builtinParts(it, brief);
  const map = new Map();
  for (const p of parts) {
    const s = partSize(p);
    const key = [p.part, p.mat, s.L, s.W, s.T, p.note].join("|");
    if (map.has(key)) map.get(key).qty++;
    else map.set(key, { item: it.name, part: p.part, mat: p.mat, L: s.L, W: s.W, T: s.T, qty: 1, note: p.note });
  }
  return { rows: [...map.values()], hw };
}

export function cutListAll(plan, brief) {
  const rows = [], hw = [];
  for (const it of plan.items) if (it.builtin) { const c = cutList(it, brief); rows.push(...c.rows); hw.push(...c.hw); }
  return { rows, hw };
}

// 家具の中の座標 → 部屋の座標（壁に付けた物）。返り値: 部屋座標の箱 [x0,y0,z0,x1,y1,z1]
export function localToRoom(it, room, box) {
  const w = wallsOf(room)[it.wall];
  const p = (x, y) => [w.a[0] + w.u[0] * (it.t + x) + w.n[0] * y, w.a[1] + w.u[1] * (it.t + x) + w.n[1] * y];
  const A = p(box[0], box[1]), B = p(box[3], box[4]);
  const z = it.z0 || 0;
  return [Math.min(A[0], B[0]), Math.min(A[1], B[1]), box[2] + z, Math.max(A[0], B[0]), Math.max(A[1], B[1]), box[5] + z];
}
