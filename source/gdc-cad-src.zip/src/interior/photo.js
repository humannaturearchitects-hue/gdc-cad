// 内装: 写真から間取り・部屋を作る（AI = Claude の画像読み取り。利用者の API キーで、オンにしたときだけ）
//  1) 間取り図の写真（不動産のチラシ・図面・手描き）→ 部屋ごとの形と寸法、ドア・窓
//  2) 部屋の写真（数枚）→ その部屋の形・天井高・ドア・窓のおおよその寸法
// 送るもの: 選んだ写真（長い辺 1568px 以下に縮小）と、補足の文だけ。
import Anthropic from "@anthropic-ai/sdk";
import { layoutFromJSON } from "./layout.js";

const PT = { type: "array", items: { type: "number" } };
const OPENING = {
  type: "object",
  properties: {
    type: { type: "string", enum: ["door", "window", "opening"] },
    a: { ...PT, description: "開口の片端 [x,y] mm（壁の上の点）" },
    b: { ...PT, description: "開口のもう片端 [x,y] mm" },
    height: { type: "number", description: "開口の高さ mm（不明ならドア 2000・窓 1100）" },
    sill: { type: "number", description: "窓の床からの高さ mm（ドアは 0）" },
  },
  required: ["type", "a", "b", "height", "sill"],
  additionalProperties: false,
};
const SCHEMA = {
  type: "object",
  properties: {
    rooms: {
      type: "array",
      items: {
        type: "object",
        properties: {
          name: { type: "string", description: "部屋名（図面の表記どおり。例: 洋室1、LDK、和室）" },
          poly: { type: "array", items: PT, description: "部屋の内側の輪郭。角の点 [x,y] mm を順番に（直角の多角形・y は上向き・間取り全体で共通の座標）" },
          height: { type: "number", description: "天井高 mm（不明なら 2400）" },
        },
        required: ["name", "poly", "height"],
        additionalProperties: false,
      },
    },
    openings: { type: "array", items: OPENING },
    scale: { type: "string", description: "寸法の根拠（例: 図面の寸法線 3640、6 帖、910 モジュール）" },
    notes: { type: "array", items: { type: "string" }, description: "読み取れなかった所・推定した所（日本語で短く）" },
  },
  required: ["rooms", "openings", "scale", "notes"],
  additionalProperties: false,
};

const PLAN_SYSTEM = `あなたは日本の建築図面を読むのが得意な設計者です。間取り図の画像から、部屋ごとの形と寸法を読み取って JSON で返します。
決まり:
- 座標は mm。間取り全体で 1 つの座標（左下あたりを原点、x は右、y は上）。部屋どうしの位置関係も正しく。
- poly は部屋の「内側」の輪郭で、壁は直角（縦か横）だけ。角の点を順番に並べる。
- 寸法の決め方（この順に優先）: 図面に書かれた寸法線 → 部屋の広さ（帖・畳・㎡。1 帖 ≒ 1.62㎡）→ 日本の在来の寸法（910mm モジュール。6 帖 ≒ 2730×3640）。
- 壁の厚みの分（約 100〜150mm）は、内側の寸法になるよう差し引く。
- 収納（CL・押入・WIC）・廊下・トイレ・浴室・洗面も、部屋として名前を付けて入れる（1㎡ 未満の物は入れない）。
- ドア・引戸・窓は openings に。a・b は壁の上の両端の点。部屋と部屋の間のドアは 1 つでよい。
- 分からない所は推定し、notes に「推定」と書く。`;

const PHOTO_SYSTEM = `あなたは内装の現場調査が得意な設計者です。1 つの部屋をいろいろな向きから撮った写真から、その部屋の形と寸法を推定して JSON で返します。
決まり:
- rooms には部屋を 1 つだけ。poly は床の内側の輪郭（直角の多角形・mm・左下が原点・x 右・y 上）。
- 寸法の手がかり: ドアの高さ（ふつう 2000mm）・幅（750〜800mm）、天井高（ふつう 2400mm）、コンセントの高さ（250mm）、
  フローリングの幅（75〜150mm）、畳（910×1820）、家具の大きさ、利用者が教えてくれた寸法（いちばん優先）。
- 写真どうしで同じ壁・角を見つけて、部屋全体の形をつなぎ合わせる。写っていない壁は推定する。
- ドア・窓は openings に（a・b は壁の上の両端の点）。窓の床からの高さ（sill）と高さも推定する。
- 推定した所と、どれくらい自信があるかを notes に書く。`;

// 画像ファイル → Claude に送る形（縮小して JPEG）
export async function imageToBlock(file, maxSide = 1568) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error("画像を開けませんでした（HEIC は JPEG に変換してください）")); i.src = url; });
    const k = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement("canvas");
    c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    const data = c.toDataURL("image/jpeg", 0.88).split(",")[1];
    return { type: "image", source: { type: "base64", media_type: "image/jpeg", data } };
  } finally { URL.revokeObjectURL(url); }
}

async function ask({ apiKey, model, system, images, text, signal }) {
  if (!apiKey) throw new Error("写真の読み取りには AI の API キーが必要です");
  const client = new Anthropic({ apiKey, dangerouslyAllowBrowser: true, timeout: 150000, maxRetries: 1 });
  const res = await client.messages.create({
    model,
    max_tokens: 16000,
    system: [{ type: "text", text: system, cache_control: { type: "ephemeral" } }],
    messages: [{ role: "user", content: [...images, { type: "text", text }] }],
    output_config: { format: { type: "json_schema", schema: SCHEMA } },
  }, { signal });
  if (res.stop_reason === "refusal") throw new Error("AI がこの画像を処理できませんでした");
  if (res.stop_reason === "max_tokens") throw new Error("AI の返事が長すぎて途中で切れました（部屋の少ない範囲で撮り直してください）");
  return JSON.parse(res.content.filter((b) => b.type === "text").map((b) => b.text).join(""));
}

// 間取り図の写真 → 間取り
export async function readFloorplanAI({ apiKey, model = "claude-opus-5-5", images, hint = "", signal }) {
  const json = await ask({ apiKey, model, system: PLAN_SYSTEM, images, signal, text: `この間取り図を読み取ってください。${hint ? "\n補足: " + hint : ""}` });
  const layout = layoutFromJSON(json, { source: "ai-plan", name: "間取り（写真から）" });
  if (!layout.rooms.length) throw new Error("部屋を読み取れませんでした。図面全体がまっすぐ写るように撮り直すか、「なぞる」で作ってください");
  layout.notes = [json.scale ? `寸法の根拠: ${json.scale}` : "", ...(json.notes || [])].filter(Boolean);
  return layout;
}

// 部屋の写真（複数）→ 部屋 1 つ
export async function readRoomPhotosAI({ apiKey, model = "claude-opus-5-5", images, hint = "", signal }) {
  const json = await ask({ apiKey, model, system: PHOTO_SYSTEM, images, signal, text: `${images.length} 枚の写真は同じ部屋です。部屋の形と寸法を推定してください。${hint ? "\n分かっている寸法・補足: " + hint : ""}` });
  json.rooms = (json.rooms || []).slice(0, 1);
  const layout = layoutFromJSON(json, { source: "ai-photo", name: "部屋（写真から）" });
  if (!layout.rooms.length) throw new Error("部屋の形を推定できませんでした。部屋の四隅が写るように何枚か撮ってください");
  const room = layout.rooms[0];
  room.log = ["写真からの推定です。壁の長さ・天井高・ドア/窓を必ず実測で確かめて直してください", ...(json.notes || []).map((n) => "AI: " + n)];
  return room;
}
