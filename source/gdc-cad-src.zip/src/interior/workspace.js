// 内装ワークスペース: スキャン → 部屋の形 → 方針 → 自動設計 → 図面（PDF / DXF / SVG）・部材表 → 3D CAD へ
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { store, newId } from "../store.js";
import { esc } from "../commands.js";
import { sheetToSVG, sheetToDXF, sheetsToPDF, download } from "../exporters.js";
import { dxfEncodingSelect, bindDxfEncoding, encodeDXF } from "../dxfenc.js";
import { loadScanFile, normalizePoints } from "./scan.js";
import { extractRoom, rectRoom, makeSampleScan, wallsOf, toRoomFrame, polyArea, rnd } from "./room.js";
import { parsePolicy, POLICY_EXAMPLES, USES, STYLES, KINDS } from "./policy.js";
import { designPlan, builtinParts, localToRoom } from "./planner.js";
import { buildSheets, cutCSV } from "./sheets.js";
import { askBriefAI } from "./aibrief.js";

const OPEN_TYPES = { door: "ドア", window: "窓", opening: "開口（建具なし）" };

export class InteriorWorkspace {
  constructor(app) {
    this.app = app;
    this.el = document.getElementById("interior-ws");
    this.points = null; // 部屋座標の点群（表示用・ファイルには保存しない）
    this.page = 0; // 0 = 3D、1〜 = 図面
    this.sheets = [];
    this.plan = null;
  }

  get state() {
    if (!store.project.interior) store.project.interior = { room: null, policy: "", seed: 1, size: "A3", useAI: false };
    return store.project.interior;
  }

  open() {
    this.el.classList.remove("hidden");
    // 別のファイルに切り替わっていたら、前の設計結果・点群は捨てる
    if (this.planRoom !== this.state.room) { this.plan = null; this.sheets = []; if (this.pointsRoom !== this.state.room) this.points = null; this.page = 0; }
    this.render();
    if (this.state.room && this.state.policy && !this.plan) this.design({ quiet: true });
  }
  close() { this.el.classList.add("hidden"); this.stop3D(); }

  // ------------------------------------------------------------ 画面
  render() {
    const st = this.state, room = st.room;
    const hasKey = !!this.app.cmdline?.aiKey?.();
    this.el.innerHTML = `
      <div class="dw-side iw-side">
        <h3>① 部屋を読み込む</h3>
        <div class="btns">
          <button class="btn primary" data-a="scan" title="iPhone の LiDAR スキャンアプリ（Polycam・Scaniverse・3D Scanner App など）で書き出した OBJ / PLY / GLB">📷 スキャンを開く</button>
          <button class="btn" data-a="sample" title="L 字の部屋の見本スキャン（ドア 1・窓 2・ソファあり）">👀 見本スキャン</button>
          <button class="btn wide" data-a="manual">📐 寸法を入れて部屋を作る（スキャンなし）</button>
        </div>
        <div class="row" style="margin-top:6px"><label>上方向</label><select data-o="up"><option value="auto">自動</option><option value="y">Y が上（iPhone・glTF）</option><option value="z">Z が上</option></select></div>
        <div class="row"><label>単位</label><select data-o="unit"><option value="auto">自動</option><option value="m">m</option><option value="cm">cm</option><option value="mm">mm</option></select></div>
        <p class="dlg-note">対応: OBJ・PLY・GLB/glTF・XYZ。USDZ（iPhone の「ルームプラン」など）は、アプリで OBJ か GLB に書き出してください。スキャンはこの端末の中だけで処理され、外には送られません。</p>
        ${room ? this.roomHTML(room) : ""}
        <h3>③ 設計の方針</h3>
        <textarea class="iw-policy" rows="4" placeholder="例: 在宅ワーク用の書斎。本が多いので壁一面の本棚と、窓に向かうデスク。ナチュラルな木の感じで">${esc(st.policy || "")}</textarea>
        <div class="iw-chips">${POLICY_EXAMPLES.map((p, i) => `<button class="chip" data-ex="${i}" title="${esc(p)}">${esc(p.split("。")[0])}</button>`).join("")}</div>
        <label class="iw-ai"><input type="checkbox" data-ai ${st.useAI ? "checked" : ""} ${hasKey ? "" : "disabled"}/> AI（Claude）で方針を読み取る${hasKey ? "" : "（AI の API キーを設定すると使えます）"}</label>
        <div class="btns" style="margin-top:6px">
          <button class="btn primary" data-a="design" ${room ? "" : "disabled"}>✨ 設計する</button>
          <button class="btn" data-a="alt" ${room && this.plan ? "" : "disabled"} title="同じ方針で、置き方を変えた別の案">🔀 別案</button>
        </div>
        <div class="iw-result">${this.plan ? this.resultHTML() : ""}</div>
        <h3>⑤ 書き出し</h3>
        <div class="row"><label>用紙</label><select data-o="size">${["A3", "A2", "A4"].map((k) => `<option ${st.size === k ? "selected" : ""}>${k}</option>`).join("")}</select></div>
        <div class="btns">
          <button class="btn primary" data-x="pdf" ${this.plan ? "" : "disabled"}>図面 PDF（全ページ）</button>
          <button class="btn" data-x="dxf" ${this.plan ? "" : "disabled"}>DXF（全ページ）</button>
          <button class="btn" data-x="svg" ${this.plan ? "" : "disabled"}>SVG（このページ）</button>
          <button class="btn" data-x="csv" ${this.plan ? "" : "disabled"}>部材表 CSV</button>
          <button class="btn wide" data-x="cad" ${this.plan ? "" : "disabled"} title="造作家具を板 1 枚ずつの部品にして 3D CAD に入れます（パネル加工データ・部品図が作れます）">🧩 3D CAD に送る（造作を板の部品に）</button>
        </div>
        <div class="row" style="margin-top:8px"><label>DXF 文字</label>${dxfEncodingSelect("iw-enc")}</div>
        <p class="dlg-note">図面: 平面図（開口の位置・壁の長さ・家具の位置の寸法）、展開図（各壁の正面・高さ寸法）、家具表・部材表・金物表。寸法はスキャンの読み取り値です。製作前に現場で実測して確認してください。</p>
      </div>
      <div class="dw-main iw-main"><div class="iw-wrap"><div class="dw-pages"></div><div class="iw-view"></div></div></div>`;
    this.bind();
    this.renderPages();
    this.renderView();
  }

  roomHTML(room) {
    const W = wallsOf(room);
    const A = Math.abs(polyArea(room.poly)) / 1e6;
    return `
      <h3>② 部屋の寸法（読み取り結果・直せます）</h3>
      <div class="iw-sum">${esc(room.name)}: 床 ${A.toFixed(2)}㎡（約 ${(A / 1.62).toFixed(1)} 畳）・壁 ${W.length} 面${room.source === "scan" ? "・スキャンから" : ""}</div>
      ${(room.log || []).map((l) => `<div class="iw-warn">⚠ ${esc(l)}</div>`).join("")}
      <div class="row"><label>天井高 CH</label><input type="number" data-r="height" value="${room.height}" step="5"/></div>
      <table class="iw-table"><tr><th>壁</th><th>長さ mm</th></tr>
        ${W.map((w) => `<tr><td>${w.name}</td><td><input type="number" data-wall="${w.i}" value="${Math.round(w.len)}" step="5"/></td></tr>`).join("")}
      </table>
      <div class="iw-opens">${room.openings.map((o, k) => `<div class="iw-op">
        <div class="iw-op1"><select data-op="${k}" data-k="type">${Object.entries(OPEN_TYPES).map(([v, n]) => `<option value="${v}" ${o.type === v ? "selected" : ""}>${n}</option>`).join("")}</select>
          <label>壁 <select data-op="${k}" data-k="wall">${W.map((w) => `<option value="${w.i}" ${o.wall === w.i ? "selected" : ""}>${w.name}</option>`).join("")}</select></label>
          <button class="icon-btn" data-del="${k}" title="この開口を消す">✕</button></div>
        <div class="iw-op2">${[["pos", "壁端から"], ["width", "幅"], ["height", "高さ"], ["sill", "床から"]].map(([f, n]) => `<label>${n}<input type="number" data-op="${k}" data-k="${f}" value="${o[f]}" step="5" ${f === "sill" && o.type !== "window" ? "disabled" : ""}/></label>`).join("")}</div>
      </div>`).join("")}</div>
      <button class="btn" data-a="addopen" style="margin-top:4px">＋ ドア・窓を足す</button>`;
  }

  resultHTML() {
    const p = this.plan, b = this.brief;
    return `
      <h3>④ 設計結果</h3>
      <div class="iw-sum">${esc(USES[b.use])}・${esc(STYLES[b.style].name)}${b.byAI ? "（AI が方針を読み取り）" : ""}</div>
      <ul class="iw-items">${p.items.map((it) => `<li><b>${esc(it.mark || "")}</b> ${esc(it.name)} <span>${it.w}×${it.d}×H${it.h}</span>${it.builtin ? '<em>造作</em>' : ""}<button class="icon-btn" data-rm="${esc(it.id)}" title="この家具を外して設計し直す">✕</button></li>`).join("")}</ul>
      ${p.warn.map((w) => `<div class="iw-warn">⚠ ${esc(w)}</div>`).join("")}
      <details><summary>設計の理由・メモ</summary><ul class="iw-notes">${[...b.notes, ...p.notes].map((n) => `<li>${esc(n)}</li>`).join("")}</ul></details>`;
  }

  bind() {
    const st = this.state, q = (s) => this.el.querySelectorAll(s);
    q("[data-a]").forEach((b) => (b.onclick = () => this.action(b.dataset.a)));
    q("[data-x]").forEach((b) => (b.onclick = () => this.exportAs(b.dataset.x)));
    q("[data-ex]").forEach((b) => (b.onclick = () => { st.policy = POLICY_EXAMPLES[+b.dataset.ex]; this.el.querySelector(".iw-policy").value = st.policy; store.touch(); }));
    const pol = this.el.querySelector(".iw-policy");
    pol.oninput = () => { st.policy = pol.value; store.touch(); };
    const ai = this.el.querySelector("[data-ai]");
    if (ai) ai.onchange = () => { st.useAI = ai.checked; store.touch(); };
    q("[data-o]").forEach((s) => {
      const k = s.dataset.o;
      if (k === "size") s.onchange = () => { st.size = s.value; store.touch(); this.rebuildSheets(); };
      else { s.value = this.opt?.[k] || "auto"; s.onchange = () => { this.opt = { ...(this.opt || {}), [k]: s.value }; }; }
    });
    const room = st.room;
    if (room) {
      this.el.querySelector('[data-r="height"]').onchange = (e) => this.editRoom((r) => { r.height = Math.max(1500, +e.target.value || r.height); });
      q("[data-wall]").forEach((i) => (i.onchange = () => this.editRoom((r) => setWallLength(r, +i.dataset.wall, +i.value))));
      q("[data-op]").forEach((i) => (i.onchange = () => this.editRoom((r) => {
        const o = r.openings[+i.dataset.op], k = i.dataset.k;
        o[k] = k === "type" ? i.value : +i.value;
        if (k === "type" && i.value === "door") o.sill = 0;
      })));
      q("[data-del]").forEach((b) => (b.onclick = () => this.editRoom((r) => { r.openings.splice(+b.dataset.del, 1); })));
    }
    q("[data-rm]").forEach((b) => (b.onclick = () => {
      const it = this.plan.items.find((x) => x.id === b.dataset.rm);
      if (!it) return;
      // 方針から外して設計し直す
      this.removed = [...(this.removed || []), it.kind];
      this.design({ keepBrief: true });
    }));
    bindDxfEncoding(this.el, "iw-enc");
  }

  editRoom(fn) {
    const r = JSON.parse(JSON.stringify(this.state.room));
    try { fn(r); } catch (e) { this.app.toast(e.message, true); return; }
    store.commit((p) => { p.interior.room = r; }, { silent: true });
    if (this.plan) this.design({ quiet: true, keepBrief: true });
    else this.render();
  }

  async action(a) {
    const st = this.state;
    if (a === "scan") return this.pickScan();
    if (a === "sample") {
      this.app.busy(true, "見本スキャンを読み取り中…");
      await tick();
      try {
        const s = makeSampleScan();
        this.setScan(normalizePoints(s.pts, this.opt || {}), "見本の部屋（L 字・約 10 畳）");
      } finally { this.app.busy(false); }
      return;
    }
    if (a === "manual") {
      const v = prompt("部屋の 幅 × 奥行 × 天井高（mm）", "3640 x 2730 x 2400");
      if (!v) return;
      const n = v.split(/[^\d.]+/).filter(Boolean).map(Number);
      if (n.length < 2) return this.app.toast("例: 3640 x 2730 x 2400", true);
      this.points = null;
      store.commit((p) => { p.interior = { ...st, room: rectRoom(n[0], n[1], n[2] || 2400) }; }, { silent: true });
      this.plan = null;
      this.page = 0;
      this.render();
      this.app.toast("部屋を作りました。ドア・窓は「＋ ドア・窓を足す」で入れてください");
      return;
    }
    if (a === "addopen") return this.editRoom((r) => r.openings.push({ id: newId("O"), type: "window", wall: 0, pos: 300, width: 1200, height: 1100, sill: 900 }));
    if (a === "design") { this.removed = []; return this.design(); }
    if (a === "alt") { st.seed = (st.seed || 1) + 1; store.touch(); return this.design({ keepBrief: true }); }
  }

  pickScan() {
    const inp = document.createElement("input");
    inp.type = "file";
    inp.accept = ".obj,.ply,.glb,.gltf,.xyz,.pts,.txt,.csv";
    inp.onchange = async () => {
      const f = inp.files[0];
      if (!f) return;
      this.app.busy(true, `「${f.name}」を読み込み中…`);
      await tick();
      try {
        const n = await loadScanFile(f, this.opt || {});
        this.setScan(n, f.name.replace(/\.[^.]+$/, ""));
      } catch (e) { this.app.toast("読み込めませんでした: " + e.message, true); }
      finally { this.app.busy(false); }
    };
    inp.click();
  }

  setScan(n, name) {
    let room;
    try { room = extractRoom(n.pts, { name }); }
    catch (e) { this.app.toast(e.message, true); return; }
    this.points = decimate(toRoomFrame(n.pts, room.transform), 120000);
    this.pointsRoom = room;
    store.commit((p) => { p.interior = { ...this.state, room, seed: 1 }; if (!p.name || p.name === "無題") p.name = name; }, { silent: true });
    this.plan = null;
    this.page = 0;
    this.render();
    const W = wallsOf(room);
    this.app.toast(`部屋を読み取りました: 壁 ${W.length} 面・天井高 ${room.height}mm・ドア/窓 ${room.openings.length} か所（${n.upAxis.toUpperCase()} が上・×${n.scale}）`);
  }

  async design({ quiet = false, keepBrief = false } = {}) {
    const st = this.state;
    if (!st.room) return;
    let brief = keepBrief && this.brief ? this.brief : null;
    if (!brief) {
      brief = parsePolicy(st.policy, st.room);
      if (st.useAI && this.app.cmdline?.aiKey?.() && (st.policy || "").trim()) {
        this.app.busy(true, "AI が方針を読み取っています…");
        try { brief = await askBriefAI({ apiKey: this.app.cmdline.aiKey(), model: this.app.cmdline.aiModel(), policy: st.policy, room: st.room, fallback: brief }); }
        catch (e) { this.app.toast("AI を使えなかったので、ふつうの読み取りで設計します: " + e.message, true); }
        finally { this.app.busy(false); }
      }
    }
    brief = { ...brief, items: brief.items.filter((k) => !(this.removed || []).includes(k)) };
    this.brief = brief;
    this.plan = designPlan(st.room, brief, st.seed || 1);
    this.planRoom = st.room;
    this.rebuildSheets(false);
    if (!quiet && this.page === 0 && this.sheets.length) this.page = 1;
    this.render();
    if (!quiet) this.app.toast(`設計しました: ${this.plan.items.length} 点${this.plan.warn.length ? `（置けなかった物 ${this.plan.warn.length}）` : ""}`);
  }

  rebuildSheets(render = true) {
    if (!this.plan) return;
    this.sheets = buildSheets(this.state.room, this.plan, this.brief, { size: this.state.size || "A3", project: store.project.name && store.project.name !== "無題" ? store.project.name : this.state.room.name });
    if (this.page > this.sheets.length) this.page = 0;
    if (render) { this.renderPages(); this.renderView(); }
  }

  renderPages() {
    const el = this.el.querySelector(".dw-pages");
    const tabs = [["3D", 0], ...this.sheets.map((s, i) => [s.name, i + 1])];
    el.innerHTML = tabs.map(([n, i]) => `<button data-pg="${i}" class="${this.page === i ? "on" : ""}">${esc(n)}</button>`).join("");
    el.querySelectorAll("[data-pg]").forEach((b) => (b.onclick = () => { this.page = +b.dataset.pg; this.renderPages(); this.renderView(); }));
  }

  renderView() {
    const v = this.el.querySelector(".iw-view");
    if (this.page === 0) { v.className = "iw-view iw-3d"; v.innerHTML = this.state.room ? "" : `<div class="iw-empty"><b>内装の自動設計</b><br>① 部屋を 3D スキャンして読み込む（または寸法を入れる）<br>② 読み取った寸法を確かめる<br>③ 方針を書いて「設計する」<br>→ 平面図・展開図・部材表を PDF / DXF で書き出し、3D CAD でさらに作り込めます</div>`; if (this.state.room) this.start3D(v); return; }
    this.stop3D();
    const sh = this.sheets[this.page - 1];
    v.className = "iw-view dw-sheet";
    v.innerHTML = sheetToSVG(sh);
    const svg = v.querySelector("svg");
    const fit = () => { const box = this.el.querySelector(".iw-main"); const px = Math.max(320, Math.min(box.clientWidth - 30, (box.clientHeight - 60) * sh.w / sh.h)); svg.setAttribute("width", px); svg.setAttribute("height", (px * sh.h) / sh.w); };
    fit();
  }

  // ------------------------------------------------------------ 3D 表示（点群・部屋・家具）
  start3D(host) {
    this.stop3D();
    const room = this.state.room;
    const canvas = document.createElement("canvas");
    host.appendChild(canvas);
    const r = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
    r.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xeef1f5);
    const cam = new THREE.PerspectiveCamera(45, 1, 10, 100000);
    cam.up.set(0, 0, 1);
    scene.add(new THREE.HemisphereLight(0xffffff, 0x888888, 2.2));
    const dl = new THREE.DirectionalLight(0xffffff, 1.4); dl.position.set(3000, -4000, 6000); scene.add(dl);
    const g = new THREE.Group(); scene.add(g);
    // 床
    const shape = new THREE.Shape(room.poly.map(([x, y]) => new THREE.Vector2(x, y)));
    const floor = new THREE.Mesh(new THREE.ShapeGeometry(shape), new THREE.MeshStandardMaterial({ color: 0xd8cbb5, side: THREE.DoubleSide }));
    g.add(floor);
    // 壁（開口を抜く・半透明）
    const wallMat = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false });
    const edgeMat = new THREE.LineBasicMaterial({ color: 0x55606e });
    for (const w of wallsOf(room)) {
      const s2 = new THREE.Shape([new THREE.Vector2(0, 0), new THREE.Vector2(w.len, 0), new THREE.Vector2(w.len, room.height), new THREE.Vector2(0, room.height)]);
      for (const o of room.openings.filter((x) => x.wall === w.i)) {
        const z0 = o.type === "window" ? o.sill : 0;
        s2.holes.push(new THREE.Path([new THREE.Vector2(o.pos, z0), new THREE.Vector2(o.pos + o.width, z0), new THREE.Vector2(o.pos + o.width, z0 + o.height), new THREE.Vector2(o.pos, z0 + o.height)]));
      }
      const geo = new THREE.ShapeGeometry(s2);
      const m = new THREE.Matrix4().makeBasis(new THREE.Vector3(w.u[0], w.u[1], 0), new THREE.Vector3(0, 0, 1), new THREE.Vector3(w.n[0], w.n[1], 0)).setPosition(w.a[0], w.a[1], 0);
      geo.applyMatrix4(m);
      g.add(new THREE.Mesh(geo, wallMat));
      g.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo), edgeMat));
    }
    // 点群
    if (this.points) {
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", new THREE.BufferAttribute(this.points, 3));
      const col = new Float32Array(this.points.length);
      for (let i = 0; i < this.points.length; i += 3) { const t = Math.min(1, Math.max(0, this.points[i + 2] / room.height)); col[i] = 0.25 + 0.5 * t; col[i + 1] = 0.35 + 0.3 * t; col[i + 2] = 0.6 - 0.2 * t; }
      geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
      this.cloud = new THREE.Points(geo, new THREE.PointsMaterial({ size: 2.2, sizeAttenuation: false, vertexColors: true, transparent: true, opacity: 0.55 }));
      g.add(this.cloud);
    }
    // 家具
    if (this.plan) {
      for (const it of this.plan.items) {
        const color = new THREE.Color(it.color || "#999");
        if (it.builtin && it.wall != null) {
          for (const p of builtinParts(it, this.brief).parts) {
            const b = localToRoom(it, room, p.box);
            g.add(box(b, /扉|フラップ/.test(p.part) ? color.clone().offsetHSL(0, 0, 0.06) : /背板|受け桟|台輪/.test(p.part) ? new THREE.Color("#c8b89a") : color));
          }
        } else g.add(box([it.x0, it.y0, it.z0 || 0, it.x1, it.y1, (it.z0 || 0) + it.h], new THREE.Color(it.kind === "sofa" ? "#8b97a6" : it.kind === "bed" ? "#e5e1da" : "#a98a6a")));
      }
    }
    const bb = new THREE.Box3().setFromObject(floor);
    const c = bb.getCenter(new THREE.Vector3()); c.z = room.height * 0.35;
    const size = Math.max(bb.max.x - bb.min.x, bb.max.y - bb.min.y, room.height);
    cam.position.set(c.x - size * 0.9, c.y - size * 1.3, c.z + size * 1.3);
    const ctl = new OrbitControls(cam, canvas);
    ctl.target.copy(c);
    ctl.update();
    const onSize = () => { const w = host.clientWidth || 600, h = host.clientHeight || 400; r.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); };
    const ro = new ResizeObserver(onSize); ro.observe(host); onSize();
    let raf = 0;
    const loop = () => { raf = requestAnimationFrame(loop); r.render(scene, cam); };
    loop();
    this.three = { r, ro, stop: () => { cancelAnimationFrame(raf); ro.disconnect(); ctl.dispose(); r.dispose(); scene.traverse((o) => { o.geometry?.dispose?.(); }); } };
  }
  stop3D() { if (this.three) { this.three.stop(); this.three = null; } }

  // ------------------------------------------------------------ 書き出し
  async exportAs(kind) {
    if (!this.plan) return;
    const base = (store.project.name && store.project.name !== "無題" ? store.project.name : this.state.room.name || "内装").replace(/[\\/:*?"<>|]/g, "_");
    try {
      if (kind === "pdf") {
        this.app.busy(true, "PDF を作っています…");
        download(await sheetsToPDF(this.sheets), `${base}_内装図面.pdf`, "application/pdf");
      } else if (kind === "dxf") {
        for (let i = 0; i < this.sheets.length; i++) {
          download(encodeDXF(sheetToDXF(this.sheets[i])), `${base}_${String(i + 1).padStart(2, "0")}_${this.sheets[i].name}.dxf`, "application/dxf");
          await new Promise((r) => setTimeout(r, 250));
        }
      } else if (kind === "svg") {
        const sh = this.sheets[Math.max(0, this.page - 1)];
        download(sheetToSVG(sh), `${base}_${sh.name}.svg`, "image/svg+xml");
      } else if (kind === "csv") {
        download(cutCSV(this.plan, this.brief), `${base}_部材表.csv`, "text/csv");
      } else if (kind === "cad") return this.sendToCAD();
      this.app.toast("書き出しました");
    } catch (e) { this.app.toast("書き出せませんでした: " + e.message, true); }
    finally { this.app.busy(false); }
  }

  // 3D CAD に送る: 部屋（床・壁）と、家具（造作は板 1 枚ずつ）を直方体の部品として入れる
  sendToCAD() {
    const room = this.state.room, plan = this.plan, brief = this.brief;
    const f = (n) => String(Math.round(n * 10) / 10);
    const feats = [], comps = [];
    const comp = (name, parent = null) => { const id = newId("C"); comps.push({ id, name, parent }); return id; };
    const top = comp(`内装: ${room.name}`);
    const roomC = comp("部屋（スキャン）", top);
    const addBox = (name, b, color, component) => feats.push({ id: newId("F"), type: "box", name, position: [f(b[0]), f(b[1]), f(b[2])], w: f(b[3] - b[0]), d: f(b[4] - b[1]), h: f(b[5] - b[2]), operation: "new", bodyName: name, color, component });
    // 床（厚み 20）と壁（厚み 100・開口を抜いて分割）
    const bbx = room.poly.reduce((a, [x, y]) => [Math.min(a[0], x), Math.min(a[1], y), Math.max(a[2], x), Math.max(a[3], y)], [Infinity, Infinity, -Infinity, -Infinity]);
    if (room.poly.length === 4) addBox("床", [bbx[0], bbx[1], -20, bbx[2], bbx[3], 0], "#d8cbb5", roomC);
    else {
      // 直交多角形の床を長方形に分けて入れる（y の区切りごと）
      const ys = [...new Set(room.poly.map((p) => p[1]))].sort((a, b) => a - b);
      for (let k = 0; k + 1 < ys.length; k++) {
        const ym = (ys[k] + ys[k + 1]) / 2;
        const xs = [];
        for (let i = 0; i < room.poly.length; i++) { const a = room.poly[i], b = room.poly[(i + 1) % room.poly.length]; if ((a[1] - ym) * (b[1] - ym) < 0) xs.push(a[0]); }
        xs.sort((a, b) => a - b);
        for (let j = 0; j + 1 < xs.length; j += 2) addBox(`床${k + 1}`, [xs[j], ys[k], -20, xs[j + 1], ys[k + 1], 0], "#d8cbb5", roomC);
      }
    }
    const WT = 100;
    for (const w of wallsOf(room)) {
      const wallBox = (t0, t1, z0, z1) => {
        const p = (t, d) => [w.a[0] + w.u[0] * t - w.n[0] * d, w.a[1] + w.u[1] * t - w.n[1] * d];
        const A = p(t0, 0), B = p(t1, WT);
        return [Math.min(A[0], B[0]), Math.min(A[1], B[1]), z0, Math.max(A[0], B[0]), Math.max(A[1], B[1]), z1];
      };
      const os = room.openings.filter((o) => o.wall === w.i).sort((a, b) => a.pos - b.pos);
      let t = 0, k = 1;
      const nm = () => `壁${w.name}-${k++}`;
      for (const o of os) {
        const z0 = o.type === "window" ? o.sill : 0, z1 = z0 + o.height;
        if (o.pos > t) addBox(nm(), wallBox(t, o.pos, 0, room.height), "#eeeeee", roomC);
        if (z0 > 0) addBox(nm(), wallBox(o.pos, o.pos + o.width, 0, z0), "#eeeeee", roomC);
        if (z1 < room.height) addBox(nm(), wallBox(o.pos, o.pos + o.width, z1, room.height), "#eeeeee", roomC);
        t = o.pos + o.width;
      }
      if (t < w.len) addBox(nm(), wallBox(t, w.len, 0, room.height), "#eeeeee", roomC);
    }
    // 家具
    for (const it of plan.items) {
      if (it.builtin && it.wall != null) {
        const c = comp(`${it.mark} ${it.name}`, top);
        const cnt = {};
        for (const p of builtinParts(it, brief).parts) {
          cnt[p.part] = (cnt[p.part] || 0) + 1;
          addBox(`${it.name}_${p.part}${cnt[p.part] > 1 ? cnt[p.part] : ""}`, localToRoom(it, room, p.box), /背板/.test(p.part) ? "#c8b89a" : it.color, c);
        }
      } else {
        const c = comp(`${it.mark} ${it.name}（参考）`, top);
        addBox(it.name, [it.x0, it.y0, it.z0 || 0, it.x1, it.y1, (it.z0 || 0) + it.h], "#9aa3ad", c);
      }
    }
    store.commit((p) => {
      p.components = [...(p.components || []), ...comps];
      p.features = [...p.features, ...feats];
      p.activeComponent = null;
    });
    this.app.setWorkspace("design");
    setTimeout(() => this.app.viewer?.fit?.(), 800);
    this.app.toast(`3D CAD に ${feats.length} 個の部品を入れました（造作は板 1 枚ずつ）。「図面」で部品図、ファイルの書き出しでパネル加工データが作れます`);
  }
}

// ---------------------------------------------------------------- 部屋の編集: 壁 i の長さを変える
// 壁 i の終点から、次に出てくる「逆向きの壁」の始点までを、壁 i の向きにずらす（反対側の壁が同じだけ伸び縮みする）
export function setWallLength(room, i, len) {
  const W = wallsOf(room), N = W.length;
  if (!(len > 100)) throw new Error("壁の長さが正しくありません");
  const d = len - W[i].len;
  if (Math.abs(d) < 0.5) return;
  let m = -1;
  for (let k = 1; k < N; k++) { const j = (i + k) % N; if (W[j].u[0] * W[i].u[0] + W[j].u[1] * W[i].u[1] < -0.99) { m = j; break; } }
  if (m < 0) throw new Error("この壁の長さは変えられません");
  for (let k = (i + 1) % N; ; k = (k + 1) % N) {
    room.poly[k] = [rnd(room.poly[k][0] + W[i].u[0] * d), rnd(room.poly[k][1] + W[i].u[1] * d)];
    if (k === m) break;
  }
  // 壁 m の開口の位置は、壁の始点が動いたので合わせる（壁の終点からの距離を保つ）
  for (const o of room.openings) if (o.wall === m) o.pos = rnd(o.pos + d);
  const W2 = wallsOf(room);
  if (W2.some((w) => w.len < 100)) throw new Error("壁が短くなりすぎます");
  for (const o of room.openings) if (o.pos + o.width > W2[o.wall].len) o.pos = Math.max(0, rnd(W2[o.wall].len - o.width));
}

function box(b, color) {
  const geo = new THREE.BoxGeometry(b[3] - b[0], b[4] - b[1], b[5] - b[2]);
  geo.translate((b[0] + b[3]) / 2, (b[1] + b[4]) / 2, (b[2] + b[5]) / 2);
  const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color, roughness: 0.8 }));
  const e = new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({ color: 0x4a3a2a, transparent: true, opacity: 0.35 }));
  m.add(e);
  return m;
}
function decimate(pts, max) {
  const n = pts.length / 3;
  if (n <= max) return pts;
  const step = n / max, out = new Float32Array(max * 3);
  for (let i = 0; i < max; i++) { const j = Math.floor(i * step) * 3; out[3 * i] = pts[j]; out[3 * i + 1] = pts[j + 1]; out[3 * i + 2] = pts[j + 2]; }
  return out;
}
const tick = () => new Promise((r) => setTimeout(r, 30));
export { KINDS };
