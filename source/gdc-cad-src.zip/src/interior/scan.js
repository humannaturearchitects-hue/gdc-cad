// 内装: 3D スキャン（点群・メッシュ）の読み込み
//  対応: OBJ / PLY（ASCII・バイナリ）/ GLB・glTF / XYZ・PTS・CSV（点群テキスト）
//  iPhone の LiDAR スキャンアプリ（Polycam・Scaniverse・3D Scanner App など）の書き出しをそのまま読めるようにする。
//  出力: { pts: Float32Array (x,y,z,...) } — 単位 mm・Z 上向き（GDC CAD と同じ座標系）

import * as THREE from "three";

// ---------------------------------------------------------------- テキスト形式
export function parseOBJ(text) {
  const v = [], tri = [];
  const lines = text.split(/\r?\n/);
  for (const ln of lines) {
    if (ln.charCodeAt(0) === 118 && ln.charCodeAt(1) === 32) { // "v "
      const p = ln.trim().split(/\s+/);
      v.push(+p[1], +p[2], +p[3]);
    } else if (ln.charCodeAt(0) === 102 && ln.charCodeAt(1) === 32) { // "f "
      const p = ln.trim().split(/\s+/).slice(1).map((s) => {
        const i = parseInt(s, 10);
        return i < 0 ? v.length / 3 + i : i - 1;
      });
      for (let k = 1; k + 1 < p.length; k++) tri.push(p[0], p[k], p[k + 1]);
    }
  }
  return { verts: Float32Array.from(v), tris: tri.length ? Uint32Array.from(tri) : null };
}

// x y z [...] の並んだ点群テキスト（XYZ・PTS・CSV）
export function parseXYZ(text) {
  const v = [];
  for (const ln of text.split(/\r?\n/)) {
    const p = ln.trim().split(/[\s,;]+/);
    if (p.length < 3) continue;
    const x = +p[0], y = +p[1], z = +p[2];
    if (Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(z)) v.push(x, y, z);
  }
  return { verts: Float32Array.from(v), tris: null };
}

// ---------------------------------------------------------------- PLY
const PLY_TYPES = {
  char: [1, "getInt8"], int8: [1, "getInt8"], uchar: [1, "getUint8"], uint8: [1, "getUint8"],
  short: [2, "getInt16"], int16: [2, "getInt16"], ushort: [2, "getUint16"], uint16: [2, "getUint16"],
  int: [4, "getInt32"], int32: [4, "getInt32"], uint: [4, "getUint32"], uint32: [4, "getUint32"],
  float: [4, "getFloat32"], float32: [4, "getFloat32"], double: [8, "getFloat64"], float64: [8, "getFloat64"],
};

export function parsePLY(buf) {
  const bytes = new Uint8Array(buf);
  // ヘッダ
  let end = -1;
  const head = new TextDecoder("latin1").decode(bytes.subarray(0, Math.min(bytes.length, 65536)));
  const m = head.match(/end_header\r?\n/);
  if (!m) throw new Error("PLY のヘッダが読めません");
  end = m.index + m[0].length;
  const hl = head.slice(0, m.index).split(/\r?\n/);
  let format = "ascii";
  const elements = [];
  for (const l of hl) {
    const p = l.trim().split(/\s+/);
    if (p[0] === "format") format = p[1];
    else if (p[0] === "element") elements.push({ name: p[1], count: +p[2], props: [] });
    else if (p[0] === "property" && elements.length) {
      const el = elements[elements.length - 1];
      if (p[1] === "list") el.props.push({ list: true, ct: p[2], it: p[3], name: p[4] });
      else el.props.push({ type: p[1], name: p[2] });
    }
  }
  const verts = [], tris = [];
  if (format === "ascii") {
    const body = new TextDecoder().decode(bytes.subarray(end)).split(/\s+/).filter(Boolean);
    let i = 0;
    for (const el of elements) {
      for (let n = 0; n < el.count; n++) {
        const rec = {};
        for (const pr of el.props) {
          if (pr.list) { const c = +body[i++]; rec[pr.name] = body.slice(i, i + c).map(Number); i += c; }
          else rec[pr.name] = +body[i++];
        }
        take(el, rec, verts, tris);
      }
    }
  } else {
    const le = format === "binary_little_endian";
    const dv = new DataView(buf, 0);
    let o = end;
    const rd = (t) => { const [sz, fn] = PLY_TYPES[t]; const v = dv[fn](o, le); o += sz; return v; };
    for (const el of elements) {
      // 頂点のよくある形（float x,y,z ＋ 色など固定長）は速い道で読む
      const fixed = el.props.every((p) => !p.list);
      if (fixed && el.name === "vertex") {
        let stride = 0; const off = {};
        for (const p of el.props) { off[p.name] = [stride, PLY_TYPES[p.type]]; stride += PLY_TYPES[p.type][0]; }
        for (let n = 0; n < el.count; n++) {
          const b = o + n * stride;
          verts.push(dv[off.x[1][1]](b + off.x[0], le), dv[off.y[1][1]](b + off.y[0], le), dv[off.z[1][1]](b + off.z[0], le));
        }
        o += stride * el.count;
        continue;
      }
      for (let n = 0; n < el.count; n++) {
        const rec = {};
        for (const pr of el.props) {
          if (pr.list) { const c = rd(pr.ct); const a = new Array(c); for (let k = 0; k < c; k++) a[k] = rd(pr.it); rec[pr.name] = a; }
          else rec[pr.name] = rd(pr.type);
        }
        take(el, rec, verts, tris);
      }
    }
  }
  return { verts: Float32Array.from(verts), tris: tris.length ? Uint32Array.from(tris) : null };
}
function take(el, rec, verts, tris) {
  if (el.name === "vertex") verts.push(rec.x, rec.y, rec.z);
  else if (el.name === "face") {
    const f = rec.vertex_indices || rec.vertex_index;
    if (f) for (let k = 1; k + 1 < f.length; k++) tris.push(f[0], f[k], f[k + 1]);
  }
}

// ---------------------------------------------------------------- GLB / glTF（three.js の読み込み機能を使う・ブラウザのみ）
export async function parseGLTF(buf) {
  const { GLTFLoader } = await import("three/examples/jsm/loaders/GLTFLoader.js");
  const gltf = await new Promise((res, rej) => new GLTFLoader().parse(buf, "", res, rej));
  const verts = [], tris = [];
  gltf.scene.updateMatrixWorld(true);
  const v = new THREE.Vector3();
  gltf.scene.traverse((o) => {
    if (!o.isMesh && !o.isPoints) return;
    const g = o.geometry, pos = g.attributes.position;
    if (!pos) return;
    const base = verts.length / 3;
    for (let i = 0; i < pos.count; i++) { v.fromBufferAttribute(pos, i).applyMatrix4(o.matrixWorld); verts.push(v.x, v.y, v.z); }
    if (o.isMesh) {
      if (g.index) for (let i = 0; i < g.index.count; i++) tris.push(base + g.index.getX(i));
      else for (let i = 0; i < pos.count; i++) tris.push(base + i);
    }
  });
  return { verts: Float32Array.from(verts), tris: tris.length ? Uint32Array.from(tris) : null };
}

// ---------------------------------------------------------------- メッシュ → 点（面積に比例して表面から点を拾う）
export function meshToPoints({ verts, tris }, maxPts = 250000, rand = Math.random) {
  if (!tris || !tris.length) return subsample(verts, maxPts, rand);
  const nt = tris.length / 3;
  const area = new Float64Array(nt);
  let total = 0;
  for (let t = 0; t < nt; t++) {
    const a = tris[3 * t] * 3, b = tris[3 * t + 1] * 3, c = tris[3 * t + 2] * 3;
    const ux = verts[b] - verts[a], uy = verts[b + 1] - verts[a + 1], uz = verts[b + 2] - verts[a + 2];
    const vx = verts[c] - verts[a], vy = verts[c + 1] - verts[a + 1], vz = verts[c + 2] - verts[a + 2];
    const cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx;
    total += area[t] = Math.sqrt(cx * cx + cy * cy + cz * cz) / 2;
  }
  if (!(total > 0)) return subsample(verts, maxPts, rand);
  const out = new Float32Array(maxPts * 3);
  let n = 0;
  const per = maxPts / total;
  let carry = 0;
  for (let t = 0; t < nt && n < maxPts; t++) {
    carry += area[t] * per;
    const k = Math.floor(carry);
    carry -= k;
    const a = tris[3 * t] * 3, b = tris[3 * t + 1] * 3, c = tris[3 * t + 2] * 3;
    for (let j = 0; j < k && n < maxPts; j++) {
      let r1 = rand(), r2 = rand();
      if (r1 + r2 > 1) { r1 = 1 - r1; r2 = 1 - r2; }
      for (let d = 0; d < 3; d++) out[3 * n + d] = verts[a + d] + r1 * (verts[b + d] - verts[a + d]) + r2 * (verts[c + d] - verts[a + d]);
      n++;
    }
  }
  return out.subarray(0, n * 3);
}

function subsample(verts, maxPts, rand) {
  const n = verts.length / 3;
  if (n <= maxPts) return verts;
  const out = new Float32Array(maxPts * 3);
  for (let i = 0; i < maxPts; i++) {
    const j = Math.floor(rand() * n) * 3;
    out[3 * i] = verts[j]; out[3 * i + 1] = verts[j + 1]; out[3 * i + 2] = verts[j + 2];
  }
  return out;
}

// ---------------------------------------------------------------- 単位と上方向をそろえる
// up: "auto" | "y" | "z" / unit: "auto" | "m" | "cm" | "mm"
// 返す点は mm・Z 上向き
export function normalizePoints(pts, { up = "auto", unit = "auto" } = {}) {
  const n = pts.length / 3;
  const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < n; i++) for (let d = 0; d < 3; d++) { const v = pts[3 * i + d]; if (v < lo[d]) lo[d] = v; if (v > hi[d]) hi[d] = v; }
  const ext = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
  let k = 1;
  if (unit === "m") k = 1000; else if (unit === "cm") k = 10; else if (unit === "mm") k = 1;
  else k = ext < 60 ? 1000 : ext < 6000 ? 10 : 1; // 部屋は 1〜60m: m なら <60、cm なら <6000
  // 上方向: 床と天井（大きな水平面）がはっきり 2 つの山になる軸を選ぶ
  let upAxis = up === "y" ? 1 : up === "z" ? 2 : up === "x" ? 0 : planeAxis(pts, lo, hi);
  const out = new Float32Array(pts.length);
  for (let i = 0; i < n; i++) {
    const x = pts[3 * i] * k, y = pts[3 * i + 1] * k, z = pts[3 * i + 2] * k;
    // 右手系を保ったまま、upAxis を Z に回す
    if (upAxis === 2) { out[3 * i] = x; out[3 * i + 1] = y; out[3 * i + 2] = z; }
    else if (upAxis === 1) { out[3 * i] = x; out[3 * i + 1] = -z; out[3 * i + 2] = y; } // Y-up（glTF・iPhone） → Z-up
    else { out[3 * i] = y; out[3 * i + 1] = z; out[3 * i + 2] = x; }
  }
  return { pts: out, scale: k, upAxis: "xyz"[upAxis] };
}

function planeAxis(pts, lo, hi) {
  const n = pts.length / 3;
  const step = Math.max(1, Math.floor(n / 60000));
  let best = 1, bestScore = -1;
  for (let d = 0; d < 3; d++) {
    const span = hi[d] - lo[d];
    if (!(span > 0)) continue;
    const B = 100, h = new Uint32Array(B);
    let m = 0;
    for (let i = 0; i < n; i += step) { h[Math.min(B - 1, Math.floor(((pts[3 * i + d] - lo[d]) / span) * B))]++; m++; }
    // 下 1/3 と上 1/3 にそれぞれ鋭い山（床・天井）があるほど高得点
    const peak = (a, b) => { let x = 0; for (let j = a; j < b; j++) x = Math.max(x, h[j]); return x; };
    const score = Math.min(peak(0, 34), peak(66, 100)) / m;
    if (score > bestScore) { bestScore = score; best = d; }
  }
  return best;
}

// ファイル 1 つを読んで、mm・Z 上の点にする
export async function loadScanFile(file, opts = {}) {
  const name = (file.name || "").toLowerCase();
  const buf = await file.arrayBuffer();
  let mesh;
  if (name.endsWith(".obj")) mesh = parseOBJ(new TextDecoder().decode(buf));
  else if (name.endsWith(".ply")) mesh = parsePLY(buf);
  else if (name.endsWith(".glb") || name.endsWith(".gltf")) mesh = await parseGLTF(buf);
  else if (/\.(xyz|pts|txt|csv)$/.test(name)) mesh = parseXYZ(new TextDecoder().decode(buf));
  else throw new Error("対応していない形式です（OBJ・PLY・GLB・glTF・XYZ）。USDZ は Polycam などで OBJ / GLB に書き出してください");
  if (!mesh.verts.length) throw new Error("点が 1 つも見つかりませんでした");
  const raw = meshToPoints(mesh, opts.maxPts || 250000);
  return normalizePoints(raw, opts);
}
