// 内装: 間取り（複数の部屋）
//   layout = { name, source: "trace"|"ai-plan"|"ai-photo", rooms: [room（origin 付き）], notes: [] }
//   room.origin = [x, y]: 間取り全体の座標で、その部屋の原点（左下）がどこにあるか（mm）
// 部屋 1 つ 1 つは、スキャンの部屋と同じ形（room.js）なので、そのまま内装設計に使える。
import { simplifyRect, edgesToPoly, startAtBottomLeft, polyArea, wallsOf, bbox2, rnd } from "./room.js";

export const ROOM_USE_WORDS = [
  [/LDK|リビング.?ダイニング/i, "ldk"], [/リビング|居間|LD/i, "living"], [/寝室|主寝室|ベッド/, "bedroom"],
  [/書斎|ワーク|納戸|サービスルーム|S\b/, "study"], [/子供|子ども|キッズ/, "kids"], [/ダイニング|DK|食堂/, "dining"],
  [/和室|畳/, "japanese"], [/店舗|ショップ|売場/, "shop"], [/事務所|オフィス/, "office"],
];
export function useOfRoomName(name) { for (const [re, u] of ROOM_USE_WORDS) if (re.test(name || "")) return u; return null; }

// ---------------------------------------------------------------- なぞった点 → 直角の多角形
// pts: [[x,y],...]（どの単位でもよい・y 上向き）。辺ごとに縦か横かを決めて、直角の部屋にする
export function traceToPoly(pts, minEdge = 0) {
  if (pts.length < 3) throw new Error("角を 3 つ以上タップしてください");
  const N = pts.length;
  let E = [];
  for (let i = 0; i < N; i++) {
    const a = pts[i], b = pts[(i + 1) % N];
    const dx = b[0] - a[0], dy = b[1] - a[1];
    if (Math.hypot(dx, dy) < 1e-9) continue;
    if (Math.abs(dx) >= Math.abs(dy)) E.push({ o: "H", c: (a[1] + b[1]) / 2, w: Math.abs(dx) });
    else E.push({ o: "V", c: (a[0] + b[0]) / 2, w: Math.abs(dy) });
  }
  // 同じ向きが続いたら 1 本にまとめる（長さで重み付け）
  let changed = true;
  while (changed && E.length > 1) {
    changed = false;
    for (let i = 0; i < E.length; i++) {
      const j = (i + 1) % E.length;
      if (i !== j && E[i].o === E[j].o) {
        const w = E[i].w + E[j].w;
        E[i] = { o: E[i].o, c: (E[i].c * E[i].w + E[j].c * E[j].w) / (w || 1), w };
        E.splice(j, 1);
        changed = true;
        break;
      }
    }
  }
  if (E.length < 4 || E.length % 2) throw new Error("部屋の形になりませんでした（角を順番にタップしてください）");
  if (minEdge > 0) E = simplifyRect(E, minEdge);
  let poly = edgesToPoly(E);
  if (polyArea(poly) < 0) poly.reverse();
  return poly;
}

// 絶対座標の多角形 → 部屋（原点を左下に・最初の壁が下）
export function roomFromPoly(abs, { name = "部屋", height = 2400, source = "trace", use = null } = {}) {
  let poly = abs.map((p) => [p[0], p[1]]);
  if (polyArea(poly) < 0) poly.reverse();
  const bb = bbox2(poly);
  poly = startAtBottomLeft(poly.map(([x, y]) => [rnd(x - bb.x0, 5), rnd(y - bb.y0, 5)]));
  // 同じ点・一直線の点を除く
  poly = cleanPoly(poly);
  return { name, height: rnd(height, 5), poly, openings: [], transform: null, source, origin: [rnd(bb.x0, 5), rnd(bb.y0, 5)], use: use || useOfRoomName(name) };
}

function cleanPoly(P) {
  let changed = true;
  while (changed && P.length > 3) {
    changed = false;
    for (let i = 0; i < P.length; i++) {
      const a = P[(i - 1 + P.length) % P.length], b = P[i], c = P[(i + 1) % P.length];
      const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
      if (Math.hypot(b[0] - a[0], b[1] - a[1]) < 1 || Math.abs(cross) < 1) { P.splice(i, 1); changed = true; break; }
    }
  }
  return P;
}

// 開口（間取り全体の座標の線分 a→b）を、いちばん近い壁に付ける
export function attachOpening(room, seg) {
  const ox = room.origin?.[0] || 0, oy = room.origin?.[1] || 0;
  const a = [seg.a[0] - ox, seg.a[1] - oy], b = [seg.b[0] - ox, seg.b[1] - oy];
  let best = null;
  for (const w of wallsOf(room)) {
    const ta = (a[0] - w.a[0]) * w.u[0] + (a[1] - w.a[1]) * w.u[1], tb = (b[0] - w.a[0]) * w.u[0] + (b[1] - w.a[1]) * w.u[1];
    const da = Math.abs((a[0] - w.a[0]) * w.n[0] + (a[1] - w.a[1]) * w.n[1]), db = Math.abs((b[0] - w.a[0]) * w.n[0] + (b[1] - w.a[1]) * w.n[1]);
    const t0 = Math.max(0, Math.min(ta, tb)), t1 = Math.min(w.len, Math.max(ta, tb));
    if (t1 - t0 < 200) continue;
    const d = Math.max(da, db);
    if (d > 400) continue;
    if (!best || d < best.d) best = { d, w, t0, t1 };
  }
  if (!best) return null;
  const type = seg.type === "window" ? "window" : seg.type === "opening" ? "opening" : "door";
  const o = {
    id: "O" + (room.openings.length + 1), type, wall: best.w.i,
    pos: rnd(best.t0, 5), width: rnd(best.t1 - best.t0, 5),
    height: rnd(seg.height || (type === "window" ? 1100 : 2000), 5),
    sill: type === "window" ? rnd(seg.sill ?? 900, 5) : 0,
  };
  room.openings.push(o);
  return o;
}

// ---------------------------------------------------------------- AI の読み取り結果（JSON）→ 間取り
// json: { rooms: [{ name, poly: [[x,y],...] (mm・y 上向き), height? }], openings: [{ type, a:[x,y], b:[x,y], height?, sill? }], notes: [] }
export function layoutFromJSON(json, { source = "ai-plan", name = "間取り", height = 2400 } = {}) {
  const rooms = [];
  for (const r of json.rooms || []) {
    if (!Array.isArray(r.poly) || r.poly.length < 3) continue;
    let poly;
    try { poly = traceToPoly(r.poly.map((p) => [+p[0], +p[1]]), 150); } catch { continue; }
    const room = roomFromPoly(poly, { name: r.name || `部屋${rooms.length + 1}`, height: r.height > 1500 ? r.height : height, source });
    if (Math.abs(polyArea(room.poly)) < 1e6) continue; // 1㎡ 未満（収納の点など）は除く
    rooms.push(room);
  }
  for (const o of json.openings || []) {
    if (!o || !Array.isArray(o.a) || !Array.isArray(o.b)) continue;
    // 開口に面している部屋すべてに付ける（部屋どうしのドアは両方の部屋に）
    for (const room of rooms) attachOpening(room, o);
  }
  return { name, source, rooms, notes: json.notes || [] };
}

export function layoutBBox(layout) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const r of layout.rooms) for (const [x, y] of r.poly) { const X = x + r.origin[0], Y = y + r.origin[1]; x0 = Math.min(x0, X); y0 = Math.min(y0, Y); x1 = Math.max(x1, X); y1 = Math.max(y1, Y); }
  return { x0, y0, x1, y1, w: x1 - x0, h: y1 - y0 };
}
export const tatami = (room) => Math.abs(polyArea(room.poly)) / 1e6 / 1.62;
