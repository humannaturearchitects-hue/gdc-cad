// 内装: 設計方針（ふだんの言葉）→ 設計条件（brief）
// 例: 「在宅ワークできる書斎。本が多いので壁一面の本棚。ナチュラルな木の感じで」
//
// brief = { use, style, storage(0-2), items:[種類], exclude:[種類], people, thickness, notes:[読み取った内容], raw }

export const USES = {
  living: "リビング", ldk: "LDK", bedroom: "寝室", study: "書斎・ワークスペース", kids: "子ども部屋",
  dining: "ダイニング", shop: "店舗", office: "オフィス", japanese: "和室",
};

export const STYLES = {
  natural: { name: "ナチュラル", wood: "オーク突板", body: "#cfae84", accent: "#f2efe8", note: "明るい木目と白で、やわらかく" },
  modern: { name: "モダン", wood: "ウォルナット突板", body: "#5d4535", accent: "#3a3d42", note: "濃い木目とグレーで、引き締まった印象に" },
  nordic: { name: "北欧", wood: "バーチ合板", body: "#e2c99f", accent: "#ffffff", note: "白とバーチで、明るく素朴に" },
  japanese: { name: "和モダン", wood: "杉・タモ突板", body: "#c9a46f", accent: "#e9e1cf", note: "木と和紙色で、落ち着いた和の空間に" },
  industrial: { name: "インダストリアル", wood: "ラワン合板＋黒皮鉄", body: "#a9805a", accent: "#2f2f2f", note: "素材感のある合板と黒い金物で" },
  hotel: { name: "ホテルライク", wood: "ダークウォルナット突板", body: "#4a3426", accent: "#d9d2c5", note: "濃色の木と間接照明で上質に" },
  white: { name: "シンプル白", wood: "白ポリ合板", body: "#eeeeea", accent: "#cfcfcf", note: "白で統一して、広く見せる" },
};

// 家具・造作の種類（寸法は mm・標準値）
//  wall: 壁に付ける / free: 部屋の中に置く, builtin: 造作（大工・家具屋で作る＝部材表を出す）
export const KINDS = {
  storage: { name: "壁面収納", wall: true, builtin: true, d: 450, h: "ceil", w: [900, 4500], mod: 450, clear: 900, tall: true },
  closet: { name: "クローゼット", wall: true, builtin: true, d: 600, h: "ceil", w: [900, 2700], mod: 450, clear: 800, tall: true },
  bookshelf: { name: "本棚", wall: true, builtin: true, d: 300, h: "ceil", w: [600, 4500], mod: 450, clear: 750, tall: true },
  tvboard: { name: "テレビボード", wall: true, builtin: true, d: 450, h: 400, w: [1500, 2700], mod: 450, clear: 0, tall: false },
  desk: { name: "デスクカウンター", wall: true, builtin: true, d: 600, h: 720, w: [1000, 2700], mod: 50, clear: 800, tall: false },
  bench: { name: "窓辺ベンチ収納", wall: true, builtin: true, d: 400, h: 420, w: [900, 2700], mod: 450, clear: 600, tall: false },
  cupboard: { name: "カップボード", wall: true, builtin: true, d: 450, h: 2100, w: [900, 2700], mod: 450, clear: 900, tall: true },
  display: { name: "陳列棚", wall: true, builtin: true, d: 400, h: 1800, w: [900, 4500], mod: 900, clear: 1000, tall: true },
  bed: { name: "ベッド", wall: true, builtin: false, d: 2050, h: 400, w: [1200, 1200], clear: 600, head: true },
  sofa_wall: { name: "ソファ", wall: true, builtin: false, d: 850, h: 800, w: [1800, 1800], clear: 450 },
  sofa: { name: "ソファ", wall: false, builtin: false, d: 850, h: 800, w: [1800, 1800], clear: 450 },
  lowtable: { name: "ローテーブル", wall: false, builtin: false, d: 500, h: 350, w: [1000, 1000], clear: 400 },
  dining: { name: "ダイニングテーブル", wall: false, builtin: false, d: 800, h: 720, w: [1400, 1400], clear: 650 },
  counter: { name: "レジカウンター", wall: false, builtin: true, d: 600, h: 1000, w: [1500, 1500], clear: 900 },
  officedesk: { name: "事務机", wall: true, builtin: false, d: 700, h: 720, w: [1200, 1200], clear: 900 },
};

// 用途ごとの基本の構成（方針で足したり消したりする）
const BASE = {
  living: ["tvboard", "sofa", "lowtable", "storage"],
  ldk: ["tvboard", "sofa", "dining", "cupboard", "storage"],
  bedroom: ["bed", "closet"],
  study: ["desk", "bookshelf", "storage"],
  kids: ["bed", "desk", "closet", "bookshelf"],
  dining: ["dining", "cupboard"],
  shop: ["display", "display", "counter"],
  office: ["officedesk", "officedesk", "storage"],
  japanese: ["closet", "bench"],
};

const WORDS = {
  use: [
    [/LDK|リビングダイニング/i, "ldk"], [/リビング|居間/, "living"], [/寝室|ベッドルーム|寝る/, "bedroom"],
    [/書斎|ワークスペース|在宅|テレワーク|リモート|仕事部屋|勉強部屋/, "study"], [/子ども部屋|子供部屋|キッズ/, "kids"],
    [/ダイニング|食堂/, "dining"], [/店舗|ショップ|お店|物販|カフェ|サロン/, "shop"], [/オフィス|事務所/, "office"], [/和室|畳/, "japanese"],
  ],
  style: [
    [/ナチュラル|木の感じ|木目|明るい木/, "natural"], [/モダン|シック|かっこいい|スタイリッシュ/, "modern"], [/北欧|スカンジ/, "nordic"],
    [/和モダン|和風|和の/, "japanese"], [/インダストリアル|ヴィンテージ|ブルックリン|男前/, "industrial"],
    [/ホテル|高級|ラグジュアリー|上質/, "hotel"], [/白|ホワイト|シンプル|ミニマル/, "white"],
  ],
  items: [
    [/壁面収納|壁一面の?収納|天井まで(の)?収納|収納家具/, "storage"], [/クローゼット|洋服|衣類|ワードローブ/, "closet"],
    [/本棚|書棚|本が(多|たくさん)|蔵書|ブックシェルフ/, "bookshelf"], [/テレビ|TV|ＴＶ/i, "tvboard"],
    [/デスク|机|(?<!レジ)カウンター|在宅|テレワーク|パソコン|PC|勉強/i, "desk"], [/ベンチ|腰掛け|窓辺/, "bench"],
    [/カップボード|食器棚/, "cupboard"], [/陳列|ディスプレイ|商品棚/, "display"], [/ベッド|寝/, "bed"],
    [/ソファ/, "sofa"], [/ローテーブル|センターテーブル/, "lowtable"], [/ダイニングテーブル|食卓/, "dining"], [/レジ/, "counter"],
  ],
};
const NEG = /(いらない|不要|なし|無し|要らない|置かない|やめ|入れない)/;

export function parsePolicy(text, room = null) {
  const raw = String(text || "").trim();
  const t = raw.replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
  const notes = [];
  const find = (list) => { for (const [re, v] of list) if (re.test(t)) return v; return null; };
  const use = find(WORDS.use) || guessUse(room);
  const style = find(WORDS.style) || "natural";
  notes.push(`用途: ${USES[use]}`, `テイスト: ${STYLES[style].name}（${STYLES[style].wood}）`);
  // 収納の量
  let storage = 1;
  if (/収納(を|は)?(多め|たっぷり|たくさん|多く|最大|大容量)|物が多い|荷物が多い|しまう場所/.test(t)) storage = 2;
  if (/収納(は)?(少なめ|最小|いらない|不要)|すっきり|広く(使|見せ)/.test(t)) storage = 0;
  notes.push(`収納量: ${["少なめ", "ふつう", "多め"][storage]}`);
  // 欲しい物・いらない物（文ごとに否定を見る）
  const items = [...BASE[use]];
  const exclude = [];
  for (const sent of t.split(/[。．、,\n]/)) {
    for (const [re, k] of WORDS.items) {
      if (!re.test(sent)) continue;
      if (NEG.test(sent)) { if (!exclude.includes(k)) exclude.push(k); }
      else if (!items.includes(k)) items.push(k);
    }
  }
  if (storage === 2 && !items.includes("storage") && !exclude.includes("storage")) items.push("storage");
  if (storage === 0) for (const k of ["storage", "cupboard"]) if (!exclude.includes(k) && !/収納|棚/.test(t.replace(/収納(は)?(少なめ|最小|いらない|不要)/g, ""))) exclude.push(k);
  // 人数
  let people = null;
  const pm = t.match(/(\d+)\s*(人|名)/);
  if (pm) people = Math.min(12, Math.max(1, +pm[1]));
  if (people) notes.push(`人数: ${people} 人`);
  // ベッドの大きさ
  let bedW = use === "kids" ? 970 : 1200;
  if (/ダブル/.test(t)) bedW = 1400;
  if (/クイーン/.test(t)) bedW = 1600;
  if (/キング/.test(t)) bedW = 1800;
  if (/セミダブル/.test(t)) bedW = 1200;
  if (/シングル/.test(t) && !/セミ/.test(t)) bedW = 970;
  // 板の厚み
  let thickness = 18;
  const tm = t.match(/(?:板厚|厚み|厚さ)\s*(\d+)/) || t.match(/(\d+)\s*mm\s*(?:厚|の板)/);
  if (tm) thickness = Math.min(40, Math.max(9, +tm[1]));
  // 窓をふさがない・天井まで
  const keepWindow = !/窓(をふさいでも|の前に置いても)(いい|よい|OK)/i.test(t);
  const toCeil = !/(天井まで(は|に)しない|背の低い|圧迫感(を|が)?(なく|出さない|ない))/.test(t);
  if (!toCeil) notes.push("背の高い収納は 2100mm までに抑える（圧迫感を出さない）");
  const final = items.filter((k) => !exclude.includes(k));
  if (exclude.length) notes.push(`入れない: ${exclude.map((k) => KINDS[k].name).join("・")}`);
  return { use, style, storage, items: final, exclude, people, bedW, thickness, keepWindow, toCeil, notes, raw };
}

function guessUse(room) {
  if (!room) return "living";
  let a = 0;
  const P = room.poly;
  for (let i = 0; i < P.length; i++) { const p = P[i], q = P[(i + 1) % P.length]; a += p[0] * q[1] - q[0] * p[1]; }
  a = Math.abs(a) / 2 / 1e6;
  return a < 8 ? "study" : a > 25 ? "ldk" : "living";
}

// 方針の例（ボタンで入れられる）
export const POLICY_EXAMPLES = [
  "在宅ワーク用の書斎。本が多いので壁一面の本棚と、窓に向かうデスクカウンター。ナチュラルな木の感じで",
  "家族4人のリビング。テレビボードとソファ、収納は多め。北欧テイストで明るく",
  "寝室。ダブルベッドとクローゼット。ホテルライクに落ち着いた雰囲気で",
  "小さな物販の店舗。壁沿いに陳列棚とレジカウンター。インダストリアルな感じで",
];
