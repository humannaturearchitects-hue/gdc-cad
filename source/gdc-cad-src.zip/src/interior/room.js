// 内装: 点群から部屋の形（床・天井高・壁の輪郭・ドア・窓）を読み取る
//
// 部屋データ（room）:
//   { name, height,                  天井高 CH (mm)
//     poly: [[x,y],...],             床の輪郭（反時計回り・mm・左下が原点）。壁 i は poly[i] → poly[i+1]
//     openings: [{ id, type: "door"|"window"|"opening", wall, pos, width, height, sill }],
//                                    pos: 壁の始点から開口の端まで、sill: 床から開口の下端まで
//     transform: { angle, ox, oy, oz } スキャン座標 → 部屋座標（angle 回転してから ox,oy,oz を足す）
//     source: "scan" | "manual" }
//
// 壁は直交（いわゆるマンハッタン形状）を前提にする。日本の住宅・店舗の内装はほとんどこれで足りる。

export const rnd = (v, s = 1) => Math.round(v / s) * s;

// ---------------------------------------------------------------- 乱数（見本スキャン・テスト用・毎回同じ結果）
export function rng(seed = 1) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------------------------------------------------------------- 基本
export function polyArea(poly) {
  let a = 0;
  for (let i = 0; i < poly.length; i++) { const p = poly[i], q = poly[(i + 1) % poly.length]; a += p[0] * q[1] - q[0] * p[1]; }
  return a / 2;
}
export function wallsOf(room) {
  const P = room.poly, out = [];
  for (let i = 0; i < P.length; i++) {
    const a = P[i], b = P[(i + 1) % P.length];
    const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
    const u = [dx / len, dy / len];
    out.push({ i, a, b, len, u, n: [-u[1], u[0]], name: wallName(i) }); // n: 部屋の内側向き
  }
  return out;
}
export const wallName = (i) => (i < 26 ? String.fromCharCode(65 + i) : "W" + (i + 1)); // 壁 A, B, C, …
export function pointInPoly(p, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1]) + a[0]) inside = !inside;
  }
  return inside;
}
export function bbox2(poly) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const [x, y] of poly) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  return { x0, y0, x1, y1, w: x1 - x0, h: y1 - y0 };
}

// 長方形の部屋（手入力・スキャンがないとき）
export function rectRoom(w = 3640, d = 2730, h = 2400, name = "部屋") {
  return { name, height: h, poly: [[0, 0], [w, 0], [w, d], [0, d]], openings: [], transform: null, source: "manual" };
}

// ---------------------------------------------------------------- 点群 → 部屋
export function extractRoom(pts, opts = {}) {
  const n = pts.length / 3;
  if (n < 500) throw new Error("点が少なすぎます（部屋全体をスキャンしてください）");
  const log = [];
  // 1) 床と天井: 高さのヒストグラムの山
  let zlo = Infinity, zhi = -Infinity;
  for (let i = 0; i < n; i++) { const z = pts[3 * i + 2]; if (z < zlo) zlo = z; if (z > zhi) zhi = z; }
  const ZB = 20, nz = Math.max(1, Math.ceil((zhi - zlo) / ZB) + 1);
  const hz = new Float64Array(nz);
  for (let i = 0; i < n; i++) hz[Math.floor((pts[3 * i + 2] - zlo) / ZB)]++;
  const sm = (k) => (hz[k - 1] || 0) + hz[k] + (hz[k + 1] || 0);
  const peakIn = (a, b) => { let best = -1, bv = -1; for (let k = Math.max(0, a); k < Math.min(nz, b); k++) { const v = sm(k); if (v > bv) { bv = v; best = k; } } return [best, bv]; };
  const [fk] = peakIn(0, Math.floor(nz * 0.45));
  const [ck, cv] = peakIn(Math.ceil(nz * 0.55), nz);
  const refineZ = (k) => { const c = zlo + (k + 0.5) * ZB; let s = 0, m = 0; for (let i = 0; i < n; i++) { const z = pts[3 * i + 2]; if (Math.abs(z - c) < 30) { s += z; m++; } } return m ? s / m : c; };
  const floorZ = refineZ(fk);
  let ceilZ = cv > n * 0.01 ? refineZ(ck) : zhi;
  const H = ceilZ - floorZ;
  if (!(H > 1500 && H < 8000)) log.push(`天井高が ${Math.round(H)}mm と読み取れました（スキャンを確認してください）`);

  // 2) 輪郭用の点: 天井のすぐ下の帯（ドア・窓の上の壁はふつうつながっているので、輪郭が閉じやすい。家具にも隠れにくい）
  const bandLo = floorZ + Math.max(H * 0.8, H - 320), bandHi = ceilZ - 50;
  let band = [];
  for (let i = 0; i < n; i++) { const z = pts[3 * i + 2]; if (z > bandLo && z < bandHi) band.push(pts[3 * i], pts[3 * i + 1]); }
  if (band.length < 400) { // 天井付近が撮れていない → 腰〜頭の高さの帯
    band = [];
    for (let i = 0; i < n; i++) { const z = pts[3 * i + 2]; if (z > floorZ + 1000 && z < floorZ + 1800) band.push(pts[3 * i], pts[3 * i + 1]); }
    log.push("天井付近の壁が少ないため、腰〜頭の高さの壁で輪郭を読み取りました");
  }
  band = Float64Array.from(band);

  // 3) 壁の向き: 回したときに x・y のヒストグラムが最も鋭くなる角度
  const angle = opts.angle ?? dominantAngle(band);
  const ca = Math.cos(angle), sa = Math.sin(angle);
  const rot = (x, y) => [x * ca + y * sa, -x * sa + y * ca];
  const nb = band.length / 2;
  const rb = new Float64Array(band.length);
  for (let i = 0; i < nb; i++) { const [x, y] = rot(band[2 * i], band[2 * i + 1]); rb[2 * i] = x; rb[2 * i + 1] = y; }

  // 4) 格子に落として、外側から塗りつぶし → 残った内側の一番大きな領域が部屋
  let loop = null;
  for (const r of [2, 4, 7, 11]) { loop = roomLoop(rb, 50, r); if (loop) break; }
  let edges;
  if (!loop) {
    log.push("壁の輪郭が閉じなかったため、外形の長方形として読み取りました");
    const bb = pctBox(rb, 0.01);
    edges = [{ o: "H", c: bb.y0 }, { o: "V", c: bb.x1 }, { o: "H", c: bb.y1 }, { o: "V", c: bb.x0 }];
  } else edges = loop;
  // 5) 小さな段差をならす → 壁の面に合わせる
  edges = simplifyRect(edges, opts.minWall || 250);
  edges = refineEdges(edges, rb);
  edges = simplifyRect(edges, 60);
  let poly = edgesToPoly(edges);
  if (polyArea(poly) < 0) poly.reverse();
  // 原点を左下に。最も長い壁が下（壁 A）に来るように並べ替え
  const bb = bbox2(poly);
  poly = poly.map(([x, y]) => [rnd(x - bb.x0, 5), rnd(y - bb.y0, 5)]);
  poly = startAtBottomLeft(poly);
  const room = {
    name: opts.name || "スキャンした部屋",
    height: rnd(H, 5),
    poly,
    openings: [],
    transform: { angle, ox: -bb.x0, oy: -bb.y0, oz: -floorZ },
    source: "scan",
    log,
  };
  room.openings = opts.openings === false ? [] : detectOpenings(pts, room);
  return room;
}

// スキャン座標 → 部屋座標
export function toRoomFrame(pts, tr) {
  const out = new Float32Array(pts.length);
  const ca = Math.cos(tr.angle), sa = Math.sin(tr.angle);
  for (let i = 0; i < pts.length; i += 3) {
    const x = pts[i], y = pts[i + 1];
    out[i] = x * ca + y * sa + tr.ox;
    out[i + 1] = -x * sa + y * ca + tr.oy;
    out[i + 2] = pts[i + 2] + tr.oz;
  }
  return out;
}

function dominantAngle(b) {
  const n = b.length / 2;
  const step = Math.max(1, Math.floor(n / 20000));
  const score = (a) => {
    const ca = Math.cos(a), sa = Math.sin(a);
    const hx = new Map(), hy = new Map();
    for (let i = 0; i < n; i += step) {
      const x = b[2 * i], y = b[2 * i + 1];
      const kx = Math.floor((x * ca + y * sa) / 30), ky = Math.floor((-x * sa + y * ca) / 30);
      hx.set(kx, (hx.get(kx) || 0) + 1); hy.set(ky, (hy.get(ky) || 0) + 1);
    }
    let s = 0;
    for (const v of hx.values()) s += v * v;
    for (const v of hy.values()) s += v * v;
    return s;
  };
  let best = 0, bv = -1;
  for (let d = 0; d < 90; d += 1) { const v = score((d * Math.PI) / 180); if (v > bv) { bv = v; best = d; } }
  for (let d = best - 1; d <= best + 1; d += 0.05) { const v = score((d * Math.PI) / 180); if (v > bv) { bv = v; best = d; } }
  let a = (best * Math.PI) / 180;
  if (a > Math.PI / 4) a -= Math.PI / 2; // 回す量はなるべく小さく（±45°）
  return a;
}

function pctBox(rb, q) {
  const xs = [], ys = [];
  for (let i = 0; i < rb.length; i += 2) { xs.push(rb[i]); ys.push(rb[i + 1]); }
  xs.sort((a, b) => a - b); ys.sort((a, b) => a - b);
  const at = (a, t) => a[Math.min(a.length - 1, Math.max(0, Math.floor(t * a.length)))];
  return { x0: at(xs, q), x1: at(xs, 1 - q), y0: at(ys, q), y1: at(ys, 1 - q) };
}

// 格子で部屋の輪郭（直交多角形）を作る。返り値: H/V の線が交互に並んだもの [{o:"H",c:y},{o:"V",c:x},…]
function roomLoop(rb, cell, dil) {
  const n = rb.length / 2;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (let i = 0; i < n; i++) { x0 = Math.min(x0, rb[2 * i]); x1 = Math.max(x1, rb[2 * i]); y0 = Math.min(y0, rb[2 * i + 1]); y1 = Math.max(y1, rb[2 * i + 1]); }
  const pad = dil + 3;
  const W = Math.ceil((x1 - x0) / cell) + 2 * pad + 1, Hh = Math.ceil((y1 - y0) / cell) + 2 * pad + 1;
  if (W * Hh > 4e6) return null;
  const cnt = new Uint16Array(W * Hh);
  for (let i = 0; i < n; i++) {
    const gx = Math.floor((rb[2 * i] - x0) / cell) + pad, gy = Math.floor((rb[2 * i + 1] - y0) / cell) + pad;
    const k = gy * W + gx; if (cnt[k] < 65535) cnt[k]++;
  }
  // 点のまばらな格子（ノイズ）を除く
  const nonzero = []; for (const v of cnt) if (v) nonzero.push(v);
  nonzero.sort((a, b) => a - b);
  const th = Math.max(1, Math.floor(nonzero[Math.floor(nonzero.length * 0.25)] * 0.3));
  let wall = new Uint8Array(W * Hh);
  for (let k = 0; k < W * Hh; k++) wall[k] = cnt[k] >= th ? 1 : 0;
  // 膨らませてスキャンの欠けをふさぐ
  const dw = new Uint8Array(W * Hh);
  for (let y = 0; y < Hh; y++) for (let x = 0; x < W; x++) {
    if (!wall[y * W + x]) continue;
    for (let dy = -dil; dy <= dil; dy++) for (let dx = -dil; dx <= dil; dx++) {
      const X = x + dx, Y = y + dy;
      if (X >= 0 && Y >= 0 && X < W && Y < Hh) dw[Y * W + X] = 1;
    }
  }
  wall = dw;
  // 外側を塗る
  const lab = new Int32Array(W * Hh); // 0: 未, -1: 外, >0: 内側の領域番号
  const stack = [];
  const flood = (s, id) => {
    let size = 0; stack.length = 0; stack.push(s); lab[s] = id;
    while (stack.length) {
      const k = stack.pop(); size++;
      const x = k % W, y = (k - x) / W;
      if (x > 0) tryp(k - 1); if (x < W - 1) tryp(k + 1); if (y > 0) tryp(k - W); if (y < Hh - 1) tryp(k + W);
    }
    function tryp(j) { if (!lab[j] && !wall[j]) { lab[j] = id; stack.push(j); } }
    return size;
  };
  flood(0, -1);
  let best = 0, bestSize = 0, id = 1;
  for (let k = 0; k < W * Hh; k++) if (!lab[k] && !wall[k]) { const s = flood(k, ++id); if (s > bestSize) { bestSize = s; best = id; } }
  if (!best || bestSize * cell * cell < 1.0e6) return null; // 1㎡ 未満 → 閉じていない
  // 縮んだ分（膨らませた分）を戻す
  const inside = new Uint8Array(W * Hh);
  for (let k = 0; k < W * Hh; k++) if (lab[k] === best) inside[k] = 1;
  const grow = new Uint8Array(inside);
  for (let it = 0; it < dil; it++) {
    const src = new Uint8Array(grow);
    for (let y = 1; y < Hh - 1; y++) for (let x = 1; x < W - 1; x++) {
      const k = y * W + x;
      if (!src[k] && (src[k - 1] || src[k + 1] || src[k - W] || src[k + W])) grow[k] = 1;
    }
  }
  const loopPts = traceLoop(grow, W, Hh);
  if (!loopPts) return null;
  // 格子座標 → mm の H/V 線
  const E = [];
  for (let i = 0; i < loopPts.length; i++) {
    const a = loopPts[i], b = loopPts[(i + 1) % loopPts.length];
    const o = a[1] === b[1] ? "H" : "V";
    const c = o === "H" ? y0 + (a[1] - pad) * cell : x0 + (a[0] - pad) * cell;
    if (E.length && E[E.length - 1].o === o) continue;
    E.push({ o, c });
  }
  if (E.length > 1 && E[0].o === E[E.length - 1].o) E.pop();
  return E.length >= 4 && E.length % 2 === 0 ? E : null;
}

// 格子の領域の外周（角の点の列・反時計回り）
function traceLoop(m, W, Hh) {
  const at = (x, y) => x >= 0 && y >= 0 && x < W && y < Hh && m[y * W + x];
  const out = new Map(); // "x,y" → [[x2,y2],…]
  const add = (a, b) => { const k = a[0] + "," + a[1]; if (!out.has(k)) out.set(k, []); out.get(k).push(b); };
  let start = null;
  for (let y = 0; y < Hh; y++) for (let x = 0; x < W; x++) {
    if (!m[y * W + x]) continue;
    if (!at(x, y - 1)) { add([x, y], [x + 1, y]); if (!start) start = [x, y]; }
    if (!at(x + 1, y)) add([x + 1, y], [x + 1, y + 1]);
    if (!at(x, y + 1)) add([x + 1, y + 1], [x, y + 1]);
    if (!at(x - 1, y)) add([x, y + 1], [x, y]);
  }
  if (!start) return null;
  const pts = [start];
  let cur = start, prevDir = [1, 0];
  for (let guard = 0; guard < 1e6; guard++) {
    const list = out.get(cur[0] + "," + cur[1]);
    if (!list || !list.length) break;
    // 分かれ道では右に曲がる方を選ぶ（領域が角でつながっているところを分ける）
    let pick = 0;
    if (list.length > 1) {
      let bestT = Infinity;
      list.forEach((b, i) => { const d = [b[0] - cur[0], b[1] - cur[1]]; const cross = prevDir[0] * d[1] - prevDir[1] * d[0]; if (cross < bestT) { bestT = cross; pick = i; } });
    }
    const nx = list.splice(pick, 1)[0];
    prevDir = [nx[0] - cur[0], nx[1] - cur[1]];
    if (nx[0] === start[0] && nx[1] === start[1]) break;
    pts.push(nx); cur = nx;
  }
  return pts.length >= 4 ? pts : null;
}

// H/V の線の列で、短い辺（段差・出っ張り）を消していく
export function simplifyRect(E, tol) {
  E = E.map((e) => ({ ...e }));
  const len = (k) => { const N = E.length; return Math.abs(E[(k + 1) % N].c - E[(k - 1 + N) % N].c); };
  while (E.length > 4) {
    let k = -1, m = Infinity;
    for (let i = 0; i < E.length; i++) { const L = len(i); if (L < m) { m = L; k = i; } }
    if (m >= tol) break;
    const N = E.length, p = (k - 1 + N) % N, q = (k + 1) % N;
    const lp = len(p), lq = len(q);
    E[p].c = lp + lq > 0 ? (E[p].c * lp + E[q].c * lq) / (lp + lq) : (E[p].c + E[q].c) / 2;
    // k と q を消す（インデックスの大きい方から）
    for (const j of [k, q].sort((a, b) => b - a)) E.splice(j, 1);
  }
  return E;
}

// 各辺を、近くにある壁の面（点の集まり）にぴったり合わせる
function refineEdges(E, rb) {
  const N = E.length, n = rb.length / 2;
  return E.map((e, k) => {
    const a = E[(k - 1 + N) % N].c, b = E[(k + 1) % N].c;
    const lo = Math.min(a, b) + 150, hi = Math.max(a, b) - 150;
    if (hi <= lo) return e;
    const h = new Map();
    const along = e.o === "H" ? 0 : 1, across = 1 - along;
    for (let i = 0; i < n; i++) {
      const t = rb[2 * i + along], s = rb[2 * i + across];
      if (t < lo || t > hi || Math.abs(s - e.c) > 450) continue;
      const kk = Math.round(s / 10); h.set(kk, (h.get(kk) || 0) + 1);
    }
    let bk = null, bv = 0;
    for (const [kk, v] of h) { const vv = v + (h.get(kk - 1) || 0) + (h.get(kk + 1) || 0); if (vv > bv) { bv = vv; bk = kk; } }
    if (bk == null || bv < 10) return e;
    let s2 = 0, m2 = 0;
    for (let i = 0; i < n; i++) {
      const t = rb[2 * i + along], s = rb[2 * i + across];
      if (t < lo || t > hi || Math.abs(s - bk * 10) > 20) continue;
      s2 += s; m2++;
    }
    return { ...e, c: m2 ? s2 / m2 : bk * 10 };
  });
}

export function edgesToPoly(E) {
  const N = E.length, P = [];
  for (let k = 0; k < N; k++) {
    const e = E[k], f = E[(k + 1) % N];
    P.push(e.o === "H" ? [f.c, e.c] : [e.c, f.c]);
  }
  return P;
}

// 左下の角から始まり、最初の壁が x+ 向きになるように並べ替える
export function startAtBottomLeft(P) {
  let k = 0;
  for (let i = 1; i < P.length; i++) if (P[i][1] < P[k][1] - 1 || (Math.abs(P[i][1] - P[k][1]) <= 1 && P[i][0] < P[k][0])) k = i;
  return [...P.slice(k), ...P.slice(0, k)];
}

// ---------------------------------------------------------------- ドア・窓を見つける
// 壁の面に点がない所 = 開口。ただし手前に家具があって隠れているだけの所（手前に点がある）は除く
export function detectOpenings(pts, room) {
  const R = toRoomFrame(pts, room.transform);
  const H = room.height, out = [];
  const CT = 50, CZ = 50, nzc = Math.ceil(H / CZ);
  for (const w of wallsOf(room)) {
    if (w.len < 600) continue;
    const nt = Math.ceil(w.len / CT);
    const on = new Uint16Array(nt * nzc), behind = new Uint16Array(nt * nzc), front = new Uint16Array(nt * nzc);
    for (let i = 0; i < R.length; i += 3) {
      const dx = R[i] - w.a[0], dy = R[i + 1] - w.a[1], z = R[i + 2];
      if (z < 0 || z >= H) continue;
      const t = dx * w.u[0] + dy * w.u[1];
      if (t < 0 || t >= w.len) continue;
      const s = dx * w.n[0] + dy * w.n[1];
      const k = Math.floor(t / CT) * nzc + Math.floor(z / CZ);
      if (Math.abs(s) < 70) on[k]++;
      else if (s < -100 && s > -6000) behind[k]++;
      else if (s > 70 && s < 900) front[k]++;
    }
    // 壁の点の密度（ふつうの格子にいくつ点があるか）
    const nz = []; for (const v of on) if (v) nz.push(v);
    nz.sort((a, b) => a - b);
    const typical = nz.length ? nz[Math.floor(nz.length / 2)] : 0;
    if (!typical) continue;
    // 向こう側が見えている（近くの格子に、壁より奥の点がある）
    const seeThrough = (k) => {
      const t = Math.floor(k / nzc), z = k % nzc;
      for (let a = Math.max(0, t - 2); a <= Math.min(nt - 1, t + 2); a++) for (let b = Math.max(0, z - 2); b <= Math.min(nzc - 1, z + 2); b++) if (behind[a * nzc + b]) return true;
      return false;
    };
    // 手前の点が「家具の面」と言えるほど多いときだけ、陰で見えないだけとみなす（散らかった小物・ノイズは無視）
    const occluded = (k) => front[k] >= Math.max(2, typical * 0.3);
    const empty = (k) => on[k] < Math.max(1, typical * 0.12) && (!occluded(k) || seeThrough(k));
    // 列ごとに、空いている縦の範囲（一番長いもの）
    const cols = [];
    for (let t = 0; t < nt; t++) {
      // 縦の 1 マスだけの点（ノイズ）は無視して、空いている一番長い範囲
      const e = new Uint8Array(nzc);
      for (let z = 0; z < nzc; z++) e[z] = empty(t * nzc + z) ? 1 : 0;
      for (let z = 1; z < nzc - 1; z++) if (!e[z] && e[z - 1] && e[z + 1]) e[z] = 2;
      let bs = -1, bl = 0, s = -1;
      for (let z = 1; z < nzc - 1; z++) {
        if (e[z]) { if (s < 0) s = z; if (z - s + 1 > bl) { bl = z - s + 1; bs = s; } }
        else s = -1;
      }
      const z0 = bs * CZ, z1 = (bs + bl) * CZ;
      let cls = null;
      if (bl && z0 <= 150 && z1 - z0 >= 1700) cls = "door";
      else if (bl && z0 >= 250 && z1 - z0 >= 300 && z1 <= H - 30) cls = "window";
      cols.push({ cls, z0, z1, e });
    }
    // 両隣と違う 1 列だけの種類（ノイズ）は、両隣に合わせる
    for (let t = 1; t < nt - 1; t++) if (cols[t - 1].cls && cols[t - 1].cls === cols[t + 1].cls && cols[t].cls !== cols[t - 1].cls) cols[t] = { ...cols[t - 1], fixed: true };
    // 同じ種類の列をまとめる（1 列の途切れは許す）
    for (let t = 0; t < nt;) {
      const c = cols[t].cls;
      if (!c) { t++; continue; }
      let e = t;
      while (e + 1 < nt && (cols[e + 1].cls === c || (e + 2 < nt && cols[e + 2].cls === c && !cols[e + 1].cls))) e++;
      const width = (e - t + 1) * CT;
      const g = cols.slice(t, e + 1).filter((x) => x.cls === c);
      const med = (a) => a.sort((p, q) => p - q)[Math.floor(a.length / 2)];
      const z0 = med(g.map((x) => x.z0)), z1 = med(g.map((x) => x.z1));
      // 本物の開口は四角い: 列ごとの上端・下端がそろっている（撮り残しの穴は丸く、ばらつく）
      const tol = 75;
      const square = g.filter((x) => Math.abs(x.z1 - z1) <= tol && (c === "door" || Math.abs(x.z0 - z0) <= tol)).length / g.length;
      // 四角の中がどれだけ空いているか（四角い開口 ≒ 1、丸い撮り残し ≒ 0.79）
      let fill = 0, tot = 0;
      for (let tt = t; tt <= e; tt++) for (let z = Math.max(1, Math.round(z0 / CZ)); z < Math.round(z1 / CZ); z++) { tot++; if (cols[tt].e && cols[tt].e[z]) fill++; }
      fill = tot ? fill / tot : 0;
      if (square >= 0.75 && fill >= 0.88 && ((c === "door" && width >= 550 && width <= 2600) || (c === "window" && width >= 350 && z1 - z0 >= 350))) {
        // 端を細かく: 開口のすぐ外側にある壁の点の位置
        const za = (c === "door" ? 200 : z0 + 80), zb = z1 - 80;
        let left = t * CT, right = (e + 1) * CT;
        const LT = [], RT = [];
        for (let i = 0; i < R.length; i += 3) {
          const z = R[i + 2]; if (z < za || z > zb) continue;
          const dx = R[i] - w.a[0], dy = R[i + 1] - w.a[1];
          if (Math.abs(dx * w.n[0] + dy * w.n[1]) > 70) continue;
          const tt = dx * w.u[0] + dy * w.u[1];
          if (tt > left - 200 && tt < left + 100) LT.push(tt);
          if (tt < right + 200 && tt > right - 100) RT.push(tt);
        }
        // 1 点だけの迷い点ではなく、点がまとまってある所（壁の端）
        const need = Math.max(3, Math.round(typical * 0.4));
        LT.sort((a, b) => b - a); RT.sort((a, b) => a - b);
        let L = -Infinity, Rr = Infinity;
        for (let k = 0; k + need - 1 < LT.length; k++) if (LT[k] - LT[k + need - 1] < 60) { L = LT[k]; break; }
        for (let k = 0; k + need - 1 < RT.length; k++) if (RT[k + need - 1] - RT[k] < 60) { Rr = RT[k]; break; }
        if (isFinite(L)) left = L;
        if (isFinite(Rr)) right = Rr;
        // 確かさ: 向こう側が見えている・大きくて四角い ほど確か。撮り残しかもしれない物は「要確認」
        let see = 0, cells = 0;
        for (let tt = t; tt <= e; tt++) for (let z = Math.max(1, Math.round(z0 / CZ)); z < Math.round(z1 / CZ); z += 2) { cells++; if (seeThrough(tt * nzc + z)) see++; }
        const sure = c === "door" || see / Math.max(1, cells) > 0.15 || (width >= 600 && z1 - z0 >= 600 && fill >= 0.95 && square >= 0.9);
        out.push({
          id: "O" + (out.length + 1), type: c, wall: w.i, ...(sure ? {} : { uncertain: true }),
          pos: rnd(left, 5), width: rnd(right - left, 5),
          height: c === "door" ? rnd(z1, 5) : rnd(z1 - z0, 5),
          sill: c === "door" ? 0 : rnd(z0, 5),
        });
      }
      t = e + 1;
    }
  }
  return out;
}

// ---------------------------------------------------------------- 見本スキャン（スキャンを持っていなくても試せるように）
// L 字の部屋（約 10 畳）・ドア 1・窓 2・ソファ 1。iPhone の書き出しと同じく m 単位・Y 上向き・斜めに置いた点群を返す
export function makeSampleScan({ seed = 7, density = 1, noise = 4 } = {}) {
  return synthScan({
    seed, density, noise,
    poly: [[0, 0], [4550, 0], [4550, 2730], [3640, 2730], [3640, 3640], [0, 3640]],
    height: 2400,
    holes: [ // 壁ごとの開口（壁番号・位置・幅・下端・高さ）
      { wall: 0, pos: 600, w: 800, z0: 0, z1: 2000, door: true },
      { wall: 4, pos: 1000, w: 1690, z0: 900, z1: 2000 },
      { wall: 1, pos: 900, w: 1200, z0: 1100, z1: 2000 },
    ],
    boxes: [{ x0: 0, x1: 1050, y0: 1000, y1: 2800, h: 800 }], // ソファ（左の壁の前）: 後ろの壁はスキャンに写らない
    angle: 23, offset: [1234, -567, -1300], upY: true, unit: "m",
  });
}

// 合成スキャン（テスト・見本用）。実際のスキャンで起きること（ノイズ・欠け・家具の陰・天井の撮り残し・
// 窓の外の点・散らかった物）をまねる
//  spec: { poly, height, holes:[{wall,pos,w,z0,z1,door}], boxes:[{x0,x1,y0,y1,h}], angle(度), offset:[x,y,z],
//          upY, unit:"m"|"mm", density, noise, ceiling(0〜1 撮れた割合), gaps(欠けの数), clutter(散らかった点の数), outside(窓の外の点の数) }
export function synthScan(spec) {
  const { poly, height: H, holes = [], boxes = [], seed = 1, density = 1, noise = 4, ceiling = 0.8, gaps = 0, clutter = 0, outside = 0 } = spec;
  const R = rng(seed);
  const g = () => (R() + R() + R() - 1.5) * noise;
  const P = [];
  const put = (x, y, z) => P.push(x + g(), y + g(), z + g());
  const area = (mm2) => Math.max(1, Math.round(mm2 * 1e-6 * 2500 * density)); // 1 ㎡ あたり 2500 点 × density
  const inBox = (x, y, z, pad = 0) => boxes.some((b) => x > b.x0 - pad && x < b.x1 + pad && y > b.y0 - pad && y < b.y1 + pad && z < b.h + pad);
  // 撮り残し（壁の一部が丸ごと写っていない）
  const gapList = [];
  for (let k = 0; k < gaps; k++) gapList.push({ wall: Math.floor(R() * poly.length), t: R(), z: R() * H, r: 150 + R() * 250 });
  const bb = bbox2(poly);
  for (let k = 0, m = area(bb.w * bb.h); k < m; k++) {
    const x = bb.x0 + R() * bb.w, y = bb.y0 + R() * bb.h;
    if (!pointInPoly([x, y], poly)) continue;
    if (!inBox(x, y, 0)) put(x, y, 0);
    if (R() < ceiling) put(x, y, H);
  }
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]), u = [(b[0] - a[0]) / L, (b[1] - a[1]) / L], nrm = [-u[1], u[0]];
    for (let k = 0, m = area(L * H); k < m; k++) {
      const t = R() * L, z = R() * H;
      const hole = holes.find((h) => h.wall === i && t > h.pos && t < h.pos + h.w && z > h.z0 && z < h.z1);
      if (hole) {
        // ドアの向こう（廊下の床・向かいの壁）が少し見える
        if (hole.door && R() < 0.5) { const d = 300 + R() * 1200; put(a[0] + u[0] * t - nrm[0] * d, a[1] + u[1] * t - nrm[1] * d, R() < 0.5 ? 0 : z); }
        continue;
      }
      if (z > H * 0.85 && R() > ceiling + 0.2) continue; // 天井の近くは撮り残しやすい
      if (gapList.some((q) => q.wall === i && Math.hypot(t - q.t * L, z - q.z) < q.r)) continue;
      const x = a[0] + u[0] * t, y = a[1] + u[1] * t;
      // 家具の陰（壁から 150mm 以内の家具の後ろ）
      if (inBox(x + nrm[0] * 100, y + nrm[1] * 100, z, 0)) continue;
      put(x, y, z);
    }
  }
  // 家具の表面（上面と、部屋に向いた側面）
  for (const b of boxes) {
    const top = (b.x1 - b.x0) * (b.y1 - b.y0), side = 2 * ((b.x1 - b.x0) + (b.y1 - b.y0)) * b.h;
    for (let k = 0, m = area(top + side); k < m; k++) {
      const f = R() * (top + side);
      let x, y, z;
      if (f < top) { x = b.x0 + R() * (b.x1 - b.x0); y = b.y0 + R() * (b.y1 - b.y0); z = b.h; }
      else {
        const per = 2 * ((b.x1 - b.x0) + (b.y1 - b.y0)); let s2 = R() * per; z = R() * b.h;
        const w = b.x1 - b.x0, d = b.y1 - b.y0;
        if (s2 < w) { x = b.x0 + s2; y = b.y0; } else if ((s2 -= w) < d) { x = b.x1; y = b.y0 + s2; } else if ((s2 -= d) < w) { x = b.x1 - s2; y = b.y1; } else { s2 -= w; x = b.x0; y = b.y1 - s2; }
      }
      if (pointInPoly([x, y], poly) && Math.min(...poly.map((_, i) => segDist([x, y], poly[i], poly[(i + 1) % poly.length]))) > 60) put(x, y, z);
    }
  }
  // 散らかった物（床の上の小物）と、窓の外に写った遠くの点
  for (let k = 0; k < clutter; k++) { const x = bb.x0 + R() * bb.w, y = bb.y0 + R() * bb.h; if (pointInPoly([x, y], poly)) put(x, y, R() * 900); }
  for (let k = 0; k < outside; k++) {
    const h = holes.filter((q) => !q.door)[k % Math.max(1, holes.filter((q) => !q.door).length)];
    if (!h) break;
    const a = poly[h.wall], b = poly[(h.wall + 1) % poly.length];
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]), u = [(b[0] - a[0]) / L, (b[1] - a[1]) / L], nrm = [-u[1], u[0]];
    const d = 2000 + R() * 15000, t = h.pos + R() * h.w;
    put(a[0] + u[0] * t - nrm[0] * d, a[1] + u[1] * t - nrm[1] * d, h.z0 + R() * (h.z1 - h.z0) + (R() - 0.5) * 3000);
  }
  // 斜めに置いて、単位・上方向を変える（iPhone の書き出しなら m・Y 上）
  const ang = ((spec.angle || 0) * Math.PI) / 180, ca = Math.cos(ang), sa = Math.sin(ang);
  const [ox, oy, oz] = spec.offset || [0, 0, 0];
  const k = spec.unit === "m" ? 1 / 1000 : 1;
  const out = new Float32Array(P.length);
  for (let i = 0; i < P.length; i += 3) {
    const x = P[i] * ca - P[i + 1] * sa + ox, y = P[i] * sa + P[i + 1] * ca + oy, z = P[i + 2] + oz;
    if (spec.upY) { out[i] = x * k; out[i + 1] = z * k; out[i + 2] = -y * k; }
    else { out[i] = x * k; out[i + 1] = y * k; out[i + 2] = z * k; }
  }
  return { pts: out, truth: { poly, height: H, holes } };
}
function segDist(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1], L2 = dx * dx + dy * dy;
  const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2));
  return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy);
}
