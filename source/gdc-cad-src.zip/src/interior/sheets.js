// 内装: 図面を作る（平面図・展開図・家具表・部材表）
// 出力は GDC CAD の図面と同じ「シート」形式 → 既存の SVG / DXF / PDF 書き出しがそのまま使える
//   sheet: { w, h, layers: { NAME: { prims, color, dash, width } }, texts: [...], fills: [...] }
import { wallsOf, polyArea, bbox2, rnd, pointInPoly } from "./room.js";
import { STYLES, USES, KINDS } from "./policy.js";
import { cutListAll, builtinParts } from "./planner.js";

const SHEET = { A3: [420, 297], A4: [297, 210], A2: [594, 420] };
const SCALES = [1 / 10, 1 / 20, 1 / 30, 1 / 40, 1 / 50, 1 / 60, 1 / 100, 1 / 200];
const WALL_T = 120; // 図面上の壁の厚み（mm・表現用）

function newSheet(size = "A3") {
  const [w, h] = SHEET[size] || SHEET.A3;
  return {
    w, h, texts: [], fills: [],
    layers: {
      BORDER: { prims: [], width: 0.5 },
      WALL: { prims: [], width: 0.6 },
      OPENING: { prims: [], width: 0.3 },
      FURN: { prims: [], width: 0.35, color: "#7a4b1e" },
      OUTLINE: { prims: [], width: 0.35 },
      HIDDEN: { prims: [], width: 0.2, dash: "1.5 1", color: "#666" },
      DIM: { prims: [], width: 0.18, color: "#1a5fb4" },
      CENTER: { prims: [], width: 0.18, dash: "4 1 1 1", color: "#b33" },
      TABLE: { prims: [], width: 0.25 },
    },
  };
}
const L = (sh, layer, a, b) => sh.layers[layer].prims.push({ t: "line", a, b });
const rectP = (sh, layer, x0, y0, x1, y1) => sh.layers[layer].prims.push({ t: "poly", pts: [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]] });
const T = (sh, x, y, text, size = 2.5, anchor = "start", extra = {}) => sh.texts.push({ x, y, text: String(text), size, anchor, ...extra });

// 寸法線（2 点 a,b の距離を、法線方向 off に寄せて書く）。value: 書く数値
function dim(sh, a, b, off, value, { size = 2.2, ext = true } = {}) {
  const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
  if (len < 0.5) return;
  const u = [dx / len, dy / len], n = [-u[1], u[0]];
  const A = [a[0] + n[0] * off, a[1] + n[1] * off], B = [b[0] + n[0] * off, b[1] + n[1] * off];
  const s = Math.sign(off) || 1;
  if (ext) {
    L(sh, "DIM", [a[0] + n[0] * s * 1, a[1] + n[1] * s * 1], [A[0] + n[0] * s * 1.5, A[1] + n[1] * s * 1.5]);
    L(sh, "DIM", [b[0] + n[0] * s * 1, b[1] + n[1] * s * 1], [B[0] + n[0] * s * 1.5, B[1] + n[1] * s * 1.5]);
  }
  L(sh, "DIM", A, B);
  // 端の印（斜線: 建築図面の慣例）
  for (const P of [A, B]) L(sh, "DIM", [P[0] - (u[0] + n[0]) * 0.9, P[1] - (u[1] + n[1]) * 0.9], [P[0] + (u[0] + n[0]) * 0.9, P[1] + (u[1] + n[1]) * 0.9]);
  const mid = [(A[0] + B[0]) / 2 + n[0] * s * 0.8, (A[1] + B[1]) / 2 + n[1] * s * 0.8];
  let rot = (Math.atan2(u[1], u[0]) * 180) / Math.PI;
  if (rot > 90.01 || rot < -89.99) rot += 180;
  const txt = String(Math.round(value));
  // 寸法が狭いときは字を外に出す
  const narrow = len < txt.length * size * 0.62;
  const tp = narrow ? [B[0] + u[0] * (txt.length * size * 0.35 + 1), B[1] + u[1] * (txt.length * size * 0.35 + 1)] : mid;
  const off2 = s > 0 ? 0.3 : -size * 0.9; // 線の外側に字
  T(sh, tp[0] + n[0] * off2, tp[1] + n[1] * off2, txt, size, "middle", { rot: Math.round(rot * 100) / 100, layer: "DIM", color: "#1a5fb4" });
}

// 表題欄
function titleBlock(sh, info, page, pages) {
  const W = sh.w, H = sh.h, M = 10;
  rectP(sh, "BORDER", M, M, W - M, H - M);
  const bw = 170, bh = 28, x0 = W - M - bw, y0 = M;
  rectP(sh, "BORDER", x0, y0, W - M, y0 + bh);
  L(sh, "BORDER", [x0, y0 + 14], [W - M, y0 + 14]);
  L(sh, "BORDER", [x0 + 100, y0], [x0 + 100, y0 + bh]);
  L(sh, "BORDER", [x0 + 135, y0], [x0 + 135, y0 + 14]);
  T(sh, x0 + 2, y0 + 19, info.project || "内装計画", 4.2);
  T(sh, x0 + 2, y0 + 4.5, info.title, 4);
  T(sh, x0 + 102, y0 + 19, info.company || "", 2.6);
  T(sh, x0 + 102, y0 + 23.5, info.author ? `作成: ${info.author}` : "", 2.4);
  T(sh, x0 + 102, y0 + 4.5, `尺度 ${info.scale}`, 2.6);
  T(sh, x0 + 137, y0 + 4.5, `${page || 0}/${pages || 0}`, 2.6);
  T(sh, x0 + 152, y0 + 19, info.date || "", 2.2);
  T(sh, M + 2, M + 2.5, "単位: mm　寸法は仕上げ面（スキャンの読み取り値・現場で要確認）", 2.2, "start", { color: "#555" });
}

const scaleLabel = (s) => `1:${Math.round(1 / s)}`;
function pickScale(wmm, hmm, aw, ah) {
  for (const s of SCALES) if (wmm * s <= aw && hmm * s <= ah) return s;
  return SCALES[SCALES.length - 1];
}

// ---------------------------------------------------------------- 平面図
function planSheet(room, plan, info) {
  const sh = newSheet(info.size);
  const bb = bbox2(room.poly);
  const M = 10, availW = sh.w - 2 * M - 75, availH = sh.h - 2 * M - 30 - 18;
  const s = pickScale(bb.w + 2 * WALL_T + 1700, bb.h + 2 * WALL_T + 1700, availW, availH);
  const ox = M + 4 + (availW - bb.w * s) / 2, oy = M + 30 + (availH - bb.h * s) / 2;
  const P = (x, y) => [ox + x * s, oy + y * s];
  const walls = wallsOf(room);
  // 壁（内側の線＋外側に厚み。開口のところは切る）
  const opens = (wi) => room.openings.filter((o) => o.wall === wi).sort((a, b) => a.pos - b.pos);
  const N = room.poly.length;
  // 外側の線: 各辺を外にずらして、隣どうしの交点で結ぶ
  const outer = room.poly.map((_, i) => {
    const wPrev = walls[(i - 1 + N) % N], w = walls[i];
    const a = [room.poly[i][0] - wPrev.n[0] * WALL_T, room.poly[i][1] - wPrev.n[1] * WALL_T];
    return [a[0] - w.n[0] * WALL_T, a[1] - w.n[1] * WALL_T];
  });
  for (const w of walls) {
    const segs = [[0, w.len]];
    for (const o of opens(w.i)) {
      const last = segs[segs.length - 1];
      if (o.pos > last[0] && o.pos + o.width < last[1]) { segs.pop(); segs.push([last[0], o.pos], [o.pos + o.width, last[1]]); }
    }
    const pt = (t, d) => P(w.a[0] + w.u[0] * t - w.n[0] * d, w.a[1] + w.u[1] * t - w.n[1] * d);
    // 外側の線の端（出隅なら外へ延ばし、入隅なら手前で止める）
    const tOf = (q) => (q[0] - w.a[0]) * w.u[0] + (q[1] - w.a[1]) * w.u[1];
    const E0 = tOf(outer[w.i]), E1 = tOf(outer[(w.i + 1) % N]);
    for (const [t0, t1] of segs) {
      L(sh, "WALL", pt(t0, 0), pt(t1, 0));
      L(sh, "WALL", pt(t0 === 0 ? E0 : t0, WALL_T), pt(t1 === w.len ? E1 : t1, WALL_T));
      if (t0 > 0) L(sh, "WALL", pt(t0, 0), pt(t0, WALL_T));
      if (t1 < w.len) L(sh, "WALL", pt(t1, 0), pt(t1, WALL_T));
    }
    // 壁の塗り（薄いグレー）
    for (const [t0, t1] of segs) {
      const q = [pt(t0, 0), pt(t1, 0), pt(t1 === w.len ? E1 : t1, WALL_T), pt(t0 === 0 ? E0 : t0, WALL_T)];
      sh.fills.push({ pts: q, color: "#d9d9d9", layer: "WALL", under: true });
    }
    // 開口
    for (const o of opens(w.i)) {
      if (o.type === "window") {
        for (const d of [0, WALL_T / 2, WALL_T]) L(sh, "OPENING", pt(o.pos, d), pt(o.pos + o.width, d));
      } else if (o.type === "door") {
        // 開き戸: 内開き・吊元は開口の始点側。扉の線と 90° の円弧
        const hinge = pt(o.pos, 0);
        const r = o.width * s;
        const a0 = Math.atan2(w.u[1], w.u[0]);
        const swing = Math.atan2(w.n[1], w.n[0]);
        const leafEnd = [hinge[0] + Math.cos(swing) * r, hinge[1] + Math.sin(swing) * r];
        L(sh, "OPENING", hinge, leafEnd);
        let d = swing - a0; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
        sh.layers.OPENING.prims.push({ t: "arc", c: hinge, r, s: a0, d });
      }
    }
  }
  // 家具・造作
  const furnLabel = [];
  for (const it of plan.items) {
    const [x0, y0] = P(it.x0, it.y0), [x1, y1] = P(it.x1, it.y1);
    rectP(sh, "FURN", x0, y0, x1, y1);
    if (it.builtin && (KINDS[it.kind]?.tall)) { L(sh, "FURN", [x0, y0], [x1, y1]); L(sh, "FURN", [x0, y1], [x1, y0]); } // 天井までの収納は ×
    if (it.kind === "bed") { const hd = it.dir; const k = 300 * s; const hx = hd[0] ? (hd[0] > 0 ? x0 + k : x1 - k) : null, hy = hd[1] ? (hd[1] > 0 ? y0 + k : y1 - k) : null; if (hx != null) L(sh, "FURN", [hx, y0], [hx, y1]); if (hy != null) L(sh, "FURN", [x0, hy], [x1, hy]); }
    if (it.kind === "sofa") { const k = 180 * s; const d = it.dir; if (d[1]) { const y = d[1] < 0 ? y1 - k : y0 + k; L(sh, "FURN", [x0, y], [x1, y]); } else { const x = d[0] < 0 ? x1 - k : x0 + k; L(sh, "FURN", [x, y0], [x, y1]); } }
    furnLabel.push({ it, c: [(x0 + x1) / 2, (y0 + y1) / 2], wpx: Math.abs(x1 - x0), hpx: Math.abs(y1 - y0) });
  }
  plan.items.forEach((it, i) => { it.mark = it.mark || markOf(i); });
  for (const f of furnLabel) {
    const vertical = f.hpx > f.wpx * 1.6 && f.wpx < 14;
    const sz = Math.max(1.8, Math.min(2.6, (vertical ? f.hpx : f.wpx) / 12));
    T(sh, f.c[0], f.c[1] + (vertical ? 0 : 0.6), `${f.it.mark} ${f.it.name}`, sz, "middle", vertical ? { rot: 90, color: "#7a4b1e" } : { color: "#7a4b1e" });
    if (!vertical && f.hpx > 9) T(sh, f.c[0], f.c[1] - sz - 0.4, `${f.it.w}×${f.it.d}${f.it.h ? " H" + f.it.h : ""}`, 1.8, "middle", { color: "#7a4b1e" });
  }
  // 寸法: 1 段目 = 開口の位置（壁ごとの区切り）、2 段目 = 壁の長さ
  for (const w of walls) {
    const out = [-w.n[0], -w.n[1]];
    const A = P(...w.a), B = P(...w.b);
    const os = opens(w.i);
    const base = WALL_T * s;
    if (os.length) {
      const cuts = [0];
      for (const o of os) cuts.push(o.pos, o.pos + o.width);
      cuts.push(w.len);
      for (let k = 0; k + 1 < cuts.length; k++) {
        const a = [A[0] + w.u[0] * cuts[k] * s, A[1] + w.u[1] * cuts[k] * s], b = [A[0] + w.u[0] * cuts[k + 1] * s, A[1] + w.u[1] * cuts[k + 1] * s];
        dimOut(sh, a, b, out, base + 6, cuts[k + 1] - cuts[k]);
      }
    }
    dimOut(sh, A, B, out, base + (os.length ? 13 : 6), w.len, 2.5);
  }
  // 家具の位置（造作は壁の端から）
  for (const it of plan.items) {
    if (!it.builtin || it.wall == null) continue;
    const w = walls[it.wall];
    if (it.t > 10) {
      const A = P(...w.a), a2 = [A[0] + w.u[0] * it.t * s, A[1] + w.u[1] * it.t * s];
      const inn = w.n;
      const d0 = (it.d + 150) * s;
      dim(sh, [A[0] + inn[0] * d0, A[1] + inn[1] * d0], [a2[0] + inn[0] * d0, a2[1] + inn[1] * d0], 0, it.t, { size: 1.9, ext: false });
    }
  }
  // 展開の方向（壁の記号 A, B, C…）
  for (const w of walls) {
    const m = [(w.a[0] + w.b[0]) / 2 + w.n[0] * 350, (w.a[1] + w.b[1]) / 2 + w.n[1] * 350];
    const c = P(...m);
    sh.layers.OUTLINE.prims.push({ t: "arc", c, r: 2.6, s: 0, d: Math.PI * 2 });
    T(sh, c[0], c[1] - 1, w.name, 2.6, "middle");
    // 矢印（壁を見る向き）
    const tip = [c[0] - w.n[0] * 4.2, c[1] - w.n[1] * 4.2];
    sh.fills.push({ pts: [tip, [c[0] + w.u[0] * 2 - w.n[0] * 2.4, c[1] + w.u[1] * 2 - w.n[1] * 2.4], [c[0] - w.u[0] * 2 - w.n[0] * 2.4, c[1] - w.u[1] * 2 - w.n[1] * 2.4]], color: "#000", layer: "OUTLINE" });
  }
  // 方位なし・面積など
  const A = Math.abs(polyArea(room.poly)) / 1e6;
  const nx = M + 4;
  let y = sh.h - M - 8;
  T(sh, nx, y, `平面図　${scaleLabel(s)}`, 4.5); y -= 7;
  T(sh, nx, y, `床面積 ${A.toFixed(2)}㎡（約 ${(A / 1.62).toFixed(1)} 畳）　天井高 CH=${room.height}`, 2.8); y -= 5;
  T(sh, nx, y, `用途: ${USES[info.brief.use]}　テイスト: ${STYLES[info.brief.style].name}`, 2.8);
  // 凡例と設計メモ（右側）
  let ny = sh.h - M - 8;
  const rx = sh.w - M - 66;
  T(sh, rx, ny, "設計メモ", 3.2); ny -= 5;
  for (const n of [...plan.notes, ...plan.warn.map((w) => "⚠ " + w)]) {
    for (const line of wrap(n, 30)) { T(sh, rx, ny, line, 2.1); ny -= 3.3; }
    ny -= 1;
    if (ny < M + 40) break;
  }
  titleBlock(sh, { ...info, title: "平面図", scale: scaleLabel(s) }, info.page, info.pages);
  return sh;
}

function dimOut(sh, a, b, out, off, value, size = 2.2) {
  // out 方向（壁の外）に off だけ離して寸法
  const u = [b[0] - a[0], b[1] - a[1]], len = Math.hypot(...u);
  if (len < 0.3) return;
  const n = [-u[1] / len, u[0] / len];
  const sgn = n[0] * out[0] + n[1] * out[1] > 0 ? 1 : -1;
  dim(sh, a, b, off * sgn, value, { size });
}
const markOf = (i) => (i < 26 ? String.fromCharCode(97 + i) : "z" + i); // 家具記号 a, b, c…
function wrap(s, n) { const out = []; let cur = ""; for (const ch of String(s)) { cur += ch; if (cur.length >= n) { out.push(cur); cur = ""; } } if (cur) out.push(cur); return out; }

// ---------------------------------------------------------------- 展開図（壁を部屋の内側から見た図）
function elevationSheets(room, plan, info) {
  const walls = wallsOf(room);
  const H = room.height;
  const sheets = [];
  // 1 枚に 2 面ずつ（上下）
  const per = 2;
  const maxLen = Math.max(...walls.map((w) => w.len));
  const size = info.size;
  const tmp = newSheet(size);
  const M = 10, availW = tmp.w - 2 * M - 40, availH = (tmp.h - 2 * M - 30 - 6) / per - 20;
  const s = pickScale(maxLen + 500, H + 350, availW, availH);
  for (let k = 0; k < walls.length; k += per) {
    const sh = newSheet(size);
    const group = walls.slice(k, k + per);
    group.forEach((w, gi) => {
      const ox = M + 25 + (availW - w.len * s) / 2;
      const oy = sh.h - M - 6 - (gi + 1) * (availH + 20) + 20;
      drawElevation(sh, room, plan, w, ox, oy, s, info.brief);
    });
    titleBlock(sh, { ...info, title: `展開図 ${group.map((w) => w.name).join("・")}`, scale: scaleLabel(s) }, 0, 0);
    sheets.push(sh);
  }
  return sheets;
}

function drawElevation(sh, room, plan, w, ox, oy, s, brief) {
  const H = room.height;
  const P = (t, z) => [ox + t * s, oy + z * s];
  // 内側から見る: 左が壁の始点（a）
  rectP(sh, "WALL", ...P(0, 0), ...P(w.len, H));
  // 床・天井の線を少し外へ
  L(sh, "WALL", P(-200, 0), P(w.len + 200, 0));
  L(sh, "WALL", P(-200, H), P(w.len + 200, H));
  T(sh, P(-220, 0)[0], P(0, 0)[1] - 1, "FL", 2.2, "end");
  T(sh, P(-220, H)[0], P(0, H)[1] - 1, "CH", 2.2, "end");
  const os = room.openings.filter((o) => o.wall === w.i).sort((a, b) => a.pos - b.pos);
  for (const o of os) {
    const z0 = o.type === "window" ? o.sill : 0, z1 = z0 + o.height;
    rectP(sh, "OPENING", ...P(o.pos, z0), ...P(o.pos + o.width, z1));
    if (o.type === "window") { rectP(sh, "OPENING", ...P(o.pos + 40, z0 + 40), ...P(o.pos + o.width - 40, z1 - 40)); L(sh, "OPENING", P(o.pos + o.width / 2, z0 + 40), P(o.pos + o.width / 2, z1 - 40)); }
    else { // ドア: 吊元を示す線（くの字）
      L(sh, "HIDDEN", P(o.pos + o.width, z1), P(o.pos, z1 / 2)); L(sh, "HIDDEN", P(o.pos, z1 / 2), P(o.pos + o.width, 0));
    }
    const lab = o.type === "window" ? "窓" : o.type === "door" ? "ドア" : "開口";
    T(sh, ...P(o.pos + o.width / 2, z1 + 60), `${lab} W${o.width}×H${o.height}`, 1.9, "middle");
    // 高さの寸法
    if (o.type === "window") {
      dim(sh, P(o.pos + o.width, 0), P(o.pos + o.width, z0), -5, z0, { size: 1.9 });
      dim(sh, P(o.pos + o.width, z0), P(o.pos + o.width, z1), -5, o.height, { size: 1.9 });
    } else dim(sh, P(o.pos + o.width, 0), P(o.pos + o.width, z1), -5, z1, { size: 1.9 });
  }
  // この壁に付く家具（壁に沿って置いた物）を正面から
  const its = plan.items.filter((it) => it.wall === w.i);
  for (const it of its) {
    const z0 = it.z0 || 0;
    const a = P(it.t, z0), b = P(it.t + it.w, z0 + it.h);
    rectP(sh, "FURN", a[0], a[1], b[0], b[1]);
    // 造作: 部材を正面から見た形（扉があれば扉、なければ側板・仕切り・棚）
    if (it.builtin && brief) {
      const parts = builtinParts(it, brief).parts;
      const doors = parts.filter((p) => /扉/.test(p.part));
      const show = doors.length ? [...doors, ...parts.filter((p) => /台輪|フィラー/.test(p.part) && !/後/.test(p.note))] : parts.filter((p) => !/背板/.test(p.part) && !/後/.test(p.note));
      for (const p of show) {
        const b = p.box;
        const A = P(it.t + b[0], z0 + b[2]), B = P(it.t + b[3], z0 + b[5]);
        rectP(sh, /棚/.test(p.part) && !doors.length ? "HIDDEN" : "FURN", A[0], A[1], B[0], B[1]);
      }
    }
    T(sh, ...P(it.t + it.w / 2, z0 + it.h / 2), `${it.mark || ""} ${it.name}`, 2.1, "middle", { color: "#7a4b1e" });
    dim(sh, P(it.t, z0 + it.h), P(it.t + it.w, z0 + it.h), 4 + (it.h > H - 100 ? 4 : 0), it.w, { size: 1.9 });
    dim(sh, P(it.t, 0), P(it.t, z0 + it.h), 4, it.h, { size: 1.9 });
  }
  // 壁の長さ・天井高
  dim(sh, P(0, 0), P(w.len, 0), -8, w.len, { size: 2.3 });
  dim(sh, P(w.len, 0), P(w.len, H), -10, H, { size: 2.3 });
  T(sh, ox, oy - 15, `展開図 ${w.name}`, 3.6);
}

// ---------------------------------------------------------------- 表（家具表・部材表）
function tableSheets(room, plan, info) {
  const brief = info.brief;
  const rowsF = plan.items.map((it) => [it.mark || "", it.name, it.builtin ? "造作" : "置き家具", `${it.w}`, `${it.d}`, `${it.h}`, it.material, it.wall != null ? `壁 ${wallsOf(room)[it.wall].name}` : "部屋の中"]);
  const cut = cutListAll(plan, brief);
  const rowsC = cut.rows.map((r) => [r.item, r.part, r.mat, `${r.L}`, `${r.W}`, `${r.T}`, `${r.qty}`, r.note]);
  const rowsH = cut.hw.map((h) => [h.item, h.name, `${h.qty}`, h.note || ""]);
  const rowsO = room.openings.map((o) => [`壁 ${wallsOf(room)[o.wall]?.name || "?"}`, o.type === "door" ? "ドア" : o.type === "window" ? "窓" : "開口", `${o.pos}`, `${o.width}`, `${o.height}`, `${o.sill}`]);
  const blocks = [
    { title: "家具・造作リスト", head: ["記号", "名前", "区分", "幅", "奥行", "高さ", "材料", "位置"], cols: [12, 42, 18, 18, 18, 18, 52, 26], rows: rowsF },
    { title: "部材表（造作の切り出し寸法）", head: ["家具", "部材", "材料", "長さ", "幅", "厚み", "数量", "備考"], cols: [36, 30, 44, 18, 18, 14, 14, 110], rows: rowsC },
    { title: "金物", head: ["家具", "金物", "数量", "備考"], cols: [40, 90, 18, 60], rows: rowsH },
    { title: "開口（スキャンから読み取り）", head: ["壁", "種類", "壁端から", "幅", "高さ", "床から"], cols: [20, 20, 26, 22, 22, 22], rows: rowsO },
  ];
  const sheets = [];
  let sh = null, y = 0;
  const M = 10, RH = 5.2;
  const start = () => { sh = newSheet(info.size); y = sh.h - M - 10; sheets.push(sh); };
  start();
  for (const b of blocks) {
    if (!b.rows.length) continue;
    let i = 0;
    while (i < b.rows.length) {
      if (y < M + 40 + RH * 3) start();
      T(sh, M + 6, y, b.title + (i ? "（つづき）" : ""), 3.6); y -= 4;
      const x0 = M + 6;
      const drawRow = (cells, bold) => {
        let x = x0;
        rectP(sh, "TABLE", x0, y - RH, x0 + b.cols.reduce((s, c) => s + c, 0), y);
        cells.forEach((c, k) => { if (k) L(sh, "TABLE", [x, y], [x, y - RH]); T(sh, x + 1.2, y - RH + 1.5, clip(c, b.cols[k]), bold ? 2.4 : 2.2, "start", bold ? { color: "#333" } : {}); x += b.cols[k]; });
        y -= RH;
      };
      drawRow(b.head, true);
      while (i < b.rows.length && y > M + 34) drawRow(b.rows[i++]);
      y -= 7;
    }
  }
  for (const s2 of sheets) titleBlock(s2, { ...info, title: "家具表・部材表", scale: "—" }, 0, 0);
  return sheets;
}
function clip(s, colW) { s = String(s ?? ""); const max = Math.floor(colW / 2.3); return s.length > max ? s.slice(0, max - 1) + "…" : s; }

// ---------------------------------------------------------------- 間取り図（複数の部屋）
function layoutSheet(layout, idx, info) {
  const sh = newSheet(info.size);
  const all = layout.rooms.flatMap((r) => r.poly.map(([x, y]) => [x + r.origin[0], y + r.origin[1]]));
  const bb = bbox2(all);
  const M = 10, availW = sh.w - 2 * M - 75, availH = sh.h - 2 * M - 30 - 18;
  const s = pickScale(bb.w + 1600, bb.h + 1600, availW, availH);
  const ox = M + 4 + (availW - bb.w * s) / 2 - bb.x0 * s, oy = M + 30 + (availH - bb.h * s) / 2 - bb.y0 * s;
  const P = (x, y) => [ox + x * s, oy + y * s];
  const seen = new Set();
  layout.rooms.forEach((r, i) => {
    const abs = r.poly.map(([x, y]) => P(x + r.origin[0], y + r.origin[1]));
    if (i === idx) sh.fills.push({ pts: abs, color: "#fbe3d0", layer: "WALL", under: true });
    sh.layers.WALL.prims.push({ t: "poly", pts: [...abs, abs[0]] });
    // 部屋名・広さ（輪郭の中の点）
    const b = bbox2(r.poly);
    let c = [b.x0 + b.w / 2, b.y0 + b.h / 2];
    if (!pointInPoly(c, r.poly)) { const w0 = wallsOf(r)[0]; c = [w0.a[0] + w0.u[0] * w0.len / 2 + w0.n[0] * 600, w0.a[1] + w0.u[1] * w0.len / 2 + w0.n[1] * 600]; }
    const C = P(c[0] + r.origin[0], c[1] + r.origin[1]);
    const A = Math.abs(polyArea(r.poly)) / 1e6;
    const big = b.w * s > 18 && b.h * s > 10;
    T(sh, C[0], C[1] + (big ? 1 : -1), r.name, big ? 4 : 2.2, "middle", i === idx ? { color: "#b54f12" } : {});
    if (big) T(sh, C[0], C[1] - 4, `${(A / 1.62).toFixed(1)}帖  ${Math.round(b.w)}×${Math.round(b.h)}`, 2.4, "middle", { color: "#555" });
    // ドア・窓（部屋どうしで重なる物は 1 回だけ）
    for (const o of r.openings) {
      const w = wallsOf(r)[o.wall]; if (!w) continue;
      const a = [w.a[0] + w.u[0] * o.pos + r.origin[0], w.a[1] + w.u[1] * o.pos + r.origin[1]];
      const e = [a[0] + w.u[0] * o.width, a[1] + w.u[1] * o.width];
      const key = [a, e].map((q) => q.map((v) => Math.round(v / 100)).join(",")).sort().join("|") + o.type;
      if (seen.has(key)) continue;
      seen.add(key);
      if (o.type === "window") { L(sh, "OPENING", P(...a), P(...e)); const n = [w.n[0] * 60, w.n[1] * 60]; L(sh, "OPENING", P(a[0] - n[0], a[1] - n[1]), P(e[0] - n[0], e[1] - n[1])); }
      else { const A2 = P(...a), E2 = P(...e); sh.fills.push({ pts: [A2, E2, P(e[0] + w.n[0] * 40, e[1] + w.n[1] * 40), P(a[0] + w.n[0] * 40, a[1] + w.n[1] * 40)], color: "#ffffff", layer: "OPENING" }); L(sh, "OPENING", A2, P(a[0] + w.n[0] * o.width, a[1] + w.n[1] * o.width)); sh.layers.OPENING.prims.push({ t: "arc", c: A2, r: o.width * s, s: Math.atan2(w.u[1], w.u[0]), d: Math.PI / 2 * (w.u[0] * w.n[1] - w.u[1] * w.n[0] > 0 ? 1 : -1) }); }
    }
  });
  // 全体の寸法
  dim(sh, P(bb.x0, bb.y0), P(bb.x1, bb.y0), -8, bb.w, { size: 2.5 });
  dim(sh, P(bb.x0, bb.y0), P(bb.x0, bb.y1), 8, bb.h, { size: 2.5 });
  const tot = layout.rooms.reduce((a, r) => a + Math.abs(polyArea(r.poly)), 0) / 1e6;
  let y = sh.h - M - 8;
  T(sh, M + 4, y, `間取り図　${scaleLabel(s)}`, 4.5); y -= 7;
  T(sh, M + 4, y, `${layout.rooms.length} 部屋・内法の合計 ${tot.toFixed(1)}㎡（${(tot / 1.62).toFixed(1)}帖）${idx != null && layout.rooms[idx] ? `　設計した部屋: ${layout.rooms[idx].name}` : ""}`, 2.8);
  let ny = sh.h - M - 8;
  const rx = sh.w - M - 66;
  T(sh, rx, ny, "読み取りのメモ", 3.2); ny -= 5;
  for (const n of [`作り方: ${{ trace: "写真をなぞって作成", "ai-plan": "AI が間取り図の写真から読み取り", "ai-photo": "AI が部屋の写真から推定" }[layout.source] || layout.source}`, ...(layout.notes || []), "寸法は写真からの読み取り値です。製作前に必ず実測してください"]) {
    for (const line of wrap(n, 30)) { T(sh, rx, ny, line, 2.1); ny -= 3.3; }
    ny -= 1;
    if (ny < M + 40) break;
  }
  titleBlock(sh, { ...info, title: "間取り図", scale: scaleLabel(s) }, 0, 0);
  return sh;
}

// ---------------------------------------------------------------- まとめて
export function buildSheets(room, plan, brief, opts = {}) {
  const info = { size: opts.size || "A3", project: opts.project || room.name || "内装計画", company: opts.company || "", author: opts.author || "", date: opts.date || new Date().toISOString().slice(0, 10), brief };
  plan.items.forEach((it, i) => { it.mark = markOf(i); });
  const list = [];
  if (opts.layout && opts.layout.rooms?.length > 1) list.push({ name: "間取り図", sheet: layoutSheet(opts.layout, opts.roomIdx, info) });
  list.push({ name: "平面図", make: () => planSheet(room, plan, info) });
  const el = elevationSheets(room, plan, info);
  el.forEach((s2, i) => list.push({ name: `展開図${i + 1}`, sheet: s2 }));
  const tb = tableSheets(room, plan, info);
  tb.forEach((s2, i) => list.push({ name: tb.length > 1 ? `部材表${i + 1}` : "家具表・部材表", sheet: s2 }));
  const sheets = list.map((x) => x.sheet || x.make());
  // ページ番号を入れ直す
  const n = sheets.length;
  sheets.forEach((s2, i) => {
    const t = s2.texts.find((t2) => /^\d+\/\d+$/.test(t2.text));
    if (t) t.text = `${i + 1}/${n}`;
    s2.name = list[i].name;
  });
  return sheets;
}

// 部材表 CSV（Excel で開けるように BOM 付き）
export function cutCSV(plan, brief) {
  const { rows, hw } = cutListAll(plan, brief);
  const q = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const out = [["家具", "部材", "材料", "長さ", "幅", "厚み", "数量", "備考"].map(q).join(",")];
  for (const r of rows) out.push([r.item, r.part, r.mat, r.L, r.W, r.T, r.qty, r.note].map(q).join(","));
  out.push("");
  out.push(["家具", "金物", "数量", "備考"].map(q).join(","));
  for (const h of hw) out.push([h.item, h.name, h.qty, h.note || ""].map(q).join(","));
  return "﻿" + out.join("\r\n") + "\r\n";
}
export { rnd };
