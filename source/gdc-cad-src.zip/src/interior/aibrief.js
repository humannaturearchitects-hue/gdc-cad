// 内装: AI（Claude）で設計方針を読み取る（任意）。
// 送るもの: 方針の文と、部屋の大きさ・ドア/窓の数だけ（スキャンの点群は送らない）。
// 配置と寸法の計算は、このソフトの決まり（planner.js）が行う。AI は「何を・どんな感じで」を決めるだけ。
import Anthropic from "@anthropic-ai/sdk";
import { USES, STYLES, KINDS } from "./policy.js";
import { wallsOf, polyArea } from "./room.js";

const ITEM_KEYS = Object.keys(KINDS).filter((k) => k !== "sofa_wall");
const SCHEMA = {
  type: "object",
  properties: {
    use: { type: "string", enum: Object.keys(USES) },
    style: { type: "string", enum: Object.keys(STYLES) },
    storage: { type: "integer", description: "収納の量 0=少なめ 1=ふつう 2=多め" },
    items: { type: "array", items: { type: "string", enum: ITEM_KEYS }, description: "置く家具・造作（同じ物を複数置くときは繰り返す）" },
    people: { type: "integer", description: "使う人数。不明なら 0" },
    bedW: { type: "integer", description: "ベッド幅 mm（970/1200/1400/1600/1800）。ベッドが無ければ 0" },
    thickness: { type: "integer", description: "造作の板厚 mm（ふつう 18）" },
    keepWindow: { type: "boolean", description: "窓を背の高い家具でふさがない" },
    toCeil: { type: "boolean", description: "背の高い収納を天井まで作る" },
    notes: { type: "array", items: { type: "string" }, description: "読み取った方針の要点（日本語・短く・3〜6 個）" },
  },
  required: ["use", "style", "storage", "items", "people", "bedW", "thickness", "keepWindow", "toCeil", "notes"],
  additionalProperties: false,
};

const SYSTEM = `あなたは日本の内装設計者です。施主の「設計の方針」を読み、部屋に置く家具・造作家具の種類とテイストを決めます。
寸法と配置はソフトが自動で計算するので、あなたは種類・量・テイストだけを JSON で返してください。
家具の種類（items に使うキー）:
${ITEM_KEYS.map((k) => `- ${k}: ${KINDS[k].name}${KINDS[k].builtin ? "（造作）" : ""}`).join("\n")}
用途（use）: ${Object.entries(USES).map(([k, v]) => `${k}=${v}`).join(", ")}
テイスト（style）: ${Object.entries(STYLES).map(([k, v]) => `${k}=${v.name}`).join(", ")}
部屋の広さに対して置きすぎないこと（家具が床の 40% を超えない目安）。方針に書かれていない物は、用途から自然に必要な物だけ足す。`;

export async function askBriefAI({ apiKey, model = "claude-opus-5-5", policy, room, fallback }) {
  const client = new Anthropic({ apiKey, dangerouslyAllowBrowser: true, timeout: 60000, maxRetries: 1 });
  const W = wallsOf(room);
  const area = Math.abs(polyArea(room.poly)) / 1e6;
  const desc = `部屋: 床 ${area.toFixed(1)}㎡、天井高 ${room.height}mm、壁 ${W.length} 面（${W.map((w) => `${w.name}=${Math.round(w.len)}mm`).join("、")}）、ドア ${room.openings.filter((o) => o.type === "door").length}、窓 ${room.openings.filter((o) => o.type === "window").length}`;
  const res = await client.messages.create({
    model,
    max_tokens: 2000,
    system: [{ type: "text", text: SYSTEM, cache_control: { type: "ephemeral" } }],
    messages: [{ role: "user", content: `${desc}\n\n設計の方針:\n${policy}` }],
    output_config: { format: { type: "json_schema", schema: SCHEMA }, effort: "low" },
  });
  if (res.stop_reason === "refusal") throw new Error("AI がこの方針を処理できませんでした");
  const out = JSON.parse(res.content.filter((b) => b.type === "text").map((b) => b.text).join(""));
  const items = (out.items || []).filter((k) => KINDS[k]);
  return {
    ...fallback,
    use: USES[out.use] ? out.use : fallback.use,
    style: STYLES[out.style] ? out.style : fallback.style,
    storage: Math.max(0, Math.min(2, out.storage | 0)),
    items: items.length ? items : fallback.items,
    people: out.people > 0 ? out.people : fallback.people,
    bedW: out.bedW >= 900 ? out.bedW : fallback.bedW,
    thickness: out.thickness >= 9 && out.thickness <= 40 ? out.thickness : fallback.thickness,
    keepWindow: out.keepWindow !== false,
    toCeil: out.toCeil !== false,
    notes: [`用途: ${USES[out.use] || USES[fallback.use]}`, `テイスト: ${(STYLES[out.style] || STYLES[fallback.style]).name}`, ...(out.notes || [])],
    byAI: true,
  };
}
