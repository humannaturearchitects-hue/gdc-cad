// AI の「頭脳」を選ぶ: 端末内 AI（既定・無料）／自分のパソコンの AI（無料）／ほかの AI アプリ（コピー＆貼り付け）／Claude（有料）
// commandline.js からは「どの頭脳に聞くか」だけをここに任せる。AI が使えない・準備中のときは、
// 言葉の解釈（nlu.js があればそれ、なければ voice.js の書き直し）で決まった書き方に直して実行する。
import { store } from "./store.js";
import { call } from "./kernel.js";
import { esc } from "./commands.js";
import { checkAgainst, buildContext, interpret } from "./nlu.js";
import { askAI, AI_MODELS } from "./ai.js";
import { localEngine, askLocal, checkSupport, LOCAL_MODELS, localModelKey, setLocalModelKey, localModelInfo } from "./localai.js";
import { pcConfig, setPcConfig, listModels, testConnection, askPC, baseUrl } from "./pcai.js";
import { buildPastePrompt, extractCommands } from "./pasteai.js";

export const BRAINS = [
  ["local", "端末内 AI（無料・データは外に出ない）"],
  ["nlu", "端末の中の読み取り（無料・AI モデルなし）"],
  ["pc", "自分のパソコンの AI（無料）"],
  ["paste", "ほかの AI アプリ（コピー＆貼り付け）"],
  ["claude", "Claude（有料・いちばん賢い）"],
];
const ls = (k, d = "") => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } };
const ss = (k, v) => { try { localStorage.setItem(k, v); } catch { /* */ } };
// 既定は端末内 AI。ただし、前の版で Claude の API キーを入れて使っていた人は Claude のまま
// 「AI を使わない」（gdc-voice-ai = 0）は「端末の中の読み取り」と同じ
export function getBrain() {
  if (ls("gdc-voice-ai") === "0") return "nlu";
  const b = ls("gdc-ai-brain");
  if (BRAINS.some(([k]) => k === b)) return b;
  return ls("gdc-ai-key") ? "claude" : "local";
}
export function setBrain(b) { ss("gdc-ai-brain", b); ss("gdc-voice-ai", b === "nlu" ? "0" : "1"); }
export const brainLabel = (b = getBrain()) => (BRAINS.find(([k]) => k === b) || BRAINS[0])[1].replace(/（.*$/, "");

// 端末内 AI に渡す今のモデル（部品名・外形・位置、タイムラインの名前、選択中のもの）
export async function localModelOf(app) {
  const ms = app.meshes || [], bodies = [];
  if (ms.length) {
    try {
      const r = await call("measure", { ids: ms.map((m) => m.id), density: 1 });
      for (const b of r.list) { const [lo, hi] = b.bounds; bodies.push({ name: b.name, size: [0, 1, 2].map((i) => hi[i] - lo[i]), min: lo, max: hi }); }
    } catch { for (const m of ms) bodies.push({ name: m.name, size: [0, 0, 0], min: [0, 0, 0], max: [0, 0, 0] }); }
  }
  const features = (store.project.features || []).map((f) => f.name).filter(Boolean);
  const nm = (id) => ms.find((m) => m.id === id)?.name;
  const selected = [...new Set((app.selection || []).map((x) => nm(x.bodyId)).filter(Boolean))];
  return { bodies, features, selected };
}

// ---- 端末内 AI の準備（同意 → ダウンロード → 読み込み） ---------------------------------
function progressItem(cl) {
  cl.log(`<div class="lai-prog"><progress max="1" value="0"></progress> <span>端末内 AI を準備しています…</span></div>`, "ai lai");
  const el = [...document.querySelectorAll(".lai-prog")].pop();
  const off = localEngine.on((e) => {
    if (!el || !el.isConnected) return;
    el.querySelector("progress").value = e.progress || 0;
    const pct = Math.round((e.progress || 0) * 100);
    el.querySelector("span").textContent = e.state === "ready" ? "✓ 端末内 AI の準備ができました" : e.state === "error" ? "✗ " + (e.error || "") : `端末内 AI を準備しています… ${pct}%`;
  });
  return { done: (ok, msg) => { off(); if (el) { el.querySelector("progress").value = ok ? 1 : el.querySelector("progress").value; el.querySelector("span").textContent = msg; } } };
}
// 初回のダウンロードの同意（大きさ・Wi-Fi 推奨・データは外に出ない）
function askDownload(info) {
  if (ls("gdc-local-consent-" + info.key) === "1") return true;
  const ok = window.confirm(`端末内 AI をこの端末にダウンロードします\n\n大きさ: 約 ${info.mb} MB（Wi-Fi で使ってください）\n動かすのに使うメモリ: 約 ${(info.mem / 1000).toFixed(1)} GB（iPhone 15 以降・Safari 26 以降／パソコンの Chrome・Edge）\n\n一度ダウンロードすれば、次からはインターネットなしで使えます。\n頼んだ言葉や設計データは、どこにも送られません（この端末の中だけで考えます）。\n\nダウンロードしますか？`);
  if (ok) ss("gdc-local-consent-" + info.key, "1");
  return ok;
}
// 端末内 AI が使える状態にする。使えないとき（WebGPU なし・未ダウンロード・同意なし・失敗）は理由を返す
// ask: まだダウンロードしていないとき、同意を聞いてダウンロードを始めるか（false なら offer: true を返すだけ＝すぐ読み取りで動く）
export async function prepareLocal(cl, { wait = true, ask = true } = {}) {
  if (localEngine.ready()) return { ok: true };
  const s = await checkSupport();
  if (!s.ok) return { ok: false, reason: s.reason };
  const info = localModelInfo();
  const cached = await localEngine.isCached();
  if (!cached && !ask && ls("gdc-local-consent-" + info.key) !== "1") return { ok: false, offer: true };
  if (!cached && !askDownload(info)) return { ok: false, reason: "端末内 AI はダウンロードしていません（⚙ 設定からいつでもダウンロードできます）" };
  const p = progressItem(cl);
  const job = localEngine.load().then(() => p.done(true, "✓ 端末内 AI の準備ができました"), (e) => { p.done(false, "✗ " + e.message); throw e; });
  // ダウンロードが要るとき（初回）は待たずに、その間は言葉の解釈で動かす
  if (!cached && !wait) { job.catch(() => {}); return { ok: false, pending: true, reason: "端末内 AI をダウンロードしています。終わるまでは、AI を使わない言葉の解釈で実行します" }; }
  try { await job; return { ok: true }; } catch (e) { return { ok: false, reason: e.message }; }
}

// 端末の中の読み取り（nlu）で分かるか（分かるならそれを使う＝速く確実。端末内 AI は分からないときだけ）
// 評価では、読み取りが分かったものはほぼ正しく、AI は読み取りが分からない言い方を補う役（tests/localai_eval/README.txt）
export async function nluUnderstands(cl, text) {
  try {
    const ctx = await buildContext({ app: cl.app, store, call, ctx: cl.ctx, pending: cl.nluPending });
    const r = interpret(text, ctx) || {};
    const has = !!(r.lines && r.lines.length);
    return { sure: !r.unknown && has && !r.ask, asks: !r.unknown && !!r.ask, unknown: !!r.unknown || (!has && !r.ask) };
  } catch { return { sure: false, asks: false, unknown: true }; }
}

// まだダウンロードしていない人に、端末内 AI を 1 回だけ勧める（押せばダウンロード。押さなければ読み取りのまま）
let offered = false;
export function offerLocal(cl) {
  if (offered) return; offered = true;
  const info = localModelInfo();
  cl.log(`いまは AI モデルを使わずに読み取っています。端末内 AI をダウンロードすると、もっと自由な言い方が分かります（無料・約 ${info.mb} MB・Wi-Fi 推奨。データは外に出ません）。<br><button class="btn" data-lai-offer>端末内 AI をダウンロード</button>`, "ai note");
  const b = [...document.querySelectorAll("[data-lai-offer]")].pop();
  if (b) b.onclick = async () => { b.disabled = true; const r = await prepareLocal(cl, { wait: true, ask: true }); if (!r.ok) { b.disabled = false; cl.log("✗ " + esc(r.reason), "ai err"); } };
}

// ---- ほかの AI アプリに頼む（コピー＆貼り付け） -------------------------------------------
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch { /* */ }
  try { const ta = document.createElement("textarea"); ta.value = t; ta.style.position = "fixed"; ta.style.opacity = "0"; document.body.appendChild(ta); ta.select(); const ok = document.execCommand("copy"); ta.remove(); return ok; } catch { return false; }
}
const PASTE_WARN = "⚠ ほかの AI アプリ（ChatGPT・Meta AI など）に貼ると、下の文（頼みごとと今のモデルの概要: 部品名・大きさ・位置・材料）がその会社に渡ります。発売前の設計などの機密は、「端末内 AI」か「自分のパソコンの AI」を使ってください。";
export async function runPaste(cl, text, { context } = {}) {
  const ctx = context ?? (await cl.aiContext());
  const prompt = buildPastePrompt({ instruction: text, context: ctx });
  const share = typeof navigator !== "undefined" && typeof navigator.share === "function";
  cl.log(`<div class="paste-box">
    <div class="paste-warn">${esc(PASTE_WARN)}</div>
    <div class="paste-step">① 送る内容（この内容がコピーされます）</div>
    <pre class="cmd-help paste-sent">${esc("頼みごと: " + text + "\n\n今のモデルの概要:\n" + ctx)}</pre>
    <details class="paste-all"><summary>答え方の説明も含めた全文（${prompt.length} 文字）</summary><pre class="cmd-help">${esc(prompt)}</pre></details>
    <div class="paste-btns"><button class="btn primary" data-paste-copy>📋 内容を確かめてコピー</button>${share ? `<button class="btn" data-paste-share>共有…</button>` : ""}</div>
    <div class="paste-step">② AI アプリに貼り付けて送り、返ってきた答えを全部コピーして、ここに貼り付けてください</div>
    <textarea class="paste-in" rows="4" placeholder="AI の答えをここに貼り付け"></textarea>
    <div class="paste-btns"><button class="btn primary" data-paste-read>③ 答えからコマンドを取り出す</button></div>
  </div>`, "ai paste");
  const box = [...document.querySelectorAll(".paste-box")].pop();
  if (!box) return [{ line: text, ok: true, msg: "貼り付け待ち" }];
  const agree = () => {
    if (ls("gdc-paste-consent") === "1") return true;
    const ok = window.confirm(PASTE_WARN.replace(/^⚠ /, "") + "\n\n送る内容は画面に出ているとおりです。コピーしますか？");
    if (ok) ss("gdc-paste-consent", "1");
    return ok;
  };
  const st = (t) => { let s = box.querySelector(".paste-st"); if (!s) { s = document.createElement("div"); s.className = "paste-st"; box.querySelector(".paste-btns").after(s); } s.textContent = t; };
  box.querySelector("[data-paste-copy]").onclick = async () => { if (!agree()) return; st((await copyText(prompt)) ? "✓ コピーしました。AI アプリに貼り付けて送ってください" : "コピーできませんでした。上の「全文」を開いて、長押しでコピーしてください"); };
  const sb = box.querySelector("[data-paste-share]");
  if (sb) sb.onclick = async () => { if (!agree()) return; try { await navigator.share({ text: prompt }); } catch { /* 取り消し */ } };
  box.querySelector("[data-paste-read]").onclick = () => {
    const ans = extractCommands(box.querySelector(".paste-in").value);
    if (ans.question) { cl.log("🤖 " + esc(ans.question) + "<br><small>答えを書いて、もう一度送ってください（前の頼みごとと合わせて書くと伝わります）</small>", "ai q"); return; }
    if (!ans.commands) { cl.log("答えの中にコマンドが見つかりませんでした。AI の答えを全部貼り付けたか確かめてください", "ai err"); return; }
    cl.log((ans.explanation ? "🤖 " + esc(ans.explanation) : "取り出したコマンド") + `<pre class="cmd-help">${esc(ans.commands)}</pre><button class="btn primary" data-paste-go>この内容で実行</button>`, "ai");
    const go = [...document.querySelectorAll("[data-paste-go]")].pop();
    if (go) go.onclick = async () => { go.disabled = true; const u0 = store.undoStack.length; await cl.runText(ans.commands, { compact: true }); cl.afterBatch(u0, false); };
  };
  return [{ line: text, ok: true, msg: "貼り付け待ち" }];
}

// ---- 頭脳ごとの聞き方 ------------------------------------------------------------
// 戻り値: { commands, explanation, question, raw, confirm }（confirm: 実行の前に確かめてもらう）
export async function askBrain(cl, brain, { instruction, retry, results, history, signal }) {
  if (brain === "local") {
    const m = await localModelOf(cl.app);
    // 直前に聞き返していたら、そのときの頼みごとと合わせて渡す（「穴をあけて」→「直径は？」→「8ミリで真ん中」）
    const ch = cl.chat || [], prevA = ch[ch.length - 1], prevU = ch[ch.length - 2];
    const joined = prevA && prevU && /^質問:/.test(String(prevA.content)) && prevU.content !== instruction ? `${prevU.content}。${instruction}` : instruction;
    const a = await askLocal({ instruction: joined, model: m });
    const notes = a.fixes && a.fixes.length ? [`数値を言葉に合わせて直しました: ${a.fixes.join("、")}`] : [];
    let confirm = !!(a.suspicious && a.suspicious.length), commands = a.commands;
    // 端末の中の読み取り（nlu.js）と照らし合わせる: 単位の取り違えは直したものを、食い違うときは読み取りの案を使う
    if (commands && !a.question) {
      try {
        const ctx = await buildContext({ app: cl.app, store, call, ctx: cl.ctx });
        const ck = checkAgainst(joined, commands.split("\n"), ctx);
        if (ck.suggestion && ck.suggestion.length) { commands = ck.suggestion.join("\n"); notes.push("AI の答えが頼みと食い違ったため、言葉の読み取りの案を使いました"); confirm = false; }
        else if (!ck.ok) {
          const unit = ck.issues.filter((x) => x.kind === "unit");
          if (unit.length) { commands = ck.lines.join("\n"); notes.push("単位を直しました: " + unit.map((x) => `${x.from}→${x.to}`).join("、")); }
          if (ck.issues.some((x) => x.kind !== "unit")) confirm = true;
        }
      } catch { /* 照合できなくても続ける */ }
    }
    if (confirm) notes.unshift("数値が頼みの言葉と合っているか確かめてから実行してください");
    return { ...a, commands, explanation: notes.join("。"), confirm };
  }
  if (brain === "pc") return askPC({ instruction, context: await cl.aiContext(), retry, results, history, signal });
  return askAI({ apiKey: cl.aiKey(), model: cl.aiModel(), instruction, context: await cl.aiContext(), history, retry, results, signal });
}
// 頭脳の性質: 失敗した行を直してもらえるか・調べた結果をまとめてもらえるか
export const brainCan = (b) => ({ fix: b === "pc" || b === "claude", summarize: b === "pc" || b === "claude", history: b === "pc" || b === "claude" });

// ---- ⚙ 設定（AI の種類と、それぞれの設定） ----------------------------------------------
export function brainSettingsHTML(cl) {
  const b = getBrain(), pc = pcConfig();
  return `<div class="brain-set">
    <label class="brain-pick">AI の種類 <select id="ai-brain">${BRAINS.map(([k, l]) => `<option value="${k}" ${b === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
    <div class="brain-sub" data-brain="local">
      <select id="local-model">${LOCAL_MODELS.map((m) => `<option value="${m.key}" ${localModelKey() === m.key ? "selected" : ""}>${m.label}・約 ${m.mb} MB</option>`).join("")}</select>
      <button class="btn" id="local-dl">ダウンロード／準備</button>
      <button class="btn" id="local-del">端末から消す</button>
      <span id="local-st" class="brain-st"></span>
      <div class="dlg-note">この端末の中だけで考えます（頼んだ言葉も設計データも外に出ません）。初回だけ AI をダウンロードします（Wi-Fi 推奨）。2 回目からはオフラインで使えます。小さな AI なので、むずかしい頼みは「決まった書き方」で入れるか、ほかの種類を使ってください。準備中や使えない端末では、AI を使わない言葉の解釈で動きます。</div>
    </div>
    <div class="brain-sub" data-brain="nlu">
      <div class="dlg-note">AI モデルを使わずに、この端末の中で言葉を読み取ります（無料・オフライン・すぐ使える・データは外に出ない）。決まった言い方に近いほど確実です。分からないときは聞き返します。</div>
    </div>
    <div class="brain-sub" data-brain="pc">
      <label>URL <input id="pc-url" type="url" inputmode="url" autocapitalize="off" spellcheck="false" placeholder="https://パソコン名.xxxx.ts.net" value="${esc(pc.url)}"></label>
      <label>モデル <input id="pc-model" list="pc-models" autocapitalize="off" spellcheck="false" placeholder="例: qwen2.5:14b" value="${esc(pc.model)}"><datalist id="pc-models"></datalist></label>
      <button class="btn" id="pc-list">一覧から選ぶ</button>
      <label>ヘッダー（任意） <input id="pc-header" autocapitalize="off" spellcheck="false" placeholder="ふつうは空のまま" value="${esc(pc.header)}"></label>
      <button class="btn primary" id="pc-test">接続テスト</button>
      <div id="pc-st" class="brain-st"></div>
      <div class="dlg-note">自分のパソコンで動かしている AI（Ollama・LM Studio・自作のサーバーなど、OpenAI 互換の /v1/chat/completions）に頼みます。頼みごとと今のモデルの概要は、そのパソコンにだけ送られます。iPhone から使うときは https が必要です（手順は「iPhone から自分のパソコンの AI を使う.txt」）。</div>
    </div>
    <div class="brain-sub" data-brain="paste">
      <div class="dlg-note">API もキーも要りません。頼むと、送る内容（頼みごと＋今のモデルの概要＋答え方）を画面に出すので、確かめてコピーし、好きな AI アプリに貼って送ります。返ってきた答えをここに貼ると、コマンドを取り出して、確かめてから実行します。<b>貼った先の会社にモデルの概要が渡るので、発売前の設計などの機密には使わないでください。</b></div>
    </div>
    <div class="brain-sub" data-brain="claude">
      <button class="btn" id="ai-key">${cl.aiKey() ? "API キー設定済み ✓（変更）" : "API キーを設定"}</button>
      <select id="ai-model">${AI_MODELS.map(([k, l]) => `<option value="${k}" ${cl.aiModel() === k ? "selected" : ""}>${l}</option>`).join("")}</select>
      <div class="dlg-note">AI（Anthropic の Claude）には、頼んだ言葉と今のモデルの概要（手順・部品名・外形の大きさと位置・材料・選択中のもの）だけを送ります。形のデータ（STEP など）は送りません。1 回ごとに API の利用料がかかります。</div>
    </div>
  </div>`;
}
export function wireBrainSettings(cl, el) {
  const pick = el.querySelector("#ai-brain");
  const show = () => { for (const d of el.querySelectorAll(".brain-sub")) d.hidden = d.dataset.brain !== pick.value; };
  show();
  pick.addEventListener("sync", () => { show(); refreshLocal(); });
  pick.onchange = async () => {
    setBrain(pick.value); show(); refreshLocal();
    const off = el.querySelector("#ai-off"); if (off) off.checked = pick.value === "nlu";
    cl.log(`AI の種類を「${esc(brainLabel(pick.value))}」にしました`, "ai note");
    // 端末内 AI をはっきり選んだら、その場で準備（初回は同意を聞いてダウンロード）
    if (pick.value === "local") { const r = await prepareLocal(cl, { wait: true, ask: true }); if (!r.ok) cl.log("✗ " + esc(r.reason), "ai err"); refreshLocal(); }
  };
  // 端末内 AI
  const lst = el.querySelector("#local-st");
  const refreshLocal = async () => {
    if (!lst || pick.value !== "local" || !el.querySelector(".cmd-set")?.open) return; // 設定を開いたときだけ
    if (typeof navigator === "undefined" || !navigator.gpu) { lst.textContent = "✗ " + (await checkSupport()).reason; return; }
    if (localEngine.state === "loading") return;
    lst.textContent = localEngine.ready() ? "✓ 使えます" : localEngine.state === "error" ? "✗ " + localEngine.error : (await localEngine.isCached()) ? "✓ ダウンロード済み（使うときに読み込みます）" : "まだダウンロードしていません";
  };
  const off = localEngine.on((e) => { if (!lst.isConnected) { off(); return; } if (e.state === "loading") lst.textContent = `準備中… ${Math.round((e.progress || 0) * 100)}%`; else refreshLocal(); });
  el.querySelector(".cmd-set")?.addEventListener("toggle", refreshLocal);
  refreshLocal();
  el.querySelector("#local-model").onchange = (e) => { setLocalModelKey(e.target.value); localEngine.state = "idle"; localEngine.loadedId = null; refreshLocal(); };
  el.querySelector("#local-dl").onclick = async () => { const r = await prepareLocal(cl, { wait: true }); if (!r.ok) cl.log("✗ " + esc(r.reason), "ai err"); refreshLocal(); };
  el.querySelector("#local-del").onclick = async () => {
    if (!window.confirm("端末内 AI をこの端末から消しますか？（もう一度使うときは、ダウンロードし直します）")) return;
    try { await localEngine.remove(); try { localStorage.removeItem("gdc-local-consent-" + localModelKey()); } catch { /* */ } cl.log("端末内 AI を消しました", "ai note"); } catch (e) { cl.log("✗ " + esc(e.message), "ai err"); }
    refreshLocal();
  };
  // 自分のパソコンの AI
  const url = el.querySelector("#pc-url"), model = el.querySelector("#pc-model"), hdr = el.querySelector("#pc-header"), pst = el.querySelector("#pc-st");
  const save = () => setPcConfig({ url: url.value, model: model.value, header: hdr.value });
  for (const i of [url, model, hdr]) { i.onchange = save; i.addEventListener("keydown", (e) => e.stopPropagation()); }
  const setSt = (t, cls = "") => { pst.textContent = t; pst.className = "brain-st " + cls; };
  el.querySelector("#pc-list").onclick = async () => {
    save(); setSt("一覧を読んでいます…");
    try {
      const ids = await listModels();
      el.querySelector("#pc-models").innerHTML = ids.map((m) => `<option value="${esc(m)}"></option>`).join("");
      if (!ids.length) { setSt("モデルが 1 つも入っていません。パソコンの AI にモデルを入れてください", "err"); return; }
      if (!model.value || !ids.includes(model.value)) { model.value = ids[0]; save(); }
      setSt(`✓ ${ids.length} 個のモデルがあります: ${ids.slice(0, 6).join("、")}${ids.length > 6 ? " …" : ""}（入力欄で選べます）`, "ok");
      // 一覧から選べる小さなメニューも出す（iPhone の datalist は使いにくいため）
      let sel = el.querySelector("#pc-model-pick");
      if (!sel) { sel = document.createElement("select"); sel.id = "pc-model-pick"; model.closest("label").after(sel); }
      sel.innerHTML = ids.map((m) => `<option ${m === model.value ? "selected" : ""}>${esc(m)}</option>`).join("");
      sel.onchange = () => { model.value = sel.value; save(); };
    } catch (e) { setSt("✗ " + e.message, "err"); }
  };
  el.querySelector("#pc-test").onclick = async () => {
    save(); setSt(`${baseUrl(url.value) || "（URL なし）"} に問い合わせています…`);
    try {
      const r = await testConnection();
      if (!model.value) { model.value = r.model; save(); }
      setSt(`✓ つながりました（${r.model}、${(r.ms / 1000).toFixed(1)} 秒）。返事: 「${r.reply}」`, "ok");
    } catch (e) { setSt("✗ " + e.message, "err"); }
  };
}
