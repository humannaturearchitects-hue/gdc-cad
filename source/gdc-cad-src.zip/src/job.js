// 初めて使う人が「最初から最後まで」迷わず仕事を通せるようにする小さな穴埋め（job 担当）
//  ・ようこそ画面のボタン（直方体・AI に頼む・開く/取り込む・見本）
//  ・最初に保存するとき／ファイルに書き出すときに、ファイルの名前を聞く（「無題」のまま残さない）
import { store } from "./store.js";
import { sampleProject } from "./sample.js";
import { downloadHooks, safeFileName } from "./exporters.js";

const UNTITLED = (n) => !n || !String(n).trim() || /^無題\d*$/.test(String(n).trim());

export function installJob(app) {
  // ---- ようこそ画面のボタン
  const wl = document.getElementById("welcome");
  if (wl) wl.addEventListener("click", (e) => {
    const b = e.target.closest("[data-wl]"); if (!b) return;
    e.stopPropagation();
    const k = b.dataset.wl;
    if (k === "box") return app.runTool("box");
    if (k === "ai") return app.runTool("cmdline");
    if (k === "open") return app.importFile();
    if (k === "sample") return app.switchTo(sampleProject());
    if (k === "interior") return app.setWorkspace("interior");
  });

  // ---- 最初の保存で名前を付ける（Ctrl+S・ファイル →保存・.kcad に書き出す）
  const askName = () => {
    const p = store.project;
    if (!p.features.length || !UNTITLED(p.name)) return;
    const n = window.prompt("ファイルの名前を付けてください（ファイル一覧や、書き出すファイルの名前になります）\n例: 収納キャビネット_1800", "");
    if (n && n.trim()) store.commit((q) => { q.name = n.trim(); });
  };
  // STEP・DXF・PDF など、どの書き出しでも「無題_…」になる前に名前を聞く（断ったファイルでは、もう聞かない）
  let declined = null;
  downloadHooks.rename = (fname) => {
    const p = store.project;
    if (!/^無題/.test(String(fname)) || !UNTITLED(p.name) || declined === store.docId) return fname;
    askName();
    if (UNTITLED(store.project.name)) { declined = store.docId; return fname; }
    return String(fname).replace(/^無題\d*/, safeFileName(store.project.name));
  };
  const save = app.saveDoc.bind(app), exp = app.exportDoc.bind(app);
  app.saveDoc = async (...a) => { askName(); return save(...a); };
  app.exportDoc = async (...a) => { askName(); return exp(...a); };
}
