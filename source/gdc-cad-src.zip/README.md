# GDC GOOD DESIGN CAD

ブラウザで動く、無料のパラメトリック 3D CAD です。
スケッチ → 押し出し → フィレットのような、履歴（タイムライン）ベースのモデリングと、
三面図の図面化、DXF / PDF / STEP などへの書き出しができます。

形状計算には OpenCascade（OCCT）を WebAssembly 化した replicad を使用しています。

## 使い方（利用者向け）

`dist-portable/GDC GOOD DESIGN CAD.html` を Chrome または Edge で開くだけで動きます（インストール不要・オフライン動作）。
詳しくは `docs/はじめにお読みください.txt` を参照してください。

iPhone / iPad では、`dist/`（通常版）を https で公開し、Safari から「ホーム画面に追加」して使います
（PWA・オフライン対応）。手順は `docs/iPhoneで使うには.txt`。GitHub Pages 用の自動公開設定（`.github/workflows/pages.yml`）付き。

## 開発

```bash
npm install
npm run dev            # 開発サーバ http://127.0.0.1:5173
npm run build          # 通常版 → dist/（Webサーバで配信する場合）
npm run build:portable # 単一HTML版 → dist-portable/GDC GOOD DESIGN CAD.html
```

### 内装の自動設計（「内装」ワークスペース）

部屋の 3D スキャン（OBJ / PLY / GLB / XYZ）→ 部屋の形（天井高・壁の輪郭・ドア・窓）の自動読み取り →
方針（ふだんの言葉）→ 家具・造作の自動配置 → 平面図・展開図・家具表・部材表（PDF / DXF / SVG / CSV）→ 3D CAD へ。
使い方は `docs/内装の自動設計.txt`。

| ファイル | 役割 |
|---|---|
| `src/interior/scan.js` | スキャンの読み込み（OBJ・PLY・glTF・XYZ）、単位と上方向の自動判定 |
| `src/interior/room.js` | 点群 → 床・天井・壁の向き・直交多角形の輪郭・ドア/窓の検出、見本スキャン |
| `src/interior/policy.js` | 方針の文 → 設計条件（用途・テイスト・家具・収納量など） |
| `src/interior/aibrief.js` | （任意）Claude で方針を読み取る |
| `src/interior/planner.js` | 配置の決まりに沿った自動配置、造作家具の部材（板ごとの位置・寸法）と部材表 |
| `src/interior/sheets.js` | 平面図・展開図・表のシート（既存の SVG / DXF / PDF 書き出しを使用） |
| `src/interior/workspace.js` | 画面・3D 表示・書き出し・3D CAD への受け渡し |

テスト: `node tests/interior.unit.mjs`、`node tests/e2e/interior.cjs`（プレビューを起動してから）

### 構成

| ファイル | 役割 |
|---|---|
| `src/kernel/worker.js` | 形状計算ワーカー。フィーチャ履歴を先頭から再計算し、メッシュ・投影・書き出しを行う |
| `src/shared/expr.js` | パラメータ式の評価（日本語のパラメータ名・全角数字に対応） |
| `src/shared/sketchgeom.js` | スケッチ平面とプロファイル（閉じた輪郭）の検出 |
| `src/viewer.js` | three.js による 3D 表示、選択（面・エッジ・ボディ・プロファイル）、ビューキューブ |
| `src/sketcher.js` | スケッチ編集（線・長方形・円・円弧・多角形、数値入力、スナップ、寸法ラベル） |
| `src/commands.js` | フィーチャのダイアログ（押し出し・回転・フィレット・シェル・移動・パターン等） |
| `src/drawing.js` | 図面ワークスペース（第三角法の三面図＋等角図、外形寸法、表題欄） |
| `src/exporters.js` | DXF（R12）・SVG・PDF・OBJ・GLB の書き出し |
| `src/main.js` | 画面全体（ツールバー、ブラウザ、タイムライン、ファイル操作、計測など） |

### データ形式

`.kcad` は JSON です。`params`（パラメータ）と `features`（履歴）を持ち、
フィーチャの寸法欄には数値またはパラメータ式（例: `幅/2 - 厚さ`）を入れられます。

## ライセンス

アプリのソースコード: MIT（`LICENSE`）。
同梱ライブラリのライセンスは `docs/THIRD_PARTY_LICENSES.txt` を参照してください。
OpenCascade は LGPL-2.1（OCCT 例外付き）です。
