// 内装: ランダムな部屋の合成スキャンで、読み取りの精度を測る（node tests/interior.stress.mjs [件数] [seed]）
// 部屋の形（長方形・L 字・壁の凹み）、ドア・窓、壁ぎわの家具（壁が陰になる）、回転、ノイズ、天井の撮り残し、
// 壁の撮り残し、散らかった物、窓の外の点 を混ぜる
import { synthScan, extractRoom, rng, wallsOf, polyArea } from "../src/interior/room.js";
import { normalizePoints } from "../src/interior/scan.js";

export function randomRoom(seed) {
  const R = rng(seed * 97 + 5);
  const q = (a, b, s = 5) => Math.round((a + R() * (b - a)) / s) * s;
  const W = q(2400, 6500), D = q(2400, 6000), H = q(2250, 2700);
  let poly = [[0, 0], [W, 0], [W, D], [0, D]];
  const kind = R();
  if (kind < 0.4) { // L 字（右上を欠く）
    const a = q(700, W / 2), b = q(700, D / 2);
    poly = [[0, 0], [W, 0], [W, D - b], [W - a, D - b], [W - a, D], [0, D]];
  } else if (kind < 0.6) { // 上の壁に凹み（床の間・収納の出っ張り）
    const a = q(800, W / 3), x = q(400, W - a - 400), b = q(450, 900);
    poly = [[0, 0], [W, 0], [W, D], [x + a, D], [x + a, D - b], [x, D - b], [x, D], [0, D]];
  }
  // 壁: どれも反時計回り
  const walls = poly.map((p, i) => { const b = poly[(i + 1) % poly.length]; return Math.hypot(b[0] - p[0], b[1] - p[1]); });
  const holes = [];
  const free = (w, pos, len) => !holes.some((h) => h.wall === w && pos < h.pos + h.w + 300 && h.pos < pos + len + 300);
  const order = walls.map((_, i) => i).filter((i) => walls[i] >= 1300).sort(() => R() - 0.5);
  if (order.length) { const w = order[0], dw = q(700, 900); holes.push({ wall: w, pos: q(150, walls[w] - dw - 150), w: dw, z0: 0, z1: q(1950, 2100), door: true }); }
  const nwin = Math.floor(R() * 3);
  for (let k = 0; k < nwin; k++) {
    const w = order[(k + 1) % Math.max(1, order.length)]; if (w == null) break;
    const ww = q(600, Math.min(2000, walls[w] - 400)); if (ww < 600) continue;
    const pos = q(200, walls[w] - ww - 200), top = Math.min(H - 150, q(1900, 2200)), z0 = q(300, Math.min(1200, top - 500));
    if (free(w, pos, ww)) holes.push({ wall: w, pos, w: ww, z0, z1: top });
  }
  // 壁ぎわの家具（ドアの前には置かない）
  const boxes = [];
  const nb = Math.floor(R() * 4);
  for (let k = 0; k < nb; k++) {
    const wi = Math.floor(R() * poly.length), a = poly[wi], b = poly[(wi + 1) % poly.length];
    const L = walls[wi]; if (L < 900) continue;
    const len = q(500, Math.min(2000, L - 200)), t = q(50, L - len - 50), dep = q(350, 900), h = q(400, 2000);
    if (holes.some((x) => x.door && x.wall === wi && t < x.pos + x.w + 200 && x.pos < t + len + 200)) continue;
    const u = [(b[0] - a[0]) / L, (b[1] - a[1]) / L], n = [-u[1], u[0]];
    const p1 = [a[0] + u[0] * t, a[1] + u[1] * t], p2 = [a[0] + u[0] * (t + len) + n[0] * dep, a[1] + u[1] * (t + len) + n[1] * dep];
    boxes.push({ x0: Math.min(p1[0], p2[0]) + 1, x1: Math.max(p1[0], p2[0]) - 1, y0: Math.min(p1[1], p2[1]) + 1, y1: Math.max(p1[1], p2[1]) - 1, h });
  }
  return {
    seed, poly, height: H, holes, boxes,
    angle: R() * 90, offset: [q(-5000, 5000), q(-5000, 5000), q(-1600, 0)], upY: R() < 0.7, unit: R() < 0.8 ? "m" : "mm",
    density: 0.4 + R() * 0.9, noise: 3 + R() * 9, ceiling: 0.3 + R() * 0.65, gaps: Math.floor(R() * 7), clutter: Math.floor(R() * 3000), outside: Math.floor(R() * 300),
  };
}

// 読み取り結果と正解を比べる（向きは 90° ずつずれてもよい・壁の順番は回してよい）
export function score(spec, room) {
  const tl = wallsOf({ poly: spec.poly }).map((w) => w.len), rl = wallsOf(room).map((w) => w.len);
  const best = { verts: rl.length === tl.length, height: Math.abs(room.height - spec.height), shape: Infinity, found: -1, missed: spec.holes.length, extra: room.openings.length, posErr: 0, shift: null };
  if (!best.verts) return best;
  const shapes = [];
  for (let k = 0; k < tl.length; k++) shapes.push(Math.max(...tl.map((l, i) => Math.abs(l - rl[(i + k) % tl.length]))));
  const minShape = Math.min(...shapes);
  // 形が同じくらい合う回し方（長方形なら 2 通り）の中で、開口が一番合うもの
  for (let k = 0; k < tl.length; k++) {
    if (shapes[k] > minShape + 30) continue;
    const used = new Set();
    let found = 0, posErr = 0, typeErr = 0;
    for (const h of spec.holes) {
      const wi = (h.wall + k) % tl.length;
      const m = room.openings.findIndex((o, j) => !used.has(j) && o.wall === wi && Math.abs(o.pos - h.pos) < 120 && Math.abs(o.width - h.w) < 150);
      if (m < 0) continue;
      used.add(m); found++;
      const o = room.openings[m];
      posErr = Math.max(posErr, Math.abs(o.pos - h.pos), Math.abs(o.width - h.w));
      if ((o.type === "door") !== !!h.door) typeErr++;
    }
    const unsureTrue = [...used].filter((j) => room.openings[j].uncertain).length;
    const unsureExtra = room.openings.filter((o, j) => !used.has(j) && o.uncertain).length;
    if (found > best.found) Object.assign(best, { unsureTrue, unsureExtra, shape: shapes[k], shift: k, found, missed: spec.holes.length - found, extra: room.openings.length - found, posErr, typeErr });
  }
  return best;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const N = +process.argv[2] || 60, base = +process.argv[3] || 1;
  const rows = [];
  const t0 = Date.now();
  for (let s = base; s < base + N; s++) {
    const spec = randomRoom(s);
    const scan = synthScan(spec);
    let room, err = null;
    try { room = extractRoom(normalizePoints(scan.pts).pts); } catch (e) { err = e.message; }
    const sc = room ? score(spec, room) : { verts: false };
    rows.push({ s, sc, err, spec, room });
  }
  const ok = rows.filter((r) => r.sc.verts && r.sc.shape <= 25 && r.sc.height <= 20);
  // 開口は、形が読めた部屋だけで数える（形が崩れると壁の番号が合わないため）
  const holes = ok.reduce((a, r) => a + r.spec.holes.length, 0);
  const found = ok.reduce((a, r) => a + (r.sc.found || 0), 0), extra = ok.reduce((a, r) => a + (r.sc.extra || 0), 0), typeErr = ok.reduce((a, r) => a + (r.sc.typeErr || 0), 0);
  const posErr = Math.max(0, ...ok.map((r) => r.sc.posErr || 0));
  const uT = ok.reduce((a, r) => a + (r.sc.unsureTrue || 0), 0), uE = ok.reduce((a, r) => a + (r.sc.unsureExtra || 0), 0);
  console.log(`形: ${ok.length}/${N} 合格（頂点数一致・壁長 ±25・天井 ±20）  開口: ${found}/${holes} 検出・誤検出 ${extra}・種類違い ${typeErr}・位置/幅の最大誤差 ${posErr}mm　「要確認」の印: 誤検出 ${uE}/${extra}・正しい物 ${uT}/${found}  (${((Date.now() - t0) / N).toFixed(0)}ms/件)`);
  for (const r of rows) {
    const bad = !(r.sc.verts && r.sc.shape <= 25 && r.sc.height <= 20) || r.sc.missed || r.sc.extra;
    if (bad && process.env.V !== "0") console.log(` seed ${r.s}: ${r.err || ""} verts ${r.room ? r.room.poly.length + "/" + r.spec.poly.length : "-"} shape ${r.sc.shape?.toFixed?.(0)} h ${r.sc.height?.toFixed?.(0)} miss ${r.sc.missed} extra ${r.sc.extra}  [ang ${r.spec.angle.toFixed(0)} noise ${r.spec.noise.toFixed(0)} dens ${r.spec.density.toFixed(2)} ceil ${r.spec.ceiling.toFixed(2)} gaps ${r.spec.gaps} boxes ${r.spec.boxes.length} clutter ${r.spec.clutter}]`);
  }
}
