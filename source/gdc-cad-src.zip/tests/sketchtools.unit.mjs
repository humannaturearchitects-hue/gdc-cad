import opencascade from "../../node_modules/replicad-opencascadejs/dist/replicad_single.js";
import * as R from "../../node_modules/replicad/dist/replicad.js";
import { findLoops } from "../../src/shared/sketchgeom.js";
import { filletCorner, offsetEntity, trimAt, mirrorEntities, applyWithLinks, explodeRect } from "../../src/sketchtools.js";
const oc = await opencascade({ locateFile: () => "../../node_modules/replicad-opencascadejs/dist/replicad_single.wasm" });
R.setOC(oc);
const num = (x) => +x;
function ext(ents) {
  const loops = findLoops(ents, num); let vols = [];
  for (const l of loops) {
    let dr; if (l.kind === 'circle') dr = R.drawCircle(l.r).translate(l.cx, l.cy);
    else { let pen = R.draw(l.segs[0].a); l.segs.forEach((s, i) => { if (s.type === 'arc') pen = pen.threePointsArcTo(s.b, s.m); else if (i < l.segs.length - 1) pen = pen.lineTo(s.b); }); dr = pen.close(); }
    vols.push(Math.round(R.measureShapeVolumeProperties(dr.sketchOnPlane('XY').extrude(1)).volume));
  }
  return { n: loops.length, areas: vols };
}
const rect = { type: 'rect', x: 0, y: 0, w: 100, h: 60 };
// fillet a rect corner (R10): area = 6000 - (100 - 25π) = 6000-21.46
let e1 = filletCorner([rect], [100, 60], 10, num);
console.log('fillet rect corner', e1.length, 'ents', JSON.stringify(ext(e1)), 'expect', Math.round(6000 - (100 - 25 * Math.PI)));
// fillet all 4 corners sequentially
let e2 = [rect]; for (const P of [[0,0],[100,0],[100,60],[0,60]]) e2 = filletCorner(e2, P, 10, num);
console.log('fillet 4 corners', JSON.stringify(ext(e2)), 'expect', Math.round(6000 - 4 * (100 - 25 * Math.PI)));
// offset rounded rect outward 5
const o2 = offsetEntity(e2, 0, 5, num);
console.log('offset rounded +5', JSON.stringify(ext(o2)), 'expect', Math.round(110*70 - 4*(225 - 225*Math.PI/4)));
const o3 = offsetEntity(e2, 0, -5, num);
console.log('offset rounded -5', JSON.stringify(ext(o3)), 'expect', Math.round(90*50 - 4*(25 - 25*Math.PI/4)));
console.log('offset rect +3', JSON.stringify(offsetEntity([rect], 0, 3, num)));
// trim: rect with a vertical line crossing; trim the part of the line outside
let t = [rect, { type: 'line', x1: 50, y1: -20, x2: 50, y2: 80 }];
t = trimAt(t, 1, [50, -10], num); t = trimAt(t, t.length - 1, [50, 70], num);
console.log('trim overhangs ->', JSON.stringify(t.slice(1)), 'regions', JSON.stringify(ext(t)));
// trim circle crossing a line
let tc = [{ type: 'line', x1: -50, y1: 0, x2: 50, y2: 0 }, { type: 'circle', cx: 0, cy: 0, d: 40 }];
tc = trimAt(tc, 1, [0, -20], num);
console.log('trim circle lower half ->', JSON.stringify(tc[1]));
// mirror
console.log('mirror line about Y', JSON.stringify(mirrorEntities([{ type: 'line', x1: 10, y1: 0, x2: 30, y2: 20 }], [0], { a: [0, 0], b: [0, 1] }, num)));
// linked edit: polygon lines, move shared endpoint
const poly = [{ type:'line', x1:0,y1:0,x2:100,y2:0 },{ type:'line', x1:100,y1:0,x2:100,y2:50 },{ type:'line', x1:100,y1:50,x2:0,y2:0 }];
const moved = applyWithLinks(poly, 0, { ...poly[0], x2: 120 }, num);
console.log('linked edit', JSON.stringify(moved.map(l => [l.x1,l.y1,l.x2,l.y2])), 'closed', ext(moved).n);
