// src/nlu.js の単体テスト: 頼みごと例 → 期待するコマンドになるか（正答率を出す）
import { interpret, checkAgainst, isFixedCommand } from "../src/nlu.js";
import { CASES, CTX } from "./nlu.cases.mjs";
const verbose = process.argv.includes("-v");
const sq = (s) => s.replace(/\s+/g, " ").trim();
let ok = 0;
const fails = [];
for (const [text, ck, exp] of CASES) {
  const r = interpret(text, CTX[ck]);
  let pass;
  if (exp === "ASK") pass = !!r.ask && !r.lines.length;
  else pass = !r.ask && JSON.stringify(r.lines.map(sq)) === JSON.stringify(exp.map(sq));
  if (pass) ok++; else fails.push([text, ck, exp, r]);
  if (verbose) console.log(pass ? "○" : "×", text, "→", r.lines.join(" / "), r.ask ? "【聞き返し】" + r.ask : "", "｜", r.reply);
}
for (const [t, ck, exp, r] of fails) console.log("NG:", JSON.stringify(t), `[${ck}]`, "→", JSON.stringify(r.lines), r.ask ? "ask: " + r.ask : "", "\n   expected", JSON.stringify(exp));
// 聞き返しへの答え（つなげて読む）
let fu = 0, fn = 0;
const follow = [
  ["床板を作って", "EMPTY", "幅600 奥行400 厚さ20", [`板 幅600 奥行400 厚さ20 名前 床板`]],
  ["8ミリの穴を四隅に", "ONE", "端から30で", ["穴 上面 Ø8 位置 30,30 570,30 570,370 30,370 床板"]],
  ["角を丸めて", "ONE", "R5で", ["フィレット R5 縦の辺 床板"]],
  ["床板を回して", "ONE", "90度", ["回す 床板 90 軸 Z"]],
  ["穴を四隅にあけて", "ONE", "直径8", null], // まだ端からの距離が足りない → もう一度聞く
];
for (const [a, ck, b, exp] of follow) {
  fn++;
  const r1 = interpret(a, CTX[ck]);
  const r2 = interpret(b, { ...CTX[ck], pending: r1.pending });
  const pass = exp ? JSON.stringify(r2.lines) === JSON.stringify(exp) && !r2.ask : !!r2.ask && /端から/.test(r2.ask);
  if (pass) fu++; else console.log("NG follow:", a, "→", b, JSON.stringify(r2));
}
// 小さい AI モデルの答えの確かめ
let ck = 0, cn = 0;
const chk = [
  [["幅60センチ奥行き40で厚さ2センチの床板を作って", ["板 幅60 奥行400 厚さ20 名前 床板"], CTX.EMPTY], (r) => !r.ok && r.lines[0] === "板 幅600 奥行400 厚さ20 名前 床板"],
  [["幅60センチ奥行き40で厚さ2センチの床板を作って", ["板 幅600 奥行400 厚さ20 名前 床板"], CTX.EMPTY], (r) => r.ok],
  [["四隅に8ミリの穴を端から30で", ["穴 上面 Ø8 位置 30,30 570,30 570,370 30,370 床板"], CTX.ONE], (r) => r.ok],
  [["四隅に8ミリの穴を端から30で", ["穴 上面 Ø8 位置 20,20 580,20 580,380 20,380 床板"], CTX.ONE], (r) => !r.ok && r.suggestion],
  [["床板を赤くして", ["床板を赤く"], CTX.ONE], (r) => !r.ok && r.issues.some((i) => i.kind === "syntax")],
  [["右に100動かして", ["移動 床板 100,0,0"], CTX.ONE], (r) => r.ok],
];
for (const [[t, l, c], f] of chk) { cn++; const r = checkAgainst(t, l, c); if (f(r)) ck++; else console.log("NG check:", t, l, JSON.stringify(r.issues), r.lines); }
const fx = ["板 幅600 奥行400 厚さ20 名前 床板", "フィレット R5 縦の辺 床板", "STEP で書き出し", "元に戻す 3", "置く 柱 上 床板 中央"].every((l) => isFixedCommand(l)) && !["床板を赤く", "板を作って"].some((l) => isFixedCommand(l));
console.log(`nlu cases: ${ok}/${CASES.length} (${(ok / CASES.length * 100).toFixed(1)}%)`);
console.log(`nlu follow-up: ${fu}/${fn}  check: ${ck}/${cn}  fixed: ${fx ? 1 : 0}/1`);
console.log(`nlu unit: ${ok + fu + ck + (fx ? 1 : 0)}/${CASES.length + fn + cn + 1}`);
// 調整に使っていない別の言い回し（正答率を正直に見る）
const { HELDOUT } = await import("./nlu.heldout.mjs");
let hok = 0;
for (const [text, ck, exp] of HELDOUT) {
  const r = interpret(text, CTX[ck]);
  const pass = exp === "ASK" ? !!r.ask && !r.lines.length : !r.ask && JSON.stringify(r.lines.map(sq)) === JSON.stringify(exp.map(sq));
  if (pass) hok++; else console.log("NG heldout:", JSON.stringify(text), `[${ck}]`, "→", JSON.stringify(r.lines), r.ask ? "ask: " + r.ask : "", "\n   expected", JSON.stringify(exp));
}
console.log(`nlu heldout: ${hok}/${HELDOUT.length} (${(hok / HELDOUT.length * 100).toFixed(1)}%)`);
const { HELDOUT2 } = await import("./nlu.heldout2.mjs");
let h2 = 0;
for (const [text, ck, exp] of HELDOUT2) {
  const r = interpret(text, CTX[ck]);
  const pass = exp === "ASK" ? !!r.ask && !r.lines.length : !r.ask && JSON.stringify(r.lines.map(sq)) === JSON.stringify(exp.map(sq));
  if (pass) h2++; else console.log("NG heldout2:", JSON.stringify(text), `[${ck}]`, "→", JSON.stringify(r.lines), r.ask ? "ask: " + r.ask : "", "\n   expected", JSON.stringify(exp));
}
console.log(`nlu heldout2: ${h2}/${HELDOUT2.length} (${(h2 / HELDOUT2.length * 100).toFixed(1)}%)`);
const { HELDOUT3 } = await import("./nlu.heldout3.mjs");
let h3 = 0;
for (const [text, ck, exp] of HELDOUT3) {
  const r = interpret(text, CTX[ck]);
  const pass = exp === "ASK" ? !!r.ask && !r.lines.length : !r.ask && JSON.stringify(r.lines.map(sq)) === JSON.stringify(exp.map(sq));
  if (pass) h3++; else console.log("NG heldout3:", JSON.stringify(text), `[${ck}]`, "→", JSON.stringify(r.lines), r.ask ? "ask: " + r.ask : "", "\n   expected", JSON.stringify(exp));
}
console.log(`nlu heldout3: ${h3}/${HELDOUT3.length} (${(h3 / HELDOUT3.length * 100).toFixed(1)}%)`);
