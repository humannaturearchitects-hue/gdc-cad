import { speechToCommand } from "/home/user/kobocad/src/voice.js";
const cases = [
  ["板、幅600、奥行き400、厚さ20、名前 床板", "板 幅600 奥行き400 厚さ20 名前 床板"],
  ["板 600かける400かける20", "板 600x400x20"],
  ["穴 上面 ファイ8 位置 30 25 570 25 570 375 30 375", "穴 上面 Ø8 位置 30,25 570,25 570,375 30,375"],
  ["フィレット アール5 縦の辺", "フィレット R5 縦の辺"],
  ["移動 柱 0 0 100", "移動 柱 0,0,100"],
  ["円 100 100 直径50。押し出し 20", "円 100,100 直径50\n押し出し 20"],
  ["床板 厚さ 30ミリ", "床板 厚さ 30"],
  ["プレスプル 上面 マイナス5", "プレスプル 上面 -5"],
  ["穴1 径 6点5", "穴1 径 6.5"],
  ["面取り シー2 上の辺 それから STEPで書き出し", "面取り C2 上の辺\nSTEPで書き出し"],
];
let ok = 0;
for (const [a, b] of cases) { const r = speechToCommand(a); const pass = r === b; if (pass) ok++; else console.log("NG:", JSON.stringify(a), "→", JSON.stringify(r), "expected", JSON.stringify(b)); }
console.log(`speech unit: ${ok}/${cases.length}`);
