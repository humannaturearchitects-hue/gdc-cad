const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  const P = (features) => ({ format:'kobocad', version:1, name:'機能テスト2', units:'mm', params:[], bodyProps:{}, rollback:null, drawing:null, features });
  const box = { id:'b', type:'box', name:'b', position:['0','0','0'], w:'100', d:'100', h:'20', operation:'new' };
  const cases = {
    'hole simple through (Ø10)': { f:[box, { id:'h', type:'hole', name:'h', points:[[50,50,20,0,0,1]], style:'simple', d:'10', through:true }], expect: 100*100*20 - Math.PI*25*20 },
    'hole x2 cbore': { f:[box, { id:'h', type:'hole', name:'h', points:[[25,25,20,0,0,1],[75,75,20,0,0,1]], style:'cbore', d:'10', through:true, cboreD:'18', cboreDepth:'6' }], expect: 200000 - 2*(Math.PI*25*14 + Math.PI*81*6) },
    'hole csink blind': { f:[box, { id:'h', type:'hole', name:'h', points:[[50,50,20,0,0,1]], style:'csink', d:'10', through:false, depth:'15', csinkD:'20', csinkAngle:'90' }], expect: null },
    'circular pattern 6': { f:[{ id:'c', type:'cylinder', name:'c', position:['100','0','0'], axis:'Z', d:'20', h:'10', operation:'new' }, { id:'cp', type:'cpattern', name:'cp', bodies:['B_c'], axis:'Z', center:['0','0','0'], count:'6', angle:'360', join:false }], bodies: 6 },
    'presspull +30 top': { f:[box, { id:'pp', type:'presspull', name:'pp', body:'B_b', face:[50,50,20,0,0,1], distance:'30', operation:'join' }], expect: 100*100*50 },
    'presspull -5 top (cut)': { f:[box, { id:'pp', type:'presspull', name:'pp', body:'B_b', face:[50,50,20,0,0,1], distance:'-5', operation:'join' }], expect: 100*100*15 },
    'split YZ at 30': { f:[box, { id:'sp', type:'split', name:'sp', body:'B_b', plane:'YZ', offset:'30' }], bodies: 2, expect: 200000 },
    'loft rect->circle': { f:[ { id:'s1', type:'sketch', name:'s1', plane:{type:'std',name:'XY',offset:'0'}, entities:[{type:'rect',x:-50,y:-50,w:100,h:100}] }, { id:'s2', type:'sketch', name:'s2', plane:{type:'std',name:'XY',offset:'80'}, entities:[{type:'circle',cx:0,cy:0,d:60}] }, { id:'l', type:'loft', name:'l', sections:[{sketch:'s1',profile:0},{sketch:'s2',profile:0}], ruled:false, operation:'new' } ], bodies: 1 },
    'align box onto box top': { f:[box, { id:'b2', type:'box', name:'b2', position:['300','0','0'], w:'50', d:'50', h:'50', operation:'new' }, { id:'al', type:'align', name:'al', body:'B_b2', from:[325,25,0,0,0,-1], toBody:'B_b', to:[50,50,20,0,0,1], mode:'center', flip:false, offset:'0' }], check: 'align' },
  };
  for (const [nm, c] of Object.entries(cases)) {
    await page.evaluate((f) => window.__store.replace(f), P(c.f));
    await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden'), null, { timeout: 30000 });
    await page.waitForTimeout(900);
    const r = await page.evaluate(async () => ({ bodies: window.__app.meshes.map(m => ({ id: m.id, bb: (() => { const v=m.vertices; let mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9]; for(let i=0;i<v.length;i+=3) for(let k=0;k<3;k++){mn[k]=Math.min(mn[k],v[i+k]);mx[k]=Math.max(mx[k],v[i+k]);} return [mn.map(Math.round), mx.map(Math.round)]; })() })), errors: window.__app.errors.map(e=>e.message) }));
    const meas = await page.evaluate(() => window.__app.constructor ? null : null);
    let vol = null;
    try { vol = await page.evaluate(async () => { const k = window.__app; const res = await new Promise((resolve) => { const t = setInterval(() => { if (document.getElementById('busy').classList.contains('hidden')) { clearInterval(t); resolve(); } }, 50); }); return null; }); } catch {}
    const tot = await page.evaluate(async () => { window.__app.selection = []; const r = await (window.__kcall ? window.__kcall('measure', { ids: [] }) : null); return r ? r.total.volume : null; });
    let msg = r.errors.length ? 'ERR ' + r.errors.join('; ') : 'ok';
    if (c.bodies && r.bodies.length !== c.bodies) msg += ` BODIES ${r.bodies.length}!=${c.bodies}`;
    if (c.expect && tot != null && Math.abs(tot - c.expect) / c.expect > 0.002) msg += ` VOL ${tot.toFixed(0)} expected ${c.expect.toFixed(0)}`;
    if (c.check === 'align') { const b2 = r.bodies.find(b => b.id === 'B_b2'); msg += ' b2 bbox ' + JSON.stringify(b2.bb); }
    console.log(nm.padEnd(28), msg, tot != null ? 'vol=' + tot.toFixed(0) : '');
  }
  await browser.close();
})();
