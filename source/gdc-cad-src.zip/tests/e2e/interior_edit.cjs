// 内装: 配置を手で直す（ドラッグ・壁に吸い付く・寸法・足す・消す・決まりの確認・元に戻す・保存して開き直す）
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 }, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  page.on('dialog', (d) => d.accept());
  await page.goto('http://127.0.0.1:4173/');
  await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && window.__app.viewer, null, { timeout: 90000 });
  await page.click('.ws[data-ws=interior]');
  await page.click('[data-a=sample]');
  await page.waitForSelector('.iw-table');
  await page.click('[data-ex="1"]');
  await page.click('[data-a=design]');
  await page.waitForSelector('.iw-items li');
  await page.click('.dw-pages [data-pg="edit"]');
  await page.waitForSelector('svg.pe');
  const W = () => page.evaluate(() => window.__app.interior);
  const itemsOf = () => page.evaluate(() => window.__app.interior.plan.items.map((i) => ({ name: i.name, wall: i.wall, t: i.t, w: i.w, F: i.F })));
  const before = await itemsOf();
  console.log('items', before.map((i) => `${i.name}@${i.wall ?? 'free'}`).join(', '));
  // mm → 画面
  const scr = (x, y) => page.evaluate(([x, y]) => { const ed = window.__app.interior.editor, svg = ed.svg, b = ed.box; const p = svg.createSVGPoint(); p.x = x; p.y = b.Y1 + b.Y0 - y; const q = p.matrixTransform(svg.getScreenCTM()); return [q.x, q.y]; }, [x, y]);
  const drag = async (from, to) => { const a = await scr(...from), b = await scr(...to); await page.mouse.move(a[0], a[1]); await page.mouse.down(); for (let k = 1; k <= 8; k++) await page.mouse.move(a[0] + (b[0] - a[0]) * k / 8, a[1] + (b[1] - a[1]) * k / 8); await page.mouse.up(); await page.waitForTimeout(150); };
  // 1) テレビボード（壁 A）を壁に沿って右へ 300 動かす
  const tv = before.find((i) => /テレビ/.test(i.name));
  const c = [(tv.F.x0 + tv.F.x1) / 2, (tv.F.y0 + tv.F.y1) / 2];
  await drag(c, [c[0] - 300, c[1] + 120]);
  let after = await itemsOf();
  const tv2 = after.find((i) => /テレビ/.test(i.name));

  console.log('tv moved', tv.t, '->', tv2.t, 'wall', tv2.wall);
  if (tv2.wall !== tv.wall || Math.abs(tv2.t - (tv.t - 300)) > 20 || Math.abs(tv2.F.y0) > 1) throw new Error('snap along wall');
  // 2) ドアの前へ動かす → 決まり違反（赤）
  const door = await page.evaluate(() => window.__app.interior.state.room.openings.find((o) => o.type === 'door'));
  await drag([(tv2.F.x0 + tv2.F.x1) / 2, (tv2.F.y0 + tv2.F.y1) / 2], [door.pos + door.width / 2, 300]);
  const bad = await page.locator('.pe-it.bad').count();
  console.log('bad after moving in front of door:', bad, await page.locator('.iw-editside .iw-warn').allTextContents());
  if (!bad) throw new Error('door rule');
  // 3) 元に戻す（Ctrl+Z）
  await page.click('#btn-undo');
  await page.waitForTimeout(300);
  const tv3 = (await itemsOf()).find((i) => /テレビ/.test(i.name));
  console.log('after undo', tv3.t);
  if (Math.abs(tv3.t - tv2.t) > 1) throw new Error('undo');
  // 4) 選んで幅を変える
  await page.click('.dw-pages [data-pg="edit"]');
  const a2 = await scr((tv3.F.x0 + tv3.F.x1) / 2, (tv3.F.y0 + tv3.F.y1) / 2);
  await page.mouse.click(a2[0], a2[1]);
  await page.fill('[data-pe="w"]', '1800'); await page.dispatchEvent('[data-pe="w"]', 'change');
  await page.waitForTimeout(200);
  const tv4 = (await itemsOf()).find((i) => /テレビ/.test(i.name));
  console.log('width', tv4.w);
  if (tv4.w !== 1800) throw new Error('width');
  // 5) 家具を足す（デスク）→ 空いている所に、決まりに合って置かれる
  await page.selectOption('[data-pe-add]', 'desk');
  await page.waitForTimeout(200);
  const st5 = await page.evaluate(() => { const ws = window.__app.interior; const it = ws.plan.items[ws.plan.items.length - 1]; return { name: it.name, wall: it.wall, warn: document.querySelectorAll('.iw-editside .iw-warn').length }; });
  console.log('added', st5);
  if (st5.name !== 'デスクカウンター' || st5.warn) throw new Error('add');
  // 6) 消す
  await page.click('[data-pe-a="del"]');
  const n6 = (await itemsOf()).length;
  console.log('after delete', n6);
  // 7) 図面にも反映（平面図の家具表）・保存して開き直しても残る
  const sheetHas = await page.evaluate(() => window.__app.interior.sheets.some((s) => s.texts.some((t) => t.text.includes('1800'))));
  console.log('sheet shows 1800:', sheetHas);
  await page.waitForTimeout(1500);
  await page.reload();
  await page.waitForFunction(() => window.__app && window.__app.viewer, null, { timeout: 90000 });
  await page.click('.ws[data-ws=interior]');
  await page.waitForTimeout(500);
  const re = await page.evaluate(() => ({ manual: !!window.__app.interior.state.manual, n: window.__app.interior.plan?.items.length, w: window.__app.interior.plan?.items.find((i) => /テレビ/.test(i.name))?.w }));
  console.log('after reload', re);
  if (!re.manual || re.n !== n6 || re.w !== 1800) throw new Error('persist');
  await page.click('.dw-pages [data-pg="edit"]');
  await page.waitForTimeout(300);
  await page.screenshot({ path: 'dl/edit.png' });
  // 新しい部屋を読み込んだら、前の部屋の手直しは引き継がない
  await page.click('[data-a=sample]');
  await page.waitForTimeout(500);
  const cleared = await page.evaluate(() => window.__app.interior.state.manual);
  console.log('manual after new scan', cleared);
  if (cleared) throw new Error('manual not cleared');
  console.log('errors', errs);
  await browser.close();
  console.log(errs.length ? 'FAIL' : 'OK');
  if (errs.length) process.exit(1);
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
