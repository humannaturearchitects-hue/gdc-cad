// モデル → 手順 → 新しいファイルで実行 → 同じ形になるか（ボディごとの体積を比べる）
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext()).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', d => d.accept());
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  const vols = async () => Object.fromEntries((await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list.map(b => [b.name, +b.volume.toFixed(1)]));
  const src = `パラメータ 幅 = 600
板 幅 幅 奥行400 厚さ20 名前 床板
シェル 厚さ5 下面 床板
穴 上面 Ø8 位置 30,25 570,25 570,375 30,375
フィレット R5 縦の辺 床板
スケッチ 上面 床板
長方形 中心 300,200 幅200 高さ100
円 300,200 直径40
押し出し 50
スケッチ XY
円 700,200 直径80
押し出し 100 名前 柱
移動 柱 0,0,10
面取り C2 上の辺 柱
コピー 柱 0,300,0
ミラー 柱 YZ 位置 1000
円形パターン 柱(コピー) 3個 軸 Z 中心 700,500,0 角度 90
床板 色 木
材料 床板 合板`;
  let r = await page.evaluate((t) => window.__cmd(t), src);
  console.log('build:', r.every(x => x.ok) ? 'all ok' : JSON.stringify(r.filter(x => !x.ok)));
  const v1 = await vols();
  const script = await page.evaluate(() => window.__app.cmdline.toScript());
  console.log('--- script ---\n' + script + '\n--------------');
  // 新しいファイルで実行
  await page.evaluate(() => { window.__store.replace({ ...window.__store.project, features: [], params: [], bodyProps: {}, components: [], name: '再現' }); });
  await page.waitForTimeout(800);
  r = await page.evaluate((t) => window.__cmd(t), script);
  console.log('replay:', r.every(x => x.ok) ? 'all ok' : JSON.stringify(r.filter(x => !x.ok)));
  const v2 = await vols();
  const keys = [...new Set([...Object.keys(v1), ...Object.keys(v2)])];
  let same = 0; for (const k of keys) { const ok = v1[k] === v2[k]; if (ok) same++; else console.log('  差:', k, v1[k], v2[k]); }
  console.log(`### 再現: ${same}/${keys.length} ボディが同じ体積`, JSON.stringify(v2));
  console.log('### 色・材料:', await page.evaluate(() => window.__app.meshes.filter(m => m.name === '床板').map(m => m.color + ' ' + (m.material && m.material.name)).join()));
  await browser.close();
})();
