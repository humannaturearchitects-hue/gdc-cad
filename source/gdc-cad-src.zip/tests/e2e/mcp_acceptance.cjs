// v0.18 受け入れテスト【改善2】AI エージェント接続（MCP）
// MCP クライアント（標準入出力の JSON-RPC）として mcp/gdc-mcp.mjs を起動し、道具だけでテスト部品を作る。
// 「画面」はブラウザのタブ（人の画面と同じ）。人の操作（Ctrl+Z・タイムライン）も同じタブで確かめる。
// 使い方: npm run build && LANG=C.UTF-8 node tests/e2e/mcp_acceptance.cjs
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '../..');
const APP = process.env.APP || path.join(ROOT, 'dist');
const OUT = path.resolve(process.env.OUT || path.join(ROOT, 'dl/mcp'));
const PORT = +(process.env.MCP_PORT || 47831);
const TOKEN = 'a1b2c3d4e5f60718293a4b5c6d7e8f90';
fs.rmSync(OUT, { recursive: true, force: true });
let pass = 0, fail = 0;
const check = (name, cond, info = '') => { cond ? pass++ : fail++; console.log(`${cond ? '✓' : '✗'} ${name}${info ? '  ' + info : ''}`); };
const near = (a, b, tol = 0.01) => Math.abs(a - b) <= tol;

// ---- MCP クライアント
const srv = spawn(process.execPath, [path.join(ROOT, 'mcp/gdc-mcp.mjs'), '--port', String(PORT), '--app', APP, '--out', OUT], { env: { ...process.env, GDC_MCP_TOKEN: TOKEN }, stdio: ['pipe', 'pipe', 'pipe'] });
srv.stderr.on('data', (d) => process.stdout.write('  [server] ' + d));
let rid = 0; const pend = new Map(); let sbuf = ''; const stdoutJunk = [];
srv.stdout.on('data', (d) => { sbuf += d; let i; while ((i = sbuf.indexOf('\n')) >= 0) { const l = sbuf.slice(0, i); sbuf = sbuf.slice(i + 1); let m; try { m = JSON.parse(l); } catch { stdoutJunk.push(l); continue; } const p = pend.get(m.id); if (p) { pend.delete(m.id); p(m); } } });
const rpc = (method, params) => new Promise((res) => { const id = ++rid; pend.set(id, res); srv.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n'); });
const tool = async (name, args = {}) => { const m = await rpc('tools/call', { name, arguments: args }); if (m.error) return { isError: true, error: m.error.message }; return { isError: !!m.result.isError, ...m.result.structuredContent }; };

(async () => {
  const init = await rpc('initialize', { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'acceptance-test', version: '1' } });
  check('initialize', init.result && init.result.serverInfo.name === 'gdc-cad', JSON.stringify(init.result && init.result.serverInfo));
  srv.stdin.write(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n');
  const tl = await rpc('tools/list', {});
  const names = tl.result.tools.map((t) => t.name);
  check('tools/list has required tools', ['get_state', 'create_box', 'create_sketch_extrude', 'create_hole', 'modify_feature', 'export_file'].every((n) => names.includes(n)), names.join(','));

  // 画面がまだ開いていないとき → 開き方を案内するエラー（ここでは画面を開いてからつなぐ）
  // ---- 画面（ブラウザのタブ）を開く
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1500, height: 900 }, serviceWorkers: 'block', acceptDownloads: true });
  const page = await ctx.newPage();
  const perr = []; page.on('pageerror', (e) => { perr.push(e.message); console.log('PAGEERROR: ' + e.message); });
  const outbound = []; page.on('request', (r) => { const u = new URL(r.url()); if (!['127.0.0.1', 'localhost'].includes(u.hostname) && !r.url().startsWith('data:') && !r.url().startsWith('blob:')) outbound.push(r.url()); });
  await page.goto(`http://127.0.0.1:${PORT}/?agent=${TOKEN}`);
  await page.waitForFunction(() => window.__agent && window.__agent.state === 'on', null, { timeout: 90000 });
  check('screen connected (🤖 AI 接続 chip)', (await page.textContent('#agent-chip')).includes('AI 接続'));

  // ===== (1) AI 接続経由だけでテスト部品（60×40×厚さ5、Ø5 貫通穴 4 つ）
  let r = await tool('get_state');
  check('get_state (empty)', !r.isError && r.bodies.length === 0 && r.units === 'mm', JSON.stringify(r).slice(0, 120));
  r = await tool('create_sketch_extrude', { plane: 'XY', profiles: [{ type: 'rect', x: 0, y: 0, width: 60, height: 40 }], distance: 5, operation: 'new', name: 'テスト部品' });
  check('create_sketch_extrude 60×40 → 5', !r.isError && r.body === 'テスト部品', JSON.stringify(r));
  r = await tool('create_hole', { body: 'テスト部品', face: '上面', diameter: 5, positions: [[6, 6], [54, 6], [54, 34], [6, 34]] });
  check('create_hole Ø5 ×4 貫通', !r.isError && /Ø5 の穴を 4 個/.test(r.summary), r.summary || r.error);
  r = await tool('get_state');
  const v5 = 60 * 40 * 5 - 4 * Math.PI * 2.5 ** 2 * 5;
  let b = r.bodies.find((x) => x.name === 'テスト部品');
  check(`(1) 体積 ${b && b.volume_mm3} = 理論値 ${v5.toFixed(2)} mm³`, b && near(b.volume_mm3, v5), JSON.stringify(b));
  check('(1) 重心 = (30, 20, 2.5)', b && near(b.centroid_mm[0], 30, 1e-3) && near(b.centroid_mm[1], 20, 1e-3) && near(b.centroid_mm[2], 2.5, 1e-3), JSON.stringify(b && b.centroid_mm));
  const sk = r.features.find((f) => f.type === 'sketch');
  check('AI のスケッチは完全拘束', sk && sk.constraintStatus.status === '完全拘束' && sk.constraintStatus.dof === 0, JSON.stringify(sk && sk.constraintStatus));
  check('各手順に by: ai', r.features.length === 3 && r.features.every((f) => f.by === 'ai'), r.features.map((f) => f.name + ':' + f.by).join(','));
  const undo0 = r.undoSteps;

  // 直方体の道具も（あとで消す）
  r = await tool('create_box', { width: 10, depth: 10, height: 10, position: [100, 0, 0], name: '試し箱' });
  check('create_box', !r.isError && /10×10×10/.test(r.summary), r.summary || r.error);
  r = await tool('undo');
  check('undo (AI の道具 1 回 = 1 手)', !r.isError && r.undone === 1);
  r = await tool('get_state');
  check('undo で箱だけ消える', r.bodies.length === 1 && r.features.length === 3 && r.undoSteps === undo0, `bodies=${r.bodies.length} undo=${r.undoSteps}/${undo0}`);

  // ===== 失敗した操作は履歴を壊さずエラーを返す
  const before = JSON.stringify((await tool('get_state')).features);
  r = await tool('create_hole', { body: 'ないボディ', diameter: 5, positions: [[1, 1]] });
  check('error: 存在しないボディ', r.isError && /ないボディ/.test(r.error), r.error);
  r = await tool('run_commands', { text: '板 幅10 奥行10 厚さ10 位置 200,0,0 名前 試し\nフィレット R50 縦の辺 試し' });
  check('error: 途中で失敗したコマンド（形状エンジンのエラー）', r.isError, (r.error || '').slice(0, 140));
  r = await tool('modify_feature', { target: 'テスト部品', set: { thickness: -3 } });
  check('error: 不正な値', r.isError, r.error);
  r = await tool('get_state');
  check('失敗のあとも履歴・形は元のまま', JSON.stringify(r.features) === before && r.undoSteps === undo0 && r.bodies.length === 1, `undo=${r.undoSteps}`);

  // ===== (2) 厚さ 5 → 8
  r = await tool('modify_feature', { target: 'テスト部品', set: { thickness: 8 } });
  check('modify_feature thickness 5→8', !r.isError, r.summary || r.error);
  r = await tool('get_state');
  b = r.bodies.find((x) => x.name === 'テスト部品');
  const v8 = 60 * 40 * 8 - 4 * Math.PI * 2.5 ** 2 * 8;
  check(`(2) 厚さ 8 の体積 ${b.volume_mm3} = 理論値 18571.68 mm³`, near(b.volume_mm3, 18571.68, 0.005) && near(v8, 18571.68, 0.005), `theory=${v8.toFixed(4)} size=${b.size_mm}`);

  // ===== (3) STEP 書き出し + 読み戻し（体積一致）、STL
  r = await tool('export_file', { format: 'step', file_name: 'テスト部品' });
  const stepPath = r.path;
  check('(3) STEP 書き出し（ファイルに保存）', !r.isError && fs.existsSync(stepPath) && /ISO-10303-21/.test(fs.readFileSync(stepPath, 'utf8').slice(0, 200)), `${stepPath} ${r.bytes}B`);
  check(`(3) STEP 読み戻し: 体積 ${r.verify && r.verify.readback_volume_mm3} = ${r.verify && r.verify.model_volume_mm3}`, r.verify && r.verify.ok && near(r.verify.readback_volume_mm3, 18571.68, 0.01), JSON.stringify(r.verify));
  r = await tool('export_file', { format: 'stl', file_name: 'テスト部品' });
  check('STL 書き出し', !r.isError && fs.existsSync(r.path) && fs.statSync(r.path).size > 1000, `${r.path} ${r.bytes}B`);
  r = await tool('save_project', { file_name: 'テスト部品' });
  const kcad = r.path;
  check('.kcad 保存', !r.isError && fs.existsSync(kcad), kcad);

  // ===== (4) 画面: AI の操作が履歴（タイムライン）に残る・人が取り消せる
  await page.waitForTimeout(500);
  const tlInfo = await page.evaluate(() => [...document.querySelectorAll('#timeline .tl-item')].map((e) => ({ ai: e.classList.contains('ai'), title: e.title.split('\n')[0] })));
  check('(4) 画面のタイムラインに AI の 3 手（🤖）', tlInfo.length === 3 && tlInfo.every((x) => x.ai), JSON.stringify(tlInfo));
  await page.screenshot({ path: path.join(OUT, 'screen_after_ai.png') });
  // 人が Ctrl+Z → 厚さが 5 に戻る（AI の 1 手 = 1 回）
  await page.click('#view3d', { position: { x: 700, y: 400 } }); await page.keyboard.press('Escape');
  await page.keyboard.press('Control+z'); await page.waitForTimeout(300);
  await page.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(300);
  r = await tool('get_state');
  b = r.bodies.find((x) => x.name === 'テスト部品');
  check('(4) 人の Ctrl+Z で AI の寸法変更が 1 手戻る（体積 → 厚さ 5）', near(b.volume_mm3, v5), `${b.volume_mm3}`);
  await page.keyboard.press('Control+y'); await page.waitForTimeout(300);
  await page.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(300);
  r = await tool('get_state');
  b = r.bodies.find((x) => x.name === 'テスト部品');
  check('人の Ctrl+Y でやり直し（厚さ 8）', near(b.volume_mm3, 18571.68, 0.005), `${b.volume_mm3}`);
  // 人が画面で編集（押し出しの距離を人が 10 に）→ AI が読める
  await page.evaluate(() => window.__cmd('テスト部品 距離 10'));
  await page.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(300);
  r = await tool('get_state');
  b = r.bodies.find((x) => x.name === 'テスト部品');
  check('人の編集のあと AI が状態を読める（厚さ 10）', near(b.size_mm[2], 10, 1e-6), JSON.stringify(b.size_mm));
  await page.keyboard.press('Control+z'); await page.waitForTimeout(300);
  await page.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 });
  check('外部への通信なし（127.0.0.1 だけ）', outbound.length === 0, outbound.slice(0, 3).join(' '));
  check('MCP の標準出力は JSON-RPC だけ', stdoutJunk.length === 0, stdoutJunk.slice(0, 2).join(' | '));
  check('no page errors (agent tab)', perr.length === 0, perr.join(' / '));

  // 2 つ目のタブで同じ合言葉を開いても、仕事は 1 つのタブだけに届く
  const p3 = await (await browser.newContext({ viewport: { width: 1200, height: 800 }, serviceWorkers: 'block' })).newPage();
  await p3.goto(`http://127.0.0.1:${PORT}/?agent=${TOKEN}`);
  await p3.waitForFunction(() => window.__agent && window.__agent.state === 'other', null, { timeout: 90000 }).catch(() => {});
  check('2 つ目のタブは「別のタブが AI 接続中」', (await p3.textContent('#agent-chip').catch(() => '')).includes('別のタブ'));
  r = await tool('get_state');
  check('仕事は最初のタブに届く', r.bodies.length === 1 && r.bodies[0].name === 'テスト部品');
  await p3.context().close();

  // ===== (4b) 別の画面（ふつうに開いた GDC）で .kcad と STEP を開く
  const p2 = await (await browser.newContext({ viewport: { width: 1400, height: 850 }, serviceWorkers: 'block' })).newPage();
  p2.on('pageerror', (e) => { perr.push(e.message); console.log('PAGEERROR(2): ' + e.message); });
  await p2.goto(`http://127.0.0.1:${PORT}/`); await p2.evaluate(() => localStorage.clear()); await p2.reload();
  await p2.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  check('ふつうに開いた画面は AI 接続なし', !(await p2.$('#agent-chip')));
  { const [fc] = await Promise.all([p2.waitForEvent('filechooser'), p2.evaluate(() => { window.__app.openDoc(); })]); await fc.setFiles(kcad); }
  await p2.waitForFunction(() => window.__app.meshes.length === 1, null, { timeout: 60000 });
  await p2.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 }); await p2.waitForTimeout(500);
  const tl2 = await p2.evaluate(() => [...document.querySelectorAll('#timeline .tl-item')].map((e) => ({ ai: e.classList.contains('ai'), t: e.title.split('\n').join(' / ') })));
  check('(4) .kcad を画面で開くと AI の操作が履歴に残っている', tl2.length === 3 && tl2.every((x) => x.ai && /AI エージェントが作成/.test(x.t)), JSON.stringify(tl2));
  // 図面の自動生成（3 面図・穴表／穴の位置寸法）
  await p2.click('.ws[data-ws=drawing]');
  await p2.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 }); await p2.waitForTimeout(1000);
  const dw = await p2.evaluate(() => { const s = window.__app.drawing.sheet; return { outline: s.layers.OUTLINE.prims.length, circles: s.layers.OUTLINE.prims.filter((p) => p.t === 'circle' || p.t === 'arc').length, dims: s.layers.DIM.prims.length, texts: s.texts.map((t) => t.text) }; });
  const txt = dw.texts.join(' ');
  check('テスト部品で図面が自動生成される（3 面図＋等角・外形寸法 60/40/8・穴 Ø5）', dw.outline > 20 && /正面/.test(txt) && /平面|上面/.test(txt) && /側面/.test(txt) && dw.texts.includes('60') && dw.texts.includes('40') && dw.texts.includes('8') && /Ø5|φ5/.test(txt), `outline=${dw.outline} circles=${dw.circles} dims=${dw.dims} texts=${txt.slice(0, 300)}`);
  await p2.screenshot({ path: path.join(OUT, 'drawing_test_part.png') });
  // STEP を別の画面に取り込んで体積を測る（独立した読み戻し）
  await p2.click('.ws[data-ws=design]'); await p2.waitForTimeout(500);
  await p2.evaluate(() => window.__store.replace({ name: 'step check', features: [] }));
  await p2.waitForTimeout(500);
  { const fc = p2.waitForEvent('filechooser'); p2.evaluate(() => { window.__app.importFile(); }); await (await fc).setFiles(stepPath); }
  await p2.waitForFunction(() => window.__app.meshes.length >= 1, null, { timeout: 90000 });
  await p2.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 }); await p2.waitForTimeout(500);
  const imp = await p2.evaluate(async () => { const ids = window.__app.meshes.map((m) => m.id); const r = await window.__kcall('measure', { ids, density: 1 }); return { n: r.list.length, v: r.total.volume, names: r.list.map((x) => x.name) }; });
  check(`(3) STEP を別の画面に取り込み: 体積 ${imp.v.toFixed(3)} = 18571.68`, near(imp.v, 18571.68, 0.01), JSON.stringify(imp));
  check('no page errors', perr.length === 0, perr.join(' / '));

  console.log(`MCP acceptance: ${pass}/${pass + fail} ok`);
  await browser.close();
  srv.stdin.end(); srv.kill();
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); srv.kill(); process.exit(2); });
