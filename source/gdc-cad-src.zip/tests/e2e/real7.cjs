// 穴を座標で: 面をクリック → X,Y を数値で（4 箇所）→ 画面に寸法表示 / 2 本の辺を基準に
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(250); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const meas = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list[0];
  const tool = (t) => page.click(`.tool:has-text("${t}")`);
  const ok = async () => { await page.click('#dialog [data-act="ok"]'); await idle(); };
  const pt = (r, c) => page.locator(`#dialog [data-pt="${r}"][data-c="${c}"]`);

  await tool('スケッチ作成'); await page.click('#planebar [data-pl=XY]'); await idle();
  await page.keyboard.press('r'); await page.mouse.click(...await scr([0, 0, 0])); await page.waitForTimeout(150);
  { const a = page.locator('.inbox input'); await a.nth(0).fill('300'); await a.nth(1).fill('200'); await page.keyboard.press('Enter'); await page.waitForTimeout(250); }
  await page.keyboard.press('e'); await idle(); await page.fill('#dialog input[data-k="distance"]', '10'); await idle(); await ok();
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  const V0 = (await meas()).volume;

  // 1. 面の左下の角を基準に 4 つ
  await page.keyboard.press('h'); await idle();
  await page.mouse.click(...await scr([150, 100, 10])); await idle();
  const rows = [[30, 25], [270, 25], [270, 175], [30, 175]];
  for (let i = 0; i < rows.length; i++) {
    if (i > 0) { await page.click('#dialog [data-ptadd]'); await page.waitForTimeout(150); }
    await pt(i, 0).fill(String(rows[i][0])); await pt(i, 1).fill(String(rows[i][1]));
  }
  await page.fill('#dialog input[data-k="d"]', '8'); await idle();
  const info = await page.evaluate(() => { const d = window.__app.dialog.active.draft; const h = window.__app.holeInfo[d.id]; return { corner: h && h.corner, centers: h && h.centers.map(c => c.map(v => +v.toFixed(3))), labels: [...document.querySelectorAll('.hdim')].map(e => e.textContent) }; });
  console.log('  corner', JSON.stringify(info.corner), 'centers', JSON.stringify(info.centers));
  console.log('  labels', JSON.stringify(info.labels));
  await page.screenshot({ path: 'real7_dims.png' });
  // ラベルをクリック → 表の欄へ
  await page.locator('.hdim', { hasText: 'X 270' }).first().click(); await page.waitForTimeout(150);
  console.log('  focused', await page.evaluate(() => { const a = document.activeElement; return a.dataset.pt + ',' + a.dataset.c + '=' + a.value; }));
  await ok();
  { const m = await meas(); console.log(`### 1 角から 4 穴 Ø8: 削れた体積 ${(V0 - m.volume).toFixed(1)}（期待 2010.6）重心 (${(m.com.x ?? m.com[0]).toFixed(3)}, ${(m.com.y ?? m.com[1]).toFixed(3)})（期待 150, 100） errors ${JSON.stringify(await page.evaluate(() => window.__app.errors.map(e => e.message)))}`); }

  // 2. 2 本の辺を基準に: 辺1 = 左の辺(x=0)、辺2 = 前の辺(y=0) → (60, 40) に Ø10
  const V1 = (await meas()).volume;
  await page.keyboard.press('h'); await idle();
  await page.mouse.click(...await scr([150, 100, 10])); await idle();
  await page.selectOption('#dialog select[data-k="ref"]', 'edges'); await idle();
  await page.mouse.click(...await scr([0, 120, 10])); await idle();
  await page.mouse.click(...await scr([120, 0, 10])); await idle();
  await pt(0, 0).fill('60'); await pt(0, 1).fill('40'); await idle();
  console.log('  edge centers', await page.evaluate(() => { const d = window.__app.dialog.active.draft; const h = window.__app.holeInfo[d.id]; return JSON.stringify(h && h.centers.map(c => c.map(v => +v.toFixed(3)))); }));
  await ok();
  { const m = await meas(); const v = V1 - m.volume; const cx = (V1 * (m.com.x ?? m.com[0]) - 0) ; console.log(`### 2 辺 2 本から (60,40) Ø10: 削れた体積 ${v.toFixed(1)}（期待 785.4） errors ${JSON.stringify(await page.evaluate(() => window.__app.errors.map(e => e.message)))}`); void cx; }
  await browser.close();
})();
