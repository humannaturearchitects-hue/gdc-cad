// 形状エンジンの失敗・時間切れ・メモリ不足、AI の通信が切れたときに、画面が固まらず作業が失われないこと
//   node robust_kernel.cjs      各行の最後が "ok" なら合格（全部で 6 行）
const { chromium } = require('playwright');
const PORT = process.env.PORT || 4173;
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', (d) => (d.type() === 'prompt' ? d.accept('sk-ant-test-key') : d.accept()));
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => { localStorage.clear(); localStorage.setItem('gdc-ai-brain', 'claude'); indexedDB.deleteDatabase('gdc-cad'); }); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  const idle = (t = 90000) => page.waitForFunction(() => !window.__app.buildsRunning && document.getElementById('busy').classList.contains('hidden'), null, { timeout: t });
  const size = () => page.evaluate(async () => { const r = await window.__kcall('measure', { ids: window.__app.meshes.map((m) => m.id), density: 1 }); return r.list.map((b) => b.bounds[1].map((v, i) => +(v - b.bounds[0][i]).toFixed(1)).join('x')).join(','); });
  const ok = (b) => (b ? 'ok' : 'NG');
  await page.evaluate(() => window.__cmd('板 幅600 奥行400 厚さ20 名前 床板\n穴 上面 Ø8 位置 30,25 570,25 570,375 30,375 床板'));
  await idle();

  // 1) メモリ不足: 知らせて、再起動して、直した内容のまま計算し直す
  await page.evaluate(() => window.__kcall('oomTest', { times: 1 }));
  await page.evaluate(() => window.__cmd('床板 厚さ 30'));
  await page.waitForFunction(() => /メモリ/.test(document.getElementById('toast').textContent), null, { timeout: 30000 });
  const t1 = await page.evaluate(() => document.getElementById('toast').textContent);
  await page.waitForFunction(() => /再起動しました/.test(document.getElementById('toast').textContent), null, { timeout: 90000 });
  await idle();
  const s1 = await size();
  console.log(`1 oom: toast「${t1.slice(0, 40)}…」 size ${s1} errors ${await page.evaluate(() => window.__app.errors.length)} ${ok(s1 === '600x400x30')}`);

  // 2) 計算中に再起動しても「計算中」が消える（待っていた計算も終わらせる）
  await page.evaluate(() => { window.__kcall('hangTest', { ms: 600000 }).catch(() => {}); window.__store.commit((p) => { p.features[0].h = '25'; }); window.__store.commit((p) => { p.features[0].h = '26'; }); });
  await page.waitForTimeout(1500);
  await page.waitForSelector('#busy-act', { timeout: 20000 }); await page.click('#busy-act');
  await page.waitForFunction(() => /再起動しました/.test(document.getElementById('toast').textContent), null, { timeout: 90000 });
  await idle(90000);
  const s2 = await size();
  console.log(`2 restart while queued: busy hidden, size ${s2} ${ok(s2 === '600x400x26')}`);

  // 3) 書き出しが終わらない: 経過時間と「中止して再起動」が出て、押すと戻る
  await page.evaluate(() => { window.__kcall('hangTest', { ms: 600000 }).catch(() => {}); window.__app.export3D('stl'); });
  await page.waitForFunction(() => /（1\d 秒）/.test(document.getElementById('busy-msg').textContent) && document.getElementById('busy-act'), null, { timeout: 30000 });
  const m3 = await page.locator('#busy').innerText();
  await page.click('#busy-act');
  await idle(90000);
  await page.waitForFunction(() => window.__app.meshes.length === 1, null, { timeout: 60000 });
  console.log(`3 export hang: 「${m3.replace(/\s+/g, ' ')}」 → recovered, bodies ${await page.evaluate(() => window.__app.meshes.length)} ${ok(/中止して再起動/.test(m3))}`);

  // 4) 続けて何度も止まる: 計算を止めて、選べるお知らせを出す → もう一度計算する で戻る
  for (let k = 0; k < 3; k++) {
    await page.evaluate(() => window.__kcall('crashTest').catch(() => {}));
    await page.waitForFunction((k) => k === 2 ? !!document.getElementById('robust-banner') : /再起動しました/.test(document.getElementById('toast').textContent), k, { timeout: 60000 });
    await idle(); await page.evaluate(() => { document.getElementById('toast').textContent = ''; });
  }
  const b4 = await page.locator('#robust-banner').innerText();
  const feats4 = await page.evaluate(() => window.__store.project.features.length);
  await page.click('#robust-banner [data-rb="retry"]');
  await idle(); await page.waitForTimeout(500);
  console.log(`4 give up banner: 「${b4.replace(/\s+/g, ' ').slice(0, 60)}…」 features kept ${feats4} → retry bodies ${await page.evaluate(() => window.__app.meshes.length)} ${ok(/保存されています/.test(b4) && feats4 === 2 && !(await page.$('#robust-banner')))}`);

  // 5) AI: 返事が来ないとき「やめる」で止められ、入力した言葉が残る
  await page.route('https://api.anthropic.com/**', () => { /* 返事をしない（電波が弱い状態） */ });
  await page.click('.tool:has-text("AI に頼む")'); await page.waitForTimeout(300);
  await page.fill('#cmd-in', '床板を3センチに');
  await page.click('#cmd-run');
  await page.waitForSelector('.ai-stop', { timeout: 10000 });
  await page.click('.ai-stop');
  await page.waitForFunction(() => /やめました/.test(document.getElementById('cmd-log').innerText), null, { timeout: 10000 });
  const r5 = await page.evaluate(() => ({ text: document.getElementById('cmd-in').value, runEnabled: !document.getElementById('cmd-run').disabled, thinking: !!document.querySelector('.thinking') }));
  console.log(`5 ai stop: ${JSON.stringify(r5)} ${ok(r5.text === '床板を3センチに' && r5.runEnabled && !r5.thinking)}`);

  // 6) AI: 待っている間に電波が切れたら、すぐ知らせる
  await page.click('#cmd-run');
  await page.waitForSelector('.ai-stop', { timeout: 10000 });
  await ctx.setOffline(true);
  await page.waitForFunction(() => /接続が切れた/.test(document.getElementById('cmd-log').innerText), null, { timeout: 10000 });
  const r6 = await page.evaluate(() => ({ text: document.getElementById('cmd-in').value, runEnabled: !document.getElementById('cmd-run').disabled }));
  await ctx.setOffline(false);
  console.log(`6 ai offline: ${JSON.stringify(r6)} ${ok(r6.text === '床板を3センチに' && r6.runEnabled)}`);
  await browser.close();
})().catch((e) => { console.log('FAILED', e.message); process.exit(1); });
