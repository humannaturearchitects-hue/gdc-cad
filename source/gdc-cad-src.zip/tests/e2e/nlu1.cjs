// AI を使わない言葉の読み取り（src/nlu.js）を、画面で利用者と同じように使って確かめる
//  パソコン（Chromium 1400x850）。WK=1 で iPhone 15（WebKit）
const { chromium, webkit, devices } = require('playwright');
const PORT = process.env.PORT || 4173;
(async () => {
  const wk = !!process.env.WK;
  const browser = wk ? await webkit.launch() : await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext(wk ? { ...devices['iPhone 15'], serviceWorkers: 'block' } : { viewport: { width: 1400, height: 850 }, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  let net = 0; page.on('request', (r) => { if (!r.url().startsWith(`http://127.0.0.1:${PORT}`) && !r.url().startsWith('data:') && !r.url().startsWith('blob:')) net++; });
  const dialogs = []; page.on('dialog', (d) => { dialogs.push(d.type()); d.type() === 'prompt' ? d.dismiss() : d.accept(); });
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => { localStorage.clear(); localStorage.setItem('gdc-voice-ai', '0'); }); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.evaluate(() => window.__app.cmdline.open()); await page.waitForTimeout(300);
  const say = async (t) => {
    const n0 = await page.locator('#cmd-log .cmd-item').count();
    await page.fill('#cmd-in', t);
    if (wk) await page.tap('#cmd-run'); else await page.click('#cmd-run');
    await page.waitForTimeout(150);
    await page.waitForFunction((n) => { const it = document.querySelectorAll('#cmd-log .cmd-item'); return it.length > n + 1 && !document.getElementById('cmd-run').disabled; }, n0, { timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(700);
    const items = await page.locator('#cmd-log .cmd-item').allInnerTexts();
    return items.slice(n0).join(' | ').replace(/\s+/g, ' ');
  };
  const vols = () => page.evaluate(async () => { const ms = window.__app.meshes; if (!ms.length) return ''; const r = await window.__kcall('measure', { ids: ms.map((m) => m.id), density: 1 }); return r.list.map((b) => `${b.name}:${b.volume.toFixed(1)} [${b.bounds[0].map((v) => +v.toFixed(1))} / ${b.bounds[1].map((v) => +v.toFixed(1))}]`).join(' ; '); });
  const ok = (name, cond, extra = '') => console.log(`${cond ? '  ✓' : '  ✗'} ${name}${extra ? '  ' + extra : ''}`);

  let log = await say('幅60センチ奥行き40で厚さ2センチの床板を作って、それの四隅に8ミリの穴を端から3センチで');
  let v = await vols();
  ok('作る＋四隅の穴', /床板:4795978\.8 \[0,0,0 \/ 600,400,20\]/.test(v), v);
  ok('返事が会話に出る', /💬 床板（600×400×20）を作ります/.test(log), log.slice(0, 160));
  log = await say('穴を10ミリに変えて'); v = await vols();
  ok('穴を直す', /床板:4793716\.8/.test(v), v);
  log = await say('全部の角をR5で');
  ok('角を丸める', await page.evaluate(() => window.__store.project.features.some((f) => f.type === 'fillet' && f.edgeKind === 'all' && f.radius == 5)), log.slice(0, 120));
  log = await say('さっきの取り消して');
  ok('取り消し', await page.evaluate(() => !window.__store.project.features.some((f) => f.type === 'fillet')), log.slice(0, 120));
  log = await say('えーと、床板の熱さを三センチにしてもらえますか'); v = await vols();
  ok('話し言葉・聞き間違い', /床板:[\d.]+ \[0,0,0 \/ 600,400,30\]/.test(v), v);
  log = await say('高さ900、奥行400、厚さ18の側板を作って。それを30上げて。左右対称に'); v = await vols();
  ok('側板＋対称', /側板:6480000\.0 \[0,0,30 \/ 18,400,930\]/.test(v) && /側板\(ミラー\):6480000\.0 \[582,0,30 \/ 600,400,930\]/.test(v), v);
  log = await say('床板だけ赤くして');
  ok('色', await page.evaluate(() => { const m = window.__app.meshes.find((x) => x.name === '床板'); return window.__store.project.bodyProps[m.id].color === '#d23b3b'; }), log.slice(0, 80));
  log = await say('床板の重さは？');
  ok('重さを答える', /床板: 600×400×30 mm.*kg/.test(log), log.slice(0, 160));
  log = await say('穴をあけて');
  ok('分からないところは聞き返す', /💬 .*(どの部品|直径|位置)/.test(log), log.slice(0, 120));
  const nb = await page.evaluate(() => window.__app.meshes.length);
  log = await say('こんにちは');
  ok('分からない言葉は候補を示す（形は変えない）', /たとえば/.test(log) && nb === await page.evaluate(() => window.__app.meshes.length), log.slice(0, 120));
  log = await say('床板を作って');
  log = await say('幅300 奥行200 厚さ10'); v = await vols();
  ok('聞き返しに答える', /床板2:600000\.0/.test(v), log.slice(0, 160));
  log = await say('板 幅100 奥行100 厚さ10 名前 試し'); v = await vols();
  ok('決まった書き方はそのまま', /試し:100000\.0/.test(v), log.slice(0, 80));
  // AI を使う設定でも、API キーが無いときは AI を使わずに読み取る
  await page.evaluate(() => { localStorage.setItem('gdc-voice-ai', '1'); localStorage.setItem('gdc-ai-brain', 'claude'); });
  log = await say('試しを消して'); v = await vols();
  ok('AI の準備がないときの代わり', !/試し:/.test(v) && /AI を使わずに/.test(log), log.slice(0, 200));
  ok('外部への通信なし', net === 0, 'requests ' + net);
  await page.screenshot({ path: wk ? 'nlu_iphone.png' : 'nlu_pc.png' });
  await browser.close();
})();
