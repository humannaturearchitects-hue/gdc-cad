// プロパティの「大きさ」を元の手順につないで直す（押し出し・スケッチ寸法・パラメータ・円柱・取り込んだ形）
// 使い方: テストフォルダにコピーし、ポートを合わせて node edit_props.cjs
//  期待: "W 700 ok" "D 450 ok" "H 35 ok" "param 床幅=700" "cyl 80x80x150 ok" "import scaled ok" "edit dialog: スケッチ1 のすべての領域"
const { open } = require('./ux_common.cjs');
const path = require('path');
(async () => {
  const { browser, page } = await open({ iphone: !!process.env.IPHONE });
  const log = (...a) => console.log(...a);
  for (const t of ['パラメータ 床幅=600', 'スケッチ XY', '長方形 0,0 幅床幅 高さ400', '押し出し 20 名前 床板', '円柱 直径50 高さ100 位置 100,100,20 名前 柱']) await page.cmd(t);
  const size = (name) => page.evaluate(async (name) => { const m = window.__app.meshes.find((m) => m.name === name); const r = await window.__kcall('measure', { ids: [m.id] }); const b = r.list[0].bounds; return [0, 1, 2].map((i) => +(b[1][i] - b[0][i]).toFixed(3)); }, name);
  const pick = async (name) => {
    await page.evaluate((name) => { const m = window.__app.meshes.find((m) => m.name === name); window.__app.selection = [{ kind: 'body', bodyId: m.id }]; window.__app.reapplyHighlights(); window.__app.ux.propsOn = true; window.__app.ux.updateProps(); }, name);
    await page.waitForFunction((name) => { const e = document.querySelector('#ux-props .uxp-head span'); return e && e.textContent === name; }, name);
    await page.waitForTimeout(300);
  };
  const setSize = async (i, v) => { const inp = page.locator(`#ux-props input[data-size="${i}"]`); await inp.fill(String(v)); await inp.press('Enter'); await page.waitForTimeout(500); await page.idle(); await page.waitForTimeout(300); };
  // 床板: 高さ(Z)=押し出し距離、幅(X)=長方形の幅（床幅パラメータ）、奥行(Y)=長方形の高さ
  await pick('床板');
  log('labels:', (await page.locator('#ux-props .uxp-drv').allInnerTexts()).join(' / '));
  log('readonly:', await page.locator('#ux-props input[data-size="2"]').getAttribute('readonly'));
  await setSize(2, 35); let s = await size('床板'); log('H', s[2], s[2] === 35 ? 'ok' : 'NG');
  await pick('床板'); await setSize(0, 700); s = await size('床板'); log('W', s[0], s[0] === 700 ? 'ok' : 'NG');
  log('param', (await page.evaluate(() => window.__store.project.params.map((p) => p.name + '=' + p.expr).join(','))));
  await pick('床板'); await setSize(1, '45cm'); s = await size('床板'); log('D', s[1], s[1] === 450 ? 'ok' : 'NG');
  // プレス/プルで厚くしたあとでも、合計の大きさで直せる
  await page.cmd('プレスプル 上面 10 床板');
  await pick('床板'); await setSize(2, 50); s = await size('床板'); log('H after presspull', s[2], s[2] === 50 ? 'ok' : 'NG', JSON.stringify(await page.evaluate(() => window.__store.project.features.filter(f => f.type === 'extrude' || f.type === 'presspull').map(f => f.distance))));
  // 円柱: X=直径 Z=高さ
  await pick('柱'); log('cyl labels:', (await page.locator('#ux-props .uxp-drv').allInnerTexts()).join(' / '));
  await setSize(0, 80); await pick('柱'); await setSize(2, 150); s = await size('柱'); log('cyl', s.join('x'), s.join('x') === '80x80x150' ? 'ok' : 'NG');
  // 取り込んだ形: 比率を保って拡大縮小（いちばん小さい角は動かない）
  const fc = page.waitForEvent('filechooser'); page.evaluate(() => { window.__app.importFile(); }); await (await fc).setFiles(path.join(__dirname, '../fixtures/nested.step'));
  await page.waitForFunction(() => window.__app.meshes.length >= 5, null, { timeout: 60000 }); await page.idle();
  const imp = await page.evaluate(() => window.__app.meshes.find((m) => window.__store.feature(m.src)?.type === 'import').name);
  await pick(imp);
  const s0 = await size(imp);
  const lo0 = await page.evaluate(async (n) => { const m = window.__app.meshes.find((m) => m.name === n); return (await window.__kcall('measure', { ids: [m.id] })).list[0].bounds[0].map(v => +v.toFixed(3)); }, imp);
  log('import labels:', (await page.locator('#ux-props .uxp-drv').allInnerTexts()).join(' / '));
  await setSize(0, +(s0[0] * 2).toFixed(3));
  const s1 = await size(imp);
  const lo1 = await page.evaluate(async (n) => { const m = window.__app.meshes.find((m) => m.name === n); return (await window.__kcall('measure', { ids: [m.id] })).list[0].bounds[0].map(v => +v.toFixed(3)); }, imp);
  const okk = s1.every((v, i) => Math.abs(v - s0[i] * 2) < 1e-2) && lo1.every((v, i) => Math.abs(v - lo0[i]) < 1e-2);
  log('import', s0.join('x'), '->', s1.join('x'), okk ? 'import scaled ok' : 'NG', JSON.stringify(lo0), JSON.stringify(lo1));
  // コマンドで作った押し出しを編集: プロファイルが「選択済み」と表示される
  await page.evaluate(() => { window.__app.selection = []; const f = window.__store.project.features.find(f => f.type === 'extrude'); window.__app.editFeature(f.id); });
  await page.waitForTimeout(600);
  log('edit dialog:', await page.locator('#dialog .selfield .cnt').first().innerText());
  await page.locator('#dialog [data-k="distance"]').fill('30'); await page.keyboard.press('Enter'); await page.idle();
  log('after edit ok, errors', JSON.stringify(await page.evaluate(() => window.__app.errors)), 'H', (await size('床板'))[2]);
  await page.screenshot({ path: 'edit_props.png' });
  await browser.close();
})();
