// タイムラインの並べ替え（ドラッグ・メニュー）、使っている手順より前に動かせないこと、抑制、2 本指ひねりで回転
// 使い方: テストフォルダにコピーし、ポートを合わせて node edit_timeline.cjs（IPHONE=1 で iPhone 15 / WebKit）
//  期待: "refused: ...使っているので" "order after menu: box,sketch,extrude,cylinder" "order after drag: cylinder,box,sketch,extrude"
//        "marker rollback 1 bodies 1" "face menu: プレス/プル（この面を押し引き） | 元の手順を編集（直方体1）"
//        "suppress bodies 2" "unsuppress bodies 3" "twist azimuth ~45 ok" "pinch no twist ok"
const { open } = require('./ux_common.cjs');
(async () => {
  const iphone = !!process.env.IPHONE;
  const { browser, page } = await open({ iphone });
  const log = (...a) => console.log(...a);
  for (const t of ['板 幅600 奥行400 厚さ20 名前 床板', '円柱 直径50 高さ100 位置 100,100,20 名前 柱', 'スケッチ XY オフセット 200', '長方形 0,0 100,50', '押し出し 10 名前 棚']) await page.cmd(t);
  const order = () => page.evaluate(() => window.__store.project.features.map((f) => f.type).join(','));
  const toast = () => page.locator('#toast').innerText();
  log('order', await order());
  const menu = async (i, label) => {
    const it = page.locator('#timeline [data-f]').nth(i);
    if (iphone) { await it.tap(); await page.waitForTimeout(700); } else { await it.click({ button: 'right' }); await page.waitForTimeout(200); }
    const b = page.locator('#ctxmenu button', { hasText: label });
    if (!(await b.count())) { log('no menu item', label, (await page.locator('#ctxmenu').innerText()).replace(/\n/g, '|')); await page.mouse.click(5, 300); return; }
    await b.first().click(); await page.waitForTimeout(400); await page.idle();
  };
  // 押し出し（4 番目）を 1 つ前へ → スケッチより前には動かせない
  await menu(3, '1つ前へ移動');
  log('refused:', await toast(), '|', await order());
  // 円柱（2 番目）を後ろへ 2 回 → 最後
  await menu(1, '1つ後ろへ移動'); await menu(2, '1つ後ろへ移動');
  log('order after menu:', (await order()).replace('box', 'box'));
  if (!iphone) {
    // ドラッグで円柱を先頭へ
    const it = page.locator('#timeline [data-f]').nth(3), first = page.locator('#timeline [data-f]').nth(0);
    const a = await it.boundingBox(), b = await first.boundingBox();
    await page.mouse.move(a.x + a.width / 2, a.y + a.height / 2); await page.mouse.down();
    await page.mouse.move(a.x - 20, a.y + 10, { steps: 4 }); await page.mouse.move(b.x + 4, b.y + b.height / 2, { steps: 6 });
    log('drop marker', await page.locator('.tl-drop').count());
    await page.mouse.up(); await page.waitForTimeout(400); await page.idle();
    log('order after drag:', await order());
    // ドラッグで押し出しをスケッチより前へ → 赤い印・動かない
    const ex = page.locator('#timeline [data-f]').nth(3), sk = page.locator('#timeline [data-f]').nth(2);
    const c = await ex.boundingBox(), d = await sk.boundingBox();
    await page.mouse.move(c.x + c.width / 2, c.y + c.height / 2); await page.mouse.down();
    await page.mouse.move(d.x + 3, d.y + d.height / 2, { steps: 6 });
    log('bad marker', await page.locator('.tl-drop.bad').count());
    await page.mouse.up(); await page.waitForTimeout(400); await page.idle();
    log('order after bad drag:', await order(), '|', await toast());
  }
  if (!iphone) {
    // 「ここまで表示」の印をドラッグして 2 つ目の手順の前へ → 手順 1 つ分だけ表示
    const mk = await page.locator('#timeline .tl-marker').boundingBox(), t1 = await page.locator('#timeline [data-f]').nth(1).boundingBox();
    await page.mouse.move(mk.x + 3, mk.y + 10); await page.mouse.down(); await page.mouse.move(t1.x + 3, t1.y + 10, { steps: 6 }); await page.mouse.up(); await page.idle();
    log('marker rollback', await page.evaluate(() => window.__store.project.rollback), 'bodies', await page.evaluate(() => window.__app.meshes.length));
    await page.locator('#timeline [data-tl="last"]').click(); await page.idle();
    // 面の右クリックメニュー: プレス/プル・元の手順を編集
    await page.evaluate(() => window.__app.viewer.fit()); await page.waitForTimeout(200);
    const p = await page.evaluate(() => window.__app.viewer.toScreen([500, 300, 20]));
    await page.mouse.click(page.vp.x + p[0], page.vp.y + p[1], { button: 'right' }); await page.waitForTimeout(300);
    log('face menu:', (await page.locator('#ctxmenu').innerText()).split('\n').filter((x) => /プレス|元の手順/.test(x)).join(' | '));
    await page.locator('#ctxmenu button', { hasText: 'プレス/プル' }).click(); await page.waitForTimeout(600);
    log('presspull face preselected:', await page.locator('#dialog .selfield .cnt').first().innerText(), 'arrow', await page.locator('.xbox').count());
    await page.keyboard.press('Escape'); await page.waitForTimeout(300);
  }
  // 抑制（一時的に無効化）
  const boxIdx = await page.evaluate(() => window.__store.project.features.findIndex((f) => f.type === 'box'));
  await menu(boxIdx, '抑制（一時的に無効化）');
  log('suppress bodies', await page.evaluate(() => window.__app.meshes.length), await page.locator('#timeline .tl-item.suppressed').count());
  await menu(boxIdx, '抑制を解除');
  log('unsuppress bodies', await page.evaluate(() => window.__app.meshes.length));
  // 2 本指ひねり（合成の PointerEvent）
  const az = () => page.evaluate(() => { const c = window.__app.viewer.camera, t = window.__app.viewer.controls.target; return Math.atan2(c.position.y - t.y, c.position.x - t.x) * 180 / Math.PI; });
  const gesture = (rot, scale) => page.evaluate(async ([rot, scale]) => {
    const cv = window.__app.viewer.canvas, r = cv.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2, R = 60;
    const ev = (type, id, a, s) => cv.dispatchEvent(new PointerEvent(type, { pointerId: id, pointerType: 'touch', isPrimary: id === 11, clientX: cx + Math.cos(a) * R * s, clientY: cy + Math.sin(a) * R * s, bubbles: true, cancelable: true, button: 0, buttons: type === 'pointerup' ? 0 : 1 }));
    try { ev('pointerdown', 11, 0, 1); ev('pointerdown', 12, Math.PI, 1); } catch (e) { /* */ }
    const N = 12;
    for (let k = 1; k <= N; k++) { const a = rot * k / N, s = 1 + (scale - 1) * k / N; try { ev('pointermove', 11, a, s); ev('pointermove', 12, Math.PI + a, s); } catch (e) { /* */ } await new Promise((r) => setTimeout(r, 16)); }
    try { ev('pointerup', 11, rot, scale); ev('pointerup', 12, Math.PI + rot, scale); } catch (e) { /* */ }
  }, [rot, scale]);
  const a0 = await az();
  await gesture(Math.PI / 4, 1);
  const a1 = await az();
  let dd = a1 - a0; if (dd > 180) dd -= 360; if (dd < -180) dd += 360;
  log('twist azimuth', dd.toFixed(1), Math.abs(Math.abs(dd) - 45) < 3 ? 'ok' : 'NG');
  const a2 = await az();
  await gesture(0.05, 1.6); // ほぼピンチだけ
  let de = (await az()) - a2; if (de > 180) de -= 360; if (de < -180) de += 360;
  log('pinch no twist', de.toFixed(2), Math.abs(de) < 0.5 ? 'ok' : 'NG');
  await page.screenshot({ path: 'edit_timeline.png' });
  await browser.close();
})();
