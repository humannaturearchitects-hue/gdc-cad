const { webkit, devices } = require('playwright');
(async () => {
  const browser = await webkit.launch();
  const ctx = await browser.newContext({ ...devices['iPhone 14'] });
  const page = await ctx.newPage();
  page.on('console', m => { if (m.type()==='error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 300)); });
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message + ' | ' + (e.stack||'').split('\n').slice(0,3).join(' / ')));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.waitForTimeout(800);
  await page.screenshot({ path: 'wkm_welcome.png' });
  const vp = await page.locator('#view3d').boundingBox();
  // sketch: tap スケッチ作成 → tap XY plane
  await page.tap('.tool:has-text("スケッチ作成")'); await page.waitForTimeout(300);
  const pos = await page.evaluate(() => { const v = window.__app.viewer; const m = v.planeMeshes.find(p=>p.userData.name==='XY'); const s = m.scale.x; return v.toScreen([s*0.3, -s*0.3, 0]); });
  await page.touchscreen.tap(vp.x + pos[0], vp.y + pos[1]); await page.waitForTimeout(1500);
  console.log('mode', await page.evaluate(() => window.__app.mode), JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature?.plane)));
  // rect via taps + typed dims
  await page.tap('.tool:has-text("2点長方形")');
  const a = await page.evaluate(() => window.__app.viewer.toScreen([0,0,0]));
  await page.touchscreen.tap(vp.x + a[0], vp.y + a[1]); await page.waitForTimeout(300);
  await page.tap('.inbox input >> nth=0'); await page.keyboard.type('150');
  await page.tap('.inbox input >> nth=1'); await page.keyboard.type('80'); await page.keyboard.press('Enter');
  await page.waitForTimeout(500);
  console.log('ents', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature.entities)));
  await page.screenshot({ path: 'wkm_sketch.png' });
  await page.tap('.tool:has-text("スケッチを終了")'); await page.waitForTimeout(1000);
  await page.tap('.tool:has-text("押し出し")'); await page.waitForTimeout(800);
  await page.fill('#dialog input[data-k="distance"]', '40'); await page.waitForTimeout(1200);
  await page.screenshot({ path: 'wkm_extrude.png' });
  await page.tap('#dialog [data-act="ok"]'); await page.waitForTimeout(1500);
  console.log('bodies', await page.evaluate(() => window.__app.meshes.length), 'errors', JSON.stringify(await page.evaluate(() => window.__app.errors)));
  // long-press on body → context menu
  const c = await page.evaluate(() => window.__app.viewer.toScreen([75,40,40]));
  await page.evaluate(([x,y]) => { const cv=document.getElementById('view3d'); const o={pointerId:7,pointerType:'touch',clientX:x,clientY:y,bubbles:true,isPrimary:true,button:0}; cv.dispatchEvent(new PointerEvent('pointerdown',o)); }, [vp.x+c[0], vp.y+c[1]]);
  await page.waitForTimeout(800);
  await page.evaluate(([x,y]) => { const cv=document.getElementById('view3d'); cv.dispatchEvent(new PointerEvent('pointerup',{pointerId:7,pointerType:'touch',clientX:x,clientY:y,bubbles:true,isPrimary:true,button:0})); }, [vp.x+c[0], vp.y+c[1]]);
  console.log('longpress menu:', await page.evaluate(() => document.getElementById('ctxmenu').className === '' ? [...document.querySelectorAll('#ctxmenu button')].map(b=>b.textContent).slice(0,3).join('|') : 'none'));
  await page.screenshot({ path: 'wkm_ctx.png' });
  await page.tap('#btn-browser'); await page.waitForTimeout(400);
  await page.screenshot({ path: 'wkm_browser.png' });
  await page.tap('#btn-browser');
  await page.tap('.ws[data-ws=drawing]');
  await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 }); await page.waitForTimeout(500);
  await page.screenshot({ path: 'wkm_drawing.png' });
  // offline reload
  await page.evaluate(() => navigator.serviceWorker.ready);
  for (let i = 0; i < 20; i++) { const n = await page.evaluate(async () => { const ks = await caches.keys(); if (!ks.length) return 0; return (await (await caches.open(ks[0])).keys()).length; }); if (n > 15) break; await page.waitForTimeout(1000); }
  console.log('sw', await page.evaluate(async () => !!(await navigator.serviceWorker.getRegistration())));
  require('child_process').execSync('pkill -f "[v]ite preview --port 4173"; true');
  await new Promise(r => setTimeout(r, 1500));
  await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.waitForTimeout(3000);
  console.log('offline reload ok, bodies', await page.evaluate(() => window.__app.meshes.length));
  await browser.close();
})();
