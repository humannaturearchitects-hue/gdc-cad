const { open } = require('./ux_common.cjs');
(async () => {
  const { browser, page } = await open();
  await page.cmd(`板 幅600 奥行400 厚さ20 名前 床板`);
  await page.evaluate(() => { const id = window.__app.meshes[0].id; window.__app.ux.setSelection([{kind:'body',bodyId:id}]); });
  await page.keyboard.press('Control+c'); await page.waitForTimeout(1500);
  await page.evaluate(() => window.__app.newDoc()); await page.waitForTimeout(1500);
  await page.keyboard.press('Control+v'); await page.waitForTimeout(3000); await page.idle();
  console.log('other doc', await page.bodies(), await page.evaluate(async () => { const r = await window.__kcall('measure', { ids: [] }); return r.total.volume; }));
  await browser.close();
})();
