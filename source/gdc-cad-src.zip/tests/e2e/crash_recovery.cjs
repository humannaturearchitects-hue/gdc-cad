const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 } })).newPage();
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
  await page.waitForFunction(() => window.__app.meshes.length > 0, null, { timeout: 30000 }); await page.waitForTimeout(500);
  await page.evaluate(() => window.__kcall('crashTest'));
  await page.waitForTimeout(6000);
  const r = await page.evaluate(() => ({ toast: document.getElementById('toast').textContent, meshes: window.__app.meshes.length }));
  console.log('after crash:', JSON.stringify(r));
  await page.evaluate(() => window.__store.commit(p => { p.params[0].expr = '350'; })); await page.waitForTimeout(2500);
  console.log('edit after restart ok:', await page.evaluate(() => window.__app.errors.length === 0 && window.__app.meshes.length === 1));
  await browser.close();
})();
