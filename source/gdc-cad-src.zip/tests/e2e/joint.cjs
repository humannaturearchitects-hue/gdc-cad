const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  const alerts = [];
  page.on('dialog', d => { alerts.push(d.message()); d.accept(); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  const bb = (id) => page.evaluate((id) => { const m = window.__app.meshes.find(x => x.id === id); const v = m.vertices; let mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9]; for(let i=0;i<v.length;i+=3) for(let k=0;k<3;k++){mn[k]=Math.min(mn[k],v[i+k]);mx[k]=Math.max(mx[k],v[i+k]);} return [mn.map(Math.round), mx.map(Math.round)]; }, id);
  const proj = (val) => ({ format:'kobocad', version:1, name:'ヒンジ', units:'mm', params:[{name:'開き', expr: val}], rollback:null, drawing:null, bodyProps:{},
    features:[
      { id:'w', type:'box', name:'w', position:['0','0','0'], w:'2000', d:'42', h:'1000', operation:'new', bodyName:'壁' },
      { id:'dk', type:'box', name:'dk', position:['0','-42','0'], w:'2000', d:'42', h:'800', operation:'new', bodyName:'デッキ' },
      { id:'j', type:'joint', name:'j', kind:'revolute', bodies:['B_dk'], axis:[1000,-42,0,1,0,0], value:'開き', min:'-90', max:'0' },
    ] });
  await page.evaluate((p) => window.__store.replace(p), proj('0'));
  await page.waitForFunction(() => window.__app.meshes.length === 2, null, { timeout: 30000 }); await page.waitForTimeout(600);
  console.log('deck at 0°   ', JSON.stringify(await bb('B_dk')), 'axis', JSON.stringify(await page.evaluate(() => window.__app.jointInfo.j)));
  await page.evaluate(() => window.__store.commit(p => { p.params[0].expr = '-90'; })); await page.waitForTimeout(1500);
  console.log('deck at -90° ', JSON.stringify(await bb('B_dk')));
  await page.evaluate(() => window.__store.commit(p => { p.params[0].expr = '0'; })); await page.waitForTimeout(1500);
  // ダイアログを開いて動かしてみる・干渉チェック
  await page.dblclick('.tl-item >> nth=2'); await page.waitForTimeout(1200);
  await page.click('#dialog button:has-text("動かしてみる")'); await page.waitForTimeout(1300);
  await page.screenshot({ path: 'joint_anim.png' });
  await page.waitForTimeout(4500);
  await page.click('#dialog button:has-text("可動範囲の干渉チェック")'); await page.waitForTimeout(6000);
  console.log('sweep -90..0 toast:', await page.evaluate(() => document.getElementById('toast').textContent));
  await page.fill('#dialog input[data-k=min]', '0'); await page.fill('#dialog input[data-k=max]', '90'); await page.waitForTimeout(500);
  await page.click('#dialog button:has-text("可動範囲の干渉チェック")'); await page.waitForTimeout(8000);
  console.log('sweep 0..90 toast:', await page.evaluate(() => document.getElementById('toast').textContent));
  console.log('sweep 0..90 alert:', alerts.map(a => a.replace(/\n/g, ' / ')).join(' || ').slice(0, 250));
  await browser.close();
})();
