const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 }, acceptDownloads: true })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
  await page.waitForFunction(() => window.__app.meshes.length > 0, null, { timeout: 30000 }); await page.waitForTimeout(600);
  await page.click('.ws[data-ws=drawing]'); await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 }); await page.waitForTimeout(800);
  await page.locator('.dw-sheet').screenshot({ path: 'd_sample.png' });
  await page.click('.ws[data-ws=design]'); await page.waitForTimeout(300);
  // 組立: 板 + 脚4本 + ボルト6本（パターン）
  await page.evaluate(() => window.__store.replace({ format:'kobocad', version:1, name:'テーブル', units:'mm', params:[], rollback:null, drawing:null,
    bodyProps: { B_top: { material: { name: '合板', density: 0.55 } } },
    features:[
      { id:'top', type:'box', name:'top', position:['0','0','700'], w:'1200', d:'600', h:'30', operation:'new', bodyName:'天板' },
      { id:'leg', type:'box', name:'leg', position:['50','50','0'], w:'60', d:'60', h:'700', operation:'new', bodyName:'脚' },
      { id:'pt', type:'pattern', name:'pt', bodies:['B_leg'], dir:'X', count:'2', spacing:'1040', dir2:'Y', count2:'2', spacing2:'440', join:false },
      { id:'h', type:'hole', name:'h', body:'B_top', points:[[300,300,730,0,0,1],[900,300,730,0,0,1]], style:'simple', d:'35', through:true },
    ] }));
  await page.waitForFunction(() => window.__app.meshes.length === 5, null, { timeout: 30000 }); await page.waitForTimeout(800);
  await page.click('.ws[data-ws=drawing]'); await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 }); await page.waitForTimeout(1200);
  await page.locator('.dw-sheet').screenshot({ path: 'd_table.png' });
  const [d] = await Promise.all([page.waitForEvent('download'), page.click('[data-x=dxf]')]); await d.saveAs('dl/table.dxf');
  // section view test
  await page.click('.ws[data-ws=design]'); await page.waitForTimeout(300);
  await page.click('.tab:has-text("検査")'); await page.click('.tool:has-text("断面表示")'); await page.waitForTimeout(300);
  await page.click('[data-nav=fit]'); await page.waitForTimeout(400); await page.selectOption('#sec-ax', 'Y'); await page.waitForTimeout(500);
  await page.screenshot({ path: 'd_section.png' });
  await browser.close();
})();
