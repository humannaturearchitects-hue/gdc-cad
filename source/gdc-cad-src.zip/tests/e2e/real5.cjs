// 構築平面: オフセット平面にスケッチ → 面まで押し出し / 角度の平面 / 中間の平面
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(250); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const state = async (label) => {
    const s = await page.evaluate(() => ({ feats: window.__store.project.features.map(f => f.type), errors: window.__app.errors.map(e => e.message) }));
    let vol = ''; try { const r = await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 })); vol = r.list.map(b => `${b.name}:${Math.round(b.volume)} [${b.bounds.map(p => p.map(Math.round).join(',')).join(' / ')}]`).join(' ; '); } catch (e) { vol = 'measure err ' + e.message; }
    console.log(`### ${label}\n  feats ${s.feats.join(',')} errors ${JSON.stringify(s.errors)}\n  ${vol}`);
  };
  const tool = (t) => page.click(`.tool:has-text("${t}")`);
  const ok = async () => { await page.click('#dialog [data-act="ok"]'); await idle(); };
  const frame = (id) => page.evaluate((id) => { const f = window.__app.sketchFrames[id]; return f && JSON.stringify({ o: f.origin.map(v => +v.toFixed(2)), n: f.normal.map(v => +v.toFixed(3)) }); }, id);
  const lastId = (t) => page.evaluate((t) => [...window.__store.project.features].reverse().find(f => f.type === t).id, t);

  // 板 200x200x20
  await tool('スケッチ作成'); await page.click('#planebar [data-pl=XY]'); await idle();
  await page.keyboard.press('r'); await page.mouse.click(...await scr([0, 0, 0])); await page.waitForTimeout(150);
  { const a = page.locator('.inbox input'); await a.nth(0).fill('200'); await a.nth(1).fill('200'); await page.keyboard.press('Enter'); await page.waitForTimeout(250); }
  await page.keyboard.press('e'); await idle(); await page.fill('#dialog input[data-k="distance"]', '20'); await idle(); await ok();
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);

  // 1. オフセット平面: 上面から 80（z=100）
  await tool('構築平面'); await idle();
  await page.mouse.click(...await scr([150, 150, 20])); await idle();
  await page.fill('#dialog input[data-k="distance"]', '80'); await idle(); await ok();
  console.log('offset plane frame', await frame(await lastId('plane')));

  // 2. その平面にスケッチ（平面をクリック）→ 円 Ø50 → 板の上面まで押し出し
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  await tool('スケッチ作成'); await page.waitForTimeout(300);
  await page.mouse.click(...await scr([100, 100, 100])); await idle();
  console.log('  sketch plane', await page.evaluate(() => JSON.stringify(window.__app.sketcher.feature?.plane)));
  await page.keyboard.press('c'); await page.mouse.click(...await scr([100, 100, 100])); await page.waitForTimeout(150);
  await page.locator('.inbox input').nth(0).fill('50'); await page.keyboard.press('Enter'); await page.waitForTimeout(250);
  await page.keyboard.press('e'); await idle();
  await page.selectOption('#dialog select[data-k="extent"]', 'to'); await idle();
  await page.click('#dialog [data-sel="to"]'); await page.waitForTimeout(150);
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  await page.mouse.click(...await scr([180, 30, 20])); await idle();
  await ok();
  await state('2 オフセット平面(z=100)の円 Ø50 を板の上面(z=20)まで → 円柱 z 20..100（157,080）');

  // 3. 角度の平面: 板の手前の上の辺（y=0,z=20）を軸に、上面から 45°
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  await tool('構築平面'); await idle();
  await page.selectOption('#dialog select[data-k="kind"]', 'angle'); await idle();
  const dd = async (l) => console.log('  ', l, await page.evaluate(() => { const a = window.__app.dialog.active; return JSON.stringify({ sel: a.activeSel, edge: a.draft.edge, base: a.draft.base, kinds: window.__app.dialog.selKinds() }); }));
  await dd('before');
  await page.mouse.click(...await scr([60, 0, 20])); await idle(); await dd('after edge');
  await page.mouse.click(...await scr([40, 60, 20])); await idle(); await dd('after base');
  await ok();
  console.log('angle plane frame', await frame(await lastId('plane')), 'errors', JSON.stringify(await page.evaluate(() => window.__app.errors.map(e => e.message))));

  // 4. 中間の平面: 板の下面(z=0) と 円柱の上面(z=100) → z=50
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  await tool('構築平面'); await idle();
  await page.selectOption('#dialog select[data-k="kind"]', 'mid'); await idle();
  await page.mouse.click(...await scr([100, 100, 100])); await idle();
  await page.evaluate(() => { const v = window.__app.viewer; v.setView([1, -1.3, -0.9], [0, 0, 1], false); v.fit(); });
  await page.waitForTimeout(300);
  await page.mouse.click(...await scr([170, 40, 0])); await idle();
  console.log('  mid draft', await page.evaluate(() => JSON.stringify([window.__app.dialog.active.draft.base, window.__app.dialog.active.draft.base2].map(a => a && a.map(v => Math.round(v))))));
  await ok();
  console.log('mid plane frame', await frame(await lastId('plane')));
  // 5. 板の厚みを 20 → 40 に変更 → オフセット平面は z=120、円柱は 40..120 に追従するか
  await page.locator('#timeline .tl-item').nth(1).dblclick(); await idle();
  await page.fill('#dialog input[data-k="distance"]', '40'); await idle(); await ok();
  await state('5 板を 40 に → 円柱は z 40..120（体積同じ 157,080）');
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  await page.screenshot({ path: 'real5_end.png' });
  await browser.close();
})();
