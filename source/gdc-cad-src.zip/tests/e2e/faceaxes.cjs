// 穴の「面の左下の角からの座標」が、面ごとにどの軸か（AI への説明が正しいか）を確かめる
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  await page.goto(`http://127.0.0.1:${process.env.PORT || 4173}/`); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  // 面ごとに: 穴 (a,b) → 期待する中心の 3D 位置で、細い円柱を作り、穴と重なる（干渉が無い）か
  const cases = [['上面', [0, 0, 1], (a, b) => [a, b, 100]], ['下面', [0, 0, -1], (a, b) => [a, b, 0]], ['前面', [0, -1, 0], (a, b) => [a, 0, b]], ['背面', [0, 1, 0], (a, b) => [a, 300, b]], ['左面', [-1, 0, 0], (a, b) => [0, a, b]], ['右面', [1, 0, 0], (a, b) => [200, a, b]]];
  for (const [face, n, at] of cases) {
    await page.evaluate(() => { window.__store.replace({ format: 'kobocad', version: 1, name: 't', units: 'mm', params: [], features: [], bodyProps: {}, rollback: null, drawing: null }); });
    await page.waitForTimeout(300);
    const a = 40, b = 30; const p = at(a, b);
    const r = await page.evaluate(async ({ face, a, b }) => window.__cmd(`板 幅200 奥行300 厚さ100 名前 箱\n穴 ${face} Ø20 深さ20 位置 ${a},${b} 箱`), { face, a, b });
    const ax = n[0] ? 'X' : n[1] ? 'Y' : 'Z';
    const pos = p.map((v, i) => (n[i] ? (n[i] > 0 ? v - 10 : v) : v));
    const r2 = await page.evaluate((t) => window.__cmd(t), `円柱 直径10 高さ10 位置 ${pos.join(',')} 軸 ${ax} 名前 棒`);
    const inter = await page.evaluate(() => window.__kcall('interference', { ids: window.__app.meshes.map((m) => m.id) }));
    console.log(face, r.every((x) => x.ok) && r2.every((x) => x.ok) ? '' : JSON.stringify([...r, ...r2].filter((x) => !x.ok)), inter.length ? `✗ 重なる（${a},${b} は別の場所）` : `✓ (${a},${b}) → ${p.join(',')}`);
  }
  await browser.close();
})();
