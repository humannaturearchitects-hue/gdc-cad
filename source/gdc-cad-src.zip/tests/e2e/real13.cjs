// DXF をスケッチとして読み込み → 押し出し（外形 R20 の角・Ø30 の穴）
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const fcP = page.waitForEvent('filechooser'); page.evaluate(() => { window.__app.importFile(); }); const fc = await fcP;
  await fc.setFiles(__dirname + '/fx/panel.dxf');
  await page.waitForTimeout(2500);
  console.log('toast:', (await page.locator('.toast').last().innerText().catch(() => '')).replace(/\s+/g, ' '));
  const sk = await page.evaluate(() => { const f = window.__store.project.features.find((x) => x.type === 'sketch'); return { name: f.name, n: f.entities.length, types: [...new Set(f.entities.map((e) => e.type))].join(','), loops: window.__app.sketchLoops(f.id).length }; });
  console.log('sketch:', JSON.stringify(sk));
  const r = await page.evaluate(() => window.__cmd('押し出し 12'));
  console.log('extrude:', JSON.stringify(r.map((x) => x.ok + ' ' + x.msg)));
  const m = (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list[0];
  const area = 400 * 250 - (4 - Math.PI) * 400 - Math.PI * 225;
  console.log(`### DXF → 立体: 体積 ${m.volume.toFixed(1)}（期待 ${(area * 12).toFixed(1)}） 外形 ${JSON.stringify(m.bounds.map(p => p.map(v => +v.toFixed(2))))}`);
  await browser.close();
})();
