const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext()).newPage();
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  for (const [box, sh] of [['板 100x100x100', 'シェル 厚さ5 上面'], ['板 600x400x20', 'シェル 厚さ5 上面'], ['板 600x400x20', 'シェル 厚さ5'], ['板 600x400x50', 'シェル 厚さ5 上面'], ['板 200x200x20', 'シェル 厚さ5 上面']]) {
    await page.evaluate(() => { window.__store.replace({ ...window.__store.project, features: [] }); });
    await page.waitForTimeout(500);
    const r = await page.evaluate(([a, b]) => window.__cmd(a + '\n' + b), [box, sh]);
    const m = (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list[0];
    console.log(box, '|', sh, '→', r.map(x => x.ok).join(','), 'vol', m.volume.toFixed(1), 'area', m.area.toFixed(0), 'bounds', JSON.stringify(m.bounds.map(p => p.map(v => +v.toFixed(1)))), 'com', JSON.stringify((m.com.x !== undefined ? [m.com.x, m.com.y, m.com.z] : m.com).map(v => +v.toFixed(2))));
  }
  await browser.close();
})();
