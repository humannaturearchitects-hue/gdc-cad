// 音声入力の流れ（本物の音声の代わりに、決まった文を返す音声認識を差し込んで確認）
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 } });
  await ctx.addInitScript(() => {
    window.__said = [];
    class FakeSR {
      constructor() { this.lang = ''; }
      start() { const t = window.__said.shift() || ''; setTimeout(() => { this.onresult && this.onresult({ resultIndex: 0, results: [Object.assign([{ transcript: t }], { isFinal: true })] }); setTimeout(() => this.onend && this.onend(), 50); }, 200); }
      stop() {}
    }
    window.SpeechRecognition = FakeSR; window.webkitSpeechRecognition = FakeSR;
  });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  let confirms = 0; page.on('dialog', d => { confirms++; d.accept(); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear() || localStorage.setItem('gdc-voice-ai', '0')); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  // ツールバーの「音声」→ 同意 → すぐ聞き取り
  await page.evaluate(() => { window.__said.push('板、600かける400かける20、名前 床板'); });
  await page.click('.tool:has-text("話す")');
  await page.waitForFunction(() => window.__app.meshes.length === 1, null, { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(800);
  console.log('confirm dialogs:', confirms, '| bodies:', await page.evaluate(() => window.__app.meshes.map(m => m.name).join(',')));
  // 2 回目: ボタンを押して話す（穴）
  await page.evaluate(() => { window.__said.push('穴 上面 ファイ8 位置 30 25 570 25 570 375 30 375'); });
  await page.click('#vc-talk');
  await page.waitForFunction(() => window.__store.project.features.some(f => f.type === 'hole'), null, { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(1500);
  const m = (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list[0];
  console.log('### 音声で 板＋穴 4 つ: 体積', m.volume.toFixed(1), '（期待', (600 * 400 * 20 - 4 * Math.PI * 16 * 20).toFixed(1) + '）');
  console.log('log:', (await page.locator('#cmd-log').innerText()).replace(/\s+/g, ' ').slice(0, 300));
  // 3 回目: 言葉で直す
  await page.evaluate(() => { window.__said.push('床板 厚さ 30ミリ'); });
  await page.click('#vc-talk'); await page.waitForTimeout(2500);
  console.log('### 厚さ:', await page.evaluate(() => window.__store.project.features[0].h));
  await page.screenshot({ path: 'voice1.png' });
  await browser.close();
})();
