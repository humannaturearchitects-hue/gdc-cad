const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1500, height: 900 }, acceptDownloads: true });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('response', r => { if (r.status() >= 400) console.log('HTTP ' + r.status() + ' ' + r.url()); });
  const save = async (fn) => { const [d] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), fn()]); const p = 'dl/' + d.suggestedFilename(); await d.saveAs(p); console.log('saved', p); return p; };
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
  await page.waitForFunction(() => window.__app.meshes.length > 0, null, { timeout: 30000 });
  await page.waitForTimeout(800);
  // 3D exports
  for (const fmt of ['step','stl','obj','glb','brep']) {
    await page.evaluate(() => window.__app.openExport3D());
    await page.selectOption('#x-fmt', fmt);
    await save(() => page.click('#dialog [data-o]'));
  }
  // sketch DXF
  await save(() => page.evaluate(() => window.__app.exportSketchDXF('S1')));
  // drawing
  await page.click('.ws[data-ws=drawing]');
  await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 });
  await page.fill('[data-t=author]', '山田 太郎'); await page.press('[data-t=author]', 'Tab');
  await page.fill('[data-t=material]', 'A5052'); await page.press('[data-t=material]', 'Tab');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: 'draw.png' });
  await save(() => page.click('[data-x=dxf]'));
  await save(() => page.click('[data-x=svg]'));
  await save(() => page.click('[data-x=pdf]'));
  await browser.close();
})();
