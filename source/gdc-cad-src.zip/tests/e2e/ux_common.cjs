const { chromium, webkit, devices } = require('playwright');
exports.open = async (opts = {}) => {
  let browser, ctx;
  if (opts.iphone) {
    process.env.PLAYWRIGHT_BROWSERS_PATH = '/home/user/agentkit/pwb';
    const { webkit: wk } = require('playwright');
    browser = await wk.launch();
    ctx = await browser.newContext({ ...devices['iPhone 15'], serviceWorkers: 'block' });
  } else {
    browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
    ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, acceptDownloads: true, serviceWorkers: 'block' });
  }
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', d => d.accept(opts.promptValue || undefined));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  page.idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(200); };
  page.cmd = async (t) => { const r = await page.evaluate((t) => window.__cmd(t), t); await page.idle(); return r; };
  page.vp = await page.locator('#view3d').boundingBox();
  page.click3 = async (p, o = {}) => { const s = await page.evaluate((p) => window.__app.viewer.toScreen(p), p); await page.mouse.click(page.vp.x + s[0], page.vp.y + s[1], o); await page.waitForTimeout(250); };
  page.bodies = () => page.evaluate(() => window.__app.meshes.map(m => m.name + (m.hidden ? '(隠)' : '')).join(','));
  page.sel = () => page.evaluate(() => JSON.stringify(window.__app.selection.map(s => s.kind + ':' + (s.bodyId || s.sketch))));
  return { browser, page };
};
