// iPhone（WebKit）: 書き出しは共有シートへ。時間がかかって共有シートを出せないときは「共有・保存…」ボタンで渡せる。
// 保存できない表示・版の履歴が iPhone の幅に収まる。期待: すべての行が "ok"
// 実行: PLAYWRIGHT_BROWSERS_PATH=/home/user/agentkit/pwb node wkfiles1.cjs
const { webkit, devices } = require('playwright');
const URL = 'http://127.0.0.1:4173/';
(async () => {
  const browser = await webkit.launch();
  const ctx = await browser.newContext({ ...devices['iPhone 15'], serviceWorkers: 'block' });
  const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('dialog', d => d.accept());
  const ok = (label, cond, extra = '') => console.log(`${label}: ${extra} ${cond ? 'ok' : 'NG'}`);
  // 共有の模擬: 1 回目は「押した直後でない」で断られ、2 回目（ボタンを押したとき）は成功
  await page.addInitScript(() => {
    window.__shared = []; let n = 0;
    navigator.canShare = () => true;
    navigator.share = async (d) => { n++; if (n === 1) throw new DOMException('no gesture', 'NotAllowedError'); window.__shared.push(d.files.map(f => `${f.name}|${f.type}|${f.size}`).join()); };
  });
  await page.goto(URL);
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 120000 });
  await page.evaluate(async () => { localStorage.clear(); await new Promise(r => { const q = indexedDB.deleteDatabase('gdc-cad'); q.onsuccess = q.onerror = q.onblocked = r; }); });
  await page.evaluate(() => window.__cmd('板 幅600 奥行400 厚さ20 名前 床板')); await page.evaluate(() => window.__store.commit(p => { p.name = '現場/A案'; })); await page.waitForTimeout(1500);
  const r = page.evaluate(() => window.__app.exportDoc());
  const offer = page.locator('#share-offer'); await offer.waitFor({ timeout: 10000 });
  ok('share offer shown', (await offer.innerText()).includes('現場_A案.kcad'));
  const bb = await offer.boundingBox(), vw = page.viewportSize().width;
  ok('offer fits iPhone', bb.x >= 0 && bb.x + bb.width <= vw);
  await offer.locator('button', { hasText: '共有・保存' }).tap(); await r;
  const sh = await page.evaluate(() => window.__shared);
  ok('shared via button', sh.length === 1 && sh[0].startsWith('現場_A案.kcad|application/octet-stream|'), sh[0]);
  // 2 回目はすぐ共有シート
  await page.evaluate(() => window.__app.exportDoc()); await page.waitForTimeout(300);
  ok('direct share', (await page.evaluate(() => window.__shared.length)) === 2 && !(await offer.count()));
  // 保存できない表示が画面に収まる
  await page.evaluate(() => { IDBObjectStore.prototype.put = function () { throw new DOMException('full', 'QuotaExceededError'); }; });
  await page.evaluate(() => window.__store.commit(p => { p.name = '容量'; })); await page.waitForTimeout(1500);
  const eb = page.locator('#safety-bars [data-key="save-error"]');
  const eb1 = await eb.boundingBox();
  ok('error bar on iPhone', await eb.isVisible() && eb1.x >= 0 && eb1.x + eb1.width <= vw, JSON.stringify(eb1));
  await page.screenshot({ path: 'wkfiles1_err.png' });
  console.log('page errors:', JSON.stringify(errs));
  await browser.close();
})();
