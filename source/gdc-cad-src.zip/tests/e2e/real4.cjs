// 穴（Fusion 方式）: 基準エッジからの距離で位置決め / スケッチの点から複数 / 丸いエッジに同心
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(250); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const meas = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list[0];
  const errs = async () => page.evaluate(() => window.__app.errors.map(e => e.message));
  const tool = (t) => page.click(`.tool:has-text("${t}")`);
  const ok = async () => { await page.click('#dialog [data-act="ok"]'); await idle(); };
  const draft = async () => page.evaluate(() => { const d = window.__app.dialog.active?.draft; return d && JSON.stringify({ face: d.face && d.face.slice(0, 3).map(Math.round), ref1: !!d.ref1, off1: d.off1, ref2: !!d.ref2, off2: d.off2, sk: d.sketchRef }); });

  // 板 300x200x10
  await tool('スケッチ作成'); await page.click('#planebar [data-pl=XY]'); await idle();
  await page.keyboard.press('r'); await page.mouse.click(...await scr([0, 0, 0])); await page.waitForTimeout(150);
  { const a = page.locator('.inbox input'); await a.nth(0).fill('300'); await a.nth(1).fill('200'); await page.keyboard.press('Enter'); await page.waitForTimeout(250); }
  await page.keyboard.press('e'); await idle(); await page.fill('#dialog input[data-k="distance"]', '10'); await idle(); await ok();
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  const V0 = (await meas()).volume; console.log('plate volume', Math.round(V0));

  // 1. 座標で: 面をクリック → 左下の角から (30, 25)、Ø8
  await page.keyboard.press('h'); await idle();
  await page.mouse.click(...await scr([60, 70, 10])); await idle();
  await page.fill('#dialog [data-pt="0"][data-c="0"]', '30'); await page.fill('#dialog [data-pt="0"][data-c="1"]', '25');
  await page.fill('#dialog input[data-k="d"]', '8'); await idle();
  await ok();
  { const m = await meas(); const v = V0 - m.volume; const cx = (V0 * 150 - m.volume * (m.com.x ?? m.com[0])) / v, cy = (V0 * 100 - m.volume * (m.com.y ?? m.com[1])) / v;
    console.log(`### 1 単一の穴 Ø8: 削れた体積 ${v.toFixed(1)}（期待 502.7）中心 (${cx.toFixed(2)}, ${cy.toFixed(2)})（期待 30, 25） errors ${JSON.stringify(await errs())}`); }

  // 2. スケッチの点から: 上面にスケッチ → 点を 4 つ → 穴 Ø6 貫通
  const V1 = (await meas()).volume;
  await tool('スケッチ作成'); await page.mouse.click(...await scr([200, 150, 10])); await idle();
  await page.click('.tool[title^="点"]');
  for (const [x, y] of [[100, 50], [200, 50], [200, 150], [100, 150]]) { await page.mouse.click(...await scr([x, y, 10])); await page.waitForTimeout(150); console.log('   pt', x, y, await page.evaluate(() => window.__app.sketcher.feature.entities.length), await page.locator('.hcur').innerText().catch(() => '-'), await page.evaluate(([x, y]) => { const e = document.elementFromPoint(x, y); return e.className || e.id; }, await scr([x, y, 10]))); }
  console.log('  points', await page.evaluate(() => JSON.stringify(window.__app.sketcher.feature.entities.map(e => [e.type, e.x, e.y]))));
  await page.click('.tool:has-text("スケッチを終了")'); await idle();
  await page.keyboard.press('h'); await idle();
  await page.selectOption('#dialog select[data-k="placement"]', 'sketch'); await idle();
  await page.fill('#dialog input[data-k="d"]', '6'); await idle();
  console.log('  sketch hole dialog', await draft());
  await ok();
  { const m = await meas(); console.log(`### 2 スケッチの点 4 つに Ø6 貫通: 削れた体積 ${(V1 - m.volume).toFixed(1)}（期待 1131.0） errors ${JSON.stringify(await errs())}`); }

  // 3. 同心: 基準「丸い辺の中心」→ 穴 1 の縁をクリック → (0,0) に Ø16 深さ 3
  const V2 = (await meas()).volume;
  await page.click('[data-nav=home]'); await page.waitForTimeout(400);
  await page.keyboard.press('h'); await idle();
  await page.mouse.click(...await scr([45, 40, 10])); await idle();
  await page.selectOption('#dialog select[data-k="ref"]', 'circle'); await idle();
  await page.mouse.click(...await scr([34, 25, 10])); await idle();
  await page.fill('#dialog [data-pt="0"][data-c="0"]', '0'); await page.fill('#dialog [data-pt="0"][data-c="1"]', '0');
  await page.fill('#dialog input[data-k="d"]', '16'); await page.click('#dialog input[data-k="through"]'); await idle();
  await page.fill('#dialog input[data-k="depth"]', '3'); await idle();
  await ok();
  { const m = await meas(); console.log(`### 3 同心 Ø16 深さ 3: 削れた体積 ${(V2 - m.volume).toFixed(1)}（期待 452.4） errors ${JSON.stringify(await errs())}`); }
  await page.screenshot({ path: 'real4_end.png' });
  await browser.close();
})();
