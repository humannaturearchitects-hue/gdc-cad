// よくある操作: ドラッグで長方形を描く / 線で四角を描いて閉じる / 交差する線
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  const vp = await page.locator('#view3d').boundingBox();
  await page.click('.tool:has-text("スケッチ作成")'); await page.waitForTimeout(300);
  const pos = await page.evaluate(() => { const v = window.__app.viewer; const m = v.planeMeshes.find(p=>p.userData.name==='XY'); const s=m.scale.x; return v.toScreen([s*0.7, s*0.7, 0]); });
  await page.mouse.click(vp.x + pos[0], vp.y + pos[1]); await page.waitForTimeout(1200);
  const S = (p) => page.evaluate((p) => window.__app.viewer.toScreen(p), p);
  // 1) ドラッグで長方形
  await page.keyboard.press('r');
  const a = await S([0,0,0]), b = await S([60,40,0]);
  await page.mouse.move(vp.x+a[0], vp.y+a[1]); await page.mouse.down(); await page.mouse.move(vp.x+b[0], vp.y+b[1], { steps: 8 }); await page.mouse.up();
  await page.waitForTimeout(300);
  console.log('after drag-rect entities:', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature.entities)));
  // 2) 線で四角（交差あり: 端を少し突き出す）
  await page.keyboard.press('l');
  for (const p of [[100,0],[180,0],[180,60],[90,60],[105,-10]]) { const s = await S([p[0],p[1],0]); await page.mouse.click(vp.x+s[0], vp.y+s[1]); await page.waitForTimeout(80); }
  await page.keyboard.press('Escape');
  const loops = await page.evaluate(() => window.__app.sketchLoops(window.__app.sketcher.featureId).map(l => l.kind + ':' + Math.round(l.area)));
  console.log('loops', JSON.stringify(loops));
  await page.screenshot({ path: 'u1_sketch.png' });
  await page.click('.tool:has-text("スケッチを終了")'); await page.waitForTimeout(800);
  await page.click('.tool:has-text("押し出し")'); await page.waitForTimeout(1200);
  // 2 つの領域をクリック
  for (const p of [[30,20,0],[140,30,0]]) { const s = await S(p); await page.mouse.click(vp.x+s[0], vp.y+s[1]); await page.waitForTimeout(200); }
  console.log('dialog profiles', await page.evaluate(() => document.querySelector('#dialog .selfield .cnt')?.textContent), 'distance', await page.inputValue('#dialog input[data-k=distance]'));
  await page.waitForTimeout(1500);
  await page.screenshot({ path: 'u1_extrude.png' });
  await page.click('#dialog [data-act="ok"]'); await page.waitForTimeout(1500);
  console.log('bodies', await page.evaluate(() => window.__app.meshes.length), 'errors', JSON.stringify(await page.evaluate(() => window.__app.errors)));
  await browser.close();
})();
