const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
  await page.waitForFunction(() => window.__app.meshes.length > 0); await page.waitForTimeout(800);
  const st = () => page.evaluate(() => [window.__app.meshes.map(m => m.name).join(','), window.__store.project.features.slice(-1)[0].type].join(' | '));
  console.log('before', await st());
  await page.click('[data-body]'); await page.waitForTimeout(200);
  await page.mouse.click(700, 500); // ビューに focus を戻す前に選択が消えないよう、ツリー選択のまま Delete
  await page.click('[data-body]'); await page.keyboard.press('Delete'); await page.waitForTimeout(1500);
  console.log('after delete', await st());
  await page.keyboard.press('Control+z'); await page.waitForTimeout(1500);
  console.log('after undo', await st());
  await page.keyboard.press('i'); await page.waitForTimeout(200);
  console.log('mode after I', await page.evaluate(() => window.__app.mode));
  await browser.close();
})();
