// データの安全: 2 つのタブ・閉じる直前の保存・保存失敗の表示・版の履歴・起動時の保護・壊れたデータ・バックアップのお知らせ・.kcad の重複
// 期待: すべての行が "ok" で終わる（run: node files1.cjs）
const { chromium } = require('playwright');
const URL = 'http://127.0.0.1:4173/';
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, serviceWorkers: 'block' });
  const errs = [];
  const open = async () => { const p = await ctx.newPage(); p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.type() === 'prompt' ? d.accept('見積り提出版') : d.accept()); await p.goto(URL); await ready(p); return p; };
  const ready = (p) => p.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning && window.__store.docId, null, { timeout: 90000 });
  const feats = (p) => p.evaluate(() => window.__store.project.features.map(f => f.name).join(','));
  const bar = (p, key) => p.locator(`#safety-bars [data-key="${key}"]`);
  const ok = (label, cond, extra = '') => console.log(`${label}: ${extra} ${cond ? 'ok' : 'NG'}`);

  const a = await open();
  await a.evaluate(async () => { localStorage.clear(); sessionStorage.clear(); await new Promise(r => { const q = indexedDB.deleteDatabase('gdc-cad'); q.onsuccess = q.onerror = q.onblocked = r; }); });
  await a.reload(); await ready(a);
  await a.evaluate(() => window.__cmd('板 幅600 奥行400 厚さ20 名前 床板')); await a.waitForTimeout(1500);

  // 1. 同じファイルを 2 つ目のタブで開くと、両方に警告が出る
  const b = await open(); await b.waitForTimeout(800);
  ok('same doc in 2 tabs', (await a.evaluate(() => window.__store.docId)) === (await b.evaluate(() => window.__store.docId)) && await bar(a, 'tabs').isVisible() && await bar(b, 'tabs').isVisible());
  // 2. B で変更・保存 → A は（未保存の変更がなければ）自動で取り込む
  await b.evaluate(() => window.__cmd('円柱 直径100 高さ50')); await b.waitForTimeout(2000);
  ok('other tab change adopted', (await feats(a)) === '直方体1,円柱1', await feats(a));
  // 3. 両方で同時に変更 → 後から保存しようとした方は上書きせず、選ばせる
  await a.evaluate(() => window.__store.commit(p => { p.params.push({ name: 'A側', expr: '1' }); }));
  await b.evaluate(() => window.__store.commit(p => { p.params.push({ name: 'B側', expr: '2' }); }));
  await a.waitForTimeout(2000);
  const states = [await a.evaluate(() => window.__store.saveState), await b.evaluate(() => window.__store.saveState)].sort().join(',');
  const loser = (await a.evaluate(() => window.__store.saveState)) === 'conflict' ? a : b;
  ok('simultaneous edit → conflict, not overwrite', states === 'conflict,saved' && await bar(loser, 'conflict').isVisible(), states);
  await bar(loser, 'conflict').locator('button', { hasText: 'あちらの内容を読み込む' }).click(); await loser.waitForTimeout(1200);
  const pn = await loser.evaluate(() => window.__store.project.params.map(p => p.name).join(','));
  ok('conflict: load other', !(await bar(loser, 'conflict').count()) && pn.length && (await loser.evaluate(() => window.__store.saveState)) === 'saved', pn);
  ok('conflict: undo brings own back', await loser.evaluate(() => { window.__store.undo(); return window.__store.project.params.length; }) === 1);
  await loser.waitForTimeout(1500);
  await b.close(); await a.waitForTimeout(500);
  ok('warning gone when other tab closes', !(await bar(a, 'tabs').count()));

  // 4. 変更直後に閉じても失われない（閉じる直前の控え）
  await a.evaluate(() => window.__cmd('板 幅50 奥行50 厚さ5 名前 閉じ直前'));
  await a.close({ runBeforeUnload: true });
  const c = await open(); await c.waitForTimeout(1500);
  ok('quick close keeps last change', (await feats(c)).includes('直方体2'), await feats(c));
  ok('rescued doc saved back to library', await c.evaluate(() => window.__store.saveState === 'saved' && !localStorage.getItem('gdc-rescue')));

  // 5. 保存できない（容量不足）→ 目立つ表示と対処ボタン → 直れば消える
  await c.evaluate(() => { window.__realPut = IDBObjectStore.prototype.put; IDBObjectStore.prototype.put = function () { throw new DOMException('full', 'QuotaExceededError'); }; });
  await c.evaluate(() => window.__store.commit(p => { p.name = '容量テスト'; })); await c.waitForTimeout(1500);
  const eb = bar(c, 'save-error');
  ok('save error bar', await eb.isVisible() && (await eb.innerText()).includes('空き容量') && await eb.locator('button', { hasText: '古い版を消して空ける' }).count() === 1 && await eb.locator('button', { hasText: 'ファイルに書き出す' }).count() === 1);
  ok('title shows error', (await c.locator('#doc-title').innerText()).includes('保存できません'));
  await c.evaluate(() => { IDBObjectStore.prototype.put = window.__realPut; });
  await eb.locator('button', { hasText: 'もう一度保存' }).click(); await c.waitForTimeout(1000);
  ok('retry clears error', !(await eb.count()) && await c.evaluate(() => window.__store.saveState) === 'saved');

  // 6. 版の履歴: 名前付きで残す → 変更 → その版に戻す → 元に戻すで取り消せる
  await c.evaluate(() => window.__safety.saveNamedVersion('見積り提出版')); await c.waitForTimeout(500);
  await c.evaluate(() => window.__cmd('円柱 直径30 高さ30 名前 後で消す')); await c.waitForTimeout(1500);
  const before = await feats(c);
  await c.click('#menu-file .menu-btn'); await c.click('text=版の履歴（前の状態に戻す）…'); await c.waitForTimeout(600);
  const rows = c.locator('.hist-row');
  ok('history panel lists versions', await rows.count() >= 2 && await c.locator('.hist-row.named', { hasText: '見積り提出版' }).count() === 1, `${await rows.count()} rows`);
  await c.locator('.hist-row.named', { hasText: '見積り提出版' }).locator('[data-a="restore"]').click(); await ready(c); await c.waitForTimeout(800);
  const after = await feats(c);
  ok('restore version', !after.includes('円柱2') && before.includes('円柱2'), `${before} → ${after}`);
  ok('restore is undoable', await c.evaluate(() => { window.__store.undo(); return window.__store.project.features.length; }) === before.split(',').length);
  const kinds = await c.evaluate(async (id) => (await window.__safety.library.history(id)).map(h => h.kind).join(','), await c.evaluate(() => window.__store.docId));
  ok('before-restore kept', kinds.includes('before') && kinds.includes('named') && kinds.includes('auto'), kinds);
  // 間引き: 古い自動の版をたくさん入れても、新しい 20 個＋1 日 1 個だけ残る。大きな取り込みデータは版どうしで共有
  const pr = await c.evaluate(async () => {
    const L = window.__safety.library, id = 'Dprune';
    const big = 'B'.repeat(300000);
    for (let i = 0; i < 40; i++) await L.addVersion(id, { format: 'kobocad', name: 'p', features: [{ id: 'F1', type: 'import', dataKey: 'k1', data: big }, { id: 'F' + i, type: 'box' }] }, { t: Date.now() - i * 6 * 3600e3 });
    const hs = await L.history(id);
    const blobs = await new Promise(r => { const q = indexedDB.open('gdc-cad'); q.onsuccess = () => { const g = q.result.transaction('blob').objectStore('blob').getAllKeys(); g.onsuccess = () => r(g.result.filter(k => k.startsWith(id + ':')).length); }; });
    const v = await L.loadVersion(hs[hs.length - 1].k);
    await L.remove(id);
    return { n: hs.length, blobs, restoredBig: v.features[0].data.length, maxSize: Math.max(...hs.map(h => h.size)) };
  });
  ok('history pruned + blobs shared', pr.n > 20 && pr.n <= 26 && pr.blobs === 1 && pr.restoredBig === 300000 && pr.maxSize < 2000, JSON.stringify(pr));

  // 7. .kcad を何度開いても一覧が増えない／.gdcbackup を「開く」で選んでも戻す処理になる
  const cnt = () => c.evaluate(async () => (await window.__safety.library.list()).length);
  const n0 = await cnt();
  await c.evaluate(async () => { const p = { ...JSON.parse(JSON.stringify(window.__store.project)), name: '受け取り' }; const f = new File([JSON.stringify(p)], '受け取り.kcad'); await window.__app.openDoc(f); await window.__app.openDoc(new File([JSON.stringify(p)], '受け取り.kcad')); });
  await c.waitForTimeout(800);
  ok('.kcad opened twice = 1 entry', (await cnt()) === n0 + 1, `${n0} → ${await cnt()}`);
  const bk = await c.evaluate(async () => { const t = await window.__safety.library.backup(); await window.__app.openDoc(new File([t], 'x.gdcbackup')); return document.getElementById('toast').textContent; });
  ok('.gdcbackup via open → restore', /戻す|戻しました/.test(bk), bk);

  // 8. 前回開く途中で止まったファイルは、次の起動で開かない（その次は開く）
  const lastId = await c.evaluate(() => window.__store.docId);
  await c.close();
  // 止まった（＝閉じる処理が走らなかった）状態を作る: 起動前に「開いている途中」の印を置く
  const d = await ctx.newPage(); d.on('pageerror', e => errs.push(e.message)); d.on('dialog', x => x.accept());
  await d.addInitScript((id) => { if (!sessionStorage.getItem('t-hung')) { sessionStorage.setItem('t-hung', '1'); localStorage.setItem('gdc-opening', JSON.stringify({ id, t: Date.now() })); localStorage.setItem('gdc-last-doc', id); } }, lastId);
  await d.goto(URL); await ready(d); await d.waitForTimeout(1200);
  ok('hung doc skipped once', (await d.evaluate(() => window.__store.project.features.length)) === 0 && (await d.locator('#toast').innerText()).includes('止まった'));
  await d.evaluate((id) => { sessionStorage.removeItem('gdc-tab-doc'); localStorage.setItem('gdc-last-doc', id); }, lastId);
  await d.reload(); await ready(d); await d.waitForTimeout(800);
  ok('opens normally next time', (await d.evaluate(() => window.__store.project.features.length)) > 0);

  // 9. 壊れたデータでも起動できる
  await d.evaluate(async () => {
    const q = indexedDB.open('gdc-cad'); await new Promise(r => q.onsuccess = r);
    const t = q.result.transaction(['meta', 'data'], 'readwrite');
    t.objectStore('data').put({ id: 'Dbroken', json: '{"format":"kobocad","features":[' });
    t.objectStore('meta').put({ id: 'Dbroken', name: '壊れた', updated: Date.now() + 1000 });
    t.objectStore('data').put({ id: 'Dodd', json: JSON.stringify({ format: 'kobocad', name: '変な形', features: 'x', params: null, bodyProps: [], rollback: 99 }) });
    t.objectStore('meta').put({ id: 'Dodd', name: '変な形', updated: Date.now() });
    await new Promise(r => t.oncomplete = r);
    sessionStorage.setItem('gdc-tab-doc', 'Dbroken');
  });
  await d.reload(); await ready(d); await d.waitForTimeout(800);
  ok('broken last doc → still starts', await d.evaluate(() => !!window.__app && window.__store.project.features.length === 0), await d.locator('#toast').innerText());
  await d.evaluate(() => sessionStorage.setItem('gdc-tab-doc', 'Dodd'));
  await d.reload(); await ready(d); await d.waitForTimeout(800);
  ok('odd doc sanitized', await d.evaluate(() => window.__store.project.name === '変な形' && Array.isArray(window.__store.project.features) && window.__store.project.rollback === null));
  await d.keyboard.press('Control+o'); await d.waitForTimeout(600);
  ok('library lists despite broken entry', await d.locator('.lib-card').count() >= 3);
  await d.locator('.lib-card', { hasText: '壊れた' }).locator('[data-a="open"]').click(); await d.waitForTimeout(600);
  ok('opening broken file shows error, no crash', (await d.locator('#toast').innerText()).length > 0 && await d.evaluate(() => window.__store.project.name) === '変な形');

  // 10. バックアップを長くしていないときの控えめなお知らせ（「あとで」で 3 日出ない）
  await d.evaluate(() => { document.querySelector('#dialog [data-o]')?.click(); localStorage.setItem('gdc-last-backup', String(Date.now() - 10 * 864e5)); localStorage.removeItem('gdc-backup-snooze'); });
  await d.reload(); await ready(d); await d.waitForTimeout(5800);
  const bb = bar(d, 'backup');
  ok('backup reminder', await bb.isVisible() && (await bb.innerText()).includes('10 日'));
  await bb.locator('button', { hasText: 'あとで' }).click();
  ok('snooze', !(await bb.count()) && await d.evaluate(() => +localStorage.getItem('gdc-backup-snooze') > Date.now() + 2 * 864e5));
  await d.screenshot({ path: 'files1.png' });
  console.log('page errors:', JSON.stringify(errs));
  await browser.close();
})();
