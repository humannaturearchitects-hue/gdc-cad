// 投影と点の寸法: 板の上面を投影 → 円を大まかに描く → 投影した辺からの距離で位置決め → 貫通の穴
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(250); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const meas = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list[0];
  const tool = (t) => page.click(`.tool:has-text("${t}")`);
  const ok = async () => { await page.click('#dialog [data-act="ok"]'); await idle(); };
  const ask = async (v) => { const i = page.locator('.inbox.ask input'); await i.fill(String(v)); await page.keyboard.press('Enter'); await page.waitForTimeout(300); };

  await tool('スケッチ作成'); await page.click('#planebar [data-pl=XY]'); await idle();
  await page.keyboard.press('r'); await page.mouse.click(...await scr([0, 0, 0])); await page.waitForTimeout(150);
  { const a = page.locator('.inbox input'); await a.nth(0).fill('300'); await a.nth(1).fill('200'); await page.keyboard.press('Enter'); await page.waitForTimeout(250); }
  await page.keyboard.press('e'); await idle(); await page.fill('#dialog input[data-k="distance"]', '10'); await idle(); await ok();
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  const V0 = (await meas()).volume;

  // 上面にスケッチ → P で面を投影
  await tool('スケッチ作成'); await page.mouse.click(...await scr([250, 150, 10])); await idle();
  await page.keyboard.press('p'); await page.waitForTimeout(150);
  await page.mouse.click(...await scr([250, 150, 10])); await idle();
  const ents = await page.evaluate(() => window.__app.sketcher.feature.entities.map(e => e.type + (e.proj ? '*' : '') + ':' + [e.x1, e.y1, e.x2, e.y2].map(Number).join(',')));
  console.log('projected', ents.length, JSON.stringify(ents));
  // 円 Ø20 をだいたい (60,50) に
  await page.keyboard.press('c'); await page.mouse.click(...await scr([60, 50, 10])); await page.waitForTimeout(150);
  await page.locator('.inbox input').nth(0).fill('20'); await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  const idx = await page.evaluate(() => { const es = window.__app.sketcher.feature.entities; return { c: es.findIndex(e => e.type === 'circle'), bottom: es.findIndex(e => e.proj && Math.abs(+e.y1) < 1e-6 && Math.abs(+e.y2) < 1e-6), left: es.findIndex(e => e.proj && Math.abs(+e.x1) < 1e-6 && Math.abs(+e.x2) < 1e-6) }; });
  console.log('  idx', JSON.stringify(idx));
  // 選択ツールで 円 + 下の辺 → 寸法 37.5
  await page.keyboard.press('s');
  const selPair = async (a, b) => {
    await page.keyboard.press('Escape');
    await page.evaluate(([a, b]) => { const s = window.__app.sketcher; s.selected.clear(); s.selected.add(a); s.selected.add(b); s.redraw(); }, [a, b]);
    await page.click('.tool:has-text("寸法")'); await page.waitForTimeout(200);
  };
  // 画面クリックでの選択も確認（円の縁をクリック、Shift で下の辺）
  await page.mouse.click(...await scr([70, 50, 10])); await page.waitForTimeout(150);
  await page.keyboard.down('Shift'); await page.mouse.click(...await scr([200, 0, 10])); await page.keyboard.up('Shift'); await page.waitForTimeout(150);
  console.log('  clicked selection', await page.evaluate(() => JSON.stringify([...window.__app.sketcher.selected])));
  await page.click('.tool:has-text("寸法")'); await page.waitForTimeout(200);
  console.log('  ask label', await page.locator('.inbox.ask .lbl').innerText().catch(() => 'none'));
  await ask(37.5);
  await selPair(idx.c, idx.left); await ask(42.5);
  const circ = await page.evaluate(() => { const e = window.__app.sketcher.feature.entities.find(e => e.type === 'circle'); return [e.cx, e.cy].map(Number); });
  console.log('  circle center after dims', JSON.stringify(circ), 'constraints', await page.evaluate(() => JSON.stringify((window.__app.sketcher.feature.constraints || []).map(c => c.type + ':' + c.value))));
  // 押し出し: 円を選んで切り取り（全体）
  await page.keyboard.press('e'); await idle();
  await page.click('#dialog [data-clr="items"]').catch(() => {}); await page.waitForTimeout(150);
  await page.mouse.click(...await scr([circ[0], circ[1], 10])); await idle();
  console.log('  items', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.items)));
  await page.selectOption('#dialog select[data-k="operation"]', 'cut'); await idle();
  await ok();
  const m = await meas(); const v = V0 - m.volume; const cx = (V0 * 150 - m.volume * (m.com.x ?? m.com[0])) / v, cy = (V0 * 100 - m.volume * (m.com.y ?? m.com[1])) / v;
  console.log(`### 投影＋寸法で位置決めした Ø20 の穴: 削れた体積 ${v.toFixed(1)}（期待 3141.6） 中心 (${cx.toFixed(2)}, ${cy.toFixed(2)})（期待 42.5, 37.5） errors ${JSON.stringify(await page.evaluate(() => window.__app.errors.map(e => e.message)))}`);
  await page.screenshot({ path: 'real6_end.png' });
  await browser.close();
})();
