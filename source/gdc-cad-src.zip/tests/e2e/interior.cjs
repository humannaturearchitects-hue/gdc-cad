// 内装ワークスペース: 見本スキャン → 方針 → 設計 → 図面・書き出し → 3D CAD へ
const { open } = require('./ux_common.cjs');
const fs = require('fs');
(async () => {
  const { browser, page } = await open();
  const shot = process.env.SHOTS || 'dl';
  const errs = [];
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  await page.click('.ws[data-ws=interior]');
  await page.waitForSelector('#interior-ws:not(.hidden)');
  await page.click('[data-a=sample]');
  await page.waitForSelector('.iw-table');
  const room = await page.evaluate(() => window.__app.interior.state.room);
  console.log('room', room.height, JSON.stringify(room.poly), room.openings.length);
  if (room.poly.length !== 6 || Math.abs(room.height - 2400) > 15 || room.openings.length !== 3) throw new Error('room extraction');
  await page.waitForTimeout(600);
  await page.screenshot({ path: `${shot}/interior_scan.png` });
  await page.click('[data-ex="1"]');
  await page.click('[data-a=design]');
  await page.waitForSelector('.iw-items li');
  const items = await page.evaluate(() => window.__app.interior.plan.items.map((i) => i.name));
  console.log('items', items.join(','));
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${shot}/interior_plan.png` });
  await page.click('.dw-pages [data-pg="0"]');
  await page.waitForTimeout(900);
  await page.screenshot({ path: `${shot}/interior_3d.png` });
  await page.click('.dw-pages [data-pg="2"]');
  await page.waitForTimeout(300);
  await page.screenshot({ path: `${shot}/interior_elev.png` });
  const n = await page.evaluate(() => window.__app.interior.sheets.length);
  await page.click(`.dw-pages [data-pg="${n}"]`);
  await page.waitForTimeout(300);
  await page.screenshot({ path: `${shot}/interior_table.png` });
  // 壁の長さを直す → 再設計
  await page.fill('[data-wall="0"]', '4600');
  await page.dispatchEvent('[data-wall="0"]', 'change');
  await page.waitForTimeout(300);
  const len = await page.evaluate(() => window.__app.interior.state.room.poly[1][0]);
  console.log('wall A edited ->', len);
  // 書き出し
  const dl = async (sel) => { const [d] = await Promise.all([page.waitForEvent('download'), page.click(sel)]); const p = `dl/${d.suggestedFilename()}`; await d.saveAs(p); return [p, fs.statSync(p).size]; };
  console.log('pdf', await dl('[data-x=pdf]'));
  console.log('csv', await dl('[data-x=csv]'));
  console.log('svg', await dl('[data-x=svg]'));
  // 3D CAD へ
  await page.click('[data-x=cad]');
  await page.waitForTimeout(500);
  await page.idle();
  await page.waitForTimeout(1500);
  const nb = await page.evaluate(() => window.__app.meshes.length);
  console.log('bodies in CAD', nb);
  await page.screenshot({ path: `${shot}/interior_cad.png` });
  if (!nb) throw new Error('no bodies');
  console.log('console errors', errs);
  await browser.close();
  console.log('OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
