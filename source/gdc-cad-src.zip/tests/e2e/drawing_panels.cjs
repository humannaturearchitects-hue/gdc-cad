// 図面（穴の位置寸法・穴表・表題欄）と書き出し（PDF 日本語・DXF・STEP 読み戻し・パネル加工 DXF / CSV）の確認
// 使い方: node drawing_panels.cjs   （ポートは 4173。python3 + ezdxf / pdfplumber / OCP があれば中身も検証）
const { chromium } = require('playwright');
const { execFileSync } = require('child_process');
const fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 4173;
const DL = path.resolve(process.env.DL || 'dl_dp');
fs.mkdirSync(DL, { recursive: true });
const ok = (name, cond, extra = '') => console.log(`${cond ? 'ok' : 'NG'}  ${name}${extra ? '  ' + extra : ''}`);
const py = (code, ...args) => { try { return execFileSync('python3', ['-c', code, ...args], { encoding: 'utf8' }).trim(); } catch (e) { return 'PYERR ' + (e.stderr || e.message).toString().slice(-300); } };
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, acceptDownloads: true });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  let n = 0;
  const save = async (fn, ext) => { const [d] = await Promise.all([page.waitForEvent('download', { timeout: 90000 }), fn()]); const p = path.join(DL, `f${++n}.${ext}`); await d.saveAs(p); return p; };
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  const cmds = [
    '板 幅600 奥行400 厚さ20 名前 床板',
    '穴 上面 Ø8 位置 30,25 570,25 570,375 30,375 床板',
    '穴 上面 Ø6.6 ざぐり径11 ざぐり深さ6.5 位置 300,200 床板',
    '穴 上面 Ø10 深さ10 位置 100,200 床板',
    'スケッチ 上面 床板', '長方形 0,150 40,250', '押し出し 切り取り 全体',
    '板 幅800 奥行300 厚さ15 位置 0,600,0 名前 棚板',
    '穴 上面 Ø5 位置 20,20 60,20 100,20 140,20 180,20 220,20 260,20 300,20 340,20 380,20 20,280 780,280 棚板',
    '材料 棚板 アルミ',
  ];
  for (const c of cmds) { const r = await page.evaluate((c) => window.__cmd(c), c); if (!r?.[0]?.ok) console.log('FAIL', c, JSON.stringify(r)); }
  await page.waitForTimeout(800);

  // 穴の認識（ざぐり・止め穴）
  const holes = await page.evaluate(() => window.__kcall('holes', { ids: [] }));
  const cb = holes.find((h) => h.dia === 6.6);
  ok('ざぐり穴を認識', cb && cb.through && cb.cbore && cb.cbore.dia === 11 && cb.cbore.depth === 6.5, JSON.stringify(cb));
  ok('止め穴の深さ', holes.some((h) => h.dia === 10 && !h.through && h.depth === 10));

  // STEP 書き出し → 読み戻し確認
  await page.evaluate(() => window.__app.openExport3D());
  await page.selectOption('#x-fmt', 'step');
  const stp = await save(() => page.click('#dialog [data-o]'), 'step');
  await page.waitForFunction(() => window.__lastStepCheck, null, { timeout: 60000 });
  const sc = await page.evaluate(() => window.__lastStepCheck);
  ok('STEP 読み戻しで体積一致（アプリ内）', sc.ok, `${sc.volume.toFixed(1)} / ${sc.expected.toFixed(1)}`);
  const stepPy = py(`
import sys,re
from OCP.STEPControl import STEPControl_Reader
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
t=open(sys.argv[1],encoding='latin-1').read()
r=STEPControl_Reader(); r.ReadFile(sys.argv[1]); r.TransferRoots(); s=r.OneShape()
g=GProp_GProps(); BRepGProp.VolumeProperties_s(s,g)
print(round(g.Mass(),1), 'MILLI' if re.search(r"SI_UNIT\\(\\.MILLI\\.,\\.METRE\\.\\)",t) else 'NOUNIT')`, stp);
  ok('STEP 別ソフト(OpenCASCADE)で体積一致・単位 mm', !stepPy.startsWith('PYERR') && Math.abs(parseFloat(stepPy) - sc.expected) < 0.5 && /MILLI/.test(stepPy), stepPy);

  // 図面
  await page.click('.ws[data-ws=drawing]');
  await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 });
  await page.selectOption('[data-s=mode]', 'each'); await page.waitForTimeout(2500);
  await page.fill('[data-t=number]', 'GDC-100'); await page.press('[data-t=number]', 'Tab');
  await page.fill('[data-t=rev]', 'B'); await page.press('[data-t=rev]', 'Tab');
  await page.fill('[data-t=author]', '山田'); await page.press('[data-t=author]', 'Tab');
  await page.waitForTimeout(2000);
  let info = await page.evaluate(() => ({ h: window.__app.drawing.sheet.holes, t: window.__app.drawing.sheet.texts.map((t) => t.text) }));
  ok('床板: 穴の位置を累進寸法で記入', info.h.mode === 'dims' && info.t.includes('570') && info.t.includes('375'), JSON.stringify(info.h).slice(0, 80));
  ok('床板: 穴の呼び（ざぐり・深さ）', info.t.includes('Ø6.6 貫通 ざぐりØ11 深さ6.5') && info.t.includes('Ø10 深さ10') && info.t.includes('4×Ø8 貫通'));
  ok('表題欄: 図番・改訂・作成者', info.t.includes('GDC-100-1') && info.t.includes('B') && info.t.includes('山田'));
  await page.selectOption('[data-s=holePos]', 'table'); await page.waitForTimeout(2500);
  await page.click('.dw-pages button[data-p="1"]'); await page.waitForTimeout(2500);
  info = await page.evaluate(() => ({ h: window.__app.drawing.sheet.holes, t: window.__app.drawing.sheet.texts.map((t) => t.text) }));
  ok('棚板: 穴表（12 行）と記号', info.h.mode === 'table' && info.h.rows.length === 12 && info.t.includes('A12') && info.t.includes('780'));
  ok('表題欄: 材質を部品の材料から自動', info.t.some((t) => /アルミ/.test(t)));
  const remembered = await page.evaluate(() => localStorage.getItem('gdc.drawing.title'));
  ok('作成者を次の図面にも引き継ぐ', /山田/.test(remembered || ''));
  const hcsv = await save(() => page.click('[data-x=holecsv]'), 'csv');
  const hc = fs.readFileSync(hcsv, 'utf8');
  ok('穴表 CSV', hc.charCodeAt(0) === 0xfeff && hc.split('\r\n').filter(Boolean).length === 13 && hc.includes('A12,780,280,Ø5 貫通'));
  const pdf = await save(() => page.click('[data-x=pdf]'), 'pdf');
  const pdfPy = py(`
import sys,pdfplumber
p=pdfplumber.open(sys.argv[1])
print(len(p.pages), round(p.pages[0].width*25.4/72), round(p.pages[0].height*25.4/72), '|', ' '.join(pg.extract_text().replace('\\n',' ') for pg in p.pages))`, pdf);
  ok('PDF: 2 ページ A3・日本語の文字が入っている', /^2 420 297/.test(pdfPy) && /床板/.test(pdfPy) && /棚板/.test(pdfPy) && /穴表/.test(pdfPy) && /第三角法/.test(pdfPy), pdfPy.slice(0, 60));
  const dxf = await save(() => page.click('[data-x=dxf]'), 'dxf');
  const dxfPy = py(`
import sys
from ezdxf import recover
d,a=recover.readfile(sys.argv[1])
t=[e.dxf.text for e in d.modelspace().query('TEXT')]
print(d.dxfversion, d.header.get('$INSUNITS'), len(a.errors), int('穴表（基準: 左下の角, mm）' in t), int('' in t))`, dxf);
  ok('図面 DXF: R12・mm・エラーなし・日本語・空文字なし', dxfPy === 'AC1009 4 0 1 0', dxfPy);

  // パネル加工データ
  await page.click('[data-x=panels]');
  await page.waitForSelector('#pn-list');
  await page.click('#dialog .x');
  await page.click('.ws[data-ws=design]'); await page.waitForTimeout(500);
  await page.click('#menu-file .menu-btn'); await page.click('text=パネル加工データ');
  await page.waitForSelector('#pn-list'); await page.waitForTimeout(300);
  const msg = await page.locator('#pn-msg').innerText();
  ok('板取り: 厚さ違いは別の板（2 枚）', /材料の板 2 枚/.test(msg), msg);
  const nd = await save(() => page.click('#pn-dxf'), 'dxf');
  const ndPy = py(`
import sys
from ezdxf import recover
from collections import Counter
d,a=recover.readfile(sys.argv[1])
m=d.modelspace()
c=Counter(e.dxf.layer for e in m)
cl=all(e.is_closed for e in m.query('POLYLINE[layer=="OUTLINE"]'))
print(d.header.get('$INSUNITS'), len(a.errors), c['OUTLINE'], c['HOLES'], c['POCKET_D10'], c['POCKET_D6.5'], int(cl), int(any('床板' in e.dxf.text for e in m.query('TEXT'))))`, nd);
  ok('板取り DXF: 外形(閉じた線)・穴・彫り(深さ別)・ラベル', ndPy === '4 0 2 17 1 1 1 1', ndPy);
  const cs = await save(() => page.click('#pn-csv'), 'csv');
  const cl = fs.readFileSync(cs, 'utf8');
  ok('切り出し一覧 CSV', cl.charCodeAt(0) === 0xfeff && /1,床板,600,400,20,1,,0\.240/.test(cl) && /2,棚板,800,300,15,1,アルミ/.test(cl) && /表彫り 深さ10/.test(cl), cl.split('\r\n')[1]);
  await page.check('#pn-ascii');
  const na = await save(() => page.click('#pn-dxf'), 'dxf');
  const txt = fs.readFileSync(na, 'latin1');
  ok('英数字だけのラベル', !/\\U\+/.test(txt) && /\nP1\r/.test(txt));
  await browser.close();
})();
