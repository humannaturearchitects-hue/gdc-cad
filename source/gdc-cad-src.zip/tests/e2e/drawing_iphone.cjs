// iPhone: 図面 PDF を共有シートで渡せるか（作成に時間がかかってタップの有効期限が切れた場合も、ボタンで共有できる）
// PLAYWRIGHT_BROWSERS_PATH=/home/user/agentkit/pwb node drawing_iphone.cjs
const { webkit, devices } = require('playwright');
const PORT = process.env.PORT || 4173;
(async () => {
  const browser = await webkit.launch();
  const ctx = await browser.newContext({ ...devices['iPhone 15'], serviceWorkers: 'block' });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.addInitScript(() => {
    window.__shared = []; window.__expire = true;
    navigator.canShare = () => true;
    navigator.share = async (d) => {
      if (window.__expire) { window.__expire = false; const e = new Error('not allowed'); e.name = 'NotAllowedError'; throw e; }
      window.__shared.push(d.files.map((f) => f.name + ':' + f.type + ':' + f.size).join(','));
    };
  });
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  for (const c of ['板 幅600 奥行400 厚さ20 名前 床板', '穴 上面 Ø8 位置 30,25 570,25 570,375 30,375 床板']) await page.evaluate((c) => window.__cmd(c), c);
  await page.waitForTimeout(800);
  await page.evaluate(() => window.__app.setWorkspace('drawing'));
  await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 });
  const btn = page.locator('[data-xq=pdf]');
  await btn.scrollIntoViewIfNeeded(); await btn.tap();
  await page.waitForSelector('#share-offer [data-a="share"]', { timeout: 60000 });
  console.log('share button shown: true');
  await page.tap('#share-offer [data-a="share"]');
  await page.waitForFunction(() => window.__shared.length, null, { timeout: 10000 });
  console.log('shared: ' + await page.evaluate(() => window.__shared[0]));
  console.log('panel removed: ' + (await page.locator('#share-offer').count() === 0));
  await browser.close();
})();
