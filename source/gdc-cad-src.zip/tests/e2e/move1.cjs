// 移動の矢印: ボディを選んで M → 矢印が出る → Z の矢印を上にドラッグ → X の矢印 → 回転リング → OK
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', d => d.accept());
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(250); };
  await page.evaluate(() => window.__cmd('板 200x100x40 名前 箱'));
  await page.click('[data-nav=home]'); await idle();
  const r = await page.locator('#view3d').boundingBox();
  const bounds = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list.map(b => b.bounds.map(p => p.map(v => +v.toFixed(1)).join(',')).join(' / ')).join(' ; ');
  // ボディを選ぶ（ツリー）→ M
  await page.click('[data-body]'); await page.keyboard.press('m'); await idle();
  console.log('gizmo?', await page.evaluate(() => !!window.__app.mvGizmo));
  const seg = async (name) => page.evaluate((n) => { const p = window.__app.mvGizmo.parts.find(q => q.name === n); return [p.a, p.b]; }, name);
  const drag = async (from, dx, dy, steps = 10) => { await page.mouse.move(r.x + from[0], r.y + from[1]); await page.mouse.down(); for (let i = 1; i <= steps; i++) { await page.mouse.move(r.x + from[0] + dx * i / steps, r.y + from[1] + dy * i / steps); await page.waitForTimeout(25); } const lab = await page.locator('.hcur').innerText().catch(() => ''); await page.mouse.up(); await idle(); return lab; };
  // Z 矢印を上に
  let [a, b] = await seg('Z'); let mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  console.log('  Z drag label:', await drag(mid, 0, -80));
  console.log('  translate after Z:', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.translate)), 'cam?', await page.evaluate(() => window.__app.viewer.controls.enabled));
  // X 矢印を右へ
  [a, b] = await seg('X'); mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const dir = [b[0] - a[0], b[1] - a[1]]; const L = Math.hypot(...dir);
  console.log('  X drag label:', await drag(mid, dir[0] / L * 100, dir[1] / L * 100));
  console.log('  translate after X:', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.translate)));
  // 回転リング（Z 軸）を回す
  const ring = await page.evaluate(() => window.__app.mvGizmo.parts.find(q => q.kind === 'ring').pts);
  const p0 = ring[0], p1 = ring[8];
  await page.mouse.move(r.x + p0[0], r.y + p0[1]); await page.mouse.down();
  for (let i = 1; i <= 8; i++) { const q = ring[i]; await page.mouse.move(r.x + q[0], r.y + q[1]); await page.waitForTimeout(30); }
  const rl = await page.locator('.hcur').innerText().catch(() => ''); await page.mouse.up(); await idle();
  console.log('  ring label:', rl, '| angle', await page.evaluate(() => window.__app.dialog.active.draft.angle), 'center', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.center)));
  await page.screenshot({ path: 'move1.png' });
  console.log('  scene:', await page.evaluate(() => { const v = window.__app.viewer; const out = []; for (const [id, b] of v.bodies) out.push(id + ' pos ' + b.mesh.position.toArray().map(Math.round) + ' q ' + b.mesh.quaternion.toArray().map(x => x.toFixed(2)) + ' vis ' + b.mesh.visible); out.push('hl ' + v.hlGroup.children.map(o => o.userData.tag + ':' + o.type + (o.userData.shared ? '(shared)' : '')).join(',')); out.push('meshes ' + window.__app.meshes.map(m => m.id + ' src ' + m.src).join(',')); return out.join(' | '); }));
  // 数値で直して OK
  await page.fill('#dialog input[data-k="angle"]', '90'); await idle();
  await page.click('#dialog [data-act="ok"]'); await idle();
  console.log('### 移動後の外形:', await bounds());
  void p1;
  await browser.close();
})();
