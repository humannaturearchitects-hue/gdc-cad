// 実際の操作 その2: 線で L 字 → 押し出し → 側面にスケッチ（既定で結合）→ 上面に円をマイナス距離（自動で切り取り）→ 元に戻す/やり直し
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(200); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const state = async (label) => {
    const s = await page.evaluate(() => ({ feats: window.__store.project.features.map(f => f.type + (f.operation ? '(' + f.operation + ')' : '')), bodies: window.__app.meshes.map(m => m.name), errors: window.__app.errors.map(e => e.message) }));
    let vol = ''; try { const r = await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 })); vol = r.list.map(b => `${b.name}:${Math.round(b.volume)} [${b.bounds.map(p => p.map(Math.round).join(',')).join(' / ')}]`).join(' ; '); } catch (e) { vol = 'measure err ' + e.message; }
    console.log(`\n### ${label}\n  feats ${s.feats.join(',')}\n  bodies ${s.bodies.join(',')} errors ${JSON.stringify(s.errors)}\n  ${vol}`);
  };
  const tool = (t) => page.click(`.tool:has-text("${t}")`);

  // L 字を線で（グリッドにスナップ）
  await tool('スケッチ作成'); await page.waitForTimeout(200);
  { const s = await page.evaluate(() => window.__app.viewer.planeMeshes.find(p => p.userData.name === 'XY').scale.x); await page.mouse.click(...await scr([s * .3, -s * .3, 0])); }
  console.log('  plane', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature?.plane)));
  await idle();
  await page.keyboard.press('l');
  for (const [x, y] of [[0, 0], [300, 0], [300, 50], [50, 50], [50, 200], [0, 200], [0, 0]]) { const p = await scr([x, y, 0]); await page.mouse.move(p[0], p[1], { steps: 4 }); await page.waitForTimeout(100); await page.mouse.click(...p); await page.waitForTimeout(250); console.log('  click', x, y, '->', p.map(Math.round).join(','), 'ents', await page.evaluate(() => window.__app.sketcher.feature.entities.length), 'wpp', await page.evaluate(() => window.__app.viewer.worldPerPixel().toFixed(3))); }
  await page.keyboard.press('Escape'); await page.waitForTimeout(200);
  const ents = await page.evaluate(() => window.__app.sketcher.feature.entities.map(e => [e.x1, e.y1, e.x2, e.y2].map(Number).join(',')));
  console.log('L lines', ents.length, JSON.stringify(ents));
  await page.screenshot({ path: 'real2_L.png' });
  await page.keyboard.press('e'); await idle();
  await page.fill('#dialog input[data-k="distance"]', '500'); await idle();
  await page.click('#dialog [data-act="ok"]'); await idle();
  await state('1 L 字 押し出し 500（体積 = (300*50+50*150)*500 = 11,250,000）');

  // 長い方の側面（x=300 の端面 … y 0..50, z 0..500）にスケッチ
  await tool('スケッチ作成'); await page.waitForTimeout(300);
  await page.mouse.click(...await scr([300, 25, 250])); await idle();
  const pl = await page.evaluate(() => window.__app.sketcher.feature?.plane);
  console.log('  side plane', JSON.stringify(pl && { type: pl.type, origin: pl.origin, normal: pl.normal }));
  await page.keyboard.press('c');
  await page.mouse.click(...await scr([300, 25, 250])); await page.waitForTimeout(200);
  const inp = page.locator('.inbox input').first(); await inp.fill('30'); await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  console.log('  circle', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature.entities)));
  await page.keyboard.press('e'); await idle();
  console.log('  default op:', await page.evaluate(() => document.querySelector('#dialog select[data-k="operation"]').value));
  await page.fill('#dialog input[data-k="distance"]', '40'); await idle();
  await page.click('#dialog [data-act="ok"]'); await idle();
  await state('2 側面に Ø30 のボス 40（1 つのボディのまま、体積 +28,274）');

  // 上面（z=500）に円 → 距離 -100 で自動切り取り
  await page.click('[data-nav=home]');
  await page.waitForTimeout(500);
  await tool('スケッチ作成'); await page.waitForTimeout(300);
  await page.mouse.click(...await scr([25, 150, 500])); await idle();
  console.log('  top plane', JSON.stringify(await page.evaluate(() => { const p = window.__app.sketcher.feature?.plane; return p && { type: p.type, origin: p.origin, normal: p.normal }; })));
  await page.keyboard.press('c');
  await page.mouse.click(...await scr([25, 150, 500])); await page.waitForTimeout(200);
  { const i = page.locator('.inbox input').first(); await i.fill('20'); await page.keyboard.press('Enter'); await page.waitForTimeout(300); }
  await page.keyboard.press('e'); await idle();
  await page.fill('#dialog input[data-k="distance"]', '-100'); await idle();
  console.log('  op after -100:', await page.evaluate(() => document.querySelector('#dialog select[data-k="operation"]').value));
  await page.screenshot({ path: 'real2_cut.png' });
  await page.click('#dialog [data-act="ok"]'); await idle();
  await state('3 上面から Ø20 深さ 100 の穴（体積 -31,416）');

  // 元に戻す ×2 → やり直し ×2
  await page.mouse.click(vp.x + 30, vp.y + vp.height - 30);
  await page.keyboard.press('Control+z'); await idle(); await page.keyboard.press('Control+z'); await idle();
  await state('4 元に戻す ×2');
  await page.keyboard.press('Control+y'); await idle(); await page.keyboard.press('Control+y'); await idle();
  await state('5 やり直し ×2');
  await page.screenshot({ path: 'real2_end.png' });
  await browser.close();
})();
