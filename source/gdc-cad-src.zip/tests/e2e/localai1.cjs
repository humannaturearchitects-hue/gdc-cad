// AI の頭脳を選ぶ（端末内 AI・自分のパソコンの AI・コピー＆貼り付け・Claude）
// 使い方: PORT=4173 node localai1.cjs（Chromium）／ WK=1 PLAYWRIGHT_BROWSERS_PATH=…/pwb node localai1.cjs（iPhone）
// 端末内 AI は「決まった返事をする偽の Worker」で（本物のモデルでの評価は localai_eval.cjs）、
// パソコンの AI は page.route で OpenAI 互換サーバーを模擬する。外部には何も送らない。
const { chromium, webkit, devices } = require('playwright');
const PORT = process.env.PORT || 4173;
const URL0 = `http://127.0.0.1:${PORT}/`;
let pass = 0, fail = 0;
const check = (name, ok, extra = '') => { ok ? pass++ : fail++; console.log(`${ok ? '  ✓' : '  ✗'} ${name}${extra ? ' — ' + extra : ''}`); };

// 偽の WebGPU と偽の端末内 AI（Worker の代わり）
const FAKE = ({ gpu = true } = {}) => `
  ${gpu ? `Object.defineProperty(navigator, 'gpu', { configurable: true, value: { requestAdapter: async () => ({ features: new Set(['shader-f16']), limits: { maxBufferSize: 2 ** 30 } }) } });` : `try { Object.defineProperty(navigator, 'gpu', { configurable: true, value: undefined }); } catch (e) {}`}
  window.__fakeReqs = []; window.__fakeAnswers = []; window.__fakeLoads = 0;
  window.__localaiWorker = class {
    postMessage(m) { setTimeout(() => this.handle(m), 5); }
    handle(m) {
      const send = (d) => this.onmessage && this.onmessage({ data: d });
      if (m.type === 'has') send({ type: 'has', id: m.id, has: localStorage.getItem('fake-cached') === '1' });
      else if (m.type === 'load') { window.__fakeLoads++; window.__fakeLoad = m; let k = 0; const step = () => { k++; send({ type: 'progress', id: m.id, progress: k / 4, text: 'dl' }); if (k < 4) setTimeout(step, 30); else { localStorage.setItem('fake-cached', '1'); caches.open('webllm/model').then((c) => c.put(m.appConfig.model_list[0].model.replace(/[/]$/, '') + '/resolve/main/tensor-cache.json', new Response('{}'))).then(() => send({ type: 'loaded', id: m.id })); } }; step(); }
      else if (m.type === 'chat') { window.__fakeReqs.push(m.request); const a = window.__fakeAnswers.shift(); send({ type: 'result', id: m.id, content: a == null ? '質問: もう一度お願いします' : a, usage: {} }); }
      else if (m.type === 'delete') { localStorage.removeItem('fake-cached'); caches.delete('webllm/model').then(() => send({ type: 'deleted', id: m.id })); }
    }
    terminate() {}
  };`;

(async () => {
 if (!process.env.WK) {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const open = async (init, { brain, clear = true } = {}) => {
    const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, serviceWorkers: 'block' });
    await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: URL0.replace(/\/$/, '') });
    if (init) await ctx.addInitScript(init);
    const page = await ctx.newPage();
    page.dialogs = [];
    page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
    page.on('dialog', (d) => { page.dialogs.push(d.message()); d.accept(); });
    await page.goto(URL0);
    if (clear) await page.evaluate((b) => { localStorage.clear(); if (b) localStorage.setItem('gdc-ai-brain', b); }, brain);
    await page.reload();
    await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
    await page.click('.tool:has-text("AI に頼む")'); await page.waitForTimeout(300);
    return page;
  };
  const idle = (page) => page.waitForFunction(() => !window.__app.buildsRunning && document.getElementById('busy').classList.contains('hidden') && !document.querySelector('.cmd-item.thinking'), null, { timeout: 60000 });
  const say = async (page, t) => { await page.fill('#cmd-in', t); await page.click('#cmd-run'); await page.waitForTimeout(400); await idle(page); await page.waitForTimeout(800); };
  const bodies = (page) => page.evaluate(async () => { const ms = window.__app.meshes; if (!ms.length) return ''; const r = await window.__kcall('measure', { ids: ms.map((m) => m.id), density: 1 }); return r.list.map((b) => `${b.name}:${Math.round(b.volume)}`).join(' '); });
  const logText = (page) => page.locator('#cmd-log').innerText();

  // ===== 1. 端末内 AI（既定）
  console.log('[端末内 AI]');
  let page = await open(FAKE());
  await page.click('.cmd-set > summary');
  check('AI の種類の既定は端末内 AI', (await page.$eval('#ai-brain', (s) => s.value)) === 'local');
  check('Claude 以外では API キーの欄を出さない', !(await page.isVisible('#ai-key')) && await page.isVisible('#local-dl'));
  await say(page, '60センチ×40センチで厚さ2センチの床板を作って');
  let lt = await logText(page);
  check('ダウンロード前でも、すぐ端末の中の読み取りで実行（同意の画面で止めない）', page.dialogs.length === 0 && /床板:4800000/.test(await bodies(page)) && (await page.evaluate(() => window.__fakeReqs.length)) === 0, await bodies(page));
  check('読み取りで分かるときはダウンロードを勧めない', !(await page.isVisible('[data-lai-offer]')));
  await say(page, 'すみっこ4か所にØ8、ふちから3センチ');
  lt = await logText(page);
  check('読み取りで分からないときに端末内 AI のダウンロードを勧める', await page.isVisible('[data-lai-offer]') && /約 880 MB/.test(lt) && page.dialogs.length === 0);
  check('API キーは聞かない', !page.dialogs.some((m) => /API キー/.test(m)));
  await page.click('[data-lai-offer]'); await page.waitForTimeout(600);
  check('押すとダウンロードの同意（大きさ・Wi-Fi）を聞く', page.dialogs.some((m) => /ダウンロード/.test(m) && /MB/.test(m) && /Wi-Fi/.test(m)), page.dialogs.join(' / ').slice(0, 80));
  await page.waitForFunction(() => /準備ができました/.test(document.getElementById('cmd-log').innerText), null, { timeout: 10000 });
  check('進み具合を表示して準備完了', /準備ができました/.test(await logText(page)) && (await page.$eval('.lai-prog progress', (p) => p.value)) === 1);
  check('モデルは Cache Storage に保存する設定（2048 文字分）', await page.evaluate(() => window.__fakeLoad.appConfig.cacheBackend === 'cache' && window.__fakeLoad.chatOpts.context_window_size === 2048 && /q4f16/.test(window.__fakeLoad.modelId)), await page.evaluate(() => window.__fakeLoad.modelId));
  await page.evaluate(() => { window.__fakeAnswers.length = 0; window.__fakeAnswers.push('穴 上面 Ø8 四隅 30 床板'); });
  await say(page, 'すみっこ4か所にØ8、ふちから3センチ');
  let req = await page.evaluate(() => window.__fakeReqs[0]);
  check('読み取りで分からない言い方は端末内 AI へ', !!req, String(await page.evaluate(() => window.__fakeReqs.length)));
  check('言葉を整えてから渡す（3センチ→30）', /ふちから30/.test(req.messages.at(-1).content), req.messages.at(-1).content.slice(-40));
  check('出力を文法で縛る', req.response_format.type === 'grammar' && /board ::=/.test(req.response_format.grammar));
  check('短い説明を使う（詳しい説明より小さい）', req.messages[0].content.length < 2500, String(req.messages[0].content.length));
  check('今ある部品名を文法に入れる', /body ::= "床板"/.test(req.response_format.grammar));
  check('「四隅 30」を座標に直して穴をあける', /床板:4795979/.test(await bodies(page)), await bodies(page) + ' ' + (await logText(page)).slice(-200).replace(/\n/g, ' / '));
  await page.evaluate(() => window.__fakeAnswers.push('床板 厚さ 35'));
  await say(page, 'ゆかいた3センチぐらいのぶあつさで');
  lt = await logText(page);
  check('数値が言葉と合わないときは言葉の数に直す（35→30）', /35→30/.test(lt) && /床板:71939\d\d/.test(await bodies(page)), await bodies(page));
  await page.evaluate(() => window.__fakeAnswers.push('移動 床板 右 77'));
  await say(page, 'ゆかいたをむこうがわへ');
  lt = await logText(page);
  check('根拠のない数値は確かめてから実行（自動では実行しない）', /確かめてから実行/.test(lt) && await page.isVisible('[data-ai-go]'));
  await page.evaluate(() => window.__fakeAnswers.push('質問: 穴の直径は何mmにしますか？'));
  await say(page, '穴をあけて');
  check('足りないときは聞き返す（読み取りの質問）', /穴の直径/.test(await logText(page)), (await logText(page)).slice(-200).replace(/\n/g, ' / '));
  // 2 回目の起動: ダウンロード済み → 同意は聞かず、待ってから端末内 AI で
  const ctx1 = page.context();
  page.dialogs.length = 0;
  await page.reload(); await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.click('.tool:has-text("AI に頼む")'); await page.waitForTimeout(300);
  await page.evaluate(() => { window.__fakeAnswers.length = 0; window.__fakeAnswers.push('床板 厚さ 20'); });
  await say(page, 'ゆかいた2センチぐらいのぶあつさで');
  check('2 回目はダウンロード済みなので同意なしで端末内 AI', page.dialogs.length === 0 && (await page.evaluate(() => window.__fakeReqs.length)) === 1 && /床板:4795979/.test(await bodies(page)), page.dialogs.join('/') + ' ' + await bodies(page));
  await page.click('.cmd-set > summary');
  await page.waitForTimeout(300);
  check('設定に「ダウンロード済み／使えます」を表示', /使えます|ダウンロード済み/.test(await page.textContent('#local-st')), await page.textContent('#local-st'));
  await page.selectOption('#ai-brain', 'nlu'); await page.waitForTimeout(300);
  check('「端末の中の読み取り」を選ぶと「AI を使わない」と同じ', await page.isChecked('#ai-off') && (await page.evaluate(() => localStorage.getItem('gdc-voice-ai'))) === '0');
  const nreq = await page.evaluate(() => window.__fakeReqs.length);
  await say(page, '床板の厚さを25にして');
  check('読み取りで実行（端末内 AI には聞かない）', /床板:59\d{5}/.test(await bodies(page)) && (await page.evaluate(() => window.__fakeReqs.length)) === nreq, await bodies(page));
  await page.uncheck('#ai-off'); await page.waitForTimeout(200);
  check('「AI を使わない」を外すと端末内 AI に戻る', (await page.$eval('#ai-brain', (s) => s.value)) === 'local');
  await ctx1.close();

  // ===== 2. WebGPU が無い端末
  console.log('[WebGPU なし]');
  page = await open(FAKE({ gpu: false }));
  await say(page, '床板を作ってください');
  lt = await logText(page);
  check('WebGPU が無いと分かりやすく知らせ、AI なしの言葉の解釈で続ける', /WebGPU/.test(lt) && /AI を使わずに/.test(lt), lt.slice(-120).replace(/\n/g, ' '));
  await say(page, '板 幅100 奥行100 厚さ10');
  check('決まった書き方なら AI を通さずそのまま実行', /:100000/.test(await bodies(page)), await bodies(page));
  await page.context().close();

  // ===== 3. 自分のパソコンの AI（OpenAI 互換・模擬）
  console.log('[自分のパソコンの AI]');
  page = await open(null, { brain: 'pc' });
  const pcReqs = []; let mode = 'ok';
  const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' };
  await page.route('https://mypc.tail0000.ts.net/**', async (route) => {
    const r = route.request(), u = new URL(r.url());
    if (r.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: CORS });
    if (mode === 'down') return route.abort('connectionrefused');
    if (mode === 'nocors') return u.pathname.startsWith('/v1') ? route.abort('failed') : route.fulfill({ status: 200, body: 'ok' }); // ブラウザが CORS で止めたときと同じ（届くが読めない）
    if (u.pathname === '/v1/models') return route.fulfill({ status: 200, headers: CORS, contentType: 'application/json', body: JSON.stringify({ object: 'list', data: [{ id: 'muse-local' }, { id: 'qwen2.5:14b' }] }) });
    if (u.pathname === '/v1/chat/completions') {
      const body = JSON.parse(r.postData()); pcReqs.push({ body, h: r.headers() });
      if (!['muse-local', 'qwen2.5:14b'].includes(body.model)) return route.fulfill({ status: 404, headers: CORS, contentType: 'application/json', body: '{"error":{"message":"model not found"}}' });
      if (mode === 'plain') return route.fulfill({ status: 200, headers: CORS, contentType: 'application/json', body: JSON.stringify({ id: 'c2', object: 'chat.completion', model: body.model, choices: [{ index: 0, message: { role: 'assistant', content: '```\n板 幅600 奥行400 厚さ20 名前 床板\n```\n床板を作ります。' }, finish_reason: 'stop' }] }) });
      if (body.response_format && body.response_format.type === 'json_schema') return route.fulfill({ status: 400, headers: CORS, contentType: 'application/json', body: '{"error":{"message":"response_format json_schema is not supported"}}' });
      const last = body.messages.at(-1).content;
      const ans = /はい/.test(last) ? 'はい' : JSON.stringify({ commands: '板 幅1200 奥行600 厚さ15 名前 天板', explanation: '天板を作ります。', question: '' });
      return route.fulfill({ status: 200, headers: CORS, contentType: 'application/json', body: JSON.stringify({ id: 'c1', object: 'chat.completion', model: body.model, choices: [{ index: 0, message: { role: 'assistant', content: ans }, finish_reason: 'stop' }] }) });
    }
    return route.fulfill({ status: 404, headers: CORS, body: 'not found' });
  });
  await page.click('.cmd-set > summary');
  check('パソコンの AI を選ぶと URL・モデル・接続テストが出る', await page.isVisible('#pc-url') && await page.isVisible('#pc-test') && !(await page.isVisible('#ai-key')));
  await page.fill('#pc-url', 'https://mypc.tail0000.ts.net'); await page.dispatchEvent('#pc-url', 'change');
  await page.fill('#pc-header', 'Authorization: Bearer test-123'); await page.dispatchEvent('#pc-header', 'change');
  await page.click('#pc-list'); await page.waitForTimeout(500);
  check('/v1/models から一覧して選べる', /2 個のモデル/.test(await page.textContent('#pc-st')) && (await page.$$eval('#pc-model-pick option', (o) => o.map((x) => x.textContent))).join(',') === 'muse-local,qwen2.5:14b', await page.textContent('#pc-st'));
  await page.selectOption('#pc-model-pick', 'muse-local');
  await page.click('#pc-test'); await page.waitForTimeout(800);
  check('接続テスト成功', /つながりました（muse-local/.test(await page.textContent('#pc-st')), await page.textContent('#pc-st'));
  pcReqs.length = 0;
  await say(page, '1.2メートル×60センチ、厚さ15ミリの天板を作って');
  check('パソコンの AI の答えで天板ができる', /天板:10800000/.test(await bodies(page)), await bodies(page));
  const big = pcReqs.find((x) => x.body.response_format && x.body.response_format.type === 'json_object') || {};
  check('詳しい説明（SYSTEM）を送る', big.body && big.body.messages[0].content.length > 5000 && /コマンドの使い方/.test(big.body.messages[0].content));
  check('json_schema が使えないときは json_object で続ける', pcReqs[0].body.response_format.type === 'json_schema' && !!big.body);
  check('任意のヘッダーを付ける', (big.h || {}).authorization === 'Bearer test-123');
  // 自作の中継（答えの形を守らず、``` で囲んだコマンドを返す）でも動く
  mode = 'plain';
  await say(page, '床板を作って');
  check('JSON で返さない自作の AI でもコマンドを取り出して実行', /床板:4800000/.test(await bodies(page)), await bodies(page));
  mode = 'ok';
  // エラーの見分け
  await page.fill('#pc-model', 'nai-model'); await page.dispatchEvent('#pc-model', 'change');
  await page.click('#pc-test'); await page.waitForTimeout(600);
  check('モデル無し', /モデル「nai-model」がパソコンの AI にありません/.test(await page.textContent('#pc-st')), await page.textContent('#pc-st'));
  await page.fill('#pc-model', 'muse-local'); await page.dispatchEvent('#pc-model', 'change');
  mode = 'nocors'; await page.click('#pc-test'); await page.waitForTimeout(800);
  check('CORS（届くが許可されていない）', /CORS/.test(await page.textContent('#pc-st')) && /OLLAMA_ORIGINS/.test(await page.textContent('#pc-st')), await page.textContent('#pc-st'));
  mode = 'down'; await page.click('#pc-test'); await page.waitForTimeout(800);
  check('届かない', /届きません/.test(await page.textContent('#pc-st')), await page.textContent('#pc-st'));
  mode = 'ok';
  await page.fill('#pc-url', 'http://example-pc.example.com:11434'); await page.dispatchEvent('#pc-url', 'change');
  await page.evaluate(() => { window.__pageHttps = true; });
  await page.click('#pc-test'); await page.waitForTimeout(500);
  check('混在コンテンツ（https のページから http の LAN）', /混在コンテンツ/.test(await page.textContent('#pc-st')) && /Tailscale/.test(await page.textContent('#pc-st')), await page.textContent('#pc-st'));
  await page.context().close();

  // ===== 4. ほかの AI アプリに頼む（コピー＆貼り付け）
  console.log('[コピー＆貼り付け]');
  page = await open(null, { brain: 'paste' });
  await page.evaluate(() => window.__cmd('板 幅600 奥行400 厚さ20 名前 床板')); await idle(page);
  await say(page, '床板の厚さを30にして');
  lt = await logText(page);
  check('機密の警告を出す', /機密/.test(lt) && /端末内 AI/.test(lt));
  check('送る内容（頼みごと＋モデルの概要）を見せる', /頼みごと: 床板の厚さを30にして/.test(await page.textContent('.paste-sent')) && /床板: 600×400×20/.test(await page.textContent('.paste-sent')));
  check('API キーは聞かない', !page.dialogs.some((m) => /API キー/.test(m)));
  await page.click('[data-paste-copy]'); await page.waitForTimeout(400);
  check('コピーの前に同意を取る', page.dialogs.some((m) => /機密/.test(m) && /コピーしますか/.test(m)));
  const clip = await page.evaluate(() => navigator.clipboard.readText().catch(() => ''));
  check('説明＋概要＋頼みごとがコピーされる', /コマンドの使い方/.test(clip) && /床板の厚さを30にして/.test(clip) && /```/.test(clip), String(clip.length));
  await page.fill('.paste-in', 'わかりました。床板の厚さを 30 mm に変更します。\n\n```\n床板 厚さ 30\n```\n\nほかに変更があれば教えてください。');
  await page.click('[data-paste-read]'); await page.waitForTimeout(300);
  check('答えからコマンドを取り出して確認画面', await page.isVisible('[data-paste-go]') && /床板:4800000/.test(await bodies(page)));
  await page.click('[data-paste-go]'); await page.waitForTimeout(500); await idle(page);
  check('確認してから実行', /床板:7200000/.test(await bodies(page)), await bodies(page));
  check('取り消しボタンも出る', await page.isVisible('[data-ai-undo]'));
  await page.context().close();
  await browser.close();
 } else {
  let page;
  // ===== 5. iPhone（WebKit）: 設定が画面に収まる
  console.log('[iPhone]');
  const wk = await webkit.launch();
  const ctx = await wk.newContext({ ...devices['iPhone 15'], serviceWorkers: 'block' });
  page = await ctx.newPage(); page.on('dialog', (d) => d.accept());
  await page.goto(URL0); await page.evaluate(() => { localStorage.clear(); localStorage.setItem('gdc-ai-brain', 'pc'); }); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 120000 });
  await page.evaluate(() => window.__app.cmdline.open()); await page.waitForTimeout(300);
  await page.tap('.cmd-set > summary'); await page.waitForTimeout(300);
  const fit = await page.evaluate(() => { const W = innerWidth; return ['#ai-brain', '#pc-url', '#pc-test'].map((q) => { const r = document.querySelector(q).getBoundingClientRect(); return r.width > 0 && r.left >= -1 && r.right <= W + 1; }).every(Boolean) && document.documentElement.scrollWidth <= W + 1; });
  check('iPhone で設定が画面の幅に収まる', fit);
  const fs = await page.$eval('#pc-url', (e) => parseFloat(getComputedStyle(e).fontSize));
  check('iPhone で入力欄が 16px 以上（勝手に拡大しない）', fs >= 16, String(fs));
  await wk.close();
 }
  console.log(`localai: ${pass}/${pass + fail}`);
})();
