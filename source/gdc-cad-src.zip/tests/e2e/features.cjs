const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  const P = (features, params=[]) => ({ format:'kobocad', version:1, name:'機能テスト', units:'mm', params, bodyProps:{}, rollback:null, drawing:null, features });
  const cases = {
    revolve: [ { id:'s', type:'sketch', name:'s', plane:{type:'std',name:'XZ'}, entities:[{type:'rect',x:20,y:0,w:30,h:80}] }, { id:'r', type:'revolve', name:'r', sketch:'s', profiles:[0], axis:'v', angle:'360', operation:'new' } ],
    revolve_half: [ { id:'s', type:'sketch', name:'s', plane:{type:'std',name:'XZ'}, entities:[{type:'circle',cx:60,cy:0,d:20}] }, { id:'r', type:'revolve', name:'r', sketch:'s', profiles:[0], axis:'v', angle:'180', operation:'new' } ],
    arc_profile: [ { id:'s', type:'sketch', name:'s', plane:{type:'std',name:'XY'}, entities:[{type:'line',x1:0,y1:0,x2:100,y2:0},{type:'line',x1:100,y1:0,x2:100,y2:50},{type:'arc',x1:100,y1:50,x2:0,y2:50,xm:50,ym:80},{type:'line',x1:0,y1:50,x2:0,y2:0}] }, { id:'e', type:'extrude', name:'e', sketch:'s', profiles:[0], distance:'10', direction:'symmetric', operation:'new' } ],
    chamfer: [ { id:'b', type:'box', name:'b', position:['0','0','0'], w:'100', d:'100', h:'50', operation:'new' }, { id:'c', type:'chamfer', name:'c', body:'B_b', edges:[[50,0,50]], radius:'5' } ],
    shell: [ { id:'b', type:'box', name:'b', position:['0','0','0'], w:'100', d:'80', h:'60', operation:'new' }, { id:'sh', type:'shell', name:'sh', body:'B_b', faces:[[50,40,60]], thickness:'3' } ],
    sphere_cut: [ { id:'b', type:'box', name:'b', position:['0','0','0'], w:'100', d:'100', h:'50', operation:'new' }, { id:'sp', type:'sphere', name:'sp', position:['50','50','50'], d:'60', operation:'cut' } ],
    move_copy: [ { id:'b', type:'box', name:'b', position:['0','0','0'], w:'50', d:'50', h:'50', operation:'new' }, { id:'m', type:'move', name:'m', bodies:['B_b'], translate:['100','0','0'], rotAxis:'Z', angle:'45', center:['25','25','0'], copy:true } ],
    mirror: [ { id:'b', type:'box', name:'b', position:['10','0','0'], w:'50', d:'50', h:'50', operation:'new' }, { id:'mi', type:'mirror', name:'mi', bodies:['B_b'], plane:'YZ', offset:'0', join:false } ],
    pattern: [ { id:'c', type:'cylinder', name:'c', position:['0','0','0'], axis:'Z', d:'20', h:'10', operation:'new' }, { id:'pt', type:'pattern', name:'pt', bodies:['B_c'], dir:'X', count:'4', spacing:'30', dir2:'Y', count2:'3', spacing2:'30', join:false } ],
    combine_cut: [ { id:'b', type:'box', name:'b', position:['0','0','0'], w:'100', d:'100', h:'20', operation:'new' }, { id:'c', type:'cylinder', name:'c', position:['50','50','-5'], axis:'Z', d:'30', h:'40', operation:'new' }, { id:'cb', type:'combine', name:'cb', target:'B_b', tools:['B_c'], op:'cut', keepTools:false } ],
    params_two_dir: [ { id:'s', type:'sketch', name:'s', plane:{type:'std',name:'YZ',offset:'L/2'}, entities:[{type:'rect',x:0,y:0,w:'W',h:'H'}] }, { id:'e', type:'extrude', name:'e', sketch:'s', profiles:[], distance:'L/2', distance2:'10', direction:'two', operation:'new' } ],
    face_sketch: [ { id:'b', type:'box', name:'b', position:['0','0','0'], w:'100', d:'100', h:'50', operation:'new' }, { id:'s', type:'sketch', name:'s', plane:{type:'face', origin:[50,50,50], xDir:[1,0,0], normal:[0,0,1], offset:'0'}, entities:[{type:'circle',cx:0,cy:0,d:30}] }, { id:'e', type:'extrude', name:'e', sketch:'s', profiles:[0], distance:'20', direction:'reverse', operation:'cut' } ],
    fillet_after_param: [ { id:'b', type:'box', name:'b', position:['0','0','0'], w:'W', d:'100', h:'50', operation:'new' }, { id:'f', type:'fillet', name:'f', body:'B_b', edges:[[100,0,25,0,0,1]], radius:'10' } ],
  };
  for (const [nm, feats] of Object.entries(cases)) {
    const params = [{name:'L',expr:'200'},{name:'W',expr:'150'},{name:'H',expr:'80'}];
    await page.evaluate(([f, p]) => window.__store.replace(f), [P(feats, params), null]);
    await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden'), null, { timeout: 30000 });
    await page.waitForTimeout(700);
    const r = await page.evaluate(async () => { const a = window.__app; const m = await import('/src/kernel.js').catch(()=>null); return { bodies: a.meshes.map(m => m.name), errors: a.errors.map(e=>e.message) }; });
    const vol = await page.evaluate(async () => { const a=window.__app; a.selection=[]; return null; });
    console.log(nm.padEnd(18), 'bodies', r.bodies.length, r.errors.length ? 'ERR ' + r.errors.join('; ') : 'ok');
  }
  await browser.close();
})();
