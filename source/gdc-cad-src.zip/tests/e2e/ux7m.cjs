const { open } = require('./ux_common.cjs');
(async () => {
  const { browser, page } = await open({ iphone: true });
  await page.cmd(`板 幅2000 奥行1200 厚さ30 名前 床板
板 幅600 奥行300 厚さ20 位置 0,30,700 名前 棚`);
  await page.evaluate(() => window.__app.viewer.fit()); await page.waitForTimeout(500);
  const nav = await page.evaluate(() => [...document.querySelectorAll('#navbar button')].filter(b => b.offsetWidth).map(b => b.textContent).join('|'));
  console.log('nav', nav, await page.evaluate(() => { const r = document.getElementById('navbar').getBoundingClientRect(); return [r.left, r.right, innerWidth].map(Math.round).join(','); }));
  await page.tap('#navbar [data-ux="multi"]');
  const tap3 = async (p) => { const s = await page.evaluate((p) => window.__app.viewer.toScreen(p), p); await page.touchscreen.tap(page.vp.x + s[0], page.vp.y + s[1]); await page.waitForTimeout(500); };
  await tap3([1500, 900, 30]); await tap3([300, 150, 720]);
  console.log('multi sel', await page.sel());
  await page.tap('#navbar [data-ux="prio"]'); await page.tap('#navbar [data-ux="multi"]');
  await tap3([300, 150, 720]); console.log('body prio', await page.sel());
  await page.tap('#navbar [data-ux="props"]'); await page.waitForTimeout(800);
  console.log('props visible', await page.locator('#ux-props').isVisible());
  await page.screenshot({ path: 'ux7m.png' });
  await browser.close();
})();
