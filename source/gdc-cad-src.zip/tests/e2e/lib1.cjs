// ファイル一覧（端末の保管庫）: 自動保存・複数ファイル・切り替え・再読み込みで復元・大きなファイル・バックアップと復元
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, acceptDownloads: true });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', d => d.type() === 'prompt' ? d.accept('改名テスト') : d.accept());
  await page.goto('http://127.0.0.1:4173/');
  await page.evaluate(async () => { localStorage.clear(); await new Promise(r => { const q = indexedDB.deleteDatabase('gdc-cad'); q.onsuccess = q.onerror = q.onblocked = r; }); });
  await page.reload();
  const ready = () => page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 90000 });
  await ready();
  const lib = () => page.evaluate(async () => (await (await import('/src/library.js').catch(() => null))?.library?.list?.()) ?? null).catch(() => null);
  const names = async () => page.evaluate(() => new Promise((res) => { const r = indexedDB.open('gdc-cad'); r.onsuccess = () => { if (!r.result.objectStoreNames.contains('meta')) { r.result.close(); return res([]); } const t = r.result.transaction('meta'); const q = t.objectStore('meta').getAll(); q.onsuccess = () => res(q.result.sort((a, b) => b.updated - a.updated).map(m => `${m.name}(${m.features})`)); }; }));
  console.log('empty start list:', JSON.stringify(await names()));
  // 1 つ目
  await page.evaluate(() => window.__cmd('板 幅600 奥行400 厚さ20 名前 床板')); await page.evaluate(() => { window.__store.commit(p => { p.name = 'ファイルA'; }); });
  await page.waitForTimeout(1500);
  console.log('title:', await page.locator('#doc-title').innerText());
  // 新規 → 2 つ目
  await page.keyboard.press('Control+n'); await page.waitForTimeout(800);
  await page.evaluate(() => window.__cmd('円柱 直径100 高さ50')); await page.evaluate(() => { window.__store.commit(p => { p.name = 'ファイルB'; }); });
  await page.waitForTimeout(1500);
  console.log('list after 2:', JSON.stringify(await names()));
  // 一覧から A を開く
  await page.keyboard.press('Control+o'); await page.waitForTimeout(600);
  console.log('library cards:', await page.locator('.lib-card').count(), '| thumbs:', await page.locator('.lib-card img').count());
  await page.locator('.lib-card', { hasText: 'ファイルA' }).locator('[data-a="open"]').click(); await ready(); await page.waitForTimeout(500);
  console.log('opened A:', await page.evaluate(() => [window.__store.project.name, window.__app.meshes.map(m => m.name).join(',')].join(' / ')));
  // 再読み込み → 最後に開いた A が復元
  await page.reload(); await ready(); await page.waitForTimeout(800);
  console.log('after reload:', await page.evaluate(() => [window.__store.project.name, window.__app.meshes.length].join(' / ')));
  // 大きなファイル（取り込みデータ 6MB 相当）も保存できる
  await page.evaluate(() => { window.__store.commit(p => { p.features.push({ id: 'Fbig', type: 'import', name: '大きい', format: 'stl', dataKey: 'kbig', data: 'A'.repeat(6_000_000), names: [], suppressed: true }); }); });
  await page.waitForTimeout(2500);
  const big = await page.evaluate(() => new Promise((res) => { const r = indexedDB.open('gdc-cad'); r.onsuccess = () => { const q = r.result.transaction('meta').objectStore('meta').getAll(); q.onsuccess = () => res(q.result.map(m => m.size)); }; }));
  console.log('big saved size MB:', Math.max(...big) / 1e6, '| save state', await page.evaluate(() => window.__store.saveState));
  console.log('undo snapshot small:', await page.evaluate(() => window.__store.undoStack.at(-1).length < 100000), '| undo works:', await page.evaluate(() => { window.__store.undo(); return window.__store.project.features.length; }));
  // バックアップ → 全部削除 → 戻す
  const [dl] = await Promise.all([page.waitForEvent('download'), page.evaluate(() => window.__app.backupAll())]);
  const path = await dl.path(); console.log('backup file:', dl.suggestedFilename(), require('fs').statSync(path).size > 1000);
  await page.evaluate(async () => { const t = indexedDB.open('gdc-cad'); await new Promise(r => t.onsuccess = r); const d = t.result; await new Promise(r => { const x = d.transaction(['meta', 'data'], 'readwrite'); x.objectStore('meta').clear(); x.objectStore('data').clear(); x.oncomplete = r; }); });
  console.log('cleared:', JSON.stringify(await names()));
  await page.evaluate(() => { window.__fileForTest = null; });
  const [chooser] = await Promise.all([page.waitForEvent('filechooser'), page.evaluate(() => { window.__app.restoreBackup(); })]);
  await chooser.setFiles(path); await page.waitForTimeout(1500);
  console.log('restored:', JSON.stringify(await names()));
  // 名前の変更（一覧から）・削除
  await page.keyboard.press('Control+o'); await page.waitForTimeout(600);
  await page.locator('.lib-card', { hasText: 'ファイルB' }).locator('[data-a="rename"]').click(); await page.waitForTimeout(800);
  await page.locator('.lib-card', { hasText: '改名テスト' }).locator('[data-a="del"]').click(); await page.waitForTimeout(800);
  console.log('after rename+delete:', JSON.stringify(await names()));
  await page.screenshot({ path: 'lib1.png' });
  await browser.close();
})();
