// iPhone（Safari）と同じふるまいの音声認識で確かめる:
//  ・話している間、文が少しずつ伸びて届く（確定＝isFinal にならない）
//  ・自分では終わらない（アプリが stop するまで聞き続ける）
//  ・候補が複数あるとき、1 番目が聞き間違い
const { webkit, devices } = require('playwright');
(async () => {
  const browser = await webkit.launch();
  const ctx = await browser.newContext({ ...devices['iPhone 15'] });
  await ctx.addInitScript(() => {
    window.__said = []; window.__stops = 0;
    const mk = (alts, fin) => Object.assign(alts.map((t) => ({ transcript: t })), { isFinal: fin });
    class FakeSR {
      start() {
        const item = window.__said.shift() || { parts: [''] };
        let i = 0;
        const tick = () => {
          if (this._stopped) return;
          if (i < item.parts.length) {
            const results = item.final ? [mk(item.final, true)] : [mk([item.parts.slice(0, ++i).join('')], false)];
            if (item.final) i = item.parts.length;
            this.onresult && this.onresult({ resultIndex: 0, results });
            setTimeout(tick, 300);
          }
        };
        setTimeout(tick, 300);
      }
      stop() { window.__stops++; this._stopped = true; setTimeout(() => this.onend && this.onend(), 50); }
    }
    window.webkitSpeechRecognition = FakeSR;
  });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  let confirms = 0; page.on('dialog', d => { confirms++; d.accept(); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  // 1. コマンド画面を開く → 実行・話すが画面の中に見えているか
  await page.evaluate(() => window.__app.cmdline.open()); await page.waitForTimeout(500);
  const vis = await page.evaluate(() => ['#cmd-run', '#vc-talk', '#dialog [data-o]'].map((q) => { const r = document.querySelector(q).getBoundingClientRect(); return q + ':' + (r.top >= 0 && r.bottom <= innerHeight && r.width > 0 ? 'visible' : 'HIDDEN ' + Math.round(r.top)); }).join(' '));
  console.log('buttons:', vis);
  await page.screenshot({ path: 'ip_cmd2.png' });
  // 2. 文字で入力 →「実行」
  await page.fill('#cmd-in', '板 幅600 奥行400 厚さ20 名前 床板'); await page.click('#cmd-run');
  await page.waitForFunction(() => window.__app.meshes.length === 1, null, { timeout: 30000 }).catch(() => {});
  console.log('typed+run bodies:', await page.evaluate(() => window.__app.meshes.map(m => m.name).join(',')));
  // 3. 話す（伸びていく文・確定しない）→ 黙ると自動で終わって実行
  await page.evaluate(() => window.__said.push({ parts: ['床板', ' 熱さ', ' 三', 'センチ'] }));
  await page.tap('#vc-talk');
  await page.waitForTimeout(800); console.log('while listening:', await page.locator('#vc-live').innerText(), '| btn', await page.locator('#vc-talk').innerText());
  await page.waitForFunction(() => window.__store.project.features[0].h == 30 || window.__store.project.features[0].h === '30', null, { timeout: 15000 }).catch(() => {});
  await page.waitForTimeout(500);
  console.log('### iOS-like speech → 厚さ:', await page.evaluate(() => window.__store.project.features[0].h), '| confirms', confirms, '| stops', await page.evaluate(() => window.__stops));
  // 4. 候補の 1 番目が聞き間違い → 2 番目（コマンドらしい方）を選ぶ
  await page.evaluate(() => window.__said.push({ parts: ['x'], final: ['床板 あつさ よんじゅう みり', '床板 厚さ 40ミリ'] }));
  await page.tap('#vc-talk');
  await page.waitForFunction(() => String(window.__store.project.features[0].h) === '40', null, { timeout: 15000 }).catch(() => {});
  console.log('### alternatives → 厚さ:', await page.evaluate(() => window.__store.project.features[0].h));
  // 5. 自動実行オフ → 文字欄に入るだけ、実行ボタンで実行
  await page.uncheck('#vc-auto');
  await page.evaluate(() => window.__said.push({ parts: ['床板 厚さ 五十'] }));
  await page.tap('#vc-talk'); await page.waitForTimeout(3500);
  console.log('manual: textarea =', JSON.stringify(await page.inputValue('#cmd-in')), '| 厚さ still', await page.evaluate(() => window.__store.project.features[0].h), '| st', await page.locator('#vc-st').innerText());
  await page.tap('#cmd-run'); await page.waitForTimeout(2500);
  console.log('### manual run → 厚さ:', await page.evaluate(() => window.__store.project.features[0].h));
  console.log('log:', (await page.locator('#cmd-log').innerText()).replace(/\s+/g, ' ').slice(0, 400));
  await page.screenshot({ path: 'ip_cmd3.png' });
  await browser.close();
})();
