const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 }, acceptDownloads: true })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  await page.evaluate(() => window.__store.replace({ format:'kobocad', version:1, name:'パネル試算', units:'mm', params:[], rollback:null, drawing:null, bodyProps:{},
    features:[
      { id:'fl', type:'box', name:'fl', position:['0','0','0'], w:'2950', d:'1900', h:'42', operation:'new', bodyName:'底部パネル' },
      { id:'wl', type:'box', name:'wl', position:['0','0','42'], w:'2950', d:'42', h:'1850', operation:'new', bodyName:'側壁パネル' },
    ] }));
  await page.waitForFunction(() => window.__app.meshes.length === 2, null, { timeout: 30000 }); await page.waitForTimeout(600);
  // 2 つとも選んで右クリック → 積層設定
  await page.click('[data-body]:has-text("底部パネル")'); await page.click('[data-body]:has-text("側壁パネル")', { modifiers: ['Shift'] });
  await page.click('[data-body]:has-text("側壁パネル")', { button: 'right' }); await page.waitForTimeout(200);
  await page.click('#ctxmenu button:has-text("積層（サンドイッチパネル）設定")'); await page.waitForTimeout(300);
  await page.click('#dialog [data-o]'); await page.waitForTimeout(1500);
  await page.click('.tab:has-text("検査")'); await page.click('.tool:has-text("材料集計")'); await page.waitForTimeout(1500);
  console.log((await page.locator('#dialog .dlg-body').innerText()).replace(/\n+/g, ' | ').slice(0, 700));
  await page.screenshot({ path: 'takeoff.png' });
  const [d] = await Promise.all([page.waitForEvent('download'), page.click('#dialog [data-o]')]); await d.saveAs('dl/takeoff.csv');
  await page.keyboard.press('Escape');
  await page.click('.tool:has-text("物理プロパティ")'); await page.waitForTimeout(1200);
  console.log('props:', (await page.locator('#dialog .dlg-body').innerText()).replace(/\n+/g, ' | ').slice(0, 300));
  await browser.close();
})();
