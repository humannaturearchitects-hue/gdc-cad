// 精査: すべてのツールを実際に押して、エラーや動かないものを洗い出す
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1500, height: 900 }, acceptDownloads: true });
  const page = await ctx.newPage();
  const issues = [];
  let cur = 'init';
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => issues.push(`[${cur}] PAGEERROR ${e.message}`));
  page.on('console', m => { if (m.type() === 'error' && !/manifest|favicon/.test(m.text())) issues.push(`[${cur}] console.error ${m.text().slice(0, 160)}`); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  const idle = async () => { await page.waitForTimeout(250); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }).catch(() => issues.push(`[${cur}] busy did not clear`)); await page.waitForTimeout(150); };
  const reset = async () => {
    await page.keyboard.press('Escape'); await page.keyboard.press('Escape');
    await page.evaluate(() => { const a = window.__app; if (a.dialog.isOpen) a.dialog.close(); if (a.mode === 'sketch') a.finishSketch(); if (a.mode === 'pickPlane') a.cancelPickPlane(); if (a.mode === 'measure') a.endMeasure(); document.getElementById('dialog').classList.add('hidden'); a.panelOpen = false; if (a.ws && a.ws !== 'design') a.setWorkspace('design'); });
    await idle();
  };
  await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
  await page.waitForFunction(() => window.__app.meshes.length > 0); await idle();
  const errsOf = () => page.evaluate(() => window.__app.errors.map(e => e.message));
  const tabs = await page.$$eval('#tabs button', bs => bs.map(b => b.textContent.trim()));
  console.log('tabs', tabs.join(','));
  const results = [];
  for (const tab of tabs) {
    await page.click(`#tabs button:has-text("${tab}")`); await page.waitForTimeout(200);
    const tools = await page.$$eval('#tools .tool span', ss => ss.map(s => s.textContent.trim()));
    for (const t of tools) {
      cur = `${tab}/${t}`;
      if (['インポート', '図面を作成', '音声'].includes(t)) { results.push(`${cur}: skip`); continue; }
      await page.click(`#tabs button:has-text("${tab}")`).catch(() => {}); await page.waitForTimeout(100);
      const dl = page.waitForEvent('download', { timeout: 4000 }).then(d => 'download ' + d.suggestedFilename()).catch(() => '');
      await page.locator('#tools .tool', { hasText: t }).first().click().catch(e => issues.push(`[${cur}] click failed ${e.message.slice(0, 80)}`));
      await idle();
      const st = await page.evaluate(() => ({ mode: window.__app.mode, dlg: !document.getElementById('dialog').classList.contains('hidden'), title: (document.querySelector('#dialog .dlg-head span') || {}).textContent || '', err: (document.querySelector('#dialog .dlg-err') || {}).textContent || '', toast: [...document.querySelectorAll('.toast')].map(t => t.textContent).slice(-1)[0] || '' }));
      let okRes = '';
      if (st.dlg && /^(シェル|ミラー|矩形パターン|円形パターン|分割|結合|移動|直方体|円柱|球|構築平面)/.test(st.title)) {
        // 既定値のまま OK を押してみる（ボディが必要な欄は 1 つ目のボディを選ぶ）
        await page.evaluate(() => { const a = window.__app; const d = a.dialog.active && a.dialog.active.draft; if (!d) return; const b = a.meshes[0]; if (b) { if ('bodies' in d && !(d.bodies || []).length) d.bodies = [b.id]; if ('body' in d && !d.body) d.body = b.id; if ('target' in d && !d.target) d.target = b.id; } a.dialog.render(); a.dialog.preview(); });
        await idle();
        const before = await page.evaluate(() => window.__store.project.features.length);
        await page.click('#dialog [data-act="ok"]').catch(() => {}); await idle();
        const after = await page.evaluate(() => window.__store.project.features.length);
        const e = await errsOf();
        okRes = `OK→${after > before ? '追加' : '追加されず'} ${e.length ? 'errors ' + JSON.stringify(e) : ''} ${await page.evaluate(() => [...document.querySelectorAll('.toast')].map(t => t.textContent).slice(-1)[0] || '')}`;
        if (after > before) await page.evaluate(() => window.__store.undo()), await idle();
      }
      results.push(`${cur}: mode=${st.mode} dlg=${st.dlg ? st.title : '-'}${st.err ? ' ERR=' + st.err : ''}${st.toast ? ' toast=' + st.toast.slice(0, 60) : ''} ${await dl} ${okRes}`);
      await reset();
    }
  }
  // スケッチのツール
  cur = 'sketch';
  await page.click('#tabs button:has-text("ソリッド")').catch(() => {});
  await page.click('.tool:has-text("スケッチ作成")'); await page.click('#planebar [data-pl=XY]'); await idle();
  const stools = await page.$$eval('#tools .tool span', ss => ss.map(s => s.textContent.trim()));
  for (const t of stools) {
    cur = `sketch/${t}`;
    if (['スケッチを終了', '押し出し', '回転'].includes(t)) continue;
    await page.locator('#tools .tool').filter({ has: page.locator('span', { hasText: new RegExp('^' + t.replace(/[/()]/g, '\\$&') + '$') }) }).first().click().catch(e => issues.push(`[${cur}] click failed`));
    await page.waitForTimeout(150);
    const st = await page.evaluate(() => ({ tool: window.__app.sketcher.tool, toast: [...document.querySelectorAll('.toast')].map(t => t.textContent).slice(-1)[0] || '' }));
    results.push(`${cur}: tool=${st.tool} ${st.toast.slice(0, 50)}`);
    await page.keyboard.press('Escape');
  }
  await reset();
  // 右クリックメニュー（ボディ・タイムライン）
  cur = 'body menu';
  await page.click('[data-body]', { button: 'right' }); await page.waitForTimeout(200);
  results.push('body menu: ' + (await page.$$eval('#ctxmenu button', bs => bs.map(b => b.textContent).join(' / '))));
  await page.keyboard.press('Escape'); await page.mouse.click(10, 880);
  cur = 'timeline menu';
  await page.locator('#timeline .tl-item').nth(1).click({ button: 'right' }); await page.waitForTimeout(200);
  results.push('timeline menu: ' + (await page.$$eval('#ctxmenu button', bs => bs.map(b => b.textContent).join(' / '))));
  await page.mouse.click(10, 880);
  // 図面ワークスペース
  cur = 'drawing';
  await page.click('.ws[data-ws=drawing]'); await page.waitForTimeout(3000);
  const dbtn = await page.$$eval('.dw-side button', bs => bs.map(b => b.textContent.trim()));
  results.push('drawing buttons: ' + dbtn.join(' / '));
  for (const b of dbtn.filter(x => /PDF|DXF|SVG/.test(x))) {
    cur = 'drawing/' + b;
    const dl = page.waitForEvent('download', { timeout: 30000 }).then(d => d.suggestedFilename()).catch(() => 'NO DOWNLOAD');
    await page.locator('.dw-side button', { hasText: b }).first().click(); 
    results.push(`${cur}: ${await dl}`);
    await page.waitForTimeout(500);
  }
  console.log(results.join('\n'));
  console.log('\n=== ISSUES (' + issues.length + ')\n' + [...new Set(issues)].join('\n'));
  await browser.close();
})();
