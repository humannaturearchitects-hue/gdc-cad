// 言葉で操作: コマンド入力に手順を貼り付けて実行 → 形ができるか（体積で確認）
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear() || localStorage.setItem('gdc-voice-ai', '0')); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const meas = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list.map(b => `${b.name}:${b.volume.toFixed(1)} [${b.bounds.map(p => p.map(v => +v.toFixed(1)).join(',')).join(' / ')}]`).join(' ; ');
  // 画面のボタンからコマンド入力を開き、手順を貼り付けて実行
  await page.click('.tool:has-text("AI に頼む")'); await page.waitForTimeout(300);
  const script = `# 床パネル
パラメータ 幅 = 600
板 幅 幅 奥行400 厚さ20 名前 床板
穴 上面 Ø8 位置 30,25 570,25 570,375 30,375
フィレット R5 縦の辺 床板
スケッチ 上面 床板
長方形 中心 300,200 幅200 高さ100
押し出し 50
スケッチ XY
円 700,200 直径80
押し出し 100 名前 柱
移動 柱 0,0,10
面取り C2 上の辺 柱
コピー 柱 0,300,0`;
  await page.fill('#cmd-in', script);
  await page.click('#cmd-run');
  await page.waitForFunction(() => document.querySelectorAll('#cmd-log .cmd-item').length >= 13 || [...document.querySelectorAll('#cmd-log .ng')].length > 0, null, { timeout: 120000 });
  await page.waitForTimeout(500);
  const log = await page.$$eval('#cmd-log .cmd-item', (els) => els.map((e) => e.innerText.replace(/\s+/g, ' ')));
  for (const l of log) console.log('  ' + l);
  console.log('### 結果:', await meas());
  await page.screenshot({ path: 'real12.png' });
  // パラメータを変えると追従するか（幅 600 → 800）
  const r = await page.evaluate(() => window.__cmd('パラメータ 幅 = 800'));
  console.log('  param:', JSON.stringify(r));
  console.log('### 幅 800:', await meas());
  // 言葉で直す
  for (const t of ['床板 厚さ 30', '床板の奥行きを500に', '穴1 径 10', '穴1 位置 40,30 760,30 760,470 40,470', '柱 高さ 150', 'フィレット1 R 8', '床板 色 赤']) {
    const r = await page.evaluate((t) => window.__cmd(t), t);
    console.log('  直す:', t, '→', r.map((x) => (x.ok ? '✓ ' : '✗ ') + x.msg).join(' | '));
  }
  console.log('### 直した後:', await meas());
  // 言葉で書き出し（STEP）
  const dl = page.waitForEvent('download', { timeout: 30000 });
  await page.evaluate(() => window.__cmd('STEP で書き出し'));
  console.log('  download:', (await dl).suggestedFilename());
  // 分からない指示はエラーで止まる
  console.log('  bad:', JSON.stringify(await page.evaluate(() => window.__cmd('ほげほげ'))));
  await browser.close();
})();
