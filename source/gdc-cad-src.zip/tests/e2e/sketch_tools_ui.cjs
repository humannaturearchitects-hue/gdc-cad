const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  const vp = await page.locator('#view3d').boundingBox();
  const S = (p) => page.evaluate((p) => window.__app.viewer.toScreen(p), p);
  const ents = () => page.evaluate(() => JSON.stringify(window.__app.sketcher.feature.entities));
  await page.click('.tool:has-text("スケッチ作成")'); await page.waitForTimeout(300);
  const pos = await page.evaluate(() => { const v = window.__app.viewer; const m = v.planeMeshes.find(p=>p.userData.name==='XY'); const s=m.scale.x; return v.toScreen([s*0.7, s*0.7, 0]); });
  await page.mouse.click(vp.x + pos[0], vp.y + pos[1]); await page.waitForTimeout(1200);
  await page.keyboard.press('r');
  let a = await S([0,0,0]); await page.mouse.click(vp.x+a[0], vp.y+a[1]); await page.keyboard.type('200'); await page.keyboard.press('Tab'); await page.keyboard.type('100'); await page.keyboard.press('Enter');
  await page.waitForTimeout(300);
  await page.click('[data-nav=fit]'); await page.waitForTimeout(400);
  // fillet tool: click corner (200,100) and enter 20
  await page.click('.tool:has-text("フィレット")');
  let c = await S([198,98,0]); await page.mouse.click(vp.x+c[0], vp.y+c[1]); await page.waitForTimeout(300);
  await page.fill('.inbox.ask input', '20'); await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  console.log('after fillet', (await ents()).slice(0, 400));
  // select tool: drag the point (0,0) to (-30,-20)
  await page.keyboard.press('s');
  const p0 = await S([0,0,0]), p1 = await S([-30,-20,0]);
  await page.mouse.move(vp.x+p0[0], vp.y+p0[1]); await page.mouse.down(); await page.mouse.move(vp.x+p1[0], vp.y+p1[1], { steps: 10 }); await page.mouse.up();
  await page.waitForTimeout(400);
  const e2 = JSON.parse(await ents());
  console.log('after drag: lines touching (-30,-20):', e2.filter(e => (e.x1===-30&&e.y1===-20)||(e.x2===-30&&e.y2===-20)).length, 'closed loops', await page.evaluate(() => window.__app.sketchLoops(window.__app.sketcher.featureId).length));
  await page.screenshot({ path: 't21_sketch.png' });
  await page.click('.tool:has-text("スケッチを終了")'); await page.waitForTimeout(800);
  await page.click('.tool:has-text("押し出し")'); await page.waitForTimeout(800);
  await page.click('#dialog [data-act="ok"]'); await page.waitForTimeout(1500);
  console.log('bodies', await page.evaluate(() => window.__app.meshes.length), JSON.stringify(await page.evaluate(() => window.__app.errors)));
  // hole: H then click top face center
  await page.click('[data-nav=home]'); await page.waitForTimeout(400);
  await page.click('.tool:has-text("穴")'); await page.waitForTimeout(600);
  const dist = await page.evaluate(() => window.__store.project.features.find(f=>f.type==='extrude').distance);
  const top = await S([100,50,+dist]); await page.mouse.click(vp.x+top[0], vp.y+top[1]); await page.waitForTimeout(300);
  await page.click('#dialog [data-act="ok"]'); await page.waitForTimeout(1500);
  const r = await page.evaluate(async () => ({ errs: window.__app.errors, hole: window.__store.project.features.find(f=>f.type==='hole'), vol: (await window.__kcall('measure', { ids: [] })).total.volume }));
  console.log('hole', JSON.stringify(r.hole.points), 'errors', JSON.stringify(r.errs), 'vol', Math.round(r.vol));
  await page.screenshot({ path: 't21_hole.png' });
  await browser.close();
})();
