// 内装: 間取り図の写真をなぞる → 間取り → 部屋を選んで設計。AI の読み取り（API はテスト用の返事に差し替え）
const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 }, serviceWorkers: 'block', acceptDownloads: true });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  const answers = [];
  page.on('dialog', (d) => d.accept(answers.length ? answers.shift() : undefined));
  // 1) 間取り図の画像を作る（1px = 10mm: LDK 5460×3640 と 洋室 2730×3640、L 字の廊下なし）
  const plan = await ctx.newPage();
  await plan.setViewportSize({ width: 1000, height: 600 });
  await plan.setContent(`<body style="margin:0;background:#fff"><svg width="1000" height="600" xmlns="http://www.w3.org/2000/svg">
    <rect x="100" y="100" width="546" height="364" fill="none" stroke="#000" stroke-width="10"/>
    <rect x="658" y="100" width="273" height="364" fill="none" stroke="#000" stroke-width="10"/>
    <text x="370" y="290" font-size="28" text-anchor="middle">LDK 12帖</text><text x="795" y="290" font-size="24" text-anchor="middle">洋室 6帖</text>
    <text x="373" y="90" font-size="18" text-anchor="middle">5460</text></svg></body>`);
  fs.mkdirSync('dl', { recursive: true });
  await plan.screenshot({ path: 'dl/plan_photo.png' });
  await plan.close();

  await page.goto('http://127.0.0.1:4173/');
  await page.waitForFunction(() => window.__app && window.__app.viewer, null, { timeout: 90000 });
  await page.click('.ws[data-ws=interior]');
  const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.click('[data-a=planphoto]')]);
  await fc.setFiles('dl/plan_photo.png');
  await page.waitForSelector('.iw-tr-in img');
  await page.waitForFunction(() => document.querySelector('.iw-tr-in img').naturalWidth > 0);
  const box = await page.locator('.iw-tr-in svg').boundingBox();
  const k = box.width / 1000;
  const tap = async (x, y) => { await page.mouse.click(box.x + x * k + (Math.random() - 0.5) * 3, box.y + y * k + (Math.random() - 0.5) * 3); };
  // LDK（内側の角を少しぶれて）
  for (const [x, y] of [[105, 105], [641, 105], [641, 459], [105, 459]]) await tap(x, y);
  answers.push('5360', 'LDK');
  await page.click('[data-t=close]');
  for (const [x, y] of [[663, 105], [926, 105], [926, 459], [663, 459]]) await tap(x, y);
  answers.push('洋室');
  await page.click('[data-t=close]');
  await page.screenshot({ path: 'dl/trace.png' });
  answers.push('2400');
  await page.click('[data-t=done]');
  await page.waitForSelector('.iw-rooms');
  const L = await page.evaluate(() => window.__app.interior.state.layout);
  console.log('trace layout', L.rooms.map((r) => `${r.name} ${JSON.stringify(r.poly)} @${r.origin}`).join(' / '));
  const w1 = L.rooms[1].poly[1][0];
  if (Math.abs(L.rooms[0].poly[1][0] - 5360) > 20 || Math.abs(w1 - 2630) > 80) throw new Error('trace scale');
  // 洋室を選んで設計
  await page.click('[data-room="1"]');
  await page.click('[data-ex="2"]');
  await page.click('[data-a=design]');
  await page.waitForSelector('.iw-items li');
  console.log('pages', await page.evaluate(() => window.__app.interior.sheets.map((s) => s.name).join(',')));
  await page.click('.dw-pages [data-pg="1"]');
  await page.waitForTimeout(300);
  await page.screenshot({ path: 'dl/layout_sheet.png' });

  // 2) AI 読み取り（API の返事を差し替え）
  await page.evaluate(() => localStorage.setItem('gdc-ai-key', 'sk-test'));
  let sent = null;
  await page.route('https://api.anthropic.com/**', async (route) => {
    sent = JSON.parse(route.request().postData());
    const json = { rooms: [
      { name: 'LDK', poly: [[0, 0], [5460, 0], [5460, 3640], [0, 3640]], height: 2400 },
      { name: '洋室', poly: [[5580, 0], [8310, 0], [8310, 3640], [5580, 3640]], height: 2400 },
    ], openings: [{ type: 'door', a: [5460, 1000], b: [5460, 1780], height: 2000, sill: 0 }, { type: 'window', a: [6000, 3640], b: [7690, 3640], height: 1100, sill: 900 }],
      scale: '寸法線 5460', notes: ['壁厚 120 として内法に'] };
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ id: 'msg_test', type: 'message', role: 'assistant', model: 'test', content: [{ type: 'text', text: JSON.stringify(json) }], stop_reason: 'end_turn', usage: { input_tokens: 1, output_tokens: 1 } }) });
  });
  const [fc2] = await Promise.all([page.waitForEvent('filechooser'), page.click('[data-a=planphoto]')]);
  await fc2.setFiles('dl/plan_photo.png');
  await page.waitForSelector('[data-t=ai]');
  answers.push('');
  await page.click('[data-t=ai]');
  await page.waitForFunction(() => window.__app.interior.state.layout?.source === 'ai-plan', null, { timeout: 20000 });
  const L2 = await page.evaluate(() => window.__app.interior.state.layout);
  console.log('ai layout', L2.rooms.map((r) => `${r.name} openings=${r.openings.map((o) => o.type + o.width).join('+')}`).join(' / '));
  console.log('sent: image', sent.messages[0].content[0].type, sent.messages[0].content[0].source.media_type, 'model', sent.model);
  if (L2.rooms.length !== 2 || !L2.rooms[1].openings.some((o) => o.type === 'window')) throw new Error('ai layout');
  await page.screenshot({ path: 'dl/ai_layout.png' });
  // 3) 部屋の写真（2 枚）→ 部屋 1 つ
  const [fc3] = await Promise.all([page.waitForEvent('filechooser'), page.click('[data-a=roomphoto]')]);
  answers.push('天井高 2400');
  await fc3.setFiles(['dl/plan_photo.png', 'dl/trace.png']);
  await page.waitForFunction(() => window.__app.interior.state.room?.source === 'ai-photo', null, { timeout: 20000 });
  const r3 = await page.evaluate(() => window.__app.interior.state.room);
  console.log('photo room', r3.name, JSON.stringify(r3.poly), (r3.log || []).length, 'images sent', sent.messages[0].content.filter((c) => c.type === 'image').length);
  if (sent.messages[0].content.filter((c) => c.type === 'image').length !== 2) throw new Error('images');
  console.log('errors', errs);
  await browser.close();
  console.log(errs.length ? 'FAIL' : 'OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
