// 実際の利用者と同じく、マウスとキーボードだけで部品を積み上げる
// 床板 600x400x20 → 上面にスケッチ → 箱を結合 → 円で穴 → フィレット → 壁（別ボディ）→ 寸法変更 → 再読み込み
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(200); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const state = async (label) => {
    const s = await page.evaluate(() => ({
      feats: window.__store.project.features.map(f => f.type),
      bodies: window.__app.meshes.map(m => m.name),
      errors: window.__app.errors.map(e => e.message),
      status: document.getElementById('status')?.textContent || '',
    }));
    let vol = '';
    try { const r = await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 })); vol = r.list.map(b => `${b.name}:${Math.round(b.volume)} [${b.bounds.map(p => p.map(Math.round).join(',')).join(' / ')}]`).join(' ; '); } catch (e) { vol = 'measure err ' + e.message; }
    console.log(`\n### ${label}\n  feats ${s.feats.join(',')}\n  bodies ${s.bodies.join(',')} errors ${JSON.stringify(s.errors)}\n  ${vol}\n  status: ${s.status.slice(0, 120)}`);
  };
  const shot = (n) => page.screenshot({ path: 'real_' + n + '.png' });
  const tool = (t) => page.click(`.tool:has-text("${t}")`);
  const typeDims = async (vals) => { for (let i = 0; i < vals.length; i++) { const inp = page.locator('.inbox input').nth(i); await inp.click(); await inp.fill(String(vals[i])); } await page.keyboard.press('Enter'); };

  // 1. 床板
  await tool('スケッチ作成'); await page.waitForTimeout(200);
  { const s = await page.evaluate(() => window.__app.viewer.planeMeshes.find(p => p.userData.name === 'XY').scale.x); await page.mouse.click(...await scr([s * .3, -s * .3, 0])); }
  await idle();
  console.log('  plane1', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature?.plane)));
  await page.keyboard.press('r'); await page.waitForTimeout(200);
  await page.mouse.click(...await scr([0, 0, 0])); await page.waitForTimeout(200);
  await typeDims([600, 400]); await page.waitForTimeout(300);
  await shot('1sketch');
  await tool('押し出し'); await idle();
  await page.fill('#dialog input[data-k="distance"]', '20'); await page.waitForTimeout(200);
  await page.click('#dialog [data-act="ok"]'); await idle();
  await state('1 床板 600x400x20'); await shot('1floor');

  // 2. 上面にスケッチ → 箱を結合
  await tool('スケッチ作成'); await page.waitForTimeout(300);
  await page.mouse.click(...await scr([450, 300, 20])); await idle();
  console.log('  plane2', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature?.plane)));
  await page.keyboard.press('r'); await page.waitForTimeout(200);
  // 上面のスケッチ座標系が分からないので画面上で2点クリック（ワールド 50,50 → 150,150）
  await page.mouse.click(...await scr([50, 50, 20])); await page.waitForTimeout(200);
  { const a = page.locator('.inbox input'); await a.nth(0).fill('100'); await a.nth(1).fill('100'); await page.keyboard.press('Enter'); await page.waitForTimeout(300); }
  const ent2 = await page.evaluate(() => window.__app.sketcher.feature?.entities);
  console.log('  sketch2 entities', JSON.stringify(ent2));
  await shot('2sketch');
  await tool('押し出し'); await idle();
  console.log('  dialog:', (await page.locator('#dialog').innerText()).replace(/\s+/g, ' ').slice(0, 200));
  await page.fill('#dialog input[data-k="distance"]', '50'); await page.waitForTimeout(200);
  await page.selectOption('#dialog select[data-k="operation"]', 'join'); await idle();
  await shot('2extrude');
  await page.click('#dialog [data-act="ok"]'); await idle();
  await state('2 箱 100x100x50 を結合（体積 4,800,000 + 500,000 になるはず）'); await shot('2join');

  // 3. 床板の上面に円 → 切り取り（貫通）
  await tool('スケッチ作成'); await page.waitForTimeout(300);
  await page.mouse.click(...await scr([400, 250, 20])); await idle();
  await page.keyboard.press('c'); await page.waitForTimeout(200);
  await page.mouse.click(...await scr([400, 250, 20])); await page.waitForTimeout(200);
  await typeDims([40]); await page.waitForTimeout(300);
  console.log('  plane3', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature?.plane)));
  console.log('  sketch3 entities', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature?.entities)));
  await tool('押し出し'); await idle();
  await page.selectOption('#dialog select[data-k="operation"]', 'cut'); await idle();
  console.log('  cut dialog:', (await page.locator('#dialog').innerText()).replace(/\s+/g, ' ').slice(0, 260));
  await shot('3cut');
  await page.click('#dialog [data-act="ok"]'); await idle();
  await state('3 Ø40 の穴（体積が約 25,000 減るはず）'); await shot('3hole');

  // 4. 箱の縦エッジをクリック → フィレット
  await tool('選択').catch(() => {});
  await page.keyboard.press('Escape');
  { const r = ent2[0]; await page.mouse.click(...await scr([r.x + r.w, r.y + r.h, 45])); } await page.waitForTimeout(300);
  console.log('  selection', JSON.stringify(await page.evaluate(() => window.__app.selection.map(s => s.kind))));
  await page.keyboard.press('f'); await idle();
  console.log('  fillet dialog:', (await page.locator('#dialog:not(.hidden)').innerText({timeout:2000}).catch(() => '')).replace(/\s+/g, ' ').slice(0, 200));
  await page.click('#dialog [data-act="ok"]').catch(e => console.log('  no fillet ok', e.message.slice(0, 80))); await idle();
  await state('4 フィレット');

  // 5. XZ 平面に壁（新規ボディ）
  await tool('スケッチ作成'); await page.waitForTimeout(300);
  { await page.click('#planebar [data-pl=XZ]'); }
  await idle();
  console.log('  plane', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature?.plane)));
  console.log('  active element', await page.evaluate(() => { const a = document.activeElement; return a.tagName + '#' + a.id + '.' + a.className + ' in ' + (a.closest('[id]')||{}).id; }));
  await page.keyboard.press('r'); await page.waitForTimeout(200);
  await page.mouse.click(...await scr([0, 0, 20])); await page.waitForTimeout(400);
  await shot('5pre'); console.log('  sk tool', await page.evaluate(() => [window.__app.sketcher.tool, window.__app.mode]), 'inbox', await page.locator('.inbox input').count());
  await typeDims([600, 300]); await page.waitForTimeout(300);
  console.log('  sketch5 entities', JSON.stringify(await page.evaluate(() => window.__app.sketcher.feature?.entities)));
  await tool('押し出し'); await idle();
  await page.fill('#dialog input[data-k="distance"]', '20'); await idle();
  await shot('5wall');
  await page.click('#dialog [data-act="ok"]'); await idle();
  await state('5 壁 600x300x20（新規ボディ）'); await shot('5after');

  // 6. 床板の厚みを 20 → 30 に変更（タイムラインのダブルクリック）
  const tl = page.locator('#timeline .tl-item, #timeline [data-fid]');
  console.log('  timeline items', await tl.count());
  await tl.nth(1).dblclick(); await idle();
  console.log('  edit dialog:', (await page.locator('#dialog').innerText().catch(() => '')).replace(/\s+/g, ' ').slice(0, 120));
  await page.fill('#dialog input[data-k="distance"]', '30'); await idle();
  await page.click('#dialog [data-act="ok"]'); await idle();
  await state('6 床板を 30 に変更（箱・穴・壁が追従するか）'); await shot('6edit');

  // 7. 再読み込みで復元
  await page.waitForTimeout(1500);
  await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.meshes.length > 0, null, { timeout: 90000 }); await idle();
  await state('7 再読み込み後');
  await browser.close();
})();
