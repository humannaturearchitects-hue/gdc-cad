// 押し出し（Fusion 方式）: 複数スケッチのプロファイル、面の押し出し、対象まで、全体
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(250); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const state = async (label) => {
    const s = await page.evaluate(() => ({ feats: window.__store.project.features.map(f => f.type + (f.operation ? '(' + f.operation + ')' : '')), errors: window.__app.errors.map(e => e.message) }));
    let vol = ''; try { const r = await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 })); vol = r.list.map(b => `${b.name}:${Math.round(b.volume)} [${b.bounds.map(p => p.map(Math.round).join(',')).join(' / ')}]`).join(' ; '); } catch (e) { vol = 'measure err ' + e.message; }
    console.log(`### ${label}\n  feats ${s.feats.join(',')} errors ${JSON.stringify(s.errors)}\n  ${vol}`);
  };
  const tool = (t) => page.click(`.tool:has-text("${t}")`);
  const rect = async (x, y, w, h) => { await page.keyboard.press('r'); await page.waitForTimeout(150); await page.mouse.click(...await scr(x)); await page.waitForTimeout(150); const a = page.locator('.inbox input'); await a.nth(0).fill(String(w)); await a.nth(1).fill(String(h)); await page.keyboard.press('Enter'); await page.waitForTimeout(250); };
  const circle = async (c, d) => { await page.keyboard.press('c'); await page.waitForTimeout(150); const pc = await scr(c); console.log('  circle at', pc.map(Math.round), 'tool', await page.evaluate(() => window.__app.sketcher.tool)); await page.mouse.click(...pc); await page.waitForTimeout(150); await page.screenshot({ path: 'real3_c.png' }); await page.locator('.inbox input').nth(0).fill(String(d)); await page.keyboard.press('Enter'); await page.waitForTimeout(250); };
  const dlg = async () => (await page.locator('#dialog').innerText()).replace(/\s+/g, ' ');
  const ok = async () => { await page.click('#dialog [data-act="ok"]'); await idle(); };

  // 1. XY に長方形を 2 つ → 片方だけ押し出し
  await tool('スケッチ作成'); await page.click('#planebar [data-pl=XY]'); await idle();
  await rect([0, 0, 0], 0, 100, 100); await rect([300, 0, 0], 0, 100, 100);
  await page.keyboard.press('e'); await idle();
  console.log('  items0:', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.items)), 'meshes', await page.evaluate(() => window.__app.meshes.map(m => m.id).join(',')));
  await page.mouse.click(...await scr([50, 50, 0])); await idle();
  console.log('  items1:', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.items)), 'meshes', await page.evaluate(() => window.__app.meshes.map(m => m.id).join(',')));
  await page.fill('#dialog input[data-k="distance"]', '50'); await idle(); await ok();
  await state('1 長方形 A だけ 100x100x50（500,000）');

  // 2. 別のスケッチ（XY）に円 → 押し出しで「スケッチ1 の長方形 B」と「スケッチ2 の円」を同時に選ぶ
  await page.click('[data-nav=home]'); await page.waitForTimeout(400);
  await tool('スケッチ作成'); await page.click('#planebar [data-pl=XY]'); await idle();
  console.log('  mode2', await page.evaluate(() => [window.__app.mode, window.__app.sketcher.tool, window.__app.sketcher.feature?.plane?.name, document.activeElement.tagName]));
  await page.screenshot({ path: 'real3_2.png' });
  console.log('  zoom before', await page.evaluate(() => [window.__app.viewer.camera.zoom, window.__app.viewer.viewHalf]));
  await page.mouse.move(vp.x + vp.width / 2, vp.y + vp.height / 2); for (let i = 0; i < 9; i++) { await page.mouse.wheel(0, 300); await page.waitForTimeout(80); } await page.waitForTimeout(300);
  console.log('  zoom after', await page.evaluate(() => [window.__app.viewer.camera.zoom, window.__app.viewer.viewHalf]));
  await circle([150, 300, 0], 60);
  await page.keyboard.press('e'); await idle();
  console.log('  auto items:', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.items)));
  await page.mouse.click(...await scr([350, 50, 0])); await idle();
  console.log('  items after click B:', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.items)));
  await page.fill('#dialog input[data-k="distance"]', '30'); await idle(); await ok();
  await state('2 長方形B(スケッチ1)+円(スケッチ2) を 30 で同時に（300,000 + 84,823）');

  // 3. ボディの上面（z=50）を押し出し 20、結合
  await page.click('[data-nav=home]'); await page.waitForTimeout(400);
  await tool('押し出し'); await idle();
  await page.click('#dialog [data-clr="items"]').catch(() => {}); await page.waitForTimeout(200);
  await page.mouse.click(...await scr([50, 50, 50])); await idle();
  console.log('  items (face):', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.items.map(i => i.face ? 'face' : 'profile'))));
  await page.fill('#dialog input[data-k="distance"]', '20'); await idle();
  await page.selectOption('#dialog select[data-k="operation"]', 'join'); await idle();
  await ok();
  await state('3 上面を 20 押し出して結合（A が 100x100x70 = 700,000）');

  // 4. 「対象まで」: XY の新しい長方形（0,150 100x100）を A の上面（z=70）まで
  await page.click('[data-nav=home]'); await page.waitForTimeout(400);
  await tool('スケッチ作成'); await page.click('#planebar [data-pl=XY]'); await idle();
  await page.mouse.move(vp.x + vp.width / 2, vp.y + vp.height / 2); for (let i = 0; i < 9; i++) { await page.mouse.wheel(0, 300); await page.waitForTimeout(80); } await page.waitForTimeout(300);
  await rect([0, 150, 0], 0, 100, 100);
  await page.keyboard.press('e'); await idle();
  await page.selectOption('#dialog select[data-k="extent"]', 'to'); await idle();
  await page.click('#dialog [data-sel="to"]'); await page.waitForTimeout(200);
  await page.mouse.click(...await scr([50, 50, 70])); await idle();
  console.log('  to:', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.to)));
  await ok();
  await state('4 長方形 C を A の上面（z=70）まで（新ボディ 100x100x70 = 700,000）');

  // 5. 「全体」で貫通穴: A の上面に円 Ø20 → 切り取り・全体
  await page.click('[data-nav=home]'); await page.waitForTimeout(400);
  await tool('スケッチ作成'); await page.mouse.click(...await scr([50, 50, 70])); await idle();
  console.log('  plane5', await page.evaluate(() => JSON.stringify(window.__app.sketcher.feature?.plane)));
  await circle([50, 50, 70], 20);
  await page.keyboard.press('e'); await idle();
  await page.selectOption('#dialog select[data-k="operation"]', 'cut'); await idle();
  console.log('  cut defaults:', await page.evaluate(() => { const d = window.__app.dialog.active.draft; return [d.direction, d.extent].join(','); }));
  await ok();
  await state('5 A に Ø20 の貫通穴（700,000 - 21,991）');
  await page.screenshot({ path: 'real3_end.png' });
  await browser.close();
})();
