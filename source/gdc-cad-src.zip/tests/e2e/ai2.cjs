// AI に自然な言葉で頼む流れ（API は模擬応答）: 質問への数値の答え・選択中の「これ」・途中で止まったときの直し・取り消し・
// 送る内容（モデルの概要・キャッシュの区切り・説明書の不要部分を送らない）と、新しいコマンド（置く・回す・部品一覧・色・元に戻す N）
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
const PORT = process.env.PORT || 4173;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext(process.env.WK ? { ...require('playwright').devices['iPhone 15'], serviceWorkers: 'block' } : { viewport: { width: 1400, height: 850 }, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', (d) => (d.type() === 'prompt' ? d.accept('sk-ant-test-key') : d.accept()));
  const answers = [], reqs = [];
  const txt = (c) => (typeof c === 'string' ? c : c.map((b) => b.text).join(''));
  await page.route('https://api.anthropic.com/**', async (route) => {
    const body = JSON.parse(route.request().postData()); reqs.push(body);
    const a = answers.shift() || { commands: '', explanation: 'ok', question: '' };
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ id: 'msg_t', type: 'message', role: 'assistant', model: body.model, stop_reason: 'end_turn', stop_sequence: null, content: [{ type: 'text', text: JSON.stringify(a) }], usage: { input_tokens: 10, output_tokens: 10 } }) });
  });
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const run = (t) => page.evaluate((t) => window.__cmd(t), t);
  const show = (r) => r.map((x) => `${x.ok ? '✓' : '✗'} ${x.line} → ${x.msg}`).join(' | ');
  const bb = async (n) => { const r = await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map((m) => m.id), density: 1 })); const b = r.list.find((x) => x.name === n); return b ? b.bounds.map((p) => p.map((v) => +v.toFixed(1)).join(',')).join(' / ') : 'none'; };

  // ---- 新しいコマンド（AI なし）
  console.log(show(await run('パラメータ 厚み = 20\n板 幅600 奥行400 厚さ 厚み 名前 床板\n板 幅20 奥行400 厚さ300 名前 側板\n板 幅20 奥行400 厚さ300 位置 580,0,0 名前 側板B\n材料 床板 側板 側板B 合板')));
  console.log('place on:', show(await run('置く 側板 上 床板 中央')), '=>', await bb('側板'));
  console.log('place at:', show(await run('置く 側板B 位置 0,0,20')), '=>', await bb('側板B'));
  console.log('place center:', show(await run('置く 側板B 中心 300,200,170')), '=>', await bb('側板B'));
  console.log('rotate:', show(await run('回す 側板 90 軸 Z')), '=>', await bb('側板'));
  console.log('count:', show(await run('部品一覧')));
  console.log('color multi:', show(await run('色 赤 側板 側板B')), await page.evaluate(() => window.__app.meshes.filter((m) => /側板/.test(m.name)).map((m) => window.__store.project.bodyProps[m.id]?.color).join(',')));
  console.log('move multi:', show(await run('移動 側板 側板B 0,0,100')), '=>', await bb('側板'), ';', await bb('側板B'));
  const nF = await page.evaluate(() => window.__store.project.features.length);
  console.log('undo 2:', show(await run('元に戻す 2')), '| features', nF, '->', await page.evaluate(() => window.__store.project.features.length));
  console.log('view:', show(await run('視点 上')));
  // 選択中（「これ」）: ボディ名を省くと選んでいるもの
  await page.evaluate(() => { const a = window.__app; a.selection = [{ kind: 'body', bodyId: a.meshes.find((m) => m.name === '側板B').id }]; });
  console.log('this-move:', show(await run('移動 0,0,-100')), '=>', await bb('側板B'));
  // 選んだ面に穴（面の名前を書かない）
  await page.evaluate(async () => { const a = window.__app; const m = a.meshes.find((x) => x.name === '床板'); a.selection = [{ kind: 'face', bodyId: m.id, point: [300, 0, 10], normal: [0, -1, 0] }]; });
  console.log('sel face hole:', show(await run('穴 Ø6 深さ10 位置 100,10')));
  await page.evaluate(() => { window.__app.selection = []; });

  // ---- AI
  await page.click('.tool:has-text("AI に頼む")').catch(async () => page.evaluate(() => window.__app.cmdline.open()));
  await page.waitForTimeout(300);
  const say = async (t) => { await page.fill('#cmd-in', t); await page.click('#cmd-run'); await page.waitForTimeout(400); await page.waitForFunction(() => !document.querySelector('.cmd-item.thinking') && !window.__app.buildsRunning && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 }); await page.waitForTimeout(800); };
  const logText = async () => (await page.locator('#cmd-log').innerText()).replace(/\s+/g, ' ');
  // 1) 質問 → 調べるコマンド → 結果を AI に返す → 数値の答え
  answers.push({ commands: '部品一覧', explanation: '数えます。', question: '' }, { commands: '', explanation: '全部で 3 枚です（20×400×300 mm が 2 枚、600×400×20 mm が 1 枚）。', question: '' });
  await say('全部で何枚？');
  const r1 = reqs[reqs.length - 1];
  console.log('Q&A results sent:', /調べるコマンドの結果:[\s\S]*合計 3 個/.test(txt(r1.messages.at(-1).content)), '| answer shown:', (await logText()).includes('全部で 3 枚です'));
  // 2) 送った概要
  const ctx0 = txt(reqs[reqs.length - 2].messages.at(-1).content);
  console.log('context has params:', /\[パラメータ\] 厚み=20/.test(ctx0), '| weight:', /床板: 600×400×20、範囲 X 0〜600 Y 0〜400 Z 0〜20、.*合板（密度 0.55）、2\.64 kg/.test(ctx0), '| total:', /\[合計\] ボディ 3 個/.test(ctx0), '| names:', /# \[穴1\]/.test(ctx0));
  const sys = reqs[0].system[0].text;
  console.log('system: few-shot', /四隅に8ミリの穴/.test(sys), '| no voice section', !/■ 音声/.test(sys), '| no api key section', !/AI に理解させる/.test(sys), '| has 置く', /置く 柱 位置/.test(sys), '| chars', sys.length);
  console.log('history cache:', JSON.stringify(r1.messages.at(-2).content[0].cache_control || null), '| older msgs plain:', typeof r1.messages[0].content === 'string');
  // 3) 「これ」: 選択中のボディが概要に入る
  await page.evaluate(() => { const a = window.__app; a.selection = [{ kind: 'body', bodyId: a.meshes.find((m) => m.name === '側板').id }]; });
  answers.push({ commands: '側板 厚さ 250', explanation: '側板の高さを 250 mm にします。', question: '' });
  await say('これを25センチにして');
  console.log('selection in context:', /\[いま選択中\].*ボディ 側板/.test(txt(reqs.at(-1).messages.at(-1).content)), '=>', await bb('側板'));
  await page.evaluate(() => { window.__app.selection = []; });
  // 4) 途中で止まる → 直す依頼（実行できた行を伝える）→ 取り消しボタン
  const f0 = await page.evaluate(() => window.__store.project.features.length);
  answers.push({ commands: '板 幅100 奥行100 厚さ10 名前 小板\n穴 上面 位置 50,50 小板\n色 青 小板', explanation: '小板を作ります。', question: '' }, { commands: '穴 上面 Ø5 位置 50,50 小板\n色 青 小板', explanation: '穴の直径を 5 mm にして続けます。', question: '' });
  await say('10センチ角の小さい板を作って、真ん中に5ミリの穴、青で');
  const rq = txt(reqs.at(-1).messages.at(-1).content);
  console.log('retry tells done lines:', /実行できました[\s\S]*板 幅100 奥行100 厚さ10 名前 小板/.test(rq), '| failing line:', /穴 上面 位置 50,50 小板/.test(rq), '| body', await bb('小板'));
  const undoBtn = page.locator('[data-ai-undo]').last();
  console.log('undo button:', (await undoBtn.innerText()).trim());
  await undoBtn.click(); await page.waitForTimeout(1500);
  console.log('after undo: features', f0, '->', await page.evaluate(() => window.__store.project.features.length), '| 小板', await bb('小板'));
  // 5) 「やっぱり戻して」→ 直前の頼みごとの回数が概要に入る
  answers.push({ commands: '板 幅50 奥行50 厚さ5 名前 札\n色 黄 札', explanation: '札を作ります。', question: '' });
  await say('5センチ角の札を黄色で');
  answers.push({ commands: '元に戻す 2', explanation: '札を作る前に戻します。', question: '' });
  await say('やっぱりやめて');
  console.log('last batch in context:', /\[直前の頼みごと\] 2 回分/.test(txt(reqs.at(-1).messages.at(-1).content)), '| 札', await bb('札'));
  // 6) 質問に、概要から直接答える（コマンドなし）
  answers.push({ commands: '', explanation: '床板の重さは 2.64 kg です（合板）。', question: '' });
  await say('床板の重さは？');
  console.log('direct answer:', (await logText()).includes('2.64 kg です'));
  console.log('requests', reqs.length);
  if (process.env.SHOT) await page.screenshot({ path: process.env.SHOT });
  await browser.close();
})();
