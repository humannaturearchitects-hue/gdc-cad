// 「初めて使う社員」の通しの仕事（job 担当）
//  A. パソコン: 新規 → 収納キャビネット 1800×600×900（側板・天板・底板・棚板2・背板、板厚 20）を直方体で
//     → 材料 → 側板の外側にビス穴（画面で） → 図面 PDF・板取り DXF・切り出し一覧 CSV・STEP → 保存（名前）→ 開き直す
//  B. iPhone 15（WebKit）: AI に頼む（API は模擬応答）で同じものを作る → 書き出し → 保存 → 開き直す
//  C. 取り込み: .kcad をインポートから / DXF → 押し出し / STEP → プレス/プルで寸法を直す → 書き出し
// 使い方: PORT=4173 LANG=C.UTF-8 node tests/e2e/job_flow.cjs A|C   （Chromium。✓ の数 A:13 C:7）
//         PLAYWRIGHT_BROWSERS_PATH=… node tests/e2e/job_flow.cjs B    （WebKit・iPhone 15。✓ 8）
const { chromium, webkit, devices } = require('playwright');
const fs = require('fs'), path = require('path');
const URL = `http://127.0.0.1:${process.env.PORT || 4173}/`;
const FIX = [process.env.FIX, path.join(__dirname, '../fixtures'), path.join(__dirname, 'fixtures'), '/home/user/agentkit/fixtures'].find((d) => d && fs.existsSync(path.join(d, 'panel.dxf')));
const OUT = path.join(process.cwd(), 'dl_job'); fs.mkdirSync(OUT, { recursive: true });
const only = process.argv[2];
let fails = 0;
const ok = (c, msg, extra = '') => { if (!c) fails++; console.log(`${c ? '✓' : '✗'} ${msg}${extra ? '  ' + extra : ''}`); };

async function boot(browser, ctxOpts, { ai = false, answers = null, names = [] } = {}) {
  const ctx = await browser.newContext({ acceptDownloads: true, ...ctxOpts });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', (d) => {
    const m = d.message();
    if (d.type() === 'prompt' && /API キー/.test(m)) return d.accept('sk-ant-test-key');
    if (d.type() === 'prompt' && /ファイルの名前/.test(m)) return d.accept(names.shift() || '');
    return d.accept();
  });
  if (answers) {
    await page.route('https://api.anthropic.com/**', async (route) => {
      const body = JSON.parse(route.request().postData());
      const a = answers.shift() || { commands: '', explanation: 'ok', question: '' };
      await route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ id: 'msg_test', type: 'message', role: 'assistant', model: body.model, stop_reason: 'end_turn', stop_sequence: null, content: [{ type: 'text', text: JSON.stringify(a) }], usage: { input_tokens: 10, output_tokens: 10 } }) });
    });
  }
  await page.goto(URL);
  await page.evaluate((ai) => { localStorage.clear(); if (!ai) localStorage.setItem('gdc-voice-ai', '0'); else localStorage.setItem('gdc-ai-brain', 'claude'); }, ai);
  await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.waitForTimeout(800);
  const idle = () => page.waitForFunction(() => !window.__app.buildsRunning && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 120000 });
  const vols = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map((m) => m.id), density: 1 }))).list;
  const download = async (fn) => {
    const [d] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), fn()]);
    const p = path.join(OUT, d.suggestedFilename()); await d.saveAs(p);
    return { name: d.suggestedFilename(), text: fs.readFileSync(p, 'latin1'), utf: fs.readFileSync(p, 'utf8') };
  };
  return { ctx, page, idle, vols, download };
}

const CAB = [
  ['側板左', [0, 0, 0], 20, 600, 900], ['側板右', [1780, 0, 0], 20, 600, 900],
  ['天板', [20, 0, 880], 1760, 600, 20], ['底板', [20, 0, 0], 1760, 600, 20],
  ['棚板1', [20, 0, 300], 1760, 580, 20], ['棚板2', [20, 0, 590], 1760, 580, 20],
  ['背板', [20, 580, 20], 1760, 20, 860],
];
const CAB_VOL = CAB.reduce((t, c) => t + c[2] * c[3] * c[4], 0);

async function partA(browser) {
  console.log('--- A. パソコン: 収納キャビネットを画面の操作で');
  const { page, idle, vols, download } = await boot(browser, { viewport: { width: 1400, height: 850 } }, { names: ['収納キャビネット'] });
  // ようこそ画面の「直方体で作る」から始める
  const btns = await page.locator('#welcome [data-wl]').count();
  await page.click('#welcome [data-wl=box]'); await page.waitForTimeout(300);
  const welcomeHidden = await page.evaluate(() => getComputedStyle(document.getElementById('welcome')).display === 'none');
  ok(btns === 4 && await page.isVisible('#dialog [data-k=w]') && welcomeHidden, 'ようこそ画面のボタンで直方体の画面が開き、ようこそは隠れる', `ボタン ${btns}`);
  await page.click('#dialog [data-act=cancel]');
  for (const [n, p, w, d, h] of CAB) {
    await page.click('.tool:has-text("直方体")'); await page.waitForTimeout(200);
    for (let i = 0; i < 3; i++) await page.fill(`#dialog [data-k=position][data-i="${i}"]`, String(p[i]));
    await page.fill('#dialog [data-k=w]', String(w)); await page.fill('#dialog [data-k=d]', String(d)); await page.fill('#dialog [data-k=h]', String(h));
    await page.fill('#dialog [data-k=bodyName]', n);
    await page.click('#dialog [data-act=ok]'); await idle();
  }
  let L = await vols();
  ok(L.length === 7 && Math.abs(L.reduce((t, b) => t + b.volume, 0) - CAB_VOL) < 1, '直方体 7 枚でキャビネット', `体積 ${L.reduce((t, b) => t + b.volume, 0).toFixed(0)}（期待 ${CAB_VOL}）`);
  const tlTitle = await page.getAttribute('.tl-item >> nth=2', 'title');
  ok(/天板/.test(tlTitle || ''), 'タイムラインの説明にボディ名が出る', JSON.stringify((tlTitle || '').split('\n')[0]));
  // 全部選んで材料
  await page.click('#view3d', { position: { x: 60, y: 60 } }); await page.keyboard.press('Control+a'); await page.waitForTimeout(300);
  await page.click('.uxp-acts [data-a=mat]'); await page.selectOption('#mat-sel', '合板'); await page.click('#dialog [data-o]'); await idle(); await page.waitForTimeout(500);
  const mats = await page.evaluate(() => window.__app.meshes.map((m) => m.material && m.material.name));
  ok(mats.length === 7 && mats.every((m) => m === '合板'), '7 枚まとめて材料「合板」');
  // 側板左の外側（左面）にビス穴: 左から見る → 穴 → 面をクリック → 表に数値
  await page.keyboard.press('Escape'); await page.keyboard.press('4'); await page.waitForTimeout(900);
  const vp = await page.locator('#view3d').boundingBox();
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  await page.click('.tool:has-text("穴")'); await page.waitForTimeout(300);
  await page.mouse.click(...await scr([0, 300, 450])); await idle(); await page.waitForTimeout(800);
  const up = await page.evaluate(() => window.__app.viewer.camera.up.z);
  // 外から見て左下（奥・下）が基準 (0,0)。カーソルを置いた場所の表示が見たままの座標
  await page.mouse.move(...await scr([0, 450, 300])); await page.waitForTimeout(300);
  const cur = await page.locator('.hcur').innerText().catch(() => '');
  ok(up > 0.9 && /X\s*150/.test(cur) && /Y\s*300/.test(cur), '左面の穴: 逆さにならず、外から見た左下からの座標', `up.z ${up.toFixed(2)} / ${cur.replace(/\s+/g, ' ')}`);
  await page.fill('#dialog [data-pt="0"][data-c="0"]', '50'); await page.fill('#dialog [data-pt="0"][data-c="1"]', '890');
  await page.click('#dialog [data-ptadd]'); await page.fill('#dialog [data-pt="1"][data-c="0"]', '550'); await page.fill('#dialog [data-pt="1"][data-c="1"]', '890');
  await page.fill('#dialog [data-k=d]', '4'); await page.waitForTimeout(200);
  await page.click('#dialog [data-act=ok]'); await idle(); await page.waitForTimeout(400);
  L = await vols();
  const side = L.find((b) => b.name === '側板左');
  const holeVol = 2 * Math.PI * 2 * 2 * 20;
  // 穴の中心が実際に Y=550・Z=890 と Y=50・Z=890 にあるか（細い棒が穴の中に収まって干渉しない）
  await page.evaluate(() => window.__cmd('円柱 直径3 高さ20 位置 0,550,890 軸 X 名前 棒1\n円柱 直径3 高さ20 位置 0,50,890 軸 X 名前 棒2'));
  const inter = await page.evaluate(() => window.__kcall('interference', { ids: window.__app.meshes.map((m) => m.id) }));
  await page.evaluate(() => window.__cmd('削除 棒1 棒2'));
  ok(side && Math.abs(20 * 600 * 900 - holeVol - side.volume) < 1 && !inter.some((x) => JSON.stringify(x).includes('棒')), 'ビス穴 Ø4 が 2 個、見たままの位置に', `側板左 ${side && side.volume.toFixed(1)}`);
  // 手順に書き起こして、そのとおり作り直しても同じ
  const script = await page.evaluate(() => window.__app.cmdline.toScript());
  ok(/穴 左面 Ø4 外から見た座標 位置 50,890 550,890 側板左/.test(script), '手順の書き起こし（外から見た座標）', (script.match(/穴 左面.*/) || [''])[0]);
  await page.keyboard.press('7'); await page.waitForTimeout(300);
  // 保存（最初は名前を聞かれる）
  await page.keyboard.press('Control+s'); await page.waitForTimeout(800);
  ok(/収納キャビネット/.test(await page.textContent('#doc-title')), '最初の保存でファイルの名前を付けられる', await page.textContent('#doc-title'));
  // 書き出し: 図面 PDF / 板取り DXF / 切り出し一覧 CSV / STEP
  await page.click('.ws[data-ws=drawing]'); await idle(); await page.waitForTimeout(2500);
  const pdf = await download(() => page.click('#drawing-ws [data-x=pdf]'));
  await page.click('.ws[data-ws=design]'); await page.waitForTimeout(600);
  await page.click('#menu-file .menu-btn'); await page.click('#menu-file >> text=パネル加工データ'); await page.waitForTimeout(1500);
  const dxf = await download(() => page.click('#pn-dxf'));
  const csv = await download(() => page.click('#pn-csv'));
  await page.click('#dialog [data-o]');
  await page.click('#menu-file .menu-btn'); await page.click('#menu-file >> text=3D 書き出し'); await page.waitForTimeout(400);
  const step = await download(() => page.click('#dialog [data-o]'));
  ok(pdf.text.startsWith('%PDF') && /収納キャビネット/.test(pdf.name), '図面 PDF', pdf.name);
  ok(/HOLES/.test(dxf.text) && /OUTLINE/.test(dxf.text) && /収納キャビネット/.test(dxf.name), '板取り DXF（外形と穴の画層）', dxf.name);
  ok(/側板左/.test(csv.utf) && /合板/.test(csv.utf) && /背板/.test(csv.utf), '切り出し一覧 CSV', csv.name);
  ok(/ISO-10303/.test(step.text) && /収納キャビネット/.test(step.name), 'STEP', step.name);
  // 開き直す
  await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.meshes.length === 7, null, { timeout: 90000 });
  L = await vols();
  ok(/収納キャビネット/.test(await page.textContent('#doc-title')) && Math.abs(L.find((b) => b.name === '側板左').volume - side.volume) < 0.1 && (await page.evaluate(() => window.__app.meshes.every((m) => m.material && m.material.name === '合板'))), '開き直しても名前・形・穴・材料がそのまま');
  await page.context().close();
}

async function partB(browser) {
  console.log('--- B. iPhone 15: AI に頼む（模擬応答）');
  const answers = [
    { commands: CAB.map(([n, p, w, d, h]) => `板 幅${w} 奥行${d} 厚さ${h} 位置 ${p.join(',')} 名前 ${n}`).join('\n'), explanation: '幅1800・奥行600・高さ900 の収納キャビネットを、厚さ 20 の板 7 枚で作ります。', question: '' },
    { commands: '材料 すべて 合板', explanation: 'すべて合板にします。', question: '' },
    { commands: '穴 左面 Ø4 位置 50,890 300,890 550,890 50,10 300,10 550,10 側板左', explanation: '左の側板に Ø4 のビス穴を 6 個あけます。', question: '' },
  ];
  const { page, idle, vols, download } = await boot(browser, { ...devices['iPhone 15'], serviceWorkers: 'block' }, { ai: true, answers, names: ['キャビネットiPhone'] });
  await page.tap('#welcome [data-wl=ai]'); await page.waitForTimeout(600);
  // 入力欄が見えていて、下のボタンに隠れていない
  const vis = async () => page.evaluate(() => {
    const ta = document.getElementById('cmd-in'); const r = ta.getBoundingClientRect();
    const hit = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
    return hit === ta && r.bottom <= innerHeight && r.top >= 0;
  });
  ok(await vis(), 'AI に頼む画面: 入力欄がすぐ見える（スクロール不要）');
  const say = async (t) => { await page.fill('#cmd-in', t); await page.tap('#cmd-run'); await page.waitForTimeout(800); await idle(); await page.waitForTimeout(1500); };
  await say('幅1800、奥行600、高さ900の収納キャビネットを板厚20で。側板2枚・天板・底板・棚板2枚・背板');
  await say('全部合板にして');
  await say('左の側板に天板と底板を留めるビス穴を4ミリで');
  const L = await vols();
  const total = L.reduce((t, b) => t + b.volume, 0);
  ok(L.length === 7 && Math.abs(total - (CAB_VOL - 6 * Math.PI * 4 * 20)) < 1, 'AI の 3 回の頼みごとでキャビネット・材料・ビス穴', `体積 ${total.toFixed(1)}`);
  ok(await vis(), '会話が長くなっても入力欄は見えたまま');
  ok(await page.evaluate(() => window.__app.meshes.every((m) => m.material && m.material.name === '合板')), '材料がすべて合板');
  // AI を使わない設定で、ふだんの言葉を書いたとき
  await page.tap('#dialog .cmd-set summary'); await page.waitForTimeout(200);
  await page.tap('#ai-off'); await page.waitForTimeout(200);
  await page.fill('#cmd-in', '天板を厚くして'); await page.tap('#cmd-run'); await page.waitForTimeout(1500);
  const lg = await page.textContent('#cmd-log'); if (process.env.DBG) console.log(lg.slice(-400));
  ok(/AI を使わない設定にしました/.test(lg) && /天板の厚さをいくつにしますか/.test(lg), 'AI を使わない設定でも、ふだんの言葉を読み取って足りない数を聞き返す');
  await page.tap('#ai-off');
  await page.tap('#dialog [data-o]'); await page.waitForTimeout(300);
  // 図面（キューブが重ならない）→ PDF
  await page.tap('.ws[data-ws=drawing]'); await page.waitForTimeout(3500);
  const cube = await page.evaluate(() => getComputedStyle(document.getElementById('viewcube')).display);
  const pdf = await download(() => page.tap('[data-xq=pdf]'));
  ok(cube === 'none' && pdf.text.startsWith('%PDF'), '図面: 3D のキューブが重ならず、PDF が出せる', `cube ${cube}`);
  await page.tap('.ws[data-ws=design]'); await page.waitForTimeout(600);
  await page.tap('#menu-file .menu-btn'); await page.waitForTimeout(200);
  await page.tap('#menu-file >> text=パネル加工データ'); await page.waitForTimeout(1500);
  const csv = await download(() => page.tap('#pn-csv'));
  ok(/側板左/.test(csv.utf) && /6/.test(csv.utf), '切り出し一覧 CSV（iPhone）', csv.name);
  await page.tap('#dialog .dlg-head .x'); await page.waitForTimeout(300);
  await page.tap('#menu-file .menu-btn'); await page.waitForTimeout(200);
  await page.tap('#menu-file >> text=保存（この端末に）'); await page.waitForTimeout(800);
  await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.meshes.length === 7, null, { timeout: 90000 });
  ok(/キャビネットiPhone/.test(await page.textContent('#doc-title')), '保存して開き直す（iPhone）', await page.textContent('#doc-title'));
  await page.context().close();
}

async function partC(browser) {
  console.log('--- C. 既存のデータを取り込んで直す');
  const { page, idle, vols, download } = await boot(browser, { viewport: { width: 1400, height: 850 } });
  const pick = async (file) => { const [fc] = await Promise.all([page.waitForEvent('filechooser'), (async () => { if (await page.isVisible('#welcome [data-wl=open]')) await page.click('#welcome [data-wl=open]'); else await page.evaluate(() => { window.__app.importFile(); }); })()]); await fc.setFiles(file); await page.waitForTimeout(1500); await idle(); };
  // .kcad を「インポート」から選んでも開ける
  await page.evaluate(() => window.__cmd('板 幅600 奥行400 厚さ20 名前 床板'));
  const kc = path.join(OUT, 'floor.kcad'); fs.writeFileSync(kc, await page.evaluate(() => JSON.stringify({ ...window.__store.project, name: '床パネル' })));
  await page.evaluate(() => window.__app.newDoc()); await page.waitForTimeout(800);
  const accept = await page.evaluate(() => { const i = document.getElementById('file-input'); return new Promise((res) => { i.addEventListener('click', (e) => { e.preventDefault(); res(i.accept); }, { once: true }); window.__app.importFile(); }); });
  await pick(kc);
  ok(/\.kcad/.test(accept) && /床パネル/.test(await page.textContent('#doc-title')) && (await vols()).length === 1, '.kcad を「開く・取り込む」から選んでも開ける', accept);
  // DXF → 押し出し（外形が自動で選ばれる）
  await page.evaluate(() => window.__app.newDoc()); await page.waitForTimeout(800);
  await pick(path.join(FIX, 'panel.dxf'));
  await page.keyboard.press('e'); await page.waitForTimeout(600);
  const sel = await page.textContent('#dialog .selfield');
  await page.fill('#dialog [data-k=distance]', '20'); await page.click('#dialog [data-act=ok]'); await idle();
  let L = await vols();
  ok(/1個/.test(sel) && L.length === 1 && Math.abs(L[0].volume - 1978996) < 2, 'DXF を読み込んで E → 外形（穴あき）が選ばれていて、そのまま板になる', `${sel.trim()} 体積 ${L[0] && L[0].volume.toFixed(0)}`);
  ok(/panel/.test(await page.textContent('#doc-title')), 'DXF のファイル名がファイルの名前に');
  // 厚さを直す（タイムラインをダブルクリック）
  await page.dblclick('.tl-item >> nth=1'); await page.waitForTimeout(400);
  await page.fill('#dialog [data-k=distance]', '30'); await page.click('#dialog [data-act=ok]'); await idle();
  L = await vols();
  ok(Math.abs(L[0].volume - 1978996 * 1.5) < 3, 'DXF の板の厚さを 30 に直せる', L[0].volume.toFixed(0));
  // STEP → ダブルクリックの案内 → プレス/プルで直す → STEP 書き出し
  await page.evaluate(() => window.__app.newDoc()); await page.waitForTimeout(800);
  await pick(path.join(FIX, 'nested.step'));
  await page.dblclick('.tl-item >> nth=0'); await page.waitForTimeout(300);
  const msg = await page.textContent('#toast');
  const vp = await page.locator('#view3d').boundingBox();
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  await page.mouse.click(...await scr([600, 0, 100])); await page.waitForTimeout(300);
  await page.keyboard.press('q'); await page.waitForTimeout(500);
  await page.fill('#dialog [data-k=distance]', '-20'); await page.click('#dialog [data-act=ok]'); await idle();
  L = await vols();
  const st = L.find((b) => b.name === 'スツール');
  ok(/プレス\/プル/.test(msg) && st && Math.abs(st.volume - 800000) < 1, 'STEP: 直し方の案内どおり、プレス/プルで高さ 100→80', `${st && st.volume}`);
  const step = await download(() => page.evaluate(() => window.__app.export3D('step')));
  ok(/ISO-10303/.test(step.text) && /nested/.test(step.name), '直した STEP を書き出し', step.name);
  // 読めない形式は分かる言葉で
  const bad = path.join(OUT, 'memo.pdf'); fs.writeFileSync(bad, '%PDF-1.4');
  await pick(bad);
  ok(/読み込めない形式/.test(await page.textContent('#toast')), '読めない形式は理由を表示');
  await page.context().close();
}

(async () => {
  if (only !== 'B') {
    const chrome = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
    if (!only || only === 'A') await partA(chrome);
    if (!only || only === 'C') await partC(chrome);
    await chrome.close();
  }
  if (!only || only === 'B') { const wk = await webkit.launch(); await partB(wk); await wk.close(); }
  console.log(fails ? `NG ${fails}` : 'ALL OK');
})();
