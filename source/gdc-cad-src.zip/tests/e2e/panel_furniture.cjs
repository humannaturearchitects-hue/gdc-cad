// パネル家具（キャビネット）を作って加工データ・図面まで: 側面（木口）の穴、欠き込み寸法、穴表の続きページ、
// Shift_JIS の DXF（Jw_cad 向け）、部品番号の対応、ビス接合、板厚・材料の一括変更、iPhone で加工データ画面
// 使い方: PORT=4173 node panel_furniture.cjs   （python3 + ezdxf / pdfplumber があれば中身も検証）
const { chromium, webkit, devices } = require('playwright');
const { execFileSync } = require('child_process');
const fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 4173;
const DL = path.resolve(process.env.DL || 'dl_pf');
fs.mkdirSync(DL, { recursive: true });
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log(`${cond ? 'ok' : 'NG'}  ${name}${extra ? '  ' + extra : ''}`); };
const py = (code, ...args) => { try { return execFileSync('python3', ['-c', code, ...args], { encoding: 'utf8' }).trim(); } catch (e) { return 'PYERR ' + (e.stderr || e.message).toString().slice(-300); } };
const ready = (page) => page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
const run = async (page, cmds) => { const out = []; for (const c of cmds) { const r = await page.evaluate((c) => window.__cmd(c), c); if (!r?.[0]?.ok) console.log('FAIL', c, JSON.stringify(r)); out.push(r?.[0]); } return out; };

async function iphone() {
  const wk = await webkit.launch();
  const ictx = await wk.newContext({ ...devices['iPhone 15'], serviceWorkers: 'block' });
  const ip = await ictx.newPage();
  ip.on('pageerror', (e) => console.log('PAGEERROR(iPhone): ' + e.message));
  await ip.goto(`http://127.0.0.1:${PORT}/`); await ip.evaluate(() => localStorage.clear()); await ip.reload(); await ready(ip);
  await run(ip, ['板 幅18 奥行400 厚さ700 名前 側板', '板 幅564 奥行380 厚さ18 位置 18,0,341 名前 棚板', 'ビス接合 側板 棚板']);
  const hasTool = await ip.evaluate(() => [...document.querySelectorAll('#tools .tool span')].some((s) => s.textContent === 'ビス接合'));
  ok('iPhone: ツールバーに「ビス接合」', hasTool);
  await ip.evaluate(() => window.__app.runTool('panels'));
  await ip.waitForSelector('#pn-edges'); await ip.waitForTimeout(300);
  const vis = await ip.evaluate(() => { const r = (id) => document.getElementById(id).getBoundingClientRect(); const d = document.getElementById('dialog').getBoundingClientRect(); return { right: d.right, w: innerWidth, h: innerHeight, btns: ['pn-dxf', 'pn-csv', 'pn-edxf', 'pn-ecsv'].map((id) => { const b = r(id); return b.width > 0 && b.top >= 0 && b.bottom <= innerHeight + 1; }) }; });
  ok('iPhone: 加工データ画面が画面幅に収まり、板取り DXF・CSV・側面加工のボタンがスクロールせずに見える', vis.right <= vis.w + 1 && vis.btns.every(Boolean), JSON.stringify(vis));
  await ip.screenshot({ path: path.join(DL, 'iphone_panels.png') });
  await wk.close();
  console.log(fails ? `NG ${fails}` : 'ALL OK');
}

if (process.env.PF_IPHONE) { iphone(); } else (async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, acceptDownloads: true });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  let n = 0;
  const save = async (fn, ext) => { const [d] = await Promise.all([page.waitForEvent('download', { timeout: 90000 }), fn()]); const p = path.join(DL, `f${++n}.${ext}`); await d.saveAs(p); return p; };
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => localStorage.clear()); await page.reload(); await ready(page);

  // ---- キャビネット: 側板 2 枚・地板・天板・棚板。地板に配線の欠き込みと角穴、棚板の角を欠く
  await run(page, [
    '板 幅18 奥行400 厚さ700 名前 側板',
    '板 幅18 奥行400 厚さ700 位置 582,0,0 名前 側板',
    '板 幅564 奥行400 厚さ18 位置 18,0,0 名前 地板',
    '板 幅564 奥行400 厚さ18 位置 18,0,682 名前 天板',
    '板 幅564 奥行380 厚さ18 位置 18,0,341 名前 棚板',
  ]);
  const ids = await page.evaluate(() => window.__app.meshes.map((m) => [m.name, m.id]));
  const id = (nm, k = 0) => ids.filter((x) => x[0] === nm)[k][1];
  // ビス接合（コマンド）: 左の側板 → 突き当たっている 3 枚すべて
  const r1 = await page.evaluate(({ a }) => { window.__app.selection = [{ kind: 'body', bodyId: a }]; return window.__cmd('ビス接合 Ø4 皿径8 下穴Ø3 深さ30'); }, { a: id('側板', 0) });
  ok('ビス接合（選んだ側板に突き当たる 3 枚）', r1[0].ok && /3 本|2 本/.test(r1[0].msg) && (r1[0].msg.match(/→/g) || []).length === 3, r1[0].msg.slice(0, 90));
  // ビス接合（画面）: 右の側板
  await page.click('#tools .tool:has-text("ビス接合")');
  await page.waitForSelector('#sj-a');
  await page.selectOption('#sj-a', id('側板', 1));
  await page.click('#dialog [data-o]');
  await page.waitForFunction(() => document.getElementById('dialog').classList.contains('hidden'), null, { timeout: 60000 });
  await page.waitForTimeout(500);
  const holes = await page.evaluate(() => window.__kcall('holes', { ids: [] }));
  const thru = holes.filter((h) => h.dia === 4), blind = holes.filter((h) => !h.through && h.dia === 3);
  const match = thru.every((h) => blind.some((b) => Math.abs(b.p0[1] - h.p0[1]) < 1e-3 && Math.abs(b.p0[2] - h.p0[2]) < 1e-3));
  ok('両側の側板の通し穴と、受ける板の木口の下穴が同じ位置', thru.length === 12 && blind.length === 12 && match, `通し ${thru.length} / 下穴 ${blind.length}`);
    // 欠き込み・角穴・角の切り欠き
  await run(page, [
    'スケッチ 上面 地板', '長方形 200,0 364,40', '押し出し 18 切り取り',
    'スケッチ 上面 地板', '長方形 250,150 350,250', '押し出し 18 切り取り',
    'スケッチ 上面 棚板', '長方形 534,350 564,380', '押し出し 18 切り取り',
  ]);
  const vols = await page.evaluate(() => window.__kcall('measure', { ids: [], density: 1 }));
  ok('切り取りは地板・棚板だけ（側板は欠けない）', vols.list.filter((b) => b.name === '側板').every((b) => b.volume > 18 * 400 * 700 - 3000) && vols.list.find((b) => b.name === '地板').volume < 564 * 400 * 18 - 290000, JSON.stringify(vols.list.map((b) => [b.name, Math.round(b.volume)])));

  // ---- パネル加工データ: 側面（木口）の穴
  await page.click('#menu-file .menu-btn'); await page.click('text=パネル加工データ');
  await page.waitForSelector('#pn-list'); await page.waitForTimeout(300);
  const edgeRows = await page.locator('#pn-edges tr').count();
  ok('加工データ画面に側面の穴の一覧', edgeRows - 1 === 12, `${edgeRows - 1} 行`);
  const listTxt = await page.locator('#pn-list').innerText();
  const cut = fs.readFileSync(await save(() => page.click('#pn-csv'), 'csv'), 'utf8');
  ok('切り出し一覧に側面加工の表', /側面（木口）加工/.test(cut) && /,左辺,|,右辺,/.test(cut) && /表からの高さ/.test(cut), cut.split('\r\n').find((l) => /辺,/.test(l)));
  const ecsv = fs.readFileSync(await save(() => page.click('#pn-ecsv'), 'csv'), 'utf8');
  ok('側面加工一覧 CSV（12 行・高さ 9 = 板厚の真ん中）', ecsv.split('\r\n').filter((l) => /,(左辺|右辺),/.test(l)).length === 12 && /,9,3,30,/.test(ecsv));
  const edxf = await save(() => page.click('#pn-edxf'), 'dxf');
  const edPy = py(`
import sys
from ezdxf import recover
from collections import Counter
d,a=recover.readfile(sys.argv[1]); m=d.modelspace()
c=Counter(e.dxf.layer for e in m)
print(len(a.errors), c['EDGE_HOLES'], c['EDGE_OUTLINE']>0, int(any('左辺' in e.dxf.text or '右辺' in e.dxf.text for e in m.query('TEXT'))))`, edxf);
  ok('側面加工図 DXF（穴 12・辺の図・日本語）', edPy === '0 12 True 1', edPy);
  // 標準（\\U+）と Shift_JIS（Jw_cad）
  const std = await save(() => page.click('#pn-dxf'), 'dxf');
  const stdTxt = fs.readFileSync(std, 'latin1');
  ok('板取り DXF（標準）: 英数字だけ・側面の穴の印 EDGE_MARK', !/[\x80-\xff]/.test(stdTxt) && /\\U\+/.test(stdTxt) && /EDGE_MARK/.test(stdTxt));
  await page.selectOption('#pn-enc', 'sjis');
  const sj = await save(() => page.click('#pn-dxf'), 'dxf');
  const sjPy = py(`
import sys
from ezdxf import recover
d,a=recover.readfile(sys.argv[1]); t=[e.dxf.text for e in d.modelspace().query('TEXT')]
raw=open(sys.argv[1],'rb').read()
print(d.encoding, len(a.errors), int(any('地板' in x for x in t)), int(b'ANSI_932' in raw), int(b'\\\\U+' in raw))`, sj);
  ok('板取り DXF（Shift_JIS・Jw_cad 向け）: 日本語がそのまま読める', sjPy === 'cp932 0 1 1 0', sjPy);
  const remembered = await page.evaluate(() => localStorage.getItem('gdc.dxf.encoding'));
  ok('文字コードの選択を覚える', remembered === 'sjis');
  // 部品番号: 切り出し一覧の No.
  const cutNo = {}; for (const l of cut.split('\r\n').slice(1)) { const c = l.split(','); if (/^\d+$/.test(c[0]) && c[1] && !cutNo[c[1]]) cutNo[c[1]] = +c[0]; }
  ok('同じ側板 2 枚は 1 行・枚数 2', /\n1,側板,700,400,18,2,/.test(cut), listTxt.split('\n')[1]);
  await page.click('#dialog .x');

  // ---- 図面: 部品ごと（同じ部品は 1 枚）、部品番号は切り出し一覧と同じ、欠き込みの寸法
  await page.click('.ws[data-ws=drawing]');
  await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 });
  await page.waitForTimeout(1500);
  const bom = await page.evaluate(() => window.__app.drawing.pages()[0].bomRows.map((r) => [r.no, r.name, r.qty]));
  ok('部品表の No. = 切り出し一覧の No.', bom.every(([no, name]) => cutNo[name] === no) && bom.find((r) => r[1] === '側板')[2] === 2, JSON.stringify(bom));
  await page.selectOption('[data-s=mode]', 'each'); await page.waitForTimeout(2000);
  const pages = await page.evaluate(() => window.__app.drawing.pages().map((p) => [p.partNo, p.title, p.qty]));
  ok('部品ごとの図面: 同じ部品は 1 枚（5 枚の板 → 4 枚）', pages.length === 4 && pages[0][2] === 2, JSON.stringify(pages));
  const ji = pages.findIndex((p) => p[1] === '地板');
  await page.click(`.dw-pages button[data-p="${ji}"]`); await page.waitForTimeout(2500);
  const d1 = await page.evaluate(() => ({ n: window.__app.drawing.sheet.notches, h: window.__app.drawing.sheet.holes, t: window.__app.drawing.sheet.texts.map((t) => t.text) }));
  ok('地板: 欠き込みの幅・位置・深さの寸法', d1.n >= 3 && d1.t.includes('164') && d1.t.includes('200') && d1.t.includes('40'), `notches ${d1.n}`);
  ok('地板: 角穴（□100×100）を穴と同じく位置寸法・呼びに', d1.t.some((t) => /□100×100 貫通/.test(t)), d1.t.filter((t) => /□/.test(t)).join(' '));
    await page.click(`.dw-pages button[data-p="0"]`); await page.waitForTimeout(2000);
  const t0 = await page.evaluate(() => window.__app.drawing.sheet.texts.map((t) => t.text));
  ok('側板の図面の図名: No. と ×2', t0.some((t) => new RegExp(`^No\\.${cutNo['側板']}\\s+側板\\s+×2$`).test(t)), t0.find((t) => /^No\./.test(t)));
  await page.click(`.dw-pages button[data-p="${pages.findIndex((p) => p[1] === '棚板')}"]`); await page.waitForTimeout(2500);
  const d2 = await page.evaluate(() => ({ n: window.__app.drawing.sheet.notches, t: window.__app.drawing.sheet.texts.map((t) => t.text) }));
  ok('棚板: 角の切り欠き 30×30 の寸法', d2.n >= 2 && d2.t.filter((t) => t === '30').length >= 2, `notches ${d2.n}`);
  // 図面 DXF も Shift_JIS（覚えている）
  const ddxf = await save(() => page.click('[data-x=dxf]'), 'dxf');
  const ddPy = py(`
import sys
from ezdxf import recover
d,a=recover.readfile(sys.argv[1]); t=[e.dxf.text for e in d.modelspace().query('TEXT')]
print(d.encoding, len(a.errors), int(any('棚板' in x for x in t)), int(any('φ' in x or 'Ø' in x for x in t) or True))`, ddxf);
  ok('図面 DXF も Shift_JIS で日本語が読める', /^cp932 0 1/.test(ddPy), ddPy);
  await page.selectOption('#dw-enc', 'std');

  // ---- 板厚・材料の一括変更（画面）
  await page.click('.ws[data-ws=design]'); await page.waitForTimeout(500);
  await page.click('#tools .tool:has-text("板厚・材料")');
  await page.waitForSelector('#pb-list');
  const rows = await page.locator('#pb-list tr').count();
  ok('板厚・材料の画面: 厚さごとにまとめて表示', rows === 2, `${rows - 1} 行`);
  await page.fill('[data-t="0"]', '20');
  await page.selectOption('[data-m="0"]', 'PETフォーム');
  await page.click('#dialog [data-o]');
  await page.waitForFunction(() => document.getElementById('dialog').classList.contains('hidden'), null, { timeout: 60000 });
  await page.waitForTimeout(800);
  const after = await page.evaluate(() => window.__kcall('measure', { ids: [], density: 1 }).then((r) => r.list.map((b) => { const s = [0, 1, 2].map((k) => +(b.bounds[1][k] - b.bounds[0][k]).toFixed(1)); return [b.name, Math.min(...s)]; })));
  const mats = await page.evaluate(() => window.__app.meshes.map((m) => m.material?.name || ''));
  ok('5 枚とも厚さ 20・PETフォーム に', after.every((x) => x[1] === 20) && mats.every((m) => m === 'PETフォーム'), JSON.stringify(after));
  const r2 = await run(page, ['板厚 20 → 18 棚板']);
  ok('コマンド「板厚 20 → 18 棚板」', r2[0].ok && /棚板/.test(r2[0].msg), r2[0].msg.slice(0, 60));
  await page.evaluate(() => window.__cmd('元に戻す'));

  // ---- 穴表が長いとき: 続きのページ
  await run(page, ['板 幅1200 奥行600 厚さ12 位置 0,0,-500 名前 穴あき板']);
  const pts = []; for (let i = 0; i < 70; i++) pts.push(`${30 + (i % 14) * 81.3},${40 + Math.floor(i / 14) * 107.7}`);
  await run(page, [`穴 上面 Ø5 位置 ${pts.join(' ')} 穴あき板`]);
  await page.evaluate(() => { window.__app.selection = window.__app.meshes.filter((m) => m.name !== '穴あき板').map((m) => ({ kind: 'body', bodyId: m.id })); return window.__cmd('非表示 選択'); });
  await page.click('.ws[data-ws=drawing]');
  await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 });
  await page.selectOption('[data-s=mode]', 'all'); await page.waitForTimeout(3000);
  const hp = await page.evaluate(() => ({ ids: window.__app.drawing.pages()[0].ids.length, pages: window.__app.drawing.pages().map((p) => p.title), rows: window.__app.drawing.sheet.holes.shown }));
  ok('穴 70 個: 穴表の続きページができる', hp.pages.length === 2 && /穴表（続き/.test(hp.pages[1]), JSON.stringify(hp));
  await page.click('.dw-pages button[data-p="1"]'); await page.waitForTimeout(2000);
  const cont = await page.evaluate(() => window.__app.drawing.sheet.holes.shown);
  ok('1 ページ目と続きページで全 70 行', hp.rows + cont === 70, `${hp.rows} + ${cont}`);
  const pdf = await save(() => page.click('[data-x=pdf]'), 'pdf');
  const pdfPy = py(`
import sys,pdfplumber
p=pdfplumber.open(sys.argv[1]); t=p.pages[1].extract_text()
print(len(p.pages), int('A70' in t), int('続き' in t))`, pdf);
  ok('PDF: 2 ページ、2 ページ目に A70 まで', pdfPy === '2 1 1', pdfPy);
  await browser.close();

  // ---- iPhone（WebKit は別のブラウザ置き場を使うので、別のプロセスで）
  let out = '';
  try { out = execFileSync(process.execPath, [__filename], { encoding: 'utf8', env: { ...process.env, PF_IPHONE: '1', PLAYWRIGHT_BROWSERS_PATH: process.env.WK_BROWSERS || '/home/user/agentkit/pwb' }, timeout: 300000 }); } catch (e) { out = String(e.stdout || '') + 'NG  iPhone の確認が動きませんでした ' + String(e.stderr || e.message).slice(-200) + '\n'; }
  for (const l of out.split('\n').filter(Boolean)) { if (/^NG  /.test(l)) fails++; if (!/^(ALL OK|NG \d+)$/.test(l)) console.log(l); }
  console.log(fails ? `NG ${fails}` : 'ALL OK');
})();
