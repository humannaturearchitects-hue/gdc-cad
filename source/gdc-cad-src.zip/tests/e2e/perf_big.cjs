// 大きなモデル（部品 N 個・穴たくさん）での速さとメモリを測る
//   node perf_big.cjs [部品数=300] [chromium|iphone]
// 出力の各行: "<項目> <ミリ秒> ms" と、最後に JSON（まとめ）
// 期待（パソコン Chromium、部品 300）: 開く < 60 秒、1 つ直す < 3 秒、元に戻す < 3 秒、保存 < 2 秒
const { chromium, webkit, devices } = require('playwright');
const PORT = process.env.PORT || 4173;
const N = +process.argv[2] || 300;
const MODE = process.argv[3] || 'chromium';

// 板 N 枚。厚さはパラメータ t（全部の板が使う）→ t を変えると全部計算し直し（いちばん重い場合）
// 10 枚に 1 枚は 6x4 = 24 個の穴、それ以外は四隅の 4 穴
function bigProject(n) {
  const features = [];
  for (let i = 0; i < n; i++) {
    const x = (i % 20) * 700, y = Math.floor(i / 20) * 500;
    const bid = `F${i}b`;
    features.push({ id: bid, type: 'box', name: `直方体${i + 1}`, position: [String(x), String(y), '0'], w: '600', d: '400', h: 't', operation: 'new', bodyName: `板${i + 1}` });
    const pos = i % 10 === 0
      ? [...Array(24)].map((_, k) => [String(50 + (k % 6) * 100), String(50 + Math.floor(k / 6) * 100)])
      : [['30', '25'], ['570', '25'], ['570', '375'], ['30', '375']];
    features.push({ id: `F${i}h`, type: 'hole', name: `穴${i + 1}`, placement: 'coords', face: [x + 7.81, y + 5.21, 20, 0, 0, 1], faceRef: { body: `B_${bid}`, point: [x + 7.81, y + 5.21, 20] }, body: `B_${bid}`, ref: 'corner', pos, axes: 'global', style: 'simple', d: '8', through: true, depth: '10', useCircles: true, flip: false, points: [] });
  }
  return { format: 'kobocad', version: 1, name: `大きいモデル${n}`, units: 'mm', params: [{ name: 't', expr: '20' }], features, bodyProps: {}, rollback: null, drawing: null };
}

(async () => {
  const args = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];
  const browser = MODE === 'iphone' ? await webkit.launch() : await chromium.launch({ args });
  const ctx = MODE === 'iphone' ? await browser.newContext({ ...devices['iPhone 15'], serviceWorkers: 'block' }) : await browser.newContext({ viewport: { width: 1400, height: 850 }, serviceWorkers: 'block', acceptDownloads: true });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  const cdp = MODE === 'iphone' ? null : await ctx.newCDPSession(page);
  if (cdp) await cdp.send('Performance.enable');
  const out = { n: N, mode: MODE };
  const heap = async () => {
    const r = {};
    if (cdp) { const m = await cdp.send('Performance.getMetrics'); r.jsMB = Math.round(m.metrics.find((x) => x.name === 'JSHeapUsedSize').value / 1048576); }
    const s = await page.evaluate(() => window.__kcall('stats').catch(() => null));
    if (s) r.wasmMB = Math.round(s.wasmBytes / 1048576), r.snaps = s.snaps;
    return r;
  };
  const idle = (t = 600000) => page.waitForFunction(() => window.__app && !window.__app.buildsRunning && document.getElementById('busy').classList.contains('hidden'), null, { timeout: t });
  const time = async (label, fn) => { const t0 = Date.now(); await fn(); const ms = Date.now() - t0; out[label] = ms; console.log(label, ms, 'ms', JSON.stringify(await heap())); return ms; };

  await page.goto(`http://127.0.0.1:${PORT}/`);
  await page.evaluate(() => { localStorage.clear(); indexedDB.deleteDatabase('gdc-cad'); });
  await time('startup', async () => { await page.reload(); await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 120000 }); });
  out.heapStart = await heap();

  const proj = bigProject(N);
  await time('open', async () => { await page.evaluate((p) => window.__store.replace(p), proj); await page.waitForFunction((n) => window.__app.meshes.length === n, N, { timeout: 900000 }); await idle(); });
  out.errors = await page.evaluate(() => window.__app.errors.length);
  out.heapOpen = await heap();
  // 1 つ直す（最後の板の幅）→ 後ろだけ計算し直し
  await time('editLast', async () => { await page.evaluate(() => { const f = window.__store.project.features; const b = f[f.length - 2]; window.__store.commit(() => { b.w = '650'; }); }); await page.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 600000 }); await idle(); });
  await time('undo', async () => { await page.evaluate(() => window.__store.undo()); await idle(); });
  await time('redo', async () => { await page.evaluate(() => window.__store.redo()); await idle(); });
  // 厚さパラメータ → 全部計算し直し
  await time('editParam', async () => { await page.evaluate(() => window.__store.commit((p) => { p.params[0].expr = '24'; })); await idle(); });
  out.heapAfterParam = await heap();
  await time('undoParam', async () => { await page.evaluate(() => window.__store.undo()); await idle(); });
  // 保存（保管庫へ）
  await time('save', async () => { await page.evaluate(() => window.__store.flush()); });
  out.saveState = await page.evaluate(() => window.__store.saveState);
  // 図面（全部を 1 枚に）
  await time('drawing', async () => { await page.evaluate(() => window.__app.setWorkspace('drawing')); await page.waitForFunction(() => document.querySelector('.dw-sheet svg') || /失敗/.test(document.querySelector('.dw-sheet')?.textContent || ''), null, { timeout: 600000 }); await idle(); });
  out.drawingOk = await page.evaluate(() => !!document.querySelector('.dw-sheet svg'));
  await page.evaluate(() => window.__app.setWorkspace('design'));
  await idle();
  // STEP 書き出し（形状エンジンでの変換だけ）
  let stepBytes = 0;
  await time('exportStep', async () => { stepBytes = await page.evaluate(async () => { const b = await window.__kcall('export', { ids: [], format: 'step' }); window.__stepBuf = b; return b.byteLength; }); });
  out.stepMB = +(stepBytes / 1048576).toFixed(1);
  // 書き出した STEP を新しいファイルとして取り込む（大きな STEP の取り込み）
  await time('importStep', async () => {
    await page.evaluate(async () => { window.__store.replace({ format: 'kobocad', features: [] }); const f = new File([window.__stepBuf], 'big.step'); window.__stepBuf = null; await window.__app.importFile(f); });
    await page.waitForFunction((n) => window.__app.meshes.length === n, N, { timeout: 900000 }); await idle();
  });
  out.heapImport = await heap();
  await time('saveImport', async () => { await page.evaluate(() => window.__store.flush()); });
  out.saveImportState = await page.evaluate(() => window.__store.saveState);
  // 取り込んだあとに 1 つ足す → 保存（取り込みデータを毎回書き直していないか）
  await time('editAfterImport', async () => { await page.evaluate(() => window.__cmd('板 幅100 奥行100 厚さ10 位置 0,0,-50')); await idle(); });
  await time('saveImport2', async () => { await page.evaluate(() => window.__store.flush()); });
  out.heapEnd = await heap();
  console.log(JSON.stringify(out));
  await browser.close();
})().catch((e) => { console.log('FAILED', e.message); process.exit(1); });
