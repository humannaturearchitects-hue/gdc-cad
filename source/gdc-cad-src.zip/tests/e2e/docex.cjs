// docs/コマンドの使い方.txt に書かれた例（決まった書き方）を 1 つずつ実行し、すべて通るか確かめる
// （AI への説明としてそのまま埋め込まれるので、書いてあるのに動かない例があると AI が失敗する）
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const REPO = process.env.REPO || path.join(__dirname, '../..');
const PORT = process.env.PORT || 4173;
function extract(text) {
  const out = [];
  let on = false;
  for (const raw of text.split('\n')) {
    if (/^■/.test(raw)) { on = !/(開き方|音声|AI に理解|手描き|書き起こす)/.test(raw); continue; }
    if (!on || !/^  \S/.test(raw) || /^  [・※#]/.test(raw)) continue;
    let s = raw.trim().replace(/（[^）]*）/g, '   ').replace(/\s+→.*$/, '');
    const frags = s.split(/\s{3,}|\s*／\s*/).map((x) => x.trim()).filter(Boolean);
    let prev = null;
    for (let f of frags.flatMap((x) => x.split(/\s+\/\s+/))) {
      if (/^(結合|切り取り|交差|新規|対称|反対)$/.test(f) && prev) f = prev.replace(/\S+$/, f);
      prev = f;
      const withOpt = f.replace(/\[([^\]|]*?)(?:\s*\|[^\]]*)?\]/g, '$1').replace(/\s+/g, ' ').trim();
      const noOpt = f.replace(/\[[^\]]*\]/g, '').replace(/\s+/g, ' ').trim();
      for (const c of new Set([noOpt, withOpt])) out.push(c);
    }
  }
  return [...new Set(out)];
}
const FIXTURE = `パラメータ 幅 = 600
板 幅600 奥行400 厚さ20 名前 床板
円柱 直径50 高さ100 位置 100,100,20 名前 柱
板 幅800 奥行300 厚さ20 位置 0,1000,0 名前 棚
穴 上面 Ø8 位置 30,25 570,25 棚
フィレット R5 縦の辺 棚
面取り C2 上の辺 柱
スケッチ XY オフセット -200
長方形 0,0 100,100
押し出し 30
スケッチ XY オフセット -400
円 300,300 直径40
押し出し 50
構築平面 XY オフセット 100
板 幅20 奥行400 厚さ300 位置 0,0,20 名前 側板
板 幅600 奥行400 厚さ20 位置 0,0,320 名前 天板
板 幅560 奥行380 厚さ15 位置 20,0,100 名前 棚板
名前変更 ボディ4 ボディ1
名前変更 ボディ5 ボディ2
スケッチ XZ
長方形 200,0 300,50`;
(async () => {
  const doc = fs.readFileSync(path.join(REPO, 'docs/コマンドの使い方.txt'), 'utf8');
  // AI への説明（src/ai.js）の例（利用者の言葉 → commands）も、そのまま動くか
  const ai = fs.readFileSync(path.join(REPO, 'src/ai.js'), 'utf8');
  const ex = ai.slice(ai.indexOf('## 例'), ai.indexOf('===== コマンドの使い方'));
  const shots = []; let cur = null;
  for (const l of ex.split('\n')) {
    if (/^→ /.test(l)) { if (cur) shots.push(cur); cur = /commands 空/.test(l) ? null : l.slice(2).trim(); }
    else if (cur && l.trim() && !/^[「（]/.test(l)) cur += '\n' + l.trim();
    else { if (cur) shots.push(cur); cur = null; }
  }
  if (cur) shots.push(cur);
  const cmds = process.argv[2] ? [process.argv[2]] : [...extract(doc), ...shots.map((x) => x.replace(/^元に戻す 3$/, '元に戻す'))];
  console.log('few-shot examples:', shots.length);
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 }, acceptDownloads: true })).newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', (d) => d.accept());
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const fx = await page.evaluate((t) => window.__cmd(t), FIXTURE);
  const bad = fx.filter((x) => !x.ok); if (bad.length) { console.log('FIXTURE FAIL', JSON.stringify(bad)); process.exit(1); }
  console.log('fixture bodies:', await page.evaluate(() => window.__app.meshes.map((m) => m.name).join(',')));
  const snap = await page.evaluate(() => ({ s: window.__store.snapshot(), sk: window.__app.cmdline.ctx.sketch }));
  let ok = 0, ng = 0;
  for (const c of cmds) {
    const r = await page.evaluate(async ({ c, snap }) => {
      const app = window.__app, st = window.__store;
      st.project = st.fromSnapshot(snap.s); st.undoStack = []; app.cmdline.ctx = { sketch: snap.sk, lastBody: null };
      await app.rebuild();
      if (app.workspace && app.workspace !== 'design') app.setWorkspace('design');
      const res = await app.cmdline.runText(c);
      return res;
    }, { c, snap });
    const f = r.find((x) => !x.ok);
    if (f || !r.length) { ng++; console.log(`  ✗ ${c} → ${f ? f.msg : '(実行されず)'}`); } else { ok++; console.log(`  ✓ ${c} → ${r.map((x) => x.msg).join(' / ').slice(0, 90)}`); }
  }
  console.log(`docs examples: ${ok}/${ok + ng} ok`);
  await browser.close();
})();
