// スケッチの寸法ツール（D）をクリックで: 線の長さ / 円と線の距離 / 円の直径
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(200); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const ask = async (v) => { const i = page.locator('.inbox.ask input'); console.log('    ask:', await page.locator('.inbox.ask .lbl').innerText()); await i.fill(String(v)); await page.keyboard.press('Enter'); await page.waitForTimeout(300); };
  const ents = () => page.evaluate(() => JSON.stringify(window.__app.sketcher.feature.entities.map(e => e.type === 'line' ? ['line', +e.x1, +e.y1, +e.x2, +e.y2].map(v => typeof v === 'number' ? +v.toFixed(3) : v) : ['circle', +(+e.cx).toFixed(3), +(+e.cy).toFixed(3), +e.d])));
  await page.click('.tool:has-text("スケッチ作成")'); await page.click('#planebar [data-pl=XY]'); await idle();
  await page.keyboard.press('l'); await page.mouse.click(...await scr([0, 0, 0])); await page.mouse.click(...await scr([100, 0, 0])); await page.keyboard.press('Escape'); await page.waitForTimeout(200);
  await page.keyboard.press('c'); await page.mouse.click(...await scr([50, 50, 0])); await page.locator('.inbox input').nth(0).fill('20'); await page.keyboard.press('Enter'); await page.waitForTimeout(250);
  await page.keyboard.press('Escape');
  // D → 線をクリック → 何もない所 → 120
  await page.keyboard.press('d'); await page.waitForTimeout(150);
  await page.mouse.click(...await scr([30, 0, 0])); await page.waitForTimeout(150);
  await page.mouse.click(...await scr([60, -60, 0])); await page.waitForTimeout(200);
  await ask(120);
  // 円の縁をクリック → 線をクリック → 40
  await page.mouse.click(...await scr([60, 50, 0])); await page.waitForTimeout(150);
  await page.mouse.click(...await scr([80, 0, 0])); await page.waitForTimeout(200);
  await ask(40);
  // 円をクリック → 何もない所 → 直径 30
  const c = JSON.parse(await ents()).find(e => e[0] === 'circle');
  await page.mouse.click(...await scr([c[1] + 10, c[2], 0])); await page.waitForTimeout(150);
  await page.mouse.click(...await scr([c[1] + 80, c[2] + 80, 0])); await page.waitForTimeout(200);
  await ask(30);
  console.log('### 寸法ツール（クリック）:', await ents(), 'tool', await page.evaluate(() => window.__app.sketcher.tool));
  await browser.close();
})();
