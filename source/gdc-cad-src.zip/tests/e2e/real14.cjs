// 追加したコマンドをひと通り（体積・数で確認）
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', d => d.accept());
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const meas = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.filter(m => !m.hidden).map(m => m.id), density: 1 }))).list.map(b => `${b.name}:${b.volume.toFixed(1)}`).join(' ; ');
  const run = async (t) => { const r = await page.evaluate((t) => window.__cmd(t), t); for (const x of r) console.log(`  ${x.ok ? '✓' : '✗'} ${x.line} → ${x.msg}`); return r; };
  await run(`板 600x400x20 名前 床板
球 直径50 位置 100,100,60 名前 玉
円柱 直径40 高さ80 位置 500,300,20 名前 柱
シェル 厚さ5 上面 床板
材料 床板 アルミ
柱 材料 鋼
重さ 床板
ミラー 柱 YZ 位置 300
矩形パターン 玉 X方向 3個 間隔120
円形パターン 柱 4個 軸 Z 中心 300,200,0
結合 床板 柱
名前変更 玉 ボール
非表示 ボール
抑制 シェル1
抑制解除 シェル1
分割 床板 YZ 位置 300
干渉チェック
構築平面 XY オフセット 200
スケッチ 構築平面1
多角形 中心 300,200 直径100 6角
長穴 100,100 200,100 幅30
押し出し 10 名前 天板
回転`);
  console.log('### 体積:', await meas());
  console.log('### ボディ:', await page.evaluate(() => window.__app.meshes.map(m => m.name + (m.hidden ? '(非表示)' : '') + (m.material ? '[' + m.material.name + ']' : '')).join(', ')));
  console.log('### 手順:', await page.evaluate(() => window.__store.project.features.map(f => f.name + (f.suppressed ? '(抑制)' : '')).join(', ')));
  await browser.close();
})();
