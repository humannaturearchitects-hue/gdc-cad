const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  let promptAnswers = ['筐体', '側板ユニット'];
  page.on('dialog', d => { if (d.type() === 'prompt') d.accept(promptAnswers.shift() || 'X'); else d.accept(); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  const info = () => page.evaluate(() => ({ comps: (window.__store.project.components||[]).map(c => c.name + (c.parent ? '<' + window.__app.comp(c.parent).name : '')), active: window.__app.comp(window.__store.project.activeComponent)?.name || 'root', bodies: window.__app.meshes.map(m => m.name + '@' + (window.__app.comp(m.component)?.name || 'root') + (m.hidden ? '(hidden)' : '')) }));
  // 新規コンポーネント「筐体」→ 直方体（入るはず）
  await page.click('.tool:has-text("新規コンポーネント")'); await page.waitForTimeout(500);
  await page.click('.tool:has-text("直方体")'); await page.waitForTimeout(600); await page.click('#dialog [data-act="ok"]'); await page.waitForTimeout(1200);
  // サブコンポーネント「側板ユニット」（筐体の下）→ 円柱
  await page.click('[data-comp]:not([data-comp=""])', { button: 'right' }); await page.waitForTimeout(200);
  await page.click('#ctxmenu button:has-text("サブコンポーネントを追加")'); await page.waitForTimeout(600);
  await page.click('.tool:has-text("円柱")'); await page.waitForTimeout(600); await page.fill('#dialog input[data-k=position][data-i="0"]', '200'); await page.click('#dialog [data-act="ok"]'); await page.waitForTimeout(1200);
  // ルートに球（アクティブをルートへ）
  await page.click('[data-activate=""]'); await page.waitForTimeout(800);
  await page.click('.tool:has-text("球")'); await page.waitForTimeout(600); await page.fill('#dialog input[data-k=position][data-i="1"]', '300'); await page.click('#dialog [data-act="ok"]'); await page.waitForTimeout(1200);
  console.log('1', JSON.stringify(await info()));
  // 球をドラッグして「筐体」へ
  await page.dragAndDrop('[data-body]:has-text("ボディ3")', '[data-comp]:has-text("筐体")'); await page.waitForTimeout(1200);
  console.log('2 after drag', JSON.stringify((await info()).bodies));
  // 筐体を非表示 → 中身すべて非表示
  await page.click('[data-comp]:has-text("筐体") [data-ceye]'); await page.waitForTimeout(1200);
  console.log('3 hidden', JSON.stringify((await info()).bodies));
  await page.click('[data-comp]:has-text("筐体") [data-ceye]'); await page.waitForTimeout(1200);
  console.log('3b reshown', JSON.stringify((await info()).bodies), 'viewer visible', await page.evaluate(() => [...window.__app.viewer.bodies.values()].map(b => b.mesh.visible).join(',')));
  await page.click('[data-nav=fit]'); await page.waitForTimeout(500);
  await page.screenshot({ path: 'c_tree.png' });
  // 図面: コンポーネントごと
  await page.click('.ws[data-ws=drawing]'); await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 });
  await page.selectOption('[data-s=mode]', 'comp'); await page.waitForTimeout(2500);
  console.log('4 comp pages', await page.evaluate(() => [...document.querySelectorAll('.dw-pages button')].map(b => b.textContent).join(' | ')));
  await page.click('.ws[data-ws=design]'); await page.waitForTimeout(500);
  // 入れ子 STEP インポート
  await page.click('#menu-file .menu-btn'); await page.click('text=新規'); await page.waitForTimeout(800);
  const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.evaluate(() => { window.__app.importFile(); })]);
  await fc.setFiles('/tmp/claude-0/-home-user/403c1375-c612-5d6e-89c1-cd4054c3a9a6/scratchpad/nested.step');
  await page.waitForFunction(() => window.__app.meshes.length >= 4, null, { timeout: 60000 }); await page.waitForTimeout(800);
  console.log('5 import', JSON.stringify(await info()));
  await page.screenshot({ path: 'c_import.png' });
  await browser.close();
})();
