// iPhone 15（WebKit・タッチ）で、主な流れを指だけで最後まで行えるか
// 使い方: PLAYWRIGHT_BROWSERS_PATH=... node iphone1.cjs [land]   （各行 "✓ ..." が合格。最後に "iphone: n/n"）
const { webkit, devices } = require('playwright');
const PORT = process.env.PORT || 4173;
const land = process.argv[2] === 'land';
const KB = land ? 170 : 300; // キーボードの高さ（模擬）
(async () => {
  const browser = await webkit.launch();
  const d = devices['iPhone 15'];
  const ctx = await browser.newContext({ ...d, ...(land ? { viewport: { width: d.viewport.height, height: d.viewport.width } } : {}), serviceWorkers: 'block' });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message + ' | ' + (e.stack || '').split('\n').slice(0, 2).join(' / ')));
  page.on('dialog', dd => dd.type() === 'prompt' ? dd.accept('sk-ant-test-key') : dd.accept());
  await page.route('https://api.anthropic.com/**', async (route) => {
    const body = JSON.parse(route.request().postData());
    const a = { commands: '板 幅 300 奥行 200 厚さ 15 名前 棚板', explanation: '棚板を作ります。', question: '' };
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ id: 'msg_test', type: 'message', role: 'assistant', model: body.model, stop_reason: 'end_turn', stop_sequence: null, content: [{ type: 'text', text: JSON.stringify(a) }], usage: { input_tokens: 10, output_tokens: 10 } }) });
  });
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.waitForTimeout(800);
  let pass = 0, total = 0;
  const check = (name, ok, info = '') => { total++; if (ok) pass++; console.log(`${ok ? '✓' : '✗'} ${name}${info ? '  ' + info : ''}`); };
  const idle = async () => { await page.waitForFunction(() => !window.__app.buildsRunning && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 }); await page.waitForTimeout(400); };
  const vp = async () => page.locator('#view3d').boundingBox();
  const scr = async (w) => { const b = await vp(); const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [b.x + p[0], b.y + p[1]]; };
  const tapW = async (w) => { const [x, y] = await scr(w); await page.touchscreen.tap(x, y); return [x, y]; };
  const tool = async (t) => {
    const loc = page.locator(`#tools .tool:has-text("${t}")`).first();
    if (await loc.isVisible()) return loc.tap({ timeout: 4000 });
    await page.tap('#tools .tool.more', { timeout: 3000 }); await page.waitForTimeout(200);
    await page.locator(`#msheet button:has-text("${t}")`).first().tap({ timeout: 3000 });
  };
  const touch = (pts) => page.evaluate((pts) => {
    // pts: [[type, id, x, y], ...] を順に canvas へ（2 本指のピンチなど）
    const cv = document.getElementById('view3d');
    for (const [t, id, x, y] of pts) cv.dispatchEvent(new PointerEvent(t, { pointerId: id, pointerType: 'touch', isPrimary: id === 1, clientX: x, clientY: y, button: 0, buttons: t === 'pointerup' ? 0 : 1, bubbles: true, cancelable: true }));
  }, pts);

  // ---- 画面: はみ出し・小さすぎるボタン
  const audit = () => page.evaluate(() => {
    const W = innerWidth, H = innerHeight, bad = [];
    for (const b of document.querySelectorAll('#topbar button, #tools .tool, #navbar button, #timeline button, .tl-item, .dlg-foot .btn, .dlg-head .x')) {
      if (b.closest('.hidden') || b.closest('.m-rest')) continue;
      const r = b.getBoundingClientRect(); if (!r.width || getComputedStyle(b).display === 'none') continue;
      if (r.width < 43.5 || r.height < 43.5) bad.push(`${(b.textContent || b.title || '').trim().slice(0, 8)} ${Math.round(r.width)}x${Math.round(r.height)}`);
      if ((!b.matches('.tl-item') && (r.right > W + 1 || r.left < -1)) || r.bottom > H + 1 || r.top < -1) bad.push(`${(b.textContent || b.title || b.className || '').trim().slice(0, 12)} はみ出し ${Math.round(r.left)},${Math.round(r.top)},${Math.round(r.right)},${Math.round(r.bottom)}`);
    }
    return bad;
  });
  let bad = await audit();
  check('ボタンはすべて 44px 以上・画面内', !bad.length, bad.slice(0, 6).join(', '));
  const tw = await page.evaluate(() => { const t = document.getElementById('tools'); const m = t.querySelector('.tool.more').getBoundingClientRect(), r = t.getBoundingClientRect(); return [t.scrollWidth, t.clientWidth, t.scrollHeight, t.clientHeight, m.top >= r.top - 1 && m.bottom <= r.bottom + 1 && m.right <= r.right + 1]; });
  check('道具の帯がはみ出さない（よく使うものを前に・残りは「その他」）', tw[0] <= tw[1] + 1 && tw[2] <= tw[3] + 1 && tw[4], JSON.stringify(tw));
  // その他シート
  await page.tap('#tools .tool.more'); await page.waitForTimeout(200);
  const sheet = await page.evaluate(() => [...document.querySelectorAll('#msheet .ms-items button')].map(b => b.textContent));
  check('「その他」に検査・書き出しも並ぶ', sheet.includes('3D 書き出し') && sheet.includes('計測') && sheet.includes('面取り'), sheet.length + ' 個');
  await page.tap('#msheet .ms-x'); await page.waitForTimeout(150);
  // 下のナビ: 使用頻度の低いボタン（グリッド・エッジ・視点・選んだものに合わせる）は「⋯」の中
  await page.tap('#navbar .m-navmore'); await page.waitForTimeout(150);
  const np = await page.evaluate(() => [...document.querySelectorAll('#navbar .m-navpop button')].filter(b => b.offsetWidth).map(b => { const r = b.getBoundingClientRect(); return b.textContent + ':' + (r.width >= 43.5 && r.height >= 43.5 && r.top >= 0 && r.right <= innerWidth + 1); }));
  check('ナビの「⋯」に 視点・単独表示 などがあり 44px 以上', np.length >= 4 && np.every(x => x.endsWith('true')) && np.some(x => x.startsWith('視点')), np.join(' '));
  await page.tap('#navbar .m-navmore'); await page.waitForTimeout(150);

  // ---- スケッチ → 長方形 → 寸法
  await tool('スケッチ作成'); await page.waitForTimeout(300);
  await page.tap('#planebar [data-pl=XY]'); await page.waitForTimeout(1200);
  bad = await audit();
  check('スケッチ中もボタンは 44px 以上', !bad.length, bad.slice(0, 6).join(', '));
  await tool('2点長方形'); await tapW([0, 0, 0]); await page.waitForTimeout(300);
  const im = await page.evaluate(() => [...document.querySelectorAll('.inbox input')].map(i => i.getAttribute('inputmode') + '/' + getComputedStyle(i).fontSize));
  check('寸法の入力欄は数字キーボード・16px（拡大されない）', im.length === 2 && im.every(x => x === 'decimal/16px'), im.join(' '));
  await page.tap('.inbox input >> nth=0'); await page.keyboard.type('200');
  check('数字入力の補助ボタン（− + × ÷ 確定）が出る', await page.isVisible('#numbar'));
  await page.tap('.inbox input >> nth=1'); await page.keyboard.type('50');
  await page.tap('#numbar [data-ins="*"]'); await page.keyboard.type('2');
  check('補助ボタンで × を入れられる', (await page.inputValue('.inbox input >> nth=1')) === '50*2');
  await page.tap('.inbox .m-inbox-ok'); await page.waitForTimeout(400);
  let ents = await page.evaluate(() => window.__app.sketcher.feature.entities.map(e => [e.type, e.w, e.h]));
  check('「確定」ボタンで長方形 200×100', JSON.stringify(ents) === '[["rect",200,100]]', JSON.stringify(ents));
  await page.locator('.dimlabel', { hasText: '200' }).first().tap(); await page.waitForTimeout(300);
  const di = page.locator('#overlay > input');
  check('長方形の道具のままでも寸法の数字をタップして変更できる', await di.count() === 1);
  await di.fill('250'); await page.tap('#numbar .ok'); await page.waitForTimeout(400);
  ents = await page.evaluate(() => window.__app.sketcher.feature.entities.map(e => [e.type, e.w, e.h]));
  check('寸法を 250 に変更', JSON.stringify(ents) === '[["rect",250,100]]', JSON.stringify(ents));
  await tool('スケッチを終了'); await page.waitForTimeout(800);

  // ---- 押し出し（ダイアログが出てもモデルが見える）
  await tool('押し出し'); await page.waitForTimeout(800);
  const ins = await page.evaluate(() => window.__mobile.inset());
  check('ダイアログのぶん 3D 表示をずらしている', land ? ins.x > 50 : ins.y > 50, JSON.stringify(ins));
  const vis = await page.evaluate(() => { const v = window.__app.viewer, r = v.canvas.getBoundingClientRect(), d = document.getElementById('dialog').getBoundingClientRect(); const [x, y] = v.toScreen([125, 50, 0]); const X = r.left + x, Y = r.top + y; return { X, Y, free: !(X > d.left && X < d.right && Y > d.top && Y < d.bottom) && X > r.left && X < r.right && Y > r.top && Y < r.bottom }; });
  check('押し出す形がダイアログに隠れない', vis.free, JSON.stringify(vis));
  // キーボード（模擬）: 入力欄・OK が見える範囲に入る
  await page.tap('#dialog input[data-k="distance"]');
  await page.evaluate((KB) => window.__mobile.keyboard(KB), KB);
  await page.waitForTimeout(200);
  const kb = await page.evaluate((KB) => { const H = innerHeight - KB; const ok = document.querySelector('#dialog [data-act=ok]').getBoundingClientRect(); const inp = document.querySelector('#dialog input[data-k=distance]').getBoundingClientRect(); const nb = document.getElementById('numbar').getBoundingClientRect(); return { H, ok: ok.bottom, inp: inp.bottom, nbTop: nb.top, okVisible: ok.bottom <= nb.top + 1 && ok.top >= 0, inpVisible: inp.bottom <= nb.top + 1 && inp.top >= 0 }; }, KB);
  check('キーボードが出ても入力欄と OK が隠れない', kb.okVisible && kb.inpVisible && kb.nbTop <= kb.H, JSON.stringify(kb));
  await page.fill('#dialog input[data-k="distance"]', '40'); await page.waitForTimeout(700);
  await page.evaluate(() => window.__mobile.keyboard(0));
  await page.tap('#dialog [data-act="ok"]'); await idle();
  check('押し出しでボディができる', await page.evaluate(() => window.__app.meshes.length) === 1);

  // ---- ジェスチャ: ピンチ・2 本指移動・ダブルタップで全体表示
  await page.tap('#navbar [data-nav=home]'); await page.waitForTimeout(300);
  const b = await vp(); const cx = b.x + b.width / 2, cy = b.y + b.height * 0.75;
  const z0 = await page.evaluate(() => window.__app.viewer.camera.zoom);
  const steps = []; steps.push(['pointerdown', 1, cx - 30, cy], ['pointerdown', 2, cx + 30, cy]);
  for (let i = 1; i <= 8; i++) steps.push(['pointermove', 1, cx - 30 - i * 10, cy], ['pointermove', 2, cx + 30 + i * 10, cy]);
  steps.push(['pointerup', 1, cx - 110, cy], ['pointerup', 2, cx + 110, cy]);
  await touch(steps); await page.waitForTimeout(200);
  const z1 = await page.evaluate(() => window.__app.viewer.camera.zoom);
  check('2 本指でピンチすると拡大', z1 > z0 * 1.3, `${z0.toFixed(2)} → ${z1.toFixed(2)}`);
  const t0 = await page.evaluate(() => window.__app.viewer.controls.target.toArray().map(v => +v.toFixed(1)));
  const st2 = [['pointerdown', 1, cx - 30, cy], ['pointerdown', 2, cx + 30, cy]];
  for (let i = 1; i <= 8; i++) st2.push(['pointermove', 1, cx - 30, cy - i * 8], ['pointermove', 2, cx + 30, cy - i * 8]);
  st2.push(['pointerup', 1, cx - 30, cy - 64], ['pointerup', 2, cx + 30, cy - 64]);
  await touch(st2); await page.waitForTimeout(200);
  const t1 = await page.evaluate(() => window.__app.viewer.controls.target.toArray().map(v => +v.toFixed(1)));
  check('2 本指で動かすと画面が移動', JSON.stringify(t0) !== JSON.stringify(t1), `${t0} → ${t1}`);
  const sel0 = await page.evaluate(() => window.__app.selection.length);
  await page.touchscreen.tap(b.x + 12, b.y + b.height - 12); await page.waitForTimeout(80); await page.touchscreen.tap(b.x + 12, b.y + b.height - 12); await page.waitForTimeout(400);
  const z2 = await page.evaluate(() => window.__app.viewer.camera.zoom);
  check('何もない所をダブルタップで全体表示', Math.abs(z2 - 1) < 1e-6 && sel0 === 0, 'zoom ' + z2);
  // 長押しメニュー（画面内に収まる）
  const [bx, by] = await scr([125, 50, 40]);
  await touch([['pointerdown', 7, bx, by]]); await page.waitForTimeout(800); await touch([['pointerup', 7, bx, by]]);
  const cm = await page.evaluate(() => { const m = document.getElementById('ctxmenu'); const r = m.getBoundingClientRect(); return { r: [r.top, r.bottom, innerHeight, getComputedStyle(m).maxHeight].map(String).join(','), shown: !m.classList.contains('hidden'), inside: r.bottom <= innerHeight && r.right <= innerWidth && r.top >= 0, n: m.children.length }; });
  check('長押しでメニュー（画面内）', cm.shown && cm.inside, JSON.stringify(cm));
  await page.touchscreen.tap(b.x + 10, b.y + 10); await page.waitForTimeout(200);
  check('メニュー外をタップで閉じる', await page.evaluate(() => document.getElementById('ctxmenu').classList.contains('hidden')));

  // ---- 面にスケッチ → 円 → 穴（2 タップで位置）→ フィレット
  await page.evaluate(() => window.__app.viewer.fit());
  await tool('スケッチ作成'); await page.waitForTimeout(300);
  await tapW([60, 50, 40]); await page.waitForTimeout(1200);
  check('ボディの面にスケッチ', await page.evaluate(() => window.__app.mode === 'sketch' && window.__app.sketcher.feature.plane.type === 'face'));
  await tool('円'); await tapW([60, 50, 40]); await page.waitForTimeout(200);
  await page.tap('.inbox input >> nth=0'); await page.keyboard.type('30'); await page.tap('.inbox .m-inbox-ok'); await page.waitForTimeout(300);
  await tool('スケッチを終了'); await page.waitForTimeout(800);
  await tool('穴'); await page.waitForTimeout(600);
  await tapW([180, 50, 40]); await page.waitForTimeout(800);
  await tapW([180, 50, 40]); await page.waitForTimeout(800);
  await page.tap('#dialog [data-act="ok"]'); await idle();
  check('穴（面をタップして位置）', await page.evaluate(() => window.__store.project.features.some(f => f.type === 'hole')));
  await page.tap('#navbar [data-nav=home]'); await page.waitForTimeout(400);
  await tool('フィレット'); await page.waitForTimeout(600);
  await tapW([250, 0, 20]); await page.waitForTimeout(600);
  const navPos = await page.evaluate(() => { const n = document.getElementById('navbar').getBoundingClientRect(), d = document.getElementById('dialog').getBoundingClientRect(); return n.bottom <= d.top + 1 || n.right <= d.left + 1; });
  check('ダイアログが出ている間はナビが邪魔にならない位置へ', navPos);
  await page.tap('#dialog [data-act="ok"]'); await idle();
  check('フィレット（辺をタップ）', await page.evaluate(() => window.__store.project.features.some(f => f.type === 'fillet') && !window.__app.errors.length), JSON.stringify(await page.evaluate(() => window.__app.errors)));

  // ---- ボディを選んで移動の矢印をドラッグ
  const [sx, sy] = await scr([125, 50, 40]);
  await page.touchscreen.tap(sx, sy); await page.waitForTimeout(100); await page.touchscreen.tap(sx, sy); await page.waitForTimeout(400);
  check('ダブルタップでボディを選択', await page.evaluate(() => window.__app.selection.some(s => s.kind === 'body')));
  await tool('移動/コピー'); await page.waitForTimeout(800);
  const ax = await page.evaluate(() => { const G = window.__app.mvGizmo; if (!G || !G.scr) return null; const q = G.parts.find(p => p.kind === 'axis'); return q && { a: q.a, b: q.b }; });
  if (ax) {
    const bb = await vp(); const x0 = bb.x + (ax.a[0] * 0.3 + ax.b[0] * 0.7), y0 = bb.y + (ax.a[1] * 0.3 + ax.b[1] * 0.7);
    const dx = ax.b[0] - ax.a[0], dy = ax.b[1] - ax.a[1], L = Math.hypot(dx, dy) || 1;
    const mv = [['pointerdown', 11, x0, y0]]; for (let i = 1; i <= 10; i++) mv.push(['pointermove', 11, x0 + dx / L * 8 * i, y0 + dy / L * 8 * i]); mv.push(['pointerup', 11, x0 + dx / L * 80, y0 + dy / L * 80]);
    await page.evaluate((pts) => { const cv = document.getElementById('view3d'); for (const [t, id, x, y] of pts) cv.dispatchEvent(new PointerEvent(t, { pointerId: id, pointerType: 'touch', isPrimary: true, clientX: x, clientY: y, button: 0, buttons: t === 'pointerup' ? 0 : 1, bubbles: true, cancelable: true })); }, mv);
    await page.waitForTimeout(500);
  }
  const tr = await page.evaluate(() => window.__app.dialog.active && window.__app.dialog.active.draft.translate);
  check('矢印を指でドラッグして移動量が入る', !!ax && tr && tr.some(v => Math.abs(parseFloat(v)) > 5), JSON.stringify(tr));
  await page.tap('#dialog [data-act="ok"]'); await idle();

  // ---- タイムライン: タップでメニュー、ダブルタップで編集 → 寸法変更
  const ext = page.locator('#timeline .tl-item').nth(1);
  await ext.tap(); await page.waitForTimeout(700);
  const menu = await page.evaluate(() => [...document.querySelectorAll('#ctxmenu:not(.hidden) button')].map(b => b.textContent));
  check('タイムラインをタップでメニュー（編集・削除など）', menu[0] === '編集', menu.join('|'));
  await page.locator('#ctxmenu button', { hasText: '編集' }).tap(); await page.waitForTimeout(800);
  check('メニューの「編集」で押し出しを開く', await page.evaluate(() => window.__app.dialog.isOpen && window.__app.dialog.active.type === 'extrude'));
  await page.tap('#dialog input[data-k="distance"]'); await page.fill('#dialog input[data-k="distance"]', '60'); await page.waitForTimeout(600);
  await page.tap('#dialog [data-act="ok"]'); await idle();
  const bz = await page.evaluate(async () => (await window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 })).list[0].bounds);
  check('タイムラインから厚さを 60 に変更', Math.abs(bz[1][2] - bz[0][2] - 60) < 0.01, JSON.stringify(bz));
  const bb2 = await ext.boundingBox();
  await page.touchscreen.tap(bb2.x + 20, bb2.y + 20); await page.waitForTimeout(90); await page.touchscreen.tap(bb2.x + 20, bb2.y + 20); await page.waitForTimeout(700);
  check('タイムラインをダブルタップでも編集', await page.evaluate(() => window.__app.dialog.isOpen && window.__app.dialog.active.type === 'extrude'));
  await page.tap('#dialog [data-act="cancel"]'); await page.waitForTimeout(300);

  // ---- ダイアログを小さくする
  await tool('フィレット'); await page.waitForTimeout(500);
  await page.tap('#dialog .dlg-head span:not(.m-grip)'); await page.waitForTimeout(200);
  const mini = await page.evaluate(() => ({ min: document.getElementById('dialog').classList.contains('m-min'), h: document.getElementById('dialog').getBoundingClientRect().height }));
  check('ダイアログの見出しをタップで小さくできる', mini.min && mini.h < 160, JSON.stringify(mini));
  await page.tap('#dialog [data-act="cancel"]'); await page.waitForTimeout(300);

  // ---- ファイル一覧 → 図面 → 書き出し → AI
  await page.tap('#menu-file .menu-btn'); await page.waitForTimeout(200);
  await page.locator('#menu-file .menu-pop button', { hasText: 'ファイル一覧' }).tap(); await page.waitForTimeout(800);
  check('ファイル一覧が開く', await page.locator('#dialog .lib-card').count() >= 1);
  await page.locator('#dialog .btn', { hasText: '閉じる' }).last().tap(); await page.waitForTimeout(300);
  await page.tap('.ws[data-ws=drawing]');
  await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 }); await page.waitForTimeout(500);
  const dw = await page.evaluate(() => { const s = document.querySelector('.dw-sheet svg').getBoundingClientRect(); return s.width > 100 && s.height > 60 && s.right <= innerWidth + 1; });
  check('図面が画面内に表示される', dw);
  await page.tap('.ws[data-ws=design]'); await page.waitForTimeout(500);
  await tool('3D 書き出し'); await page.waitForTimeout(600);
  const exp = await page.locator('#dialog:not(.hidden)').count();
  check('「その他」から 3D 書き出しを開ける', exp === 1);
  await page.locator('#dialog [data-act=cancel], #dialog .x').first().tap(); await page.waitForTimeout(300);
  await tool('AI に頼む'); await page.waitForTimeout(500);
  await page.tap('#cmd-in'); await page.fill('#cmd-in', '棚板を300×200、厚さ15で');
  await page.tap('#cmd-run'); await page.waitForTimeout(800);
  await page.waitForFunction(() => window.__app.meshes.length >= 2, null, { timeout: 30000 }).catch(() => {});
  await idle();
  check('AI に頼む（模擬応答）でボディが増える', await page.evaluate(() => window.__app.meshes.some(m => m.name === '棚板')));
  bad = await audit();
  check('AI 画面でもボタンは 44px 以上・画面内', !bad.length, bad.slice(0, 6).join(', '));
  const sc = await page.evaluate(() => ({ x: scrollX, y: scrollY, s: visualViewport ? visualViewport.scale : 1 }));
  check('ページ自体はスクロール・拡大していない', sc.x === 0 && sc.y === 0 && sc.s === 1, JSON.stringify(sc));
  console.log(`iphone${land ? ' (横)' : ''}: ${pass}/${total}`);
  await browser.close();
})();
