const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1500, height: 900 }, acceptDownloads: true });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', d => d.accept());
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  const vp = await page.locator('#view3d').boundingBox();
  await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
  await page.waitForFunction(() => window.__app.meshes.length > 0, null, { timeout: 30000 });
  await page.waitForTimeout(800);
  // save
  const [d] = await Promise.all([page.waitForEvent('download'), page.keyboard.press('Control+s')]);
  await d.saveAs('dl/roundtrip.kcad');
  // undo / redo: delete last feature then undo
  const n0 = await page.evaluate(() => window.__store.project.features.length);
  await page.evaluate(() => window.__store.commit(p => p.features.pop()));
  await page.waitForTimeout(800);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(1200);
  const n1 = await page.evaluate(() => window.__store.project.features.length);
  console.log('undo restores features', n0 === n1, n0, n1);
  // measure: two plate corners on top face
  await page.click('[data-nav=home]'); await page.waitForTimeout(400);
  await page.click('.tool:has-text("計測")');
  for (const p of [[50,100,20],[250,100,20]]) { const s = await page.evaluate((p) => window.__app.viewer.toScreen(p), p); await page.mouse.click(vp.x + s[0], vp.y + s[1]); await page.waitForTimeout(200); }
  console.log('measure:', await page.evaluate(() => document.querySelector('.measure-label')?.textContent));
  await page.keyboard.press('Escape');
  // sketch on face: right click top face then menu
  const tp = await page.evaluate(() => window.__app.viewer.toScreen([230, 40, 20]));
  await page.mouse.click(vp.x + tp[0], vp.y + tp[1], { button: 'right' });
  await page.waitForTimeout(300);
  console.log('ctx items', await page.evaluate(() => [...document.querySelectorAll('#ctxmenu button')].map(b=>b.textContent).join(' | ') + ' / class=' + document.getElementById('ctxmenu').className));
  await page.click('#ctxmenu button:has-text("この面にスケッチを作成")');
  await page.waitForTimeout(1500);
  const sk = await page.evaluate(() => ({ mode: window.__app.mode, plane: window.__app.sketcher.feature?.plane }));
  console.log('sketch on face', JSON.stringify(sk));
  await page.screenshot({ path: 'face_sketch.png' });
  await page.click('.tool:has-text("スケッチを終了")'); await page.waitForTimeout(800);
  // open saved file
  const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.evaluate(() => { window.__app.openDoc(); })]);
  await fc.setFiles('dl/roundtrip.kcad');
  await page.waitForTimeout(2500);
  console.log('reopened', JSON.stringify(await page.evaluate(() => ({ name: window.__store.project.name, f: window.__store.project.features.length, bodies: window.__app.meshes.length, err: window.__app.errors.length }))));
  await browser.close();
})();
