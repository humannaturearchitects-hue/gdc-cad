// job 担当が見つけた点: キャビネットの一括伸縮・立っている面の穴が面からはみ出さない・1400px の道具バー・書き出しの名前
// 使い方: テストフォルダにコピーし、ポートを合わせて node edit_job.cjs（IPHONE=1 で iPhone 15、一括伸縮のみ）
//  期待: "cabinet ok" "hole near edge stays inside ok" "off-face click refused ok" "toolbar fits ok" "export name: 収納棚.step"
const { open } = require('./ux_common.cjs');
(async () => {
  const iphone = !!process.env.IPHONE;
  const { browser, page } = await open({ iphone, promptValue: '収納棚' });
  const log = (...a) => console.log(...a);
  const T = 18;
  const boards = [
    ['側板L', 18, 450, 900, '0,0,0'], ['側板R', 18, 450, 900, '1782,0,0'], ['天板', 1764, 450, 18, '18,0,882'], ['底板', 1764, 450, 18, '18,0,0'],
    ['棚板', 1764, 432, 18, '18,0,441'], ['仕切り', 18, 432, 864, '891,0,18'], ['背板', 1764, 9, 864, '18,441,18'],
  ];
  for (const [n, w, d, h, p] of boards) await page.cmd(`板 幅${w} 奥行${d} 厚さ${h} 位置 ${p} 名前 ${n}`);
  const bb = () => page.evaluate(async () => { const r = await window.__kcall('measure', { ids: window.__app.meshes.map((m) => m.id) }); const o = {}; for (const b of r.list) o[b.name] = [+b.bounds[0][0].toFixed(2), +b.bounds[1][0].toFixed(2), +(b.bounds[1][2] - b.bounds[0][2]).toFixed(2)]; return o; });
  // すべて選んで、幅を 1500 に
  await page.evaluate(() => { window.__app.selection = window.__app.meshes.map((m) => ({ kind: 'body', bodyId: m.id })); window.__app.reapplyHighlights(); window.__app.ux.propsOn = true; window.__app.ux.updateProps(); });
  await page.waitForFunction(() => document.querySelector('#ux-props .uxp-head span')?.textContent.includes('7 個'));
  await page.waitForTimeout(300);
  log('multi label:', await page.locator('#ux-props .uxp-ro').innerText());
  const w = page.locator('#ux-props input[data-size="0"]'); await w.fill('1500'); await w.press('Enter'); await page.waitForTimeout(600); await page.idle(); await page.waitForTimeout(400);
  const b = await bb();
  log(JSON.stringify(b));
  const ok = JSON.stringify(b['側板L']) === '[0,18,900]' && JSON.stringify(b['側板R']) === '[1482,1500,900]' && JSON.stringify(b['天板']) === '[18,1482,18]' && JSON.stringify(b['棚板']) === '[18,1482,18]' && JSON.stringify(b['仕切り']) === '[741,759,864]' && JSON.stringify(b['背板']) === '[18,1482,864]';
  log(ok ? 'cabinet ok' : 'cabinet NG');
  log('one undo:', await page.evaluate(async () => { window.__store.undo(); await new Promise((r) => setTimeout(r, 300)); return null; }) ?? '', JSON.stringify((await (async () => { await page.idle(); return bb(); })())['側板R']));
  if (!iphone) {
    // 立っている面（側板L の左面 X=0）に穴: 端（Y 450）の近くをクリックしても面の中に収まる
    await page.evaluate(() => { window.__app.selection = []; window.__app.reapplyHighlights(); window.__app.ux.propsOn = false; window.__app.ux.updateProps(); });
    await page.evaluate(() => window.__app.viewer.setView([-1, 0, 0], [0, 0, 1], false)); await page.evaluate(() => window.__app.viewer.fit()); await page.waitForTimeout(300);
    await page.click3([0, 200, 400]);
    await page.keyboard.press('h'); await page.waitForTimeout(1500); await page.idle();
    log('placing', await page.evaluate(() => window.__app.holePlacing()));
    const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [page.vp.x + p[0], page.vp.y + p[1]]; };
    // 面の端（Y=450）から 6mm 内側（穴 Ø10 は収まる）→ 端の点に吸着しない
    await page.mouse.move(...await scr([0, 444, 600])); await page.waitForTimeout(250);
    const lab = await page.locator('.hcur').innerText().catch(() => '');
    await page.mouse.click(...await scr([0, 444, 600])); await page.idle();
    const rows = await page.evaluate(() => window.__app.dialog.active.draft.pos);
    const y = rows.length ? +rows[rows.length - 1][0] : NaN;
    log('label', lab.replace(/\s+/g, ' '), 'rows', JSON.stringify(rows));
    log(rows.length && !/はみ出/.test(lab) ? 'hole near edge stays inside ok' : 'NG');
    // 面の外（Y=-1）をクリック → 置かない
    const n0 = rows.length;
    await page.mouse.move(...await scr([0, -1, 300])); await page.waitForTimeout(250);
    log('off label', (await page.locator('.hcur').innerText().catch(() => '(none)')).replace(/\s+/g, ' '));
    await page.mouse.click(...await scr([0, -1, 300])); await page.waitForTimeout(200);
    const n1 = (await page.evaluate(() => window.__app.dialog.active.draft.pos)).length;
    const tm = await page.locator('#toast').innerText();
    log(n1 === n0 && /はみ出す/.test(tm) ? 'off-face click refused ok' : 'NG', tm);
    await page.keyboard.press('Escape'); await page.waitForTimeout(300);
    // 道具バー: 右端が切れない（入りきらない道具は「その他」）
    const fit = await page.evaluate(() => { const el = document.getElementById('tools'); const r = el.getBoundingClientRect(); const vis = [...el.querySelectorAll('.tool')].filter((b) => b.offsetParent); const last = vis[vis.length - 1].getBoundingClientRect(); return { sw: el.scrollWidth, cw: el.clientWidth, lastRight: Math.round(last.right), right: Math.round(r.right), more: !!el.querySelector('.ed-more'), talk: vis.some((b) => b.textContent.includes('話す')) }; });
    log(JSON.stringify(fit), fit.sw <= fit.cw + 1 && fit.lastRight <= fit.right && fit.talk ? 'toolbar fits ok' : 'NG');
    if (fit.more) { await page.locator('#tools .ed-more button').click(); await page.waitForTimeout(200); log('more menu:', (await page.locator('#ctxmenu').innerText()).replace(/\n/g, ' | ')); await page.mouse.click(700, 500); }
    // 書き出し（保存前）: 名前を聞いて、その名前のファイルに
    await page.evaluate(() => { const o = HTMLAnchorElement.prototype.click; HTMLAnchorElement.prototype.click = function () { window.__lastDl = this.download; return o.call(this); }; });
    await page.evaluate(() => window.__app.export3D('step', [])); await page.waitForTimeout(500);
    log('export name:', await page.evaluate(() => window.__lastDl), '| project', await page.evaluate(() => window.__store.project.name));
  }
  await browser.close();
})();
