// 計算エンジンが応答しないとき: 経過時間と「中止して再起動」が出て、押すと復帰する
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
  await page.waitForFunction(() => window.__app.meshes.length > 0); await page.waitForTimeout(800);
  await page.evaluate(() => { window.__kcall('hangTest', { ms: 600000 }).catch(() => {}); window.__app.rebuild(); });
  await page.waitForTimeout(10500);
  console.log('busy text:', await page.locator('#busy').innerText());
  await page.click('#busy-act');
  await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && window.__app.meshes.length > 0, null, { timeout: 90000 });
  console.log('recovered ok, bodies', await page.evaluate(() => window.__app.meshes.length), 'toast', await page.evaluate(() => [...document.querySelectorAll('.toast')].map(t => t.textContent).join('|')));
  await browser.close();
})();
