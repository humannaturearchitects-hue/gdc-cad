const { chromium, webkit, devices } = require('playwright');
(async () => {
  for (const mob of [process.argv[2] === 'phone']) {
    const browser = await (mob ? webkit : chromium).launch(mob ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
    const ctx = await browser.newContext(mob ? { ...devices['iPhone 14'] } : { viewport: { width: 1400, height: 850 } });
    const page = await ctx.newPage();
    page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
    await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
    await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
    await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
    await page.waitForFunction(() => window.__app.meshes.length > 0); await page.waitForTimeout(800);
    await page.click('.tool:has-text("スケッチ作成")'); await page.waitForTimeout(600);
    await page.screenshot({ path: mob ? 'pb_phone.png' : 'pb_desk.png' });
    await page.click('#planebar [data-pl=XZ]'); await page.waitForTimeout(1500);
    console.log(mob ? 'phone' : 'desk', 'after XZ button:', JSON.stringify(await page.evaluate(() => [window.__app.mode, window.__app.sketcher.feature?.plane?.name])));
    await browser.close();
  }
})();
