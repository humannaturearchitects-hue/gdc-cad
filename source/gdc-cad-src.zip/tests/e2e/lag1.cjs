// スケッチ作成の待ち時間を計測（CPU を 4 倍遅くして一般的なノート PC を想定）
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  const cdp = await page.context().newCDPSession(page);
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear());
  if (process.argv[2] === 'slow') await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
  const ts = Date.now(); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 120000 });
  const tStart = Date.now() - ts;
  const to = Date.now();
  await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く');
  await page.waitForFunction(() => window.__app.meshes.length > 0, null, { timeout: 60000 });
  console.log('startup', tStart, 'ms | open sample', Date.now() - to, 'ms');
  await page.waitForTimeout(800);
  // 計測用: ビルド開始/終了のログ
  await page.evaluate(() => {
    window.__log = []; const a = window.__app; const orig = a.rebuild.bind(a);
    a.rebuild = async (o = {}) => { const t = performance.now(); window.__log.push(['build start', JSON.stringify(o).slice(0, 40), Math.round(t)]); const r = await orig(o); window.__log.push(['build end', Math.round(performance.now() - t) + 'ms', Math.round(performance.now())]); return r; };
  });
  const vp = await page.locator('#view3d').boundingBox();
  const t0 = Date.now();
  await page.click('.tool:has-text("スケッチ作成")');
  const pos = await page.evaluate(() => { const v = window.__app.viewer; const m = v.planeMeshes.find(p=>p.userData.name==='XY'); const s=m.scale.x; return v.toScreen([s*0.3, -s*0.3, 0]); });
  const t1 = Date.now();
  await page.mouse.click(vp.x + pos[0], vp.y + pos[1]);
  await page.waitForFunction(() => window.__app.sketcher.active, null, { timeout: 60000 });
  const t2 = Date.now();
  await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 });
  const t3 = Date.now();
  console.log(process.argv[2] || 'normal', '| plane click → sketch ready', t2 - t1, 'ms | → busy gone', t3 - t1, 'ms');
  console.log(JSON.stringify(await page.evaluate(() => window.__log)));
  // スケッチ終了
  const t4 = Date.now();
  await page.click('.tool:has-text("スケッチを終了")');
  await page.waitForFunction(() => !window.__app.sketcher.active && document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 });
  console.log('finish sketch →', Date.now() - t4, 'ms');
  await browser.close();
})();
