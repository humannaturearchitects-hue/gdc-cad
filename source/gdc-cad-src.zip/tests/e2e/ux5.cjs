// ユーザー操作どおり: 新規 → スケッチ作成 → XY クリック → 長方形をクリックで描く → 終了 → 押し出し → OK
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') console.log('console.' + m.type() + ': ' + m.text().slice(0, 300)); });
  const URL = process.env.PORTABLE ? 'file:///home/user/kobocad/dist-portable/' + encodeURIComponent('GDC GOOD DESIGN CAD.html') : 'http://127.0.0.1:4173/'; await page.goto(URL); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  if (process.argv[2] === 'sample') { await page.click('#menu-file .menu-btn'); await page.click('text=サンプルを開く'); await page.waitForFunction(() => window.__app.meshes.length > 0); await page.waitForTimeout(800); }
  const vp = await page.locator('#view3d').boundingBox();
  const st = async (l) => console.log(l, JSON.stringify(await page.evaluate(() => ({ mode: window.__app.mode, sk: window.__app.sketcher.active, busy: document.getElementById('busy').className, msg: document.getElementById('busy-msg').textContent, feats: window.__store.project.features.map(f => f.type + (f.entities ? ':' + f.entities.length : '')), bodies: window.__app.meshes.length, dlg: document.getElementById('dialog').className, toast: (document.querySelector('.toast') || {}).textContent }))));
  if (process.argv[4] === 'comp') { await page.evaluate(() => window.__store.commit(p => { p.components = [{ id: 'C1', name: 'コンポーネント1', parent: null }]; p.activeComponent = 'C1'; })); await page.waitForTimeout(800); await st('after comp'); }
  await page.click('.tool:has-text("スケッチ作成")');
  const pos = await page.evaluate(() => { const v = window.__app.viewer; const m = v.planeMeshes.find(p=>p.userData.name==='XY'); const s=m.scale.x; return v.toScreen([s*0.5, s*0.5, 0]); });
  await page.mouse.click(vp.x + pos[0], vp.y + pos[1]);
  await page.waitForTimeout(1500); await st('after plane');
  await page.click('.tool:has-text("長方形")').catch(e => console.log('no rect tool', e.message));
  const cx = vp.x + vp.width / 2, cy = vp.y + vp.height / 2;
  await page.mouse.click(cx - 120, cy - 80); await page.waitForTimeout(200);
  await page.mouse.click(cx + 120, cy + 80); await page.waitForTimeout(500);
  await st('after rect');
  if (process.argv[3] === 'key') await page.keyboard.press('e'); else await page.click('.tool:has-text("押し出し")'); await page.waitForTimeout(1500); await st('after E');
  console.log('dialog text', (await page.locator('#dialog').innerText()).replace(/\s+/g, ' ').slice(0, 300));
  await page.screenshot({ path: 'ux1_' + (process.argv[2] || 'new') + '.png' });
  await page.mouse.click(cx, cy); await page.waitForTimeout(1500); await st('after profile click'); console.log('dlg2', (await page.locator('#dialog').innerText()).replace(/\s+/g,' ').slice(80,260));
  const ok = page.locator('#dialog button:has-text("OK")');
  if (await ok.count()) await ok.first().click();
  await page.waitForTimeout(3000); await st('after OK'); console.log('tree', (await page.locator('#browser').innerText()).replace(/\\s+/g,' ')); await page.screenshot({path:'ux5.png'}); console.log('errors', JSON.stringify(await page.evaluate(() => window.__app.errors)));
  await browser.close();
})();
