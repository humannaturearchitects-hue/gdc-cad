// 穴の配置（直感＋正確）: カーソルに穴が付いてくる・角/中点/中心に吸着・ガイド・クリックで置く・ドラッグで移動・数値で微調整
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(250); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const rows = () => page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.pos));
  const cur = () => page.locator('.hcur').innerText().catch(() => '(none)');
  await page.click('.tool:has-text("スケッチ作成")'); await page.click('#planebar [data-pl=XY]'); await idle();
  await page.keyboard.press('r'); await page.mouse.click(...await scr([0, 0, 0])); await page.waitForTimeout(150);
  { const a = page.locator('.inbox input'); await a.nth(0).fill('300'); await a.nth(1).fill('200'); await page.keyboard.press('Enter'); await page.waitForTimeout(250); }
  await page.keyboard.press('e'); await idle(); await page.fill('#dialog input[data-k="distance"]', '10'); await idle(); await page.click('#dialog [data-act="ok"]'); await idle();
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  await page.keyboard.press('h'); await idle();
  await page.mouse.click(...await scr([150, 100, 10])); await idle(); await page.waitForTimeout(500);
  console.log('placing?', await page.evaluate(() => window.__app.holePlacing()));
  // カーソルを (31.3, 24.6) に → 刻み吸着
  await page.mouse.move(...await scr([31.3, 24.6, 10])); await page.waitForTimeout(200);
  console.log('hover near (31,25):', await cur());
  await page.screenshot({ path: 'real10_hover.png' });
  // 辺の中点 (150, 0) の近く → 中点に吸着
  await page.mouse.move(...await scr([151.5, 1.2, 10])); await page.waitForTimeout(200);
  console.log('hover near mid:', await cur());
  // クリックで 1 つ目（既定の行を置き換え）: (30,25) 付近
  await page.mouse.click(...await scr([30.4, 25.3, 10])); await idle();
  console.log('rows after click1', await rows());
  // 2 つ目: (270, 25.3) → 穴 1 と横（Y）がそろう
  await page.mouse.move(...await scr([270.2, 26.1, 10])); await page.waitForTimeout(200);
  console.log('hover align:', await cur());
  await page.screenshot({ path: 'real10_align.png' });
  await page.mouse.click(...await scr([270.2, 26.1, 10])); await idle();
  console.log('rows after click2', await rows());
  // 穴 2 をドラッグして (270, 175) へ
  const p2 = await scr([270, 25, 10]);
  await page.mouse.move(...p2); console.log('  rowAt', await page.evaluate(([x, y]) => [window.__app.hpRowAt({ clientX: x, clientY: y }), window.__app.holePlacing(), document.elementFromPoint(x, y).id || document.elementFromPoint(x, y).className], p2)); await page.mouse.down(); console.log('  dragRow', await page.evaluate(() => window.__app.hpDragRow));
  const q = await scr([270, 174.2, 10]);
  for (let i = 1; i <= 8; i++) { await page.mouse.move(p2[0] + (q[0] - p2[0]) * i / 8, p2[1] + (q[1] - p2[1]) * i / 8); await page.waitForTimeout(40); }
  await page.mouse.up(); await idle();
  console.log('rows after drag', await rows());
  // 数値で微調整（表）
  await page.fill('#dialog [data-pt="1"][data-c="1"]', '172.5'); await idle();
  console.log('rows after typing', await rows());
  await page.click('#dialog [data-act="ok"]'); await idle();
  const m = (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list[0];
  console.log('### 体積', Math.round(m.volume), '（期待 600000 - 2×785.4 = 598429）errors', JSON.stringify(await page.evaluate(() => window.__app.errors.map(e => e.message))));
  await browser.close();
})();
