const { open } = require('./ux_common.cjs');
(async () => {
  const { browser, page } = await open();
  await page.cmd(`板 幅600 奥行400 厚さ20 名前 床板`);
  const feats = () => page.evaluate(() => window.__store.project.features.map(f => f.type).join(','));
  const sel = async (n) => page.evaluate((n) => { const id = window.__app.meshes.find(m=>m.name===n).id; window.__app.ux.setSelection([{kind:'body',bodyId:id}]); }, n);
  await sel('床板'); await page.waitForTimeout(600);
  const x = page.locator('#ux-props input[data-pos="0"]'); await x.fill('100'); await x.press('Enter'); await page.idle();
  await page.waitForTimeout(600);
  const x2 = page.locator('#ux-props input[data-pos="0"]'); await x2.fill('150'); await x2.press('Enter'); await page.idle();
  console.log('2 moves merged:', await feats(), JSON.stringify(await page.evaluate(() => window.__store.project.features.at(-1).translate)));
  await page.keyboard.press('Control+z'); await page.idle(); console.log('undo1', JSON.stringify(await page.evaluate(() => window.__store.project.features.at(-1).translate)));
  await page.keyboard.press('Control+z'); await page.idle(); console.log('undo2', await feats());
  await page.keyboard.press('Control+y'); await page.idle(); console.log('redo', await feats());
  // paste then undo
  await sel('床板'); await page.keyboard.press('Control+d'); await page.waitForTimeout(800);
  await page.locator('#dialog input[data-k="translate"][data-i="1"]').fill('500');
  await page.locator('#dialog button:has-text("OK")').click(); await page.idle();
  console.log('dup', await page.bodies());
  await page.keyboard.press('Control+z'); await page.idle(); console.log('undo dup', await page.bodies(), 'sel', await page.sel());
  // ctrl+z with dialog open
  await page.keyboard.press('m'); await page.waitForTimeout(400);
  await page.keyboard.press('Control+y'); await page.idle(); console.log('redo with dialog', await page.bodies(), 'dialog', await page.evaluate(() => !!window.__app.dialog.active));
  // sketch copy paste
  await page.cmd('スケッチ XY'); 
  await page.evaluate(() => { const f = window.__store.project.features.findLast(f=>f.type==='sketch'); window.__app.enterSketch(f.id); }); await page.waitForTimeout(800);
  await page.evaluate(() => window.__store.commit(p => p.features.findLast(f=>f.type==='sketch').entities.push({ id:'eA', type:'circle', cx:100, cy:100, d:50 }), { silent: true }));
  await page.evaluate(() => window.__app.sketcher.redraw());
  await page.keyboard.press('Control+a'); await page.keyboard.press('Control+c'); await page.keyboard.press('Control+v'); await page.waitForTimeout(400);
  console.log('sketch ents', await page.evaluate(() => JSON.stringify(window.__app.sketcher.feature.entities.map(e => [e.type, e.cx, e.cy]))), 'sel', await page.evaluate(() => [...window.__app.sketcher.selected].join()));
  await page.keyboard.press('Control+z'); await page.waitForTimeout(400);
  console.log('sketch undo', await page.evaluate(() => window.__app.sketcher.feature.entities.length));
  await browser.close();
})();
