// 新しい版が出たとき: 「新しい版があります → 更新する」で切り替わり、作業は残る。勝手には切り替わらない
// 期待: すべての行が "ok" で終わる。dist/sw.js を一時的に書き換えて新しい版を作る（最後に元に戻す）
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const URL = 'http://127.0.0.1:4173/';
const SW = path.join(process.env.REPO || path.join(__dirname, '../..'), 'dist/sw.js');
(async () => {
  const orig = fs.readFileSync(SW, 'utf8');
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 } });
  const page = await ctx.newPage();
  const ok = (label, cond, extra = '') => console.log(`${label}: ${extra} ${cond ? 'ok' : 'NG'}`);
  const ready = () => page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 90000 });
  try {
    await page.goto(URL);
    await page.evaluate(async () => { for (const r of await navigator.serviceWorker.getRegistrations()) await r.unregister(); localStorage.clear(); });
    await page.reload(); await ready();
    await page.evaluate(() => navigator.serviceWorker.ready);
    await page.reload(); await ready();
    ok('controlled by sw', await page.evaluate(() => !!navigator.serviceWorker.controller));
    await page.evaluate(() => window.__cmd('板 幅600 奥行400 厚さ20 名前 床板')); await page.waitForTimeout(1500);
    fs.writeFileSync(SW, orig.replace(/self.__BUILD__ = "([^"]+)"/, 'self.__BUILD__ = "$1x"'));
    await page.evaluate(() => window.__checkUpdate());
    const bar = page.locator('#safety-bars [data-key="update"]');
    await bar.waitFor({ timeout: 30000 });
    ok('update offered', (await bar.innerText()).includes('新しい版があります'));
    const before = await page.evaluate(() => navigator.serviceWorker.controller.scriptURL + '|' + performance.timeOrigin);
    await page.waitForTimeout(1500);
    ok('not switched without consent', await page.evaluate(async () => !!(await navigator.serviceWorker.getRegistration()).waiting));
    await Promise.all([page.waitForNavigation({ timeout: 30000 }), bar.locator('button', { hasText: '更新する' }).click()]);
    await ready(); await page.waitForTimeout(800);
    const after = await page.evaluate(() => navigator.serviceWorker.controller.scriptURL + '|' + performance.timeOrigin);
    ok('reloaded on new version', before !== after && await page.evaluate(async () => !(await navigator.serviceWorker.getRegistration()).waiting));
    ok('work kept', await page.evaluate(() => window.__store.project.features.length === 1));
    ok('bar gone', !(await page.locator('#safety-bars [data-key="update"]').count()));
  } finally { fs.writeFileSync(SW, orig); await browser.close(); }
})();
