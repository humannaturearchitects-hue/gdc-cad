// 長く使ったときのメモリの増え方（元に戻す数百回・ファイルの切り替えの繰り返し）
//   node perf_long.cjs        最後の行 "memory ok" が出れば合格
// ・部品 40 個のモデルで 300 回直す → 300 回元に戻す → 300 回やり直す
// ・STEP を取り込んだファイルと普通のファイルを 30 回切り替える（形状エンジンのメモリが目安を超えたら、切り替えのときに作り直して片付ける）
// JS（画面側）と形状エンジン（WASM）のメモリを、最初と最後で比べる
const { chromium } = require('playwright');
const PORT = process.env.PORT || 4173;
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--js-flags=--expose-gc'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Performance.enable');
  await page.goto(`http://127.0.0.1:${PORT}/`); await page.evaluate(() => { localStorage.clear(); indexedDB.deleteDatabase('gdc-cad'); }); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  const idle = (t = 120000) => page.waitForFunction(() => !window.__app.buildsRunning && document.getElementById('busy').classList.contains('hidden'), null, { timeout: t });
  const mem = async () => {
    await cdp.send('HeapProfiler.collectGarbage');
    const m = await cdp.send('Performance.getMetrics');
    const s = await page.evaluate(() => window.__kcall('stats'));
    return { js: +(m.metrics.find((x) => x.name === 'JSHeapUsedSize').value / 1048576).toFixed(1), wasm: Math.round(s.wasmBytes / 1048576), imports: s.imports, undo: await page.evaluate(() => window.__store.undoStack.length) };
  };
  const lines = [];
  for (let i = 0; i < 40; i++) lines.push(`板 幅300 奥行200 厚さ15 位置 ${(i % 8) * 400},${Math.floor(i / 8) * 300},0 名前 P${i}`, `穴 上面 Ø6 位置 20,20 280,20 280,180 20,180 P${i}`);
  await page.evaluate((t) => window.__cmd(t), lines.join('\n'));
  await idle();
  await page.evaluate(() => window.__store.flush());
  const m0 = await mem();
  console.log('start', JSON.stringify(m0));
  // 300 回直す（最後の板の幅を変える）
  let t0 = Date.now();
  for (let k = 0; k < 300; k++) {
    await page.evaluate((k) => { const f = window.__store.project.features; window.__store.commit(() => { f[f.length - 2].w = String(300 + (k % 50)); }); }, k);
    if (k % 25 === 24) await idle();
  }
  await idle();
  const tEdit = Date.now() - t0;
  const m1 = await mem();
  console.log('after 300 edits', tEdit, 'ms', JSON.stringify(m1));
  t0 = Date.now();
  for (let k = 0; k < 300; k++) { await page.evaluate(() => window.__store.undo()); if (k % 25 === 24) await idle(); }
  await idle();
  for (let k = 0; k < 300; k++) { await page.evaluate(() => window.__store.redo()); if (k % 25 === 24) await idle(); }
  await idle();
  const tUndo = Date.now() - t0;
  const m2 = await mem();
  console.log('after 300 undo + 300 redo', tUndo, 'ms', JSON.stringify(m2));

  // STEP を取り込んだファイルを作って保管庫へ
  const step = await page.evaluate(async () => { const b = await window.__kcall('export', { ids: [], format: 'step' }); return Array.from(new Uint8Array(b)); });
  const idA = await page.evaluate(() => window.__store.docId);
  await page.evaluate(async (bytes) => { window.__store.replace({ format: 'kobocad', features: [] }); await window.__app.importFile(new File([new Uint8Array(bytes)], 'big.step')); }, step);
  await idle(); await page.evaluate(() => window.__store.flush());
  const idB = await page.evaluate(() => window.__store.docId);
  // 保管庫から読んで開く（ファイル一覧から開くのと同じ）
  const openDoc = async (id) => {
    await page.evaluate(async (id) => {
      await window.__store.flush();
      const json = await new Promise((res, rej) => { const r = indexedDB.open('gdc-cad'); r.onsuccess = () => { const g = r.result.transaction('data').objectStore('data').get(id); g.onsuccess = () => { res(g.result.json); r.result.close(); }; g.onerror = rej; }; r.onerror = rej; });
      window.__store.replace(JSON.parse(json), id);
    }, id);
    await idle();
  };
  // ファイルを 15 回行き来する
  t0 = Date.now();
  for (let k = 0; k < 15; k++) {
    for (const id of [idA, idB]) {
      await openDoc(id);
    }
  }
  const tSwitch = Date.now() - t0;
  const m3 = await mem();
  console.log('after 30 file switches', tSwitch, 'ms', JSON.stringify(m3));
  // もう 15 回。メモリが目安を超えたら、切り替えるときにエンジンを作り直して片付ける（目安をテスト用に小さくする）
  await page.evaluate((mb) => { window.__gdcRefreshBytes = mb * 1048576; }, m3.wasm + 20);
  for (let k = 0; k < 15; k++) for (const id of [idA, idB]) {
    await openDoc(id);
  }
  const m4 = await mem();
  console.log('after 60 file switches', JSON.stringify(m4));
  const bodies = await page.evaluate(() => [window.__app.meshes.length, window.__app.errors.length]);
  console.log('bodies/errors after switches', JSON.stringify(bodies));
  const okJs = m4.js < m3.js * 1.3 + 5, okWasm = m4.wasm <= m3.wasm + 60 && bodies[1] === 0 && bodies[0] > 0, okImp = m4.imports <= 3;
  console.log(`js ${okJs} wasm ${okWasm} imports ${okImp}`);
  if (okJs && okWasm && okImp) console.log('memory ok');
  await browser.close();
})().catch((e) => { console.log('FAILED', e.message); process.exit(1); });
