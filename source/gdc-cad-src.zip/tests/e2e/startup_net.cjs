// 初回起動（キャッシュなし）の時間とダウンロード量を、遅い回線（携帯 4G 相当）で測る
//   node startup_net.cjs
// ・CADエンジン（WASM）の先読み（preload）があると早くなるか（先読みを外したページと比べる）
// ・WASM を 2 回ダウンロードしていないか
const { chromium } = require('playwright');
const PORT = process.env.PORT || 4173;
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const run = async (stripPreload) => {
    const ctx = await browser.newContext({ viewport: { width: 393, height: 852 }, serviceWorkers: 'block' });
    const page = await ctx.newPage();
    const cdp = await ctx.newCDPSession(page);
    await cdp.send('Network.enable');
    await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
    // 4G 相当: 下り 12Mbps・遅延 80ms
    await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 80, downloadThroughput: 12e6 / 8, uploadThroughput: 3e6 / 8 });
    let bytes = 0, wasmReqs = 0;
    cdp.on('Network.loadingFinished', (e) => { bytes += e.encodedDataLength; });
    cdp.on('Network.requestWillBeSent', (e) => { if (/\.wasm/.test(e.request.url)) wasmReqs++; });
    if (stripPreload) await page.route(/\/(index\.html)?$/, async (r) => { const res = await r.fetch(); r.fulfill({ response: res, body: (await res.text()).replace(/<link rel="preload"[^>]*wasm[^>]*>/, '') }); });
    const t0 = Date.now();
    await page.goto(`http://127.0.0.1:${PORT}/`);
    await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && typeof window.__kcall === 'function', null, { timeout: 180000 });
    await page.evaluate(() => window.__kcall('ping'));
    const ms = Date.now() - t0;
    await ctx.close();
    return { ms, MB: +(bytes / 1048576).toFixed(1), wasmReqs };
  };
  const a = await run(true);
  const b = await run(false);
  console.log('without preload', JSON.stringify(a));
  console.log('with preload   ', JSON.stringify(b));
  console.log(`preload faster: ${b.ms < a.ms} | wasm downloaded once: ${b.wasmReqs === 1}`);
  await browser.close();
})();
