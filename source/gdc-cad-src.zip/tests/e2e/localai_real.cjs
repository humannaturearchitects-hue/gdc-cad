// 端末内 AI を本物のモデル（Qwen2.5 0.5B・WebGPU）で動かす通しのテスト（遅い: CPU の swiftshader で数分〜）
// Hugging Face / GitHub への取得は、手元に写したファイル（MODELS_DIR）で応答する（外部に出ない）。
// 準備: MODELS_DIR=…/models（{モデルID}/resolve/main/… と libs/*.wasm を置いた所）
// 使い方: MODELS_DIR=/path PORT=4173 node localai_real.cjs
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 4173, DIR = process.env.MODELS_DIR;
if (!DIR) { console.log('MODELS_DIR を指定してください'); process.exit(0); }
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--enable-unsafe-webgpu', '--enable-features=Vulkan', '--use-vulkan=swiftshader', '--use-webgpu-adapter=swiftshader', '--disable-vulkan-surface'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 }, serviceWorkers: 'block' });
  let served = 0;
  const serve = async (route, file) => {
    if (!fs.existsSync(file)) return route.fulfill({ status: 404, body: 'nf', headers: { 'Access-Control-Allow-Origin': '*' } });
    served++;
    await route.fulfill({ status: 200, body: fs.readFileSync(file), headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/octet-stream' } });
  };
  await ctx.route(/huggingface\.co\/mlc-ai\//, (route) => { const u = new URL(route.request().url()); const rel = u.pathname.replace(/^\/mlc-ai\//, ''); return serve(route, path.join(DIR, rel)); });
  await ctx.route(/raw\.githubusercontent\.com\/mlc-ai\//, (route) => serve(route, path.join(DIR, 'libs', path.basename(new URL(route.request().url()).pathname))));
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', (d) => d.accept());
  await page.goto(`http://127.0.0.1:${PORT}/`);
  await page.evaluate(() => { localStorage.clear(); localStorage.setItem('gdc-local-model', 'small'); });
  await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  await page.click('.tool:has-text("AI に頼む")'); await page.waitForTimeout(300);
  await page.click('.cmd-set > summary');
  const t0 = Date.now();
  await page.click('#local-dl');
  await page.waitForFunction(() => /準備ができました|✗/.test(document.getElementById('cmd-log').innerText), null, { timeout: 600000, polling: 1000 });
  console.log('load:', (await page.innerText('#cmd-log')).split('\n').pop(), `${Math.round((Date.now() - t0) / 1000)}s`, 'files', served);
  const t1 = Date.now();
  await page.fill('#cmd-in', '床板を幅600、奥行400、厚さ20で作って'); await page.click('#cmd-run');
  await page.waitForFunction(() => window.__app.meshes.length > 0 || /✗|質問|確かめて/.test(document.getElementById('cmd-log').innerText.split('床板を幅600')[1] || ''), null, { timeout: 1800000, polling: 2000 });
  await page.waitForTimeout(1500);
  const r = await page.evaluate(async () => { const ms = window.__app.meshes; if (!ms.length) return 'none'; const q = await window.__kcall('measure', { ids: ms.map((m) => m.id), density: 1 }); return q.list.map((b) => `${b.name}:${Math.round(b.volume)}`).join(' '); });
  console.log('real local AI:', r, `${Math.round((Date.now() - t1) / 1000)}s`);
  console.log('log:', (await page.innerText('#cmd-log')).replace(/\n+/g, ' / ').slice(-200));
  // 2 回目: キャッシュから読む（ダウンロードしない）
  served = 0;
  await page.reload(); await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  const cached = await page.evaluate(async () => { const ks = await caches.keys(); return ks.filter((k) => /webllm/.test(k)).join(','); });
  console.log('cache storage:', cached, '| downloads on reload:', served);
  await browser.close();
})();
