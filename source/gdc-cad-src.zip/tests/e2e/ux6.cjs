// 使い方: テストフォルダにコピーし、ポートを合わせて node ux6.cjs（期待: box all 4 個・面と面の間隔 790 mm・after props [[0,30,800],[310,330,820]] など）
const { open } = require('./ux_common.cjs');
(async () => {
  const { browser, page } = await open();
  await page.cmd(`板 幅2000 奥行1200 厚さ30 名前 床板
板 幅2000 奥行30 厚さ1000 位置 0,0,30 名前 壁
板 幅600 奥行300 厚さ20 位置 0,30,700 名前 棚`);
  await page.evaluate(() => window.__app.viewer.fit()); await page.waitForTimeout(400);
  const feats = () => page.evaluate(() => window.__store.project.features.map(f => f.type).join(','));
  // units in commands
  console.log('cmd cm:', JSON.stringify((await page.cmd('板 幅60cm 奥行0.4m 厚さ20 位置 3000,0,0 名前 試し'))[0].msg));
  // Ctrl+A
  await page.click3([1500, 800, 30]);
  await page.keyboard.press('Control+a'); await page.waitForTimeout(200); console.log('ctrl+a', await page.sel());
  await page.keyboard.press('Escape');
  // box select (left->right window around shelf? use whole screen)
  const vp = page.vp;
  await page.keyboard.down('Shift');
  await page.mouse.move(vp.x + 5, vp.y + 5); await page.mouse.down(); await page.mouse.move(vp.x + vp.width - 150, vp.y + vp.height - 5, { steps: 5 }); await page.mouse.up();
  await page.keyboard.up('Shift'); await page.waitForTimeout(300);
  console.log('box all', await page.sel());
  // shift+click add
  await page.keyboard.press('Escape');
  await page.click3([1500, 800, 30]);
  await page.keyboard.down('Shift'); await page.click3([300, 150, 720]); await page.keyboard.up('Shift');
  console.log('shift add', await page.sel());
  // V hide both
  await page.keyboard.press('v'); await page.idle(); console.log('after V', await page.bodies());
  await page.keyboard.press('Control+z'); await page.idle(); console.log('undo V', await page.bodies());
  // select shelf body via dblclick, props
  const s = await page.evaluate(() => window.__app.viewer.toScreen([300,150,720]));
  await page.evaluate(() => { const id = window.__app.meshes.find(m=>m.name==='棚').id; window.__app.ux.setSelection([{kind:'body',bodyId:id}]); }); await page.waitForTimeout(800);
  console.log('props', (await page.locator('#ux-props').innerText()).replace(/\s+/g,' ').slice(0,200));
  const z = page.locator('#ux-props input[data-pos="2"]'); await z.fill('80cm'); await z.press('Enter'); await page.idle(); await page.waitForTimeout(500);
  const w = page.locator('#ux-props input[data-size="0"]'); await w.fill('600/2+10'); await w.press('Enter'); await page.idle(); await page.waitForTimeout(500);
  console.log('after props', await page.evaluate(async () => { const r = await window.__kcall('measure', { ids: window.__app.meshes.filter(m=>m.name==='棚').map(m=>m.id) }); return JSON.stringify(r.list[0].bounds.map(b=>b.map(v=>+v.toFixed(3)))); }), await feats());
  // copy paste
  await page.keyboard.press('Control+c'); await page.waitForTimeout(300);
  await page.keyboard.press('Control+v'); await page.waitForTimeout(800);
  console.log('paste dialog', await page.evaluate(() => { const a = window.__app.dialog.active; return a && a.type + ' copy=' + a.draft.copy + ' bodies=' + a.draft.bodies.length; }));
  await page.locator('#dialog input[data-k="translate"][data-i="0"]').fill('700');
  await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  await page.locator('#dialog button:has-text("OK")').click().catch(()=>{}); await page.idle();
  console.log('after paste', await page.bodies());
  // measure faces: top of floor vs bottom of shelf
  await page.keyboard.press('Escape');
  await page.keyboard.press('5'); await page.waitForTimeout(600); await page.keyboard.press('F6'); await page.waitForTimeout(300);
  await page.keyboard.press('i'); await page.waitForTimeout(200);
  await page.click3([1500, 800, 30]); await page.waitForTimeout(800);
  await page.click3([155, 180, 820], {}); await page.waitForTimeout(1200);
  console.log('measure', (await page.locator('#ux-meas').innerText()).replace(/\s+/g,' '));
  await page.keyboard.press('Escape'); await page.waitForTimeout(200);
  console.log('meas closed', await page.locator('#ux-meas').count());
  // views
  await page.keyboard.press('1'); await page.waitForTimeout(500);
  console.log('front dir', await page.evaluate(() => { const v = window.__app.viewer; const d = v.camera.position.clone().sub(v.controls.target).normalize(); return [d.x,d.y,d.z].map(x=>+x.toFixed(2)).join(','); }));
  // isolate
  await page.mouse.dblclick(vp.x + 200, vp.y + 200).catch(()=>{});
  await page.evaluate(() => { const id = window.__app.meshes.find(m=>m.name==='床板').id; window.__app.selection=[{kind:'body',bodyId:id}]; });
  await page.keyboard.press('Shift+V'); await page.waitForTimeout(300);
  console.log('isolate visible', await page.evaluate(() => [...window.__app.viewer.bodies.values()].filter(b=>b.mesh.visible).length), await page.locator('#ux-isobar').count());
  await page.keyboard.press('Shift+V'); await page.waitForTimeout(300);
  console.log('unisolate visible', await page.evaluate(() => [...window.__app.viewer.bodies.values()].filter(b=>b.mesh.visible).length));
  // shortcuts
  await page.keyboard.press('?'); await page.waitForTimeout(300);
  console.log('shortcuts', (await page.locator('#dialog').innerText()).slice(0,40).replace(/\s+/g,' '));
  await page.keyboard.press('Escape');
  // presspull preselect + field error
  await page.keyboard.press('7'); await page.waitForTimeout(400);
  await page.click3([1500, 800, 30]);
  await page.keyboard.press('q'); await page.waitForTimeout(800);
  console.log('Q face', (await page.locator('#dialog .selfield').first().innerText()));
  await page.locator('#dialog input[data-k="distance"]').fill('abc'); await page.waitForTimeout(300);
  console.log('err', await page.locator('#dialog .fld-err').innerText().catch(()=>'none'));
  await page.screenshot({ path: 'ux6.png' });
  console.log('errors', JSON.stringify(await page.evaluate(() => window.__app.errors)));
  await browser.close();
})();
