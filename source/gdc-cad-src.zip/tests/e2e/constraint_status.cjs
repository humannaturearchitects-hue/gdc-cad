// v0.18 受け入れテスト【改善1】スケッチ拘束の見える化（画面の操作で）
// npm run build && npx vite preview --port 4173 &  →  LANG=C.UTF-8 node tests/e2e/constraint_status.cjs
const { chromium } = require('playwright');
let ok = 0, ng = 0;
const check = (name, cond, info = '') => { cond ? ok++ : ng++; console.log(`${cond ? '✓' : '✗'} ${name}${info ? '  ' + info : ''}`); };
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 }, serviceWorkers: 'block' })).newPage();
  const errors = [];
  page.on('pageerror', e => { errors.push(e.message); console.log('PAGEERROR: ' + e.message); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  await page.evaluate(() => document.getElementById('welcome').classList.add('hidden'));
  const vp = await page.locator('#view3d').boundingBox();
  const S = (p) => page.evaluate((p) => window.__app.viewer.toScreen(p), p);
  const click3 = async (p) => { const s = await S([p[0], p[1], 0]); await page.mouse.click(vp.x + s[0], vp.y + s[1]); await page.waitForTimeout(120); };
  const status = () => page.evaluate(() => {
    const el = document.getElementById('sk-status'); if (!el) return null;
    return { status: el.querySelector('[data-status]').dataset.status, dof: +el.querySelector('[data-dof]').dataset.dof, count: +el.querySelector('[data-count]').dataset.count, text: el.innerText.replace(/\s+/g, ' ') };
  });
  const clickLabel = async (txt) => { for (const l of await page.$$('.dimlabel')) { if ((await l.textContent()) === txt) { await l.click(); return true; } } return false; };
  const setLabel = async (txt, v) => { const r = await clickLabel(txt); await page.keyboard.press('Control+A'); await page.keyboard.type(String(v)); await page.keyboard.press('Enter'); await page.waitForTimeout(400); return r; };
  const newSketch = async () => {
    await page.click('.tool:has-text("スケッチ作成")'); await page.waitForTimeout(300);
    const pos = await page.evaluate(() => { const v = window.__app.viewer; const m = v.planeMeshes.find(p => p.userData.name === 'XY'); const s = m.scale.x; return v.toScreen([s * 0.3, s * 0.3, 0]); });
    await page.mouse.click(vp.x + pos[0], vp.y + pos[1]);
    await page.waitForFunction(() => window.__app.sketcher.active && document.getElementById('sk-status'), null, { timeout: 30000 });
    await page.waitForTimeout(1200);
  };

  // ===== A: 長方形（2点長方形ツール）60×40 を原点から離して描く
  await newSketch();
  let st = await status();
  check('panel shown on sketch start (図形なし)', st && st.status === 'empty', JSON.stringify(st));
  await page.keyboard.press('r');
  await click3([10, 10]); await click3([70, 50]);
  await page.keyboard.press('Escape'); await page.keyboard.press('s'); await page.waitForTimeout(300);
  st = await status();
  check('rect drawn: 拘束不足 dof 4', st.status === 'under' && st.dof === 4, st.text);
  await setLabel('60', 60); await setLabel('40', 40);
  st = await status();
  check('rect + 寸法 2 つ: dof 2, 位置が不足と表示', st.status === 'under' && st.dof === 2 && /長方形1: 位置/.test(st.text), st.text);
  await click3([10, 25]); // 長方形を選択（左の辺）
  console.log('selected', await page.evaluate(() => [...window.__app.sketcher.selected]), await page.evaluate(() => JSON.stringify(window.__app.sketcher.feature.entities)));
  await page.click('.tool:has-text("固定")'); await page.waitForTimeout(400);
  console.log('toast', await page.evaluate(() => document.getElementById('toast').innerText), await page.evaluate(() => JSON.stringify(window.__app.sketcher.feature.constraints)));
  st = await status();
  check('(1) 寸法 2 つ + 位置拘束（固定）→ 完全拘束・自由度 0', st.status === 'full' && st.dof === 0 && st.count === 3 && /完全拘束/.test(st.text), st.text);
  await page.screenshot({ path: 'dl/v018_sketch_full.png' });
  // 寸法を 1 つ外す（一覧の × から）
  await page.click('#sk-status details summary'); await page.waitForTimeout(150);
  const delBtn = await page.evaluateHandle(() => [...document.querySelectorAll('#sk-status details .sks-item')].find(e => /寸法 高さ/.test(e.textContent)).querySelector('button'));
  await delBtn.click(); await page.waitForTimeout(400);
  st = await status();
  check('(2) 寸法を 1 つ外す → 拘束不足・自由度 1・高さが不足', st.status === 'under' && st.dof === 1 && /長方形1: 高さ/.test(st.text), st.text);
  await page.screenshot({ path: 'dl/v018_sketch_under.png' });
  await page.keyboard.press('Control+z'); await page.waitForTimeout(400);
  st = await status();
  check('undo restores 完全拘束', st.status === 'full' && st.dof === 0, st.text);
  await page.click('.tool:has-text("スケッチを終了")'); await page.waitForTimeout(800);
  check('panel hidden after finishing sketch', !(await status()));

  // ===== B: 線で描いた長方形（原点から）+ 寸法 → 矛盾
  await newSketch();
  await page.keyboard.press('l');
  for (const p of [[0, 0], [60, 0], [60, 40], [0, 40], [0, 0]]) await click3(p);
  await page.keyboard.press('Escape'); await page.keyboard.press('s'); await page.waitForTimeout(300);
  st = await status();
  check('lines from origin (自動の水平・垂直＋原点): dof 2', st.status === 'under' && st.dof === 2, st.text);
  // 下の辺と右の辺に長さ
  const lab = await page.evaluate(() => [...document.querySelectorAll('.dimlabel')].map(l => l.textContent));
  const L60 = await page.$$('.dimlabel'); // 下の辺（最初の 60）
  for (const l of L60) if ((await l.textContent()) === '60') { await l.click(); break; }
  await page.keyboard.press('Control+A'); await page.keyboard.type('60'); await page.keyboard.press('Enter'); await page.waitForTimeout(400);
  await setLabel('40', 40);
  st = await status();
  check('(1b) 線の長方形 + 寸法 2 つ + 原点 → 完全拘束・自由度 0', st.status === 'full' && st.dof === 0, st.text + ' labels=' + lab.join(','));
  // 上の辺（まだ寸法の無い 60）に 50 を入れる → 矛盾
  const plain = await page.evaluateHandle(() => [...document.querySelectorAll('.dimlabel')].find(l => l.textContent === '60' && !l.classList.contains('driving')));
  await plain.click(); await page.keyboard.press('Control+A'); await page.keyboard.type('50'); await page.keyboard.press('Enter'); await page.waitForTimeout(800);
  st = await status();
  const toast = await page.evaluate(() => document.getElementById('toast').innerText);
  const red = await page.evaluate(() => [...document.querySelectorAll('.dimlabel.conflict, .cglyph.conflict')].map(e => e.textContent));
  check('(3) 矛盾する寸法 → その場で警告', /矛盾/.test(toast) && /拘束が矛盾/.test(st.text), toast);
  check('(3) 対象が分かる（新しい拘束と相手を名指し＋赤表示）', /長さ 50（線3）/.test(st.text) && /長さ 60（線1）/.test(st.text) && red.includes('60'), 'red=' + JSON.stringify(red));
  check('(3) 矛盾した拘束は追加されず、形は壊れない', st.status === 'full' && st.dof === 0, st.text);
  await page.screenshot({ path: 'dl/v018_sketch_conflict.png' });
  await page.click('.tool:has-text("スケッチを終了")'); await page.waitForTimeout(800);

  // ===== (4) 押し出し・穴あけの後に寸法を変えても壊れない
  const r1 = await page.evaluate(() => window.__cmd('押し出し 5 名前 プレート'));
  await page.waitForTimeout(500);
  const r2 = await page.evaluate(() => window.__cmd('穴 上面 Ø5 位置 6,6 54,6 54,34 6,34 プレート'));
  await page.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(500);
  const vol = () => page.evaluate(async () => { const b = window.__app.meshes.find(m => m.name === 'プレート'); const r = await window.__app.kcall('measure', { ids: [b.id], density: 1 }); return { v: r.list[0].volume, bb: r.list[0].bounds }; }).catch(e => ({ err: e.message }));
  const v1 = await page.evaluate(async () => { const { call } = window.__kernel || {}; return null; });
  void v1;
  check('extrude + hole ok', r1.every(x => x.ok) && r2.every(x => x.ok), JSON.stringify([r1, r2]));
  // スケッチ 2 を開いて、下の辺の寸法 60 → 80
  const sk2 = await page.evaluate(() => window.__store.project.features.filter(f => f.type === 'sketch')[1].id);
  await page.evaluate((id) => window.__app.enterSketch(id), sk2); await page.waitForTimeout(1500);
  const drv = await page.evaluateHandle(() => [...document.querySelectorAll('.dimlabel.driving')].find(l => l.textContent === '60'));
  await drv.click(); await page.keyboard.press('Control+A'); await page.keyboard.type('80'); await page.keyboard.press('Enter'); await page.waitForTimeout(500);
  st = await status();
  check('dimension changed in sketch, still 完全拘束', st.status === 'full' && st.dof === 0, st.text);
  await page.click('.tool:has-text("スケッチを終了")'); await page.waitForTimeout(500);
  await page.waitForFunction(() => !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(800);
  const res = await page.evaluate(async () => {
    const errs = (window.__app.lastErrors || []).map(e => e.message);
    const b = window.__app.meshes.find(m => m.name === 'プレート');
    const r = await window.__cmd('体積 プレート');
    return { errs, body: !!b, msg: r.map(x => x.msg).join(' | ') };
  });
  const expected = 80 * 40 * 5 - 4 * Math.PI * 2.5 * 2.5 * 5;
  const m = res.msg.match(/([0-9,.]+)\s*mm³/) || res.msg.match(/([0-9][0-9,.]*)/);
  check('(4) 押し出し＋穴の後に寸法 60→80 でも壊れない（体積 ' + expected.toFixed(1) + '）', res.body && !res.errs.length, JSON.stringify(res));
  console.log('volume message:', res.msg, m && m[1]);
  check('no page errors', !errors.length, errors.join(' / '));
  console.log(`constraint status e2e: ${ok}/${ok + ng} ok`);
  await browser.close();
})();
