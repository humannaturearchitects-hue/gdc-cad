const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1500, height: 900 }, acceptDownloads: true })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', d => d.accept('A5052 t20 アルマイト'));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 60000 });
  await page.evaluate(() => window.__store.replace({ format:'kobocad', version:1, name:'テーブル', units:'mm', params:[], rollback:null, drawing:null, bodyProps:{},
    features:[
      { id:'top', type:'box', name:'top', position:['0','0','700'], w:'1200', d:'600', h:'30', operation:'new', bodyName:'天板' },
      { id:'leg', type:'box', name:'leg', position:['50','50','0'], w:'60', d:'60', h:'700', operation:'new', bodyName:'脚' },
      { id:'pt', type:'pattern', name:'pt', bodies:['B_leg'], dir:'X', count:'2', spacing:'1040', dir2:'Y', count2:'2', spacing2:'440', join:false },
    ] }));
  await page.waitForFunction(() => window.__app.meshes.length === 5, null, { timeout: 30000 }); await page.waitForTimeout(600);
  await page.click('.ws[data-ws=drawing]'); await page.waitForFunction(() => document.querySelector('.dw-sheet svg'), null, { timeout: 60000 }); await page.waitForTimeout(1000);
  // 正面図: 脚の間（内側）の寸法を入れる。ビュー情報から画面座標を求める
  const toClient = (v, m) => page.evaluate(([v, m]) => { const d = window.__app.drawing; const info = d.sheet.views[v]; const svg = document.querySelector('.dw-sheet svg'); const r = svg.getBoundingClientRect(); const sx = info.ox + m[0] * info.sc, sy = info.oy + m[1] * info.sc; return [r.left + sx / d.sheet.w * r.width, r.top + (d.sheet.h - sy) / d.sheet.h * r.height]; }, [v, m]);
  await page.click('[data-ann=dim]');
  const p1 = await toClient('front', [110, 0]), p2 = await toClient('front', [1090, 0]), p3 = await toClient('front', [600, 300]);
  await page.mouse.click(p1[0] + 1, p1[1] - 1); await page.waitForTimeout(200);
  await page.mouse.click(p2[0] - 1, p2[1] + 1); await page.waitForTimeout(200);
  await page.mouse.click(p3[0], p3[1]); await page.waitForTimeout(1200);
  await page.click('[data-ann=note]');
  const p4 = await toClient('front', [100, -120]); await page.mouse.click(p4[0], p4[1]); await page.waitForTimeout(1200);
  await page.click('[data-ann=note]');
  await page.click('[data-ann=balloon]'); await page.waitForTimeout(1500);
  const ann = await page.evaluate(() => JSON.stringify(Object.values(window.__store.project.drawing.annotations)[0].map(a => ({ t: a.t, dir: a.dir, a: a.a, b: a.b, n: a.n, text: a.text }))));
  console.log('annotations', ann);
  await page.locator('.dw-sheet').screenshot({ path: 'd_ann.png' });
  const [d] = await Promise.all([page.waitForEvent('download'), page.click('[data-x=dxf]')]); await d.saveAs('dl/ann.dxf');
  await browser.close();
})();
