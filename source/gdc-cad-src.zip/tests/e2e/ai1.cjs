// AI モード（Anthropic API は模擬応答）＋ 尺度（スケール）
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 850 } });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('dialog', d => d.type() === 'prompt' ? d.accept('sk-ant-test-key') : d.accept());
  const answers = [
    { commands: '板 幅 600 奥行 400 厚さ 20 名前 床板\n穴 上面 Ø8 位置 30,30 570,30 570,370 30,370 床板\nフィレット R5 縦の辺 床板', explanation: '床板を作り、四隅に Ø8 の穴、角を R5 で丸めます。', question: '' },
    { commands: '床板 厚さ 30\nほげ', explanation: '厚さを 30 に。', question: '' },
    { commands: 'スケール 0.5', explanation: '全体を半分に。', question: '' },
    { commands: '', explanation: '', question: '穴の直径は何 mm にしますか？' },
  ];
  const reqs = [];
  await page.route('https://api.anthropic.com/**', async (route) => {
    const req = route.request(); const body = JSON.parse(req.postData());
    reqs.push({ url: req.url(), h: await req.allHeaders(), body });
    const a = answers.shift() || { commands: '', explanation: 'ok', question: '' };
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ id: 'msg_test', type: 'message', role: 'assistant', model: body.model, stop_reason: 'end_turn', stop_sequence: null, content: [{ type: 'text', text: JSON.stringify(a) }], usage: { input_tokens: 10, output_tokens: 10 } }) });
  });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden'), null, { timeout: 90000 });
  const vol = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list.map(b => `${b.name}:${b.volume.toFixed(1)} [${b.bounds.map(p => p.map(v => +v.toFixed(1)).join(',')).join(' / ')}]`).join(' ; ');
  // 尺度（AI なし）
  await page.evaluate(() => window.__cmd('板 100x100x10 名前 試し'));
  console.log('scale offline:', JSON.stringify((await page.evaluate(() => window.__cmd('全部のサイズを10分の1に'))).map(x => x.msg)), await vol());
  console.log('scale body:', JSON.stringify((await page.evaluate(() => window.__cmd('試しを2倍に'))).map(x => x.msg)), await vol());
  await page.evaluate(() => window.__cmd('削除 試し'));
  // AI をオン
  await page.click('.tool:has-text("AI に頼む")'); await page.waitForTimeout(300);
  const say = async (t) => { await page.fill('#cmd-in', t); await page.click('#cmd-run'); await page.waitForTimeout(500); await page.waitForFunction(() => !window.__app.buildsRunning && document.getElementById('busy').classList.contains('hidden')); await page.waitForTimeout(2500); };
  await say('床板を600×400の厚さ20で作って、四隅に8mmの穴を端から30ずつ。角は5Rで丸めて');
  console.log('### 1:', await vol());
  console.log('key set:', await page.locator('#ai-key').textContent());
  answers.splice(1, 0, { commands: '', explanation: '（直し）不要な行を除きました', question: '' }); // 2 回目の依頼（直し）への応答
  await say('厚みを30にして');
  console.log('### 2:', await vol());
  await say('全体を半分の大きさに');
  console.log('### 3:', await vol());
  await say('穴を追加して');
  const log = (await page.locator('#cmd-log').innerText()).replace(/\s+/g, ' ');
  console.log('question shown:', log.includes('穴の直径は何 mm にしますか'));
  answers.push({ commands: '穴 上面 Ø10 位置 300,200 床板', explanation: '中央に Ø10 の穴を開けます。', question: '' });
  await say('10ミリで真ん中に');
  const last = reqs[reqs.length - 1].body.messages;
  console.log('follow-up has history:', last.length > 2 && last.some(m => m.role === 'assistant' && /穴の直径は何 mm/.test(m.content)) && /10ミリで真ん中に/.test(last[last.length - 1].content), '| msgs', last.length);
  console.log('### 4:', await vol());
  const r0 = reqs[0];
  console.log('hdrs', Object.keys(r0.h).join(','), r0.h.authorization ? 'auth:' + r0.h.authorization.slice(0,14) : ''); console.log('request:', r0.url, '| key', r0.h['x-api-key'], '| browser header', r0.h['anthropic-dangerous-direct-browser-access'], '| beta', r0.h['anthropic-beta']);
  console.log('body:', JSON.stringify({ model: r0.body.model, effort: r0.body.output_config && r0.body.output_config.effort, format: r0.body.output_config && r0.body.output_config.format.type, fallbacks: r0.body.fallbacks, cache: r0.body.system[0].cache_control, max_tokens: r0.body.max_tokens }));
  console.log('context sent (req 2):', reqs[1].body.messages.at(-1).content.slice(0, 260).replace(/\n/g, ' / '));
  console.log('retry request had error:', /止まりました/.test(reqs[2].body.messages.at(-1).content), '| total requests', reqs.length);
  await page.screenshot({ path: 'ai1.png' });
  await browser.close();
})();
