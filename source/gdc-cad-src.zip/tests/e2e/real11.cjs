// スケッチのスマートガイド: 角・中点・四分点・線上への吸着、縦横のそろい、座標表示
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(200); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const hov = async (x, y, l) => { await page.mouse.move(...await scr([x, y, 0]), { steps: 3 }); await page.waitForTimeout(120); console.log(`  ${l}:`, (await page.locator('.hcur').innerText().catch(() => '(none)')).replace(/\s+/g, ' ')); };
  await page.click('.tool:has-text("スケッチ作成")'); await page.click('#planebar [data-pl=XY]'); await idle();
  await page.keyboard.press('r'); await page.mouse.click(...await scr([0, 0, 0])); await page.waitForTimeout(150);
  { const a = page.locator('.inbox input'); await a.nth(0).fill('100'); await a.nth(1).fill('60'); await page.keyboard.press('Enter'); await page.waitForTimeout(250); }
  await page.keyboard.press('c'); await page.mouse.click(...await scr([150, 30, 0])); await page.locator('.inbox input').nth(0).fill('40'); await page.keyboard.press('Enter'); await page.waitForTimeout(250);
  await page.keyboard.press('l');
  await hov(100.8, 59.3, '角の近く');
  await hov(50.6, 0.5, '辺の中点の近く');
  await hov(23.3, 0.6, '辺の上');
  await hov(170.6, 30.5, '円の四分点の近く');
  await hov(100.4, 112, '角と縦にそろう');
  await page.screenshot({ path: 'real11_guide.png' });
  await page.mouse.click(...await scr([100.4, 112, 0])); await page.waitForTimeout(150);
  await hov(37, 30.4, '描き始めの点から… 角(0,60)?/中心(50,30)と横');
  await page.keyboard.press('Escape');
  console.log('### 線の始点', await page.evaluate(() => JSON.stringify(window.__app.sketcher.chainStart || window.__app.sketcher.feature.entities.slice(-1)[0])));
  await browser.close();
})();
