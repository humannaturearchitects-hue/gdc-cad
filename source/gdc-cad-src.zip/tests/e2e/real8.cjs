// 押し出しの操作感: 先にプロファイル／面を選んで E、矢印のドラッグ、画面上の数値ボックス
const { chromium, webkit } = require('playwright');
const B = process.env.WK ? webkit : chromium;
(async () => {
  const browser = await B.launch(process.env.WK ? {} : { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 850 } })).newPage();
  page.on('dialog', d => d.accept());
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/manifest/.test(m.text())) console.log('console.error: ' + m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4173/'); await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.waitForFunction(() => window.__app && document.getElementById('busy').classList.contains('hidden') && window.__app.viewer, null, { timeout: 90000 });
  const vp = await page.locator('#view3d').boundingBox();
  const idle = async () => { await page.waitForTimeout(300); await page.waitForFunction(() => document.getElementById('busy').classList.contains('hidden') && !window.__app.buildsRunning, null, { timeout: 60000 }); await page.waitForTimeout(250); };
  const scr = async (w) => { const p = await page.evaluate((w) => window.__app.viewer.toScreen(w), w); return [vp.x + p[0], vp.y + p[1]]; };
  const meas = async () => (await page.evaluate(() => window.__kcall('measure', { ids: window.__app.meshes.map(m => m.id), density: 1 }))).list.map(b => Math.round(b.volume) + ' [' + b.bounds.map(p => p.map(Math.round).join(',')).join(' / ') + ']').join(' ; ');
  const tool = (t) => page.click(`.tool:has-text("${t}")`);

  // スケッチ: 長方形 2 つ → 終了
  await tool('スケッチ作成'); await page.click('#planebar [data-pl=XY]'); await idle();
  for (const [x, y] of [[0, 0], [150, 0]]) { await page.keyboard.press('r'); await page.mouse.click(...await scr([x, y, 0])); await page.waitForTimeout(150); const a = page.locator('.inbox input'); await a.nth(0).fill('100'); await a.nth(1).fill('100'); await page.keyboard.press('Enter'); await page.waitForTimeout(250); }
  await page.click('.tool:has-text("スケッチを終了")'); await idle();
  await page.click('[data-nav=home]'); await page.waitForTimeout(500);
  // 1. 先に右の長方形をクリックで選ぶ → E
  await page.mouse.click(...await scr([200, 50, 0])); await page.waitForTimeout(200);
  console.log('  selection', await page.evaluate(() => JSON.stringify(window.__app.selection.map(s => s.kind + (s.loop !== undefined ? ':' + s.loop : '')))));
  await page.keyboard.press('e'); await idle();
  console.log('  items from preselect', await page.evaluate(() => JSON.stringify(window.__app.dialog.active.draft.items)));
  console.log('  xbox', await page.locator('.xbox input').inputValue());
  // 2. 画面上の数値ボックスに 40 と入力
  await page.locator('.xbox input').fill('40'); await idle();
  console.log('  dialog distance after xbox', await page.inputValue('#dialog input[data-k="distance"]'));
  // 3. 矢印を上にドラッグ
  const hs = await page.evaluate(() => window.__app.exHandle && [window.__app.exHandle.tipScreen, window.__app.exHandle.headScreen]);
  const r = await page.locator('#view3d').boundingBox();
  const a = [r.x + (hs[0][0] + hs[1][0]) / 2, r.y + (hs[0][1] + hs[1][1]) / 2];
  await page.mouse.move(a[0], a[1]); await page.mouse.down();
  for (let i = 1; i <= 10; i++) { await page.mouse.move(a[0], a[1] - i * 6); await page.waitForTimeout(30); }
  await page.mouse.up(); await idle();
  const dragged = await page.inputValue('#dialog input[data-k="distance"]');
  console.log('  after drag distance', dragged, 'cam moved?', await page.evaluate(() => window.__app.viewer.controls.enabled));
  await page.screenshot({ path: 'real8_arrow.png' });
  await page.keyboard.press('Enter'); await idle();
  console.log('### 1 先に選んだ右の長方形を、ドラッグした距離で押し出し:', await meas(), '(distance', dragged + ')');
  // 4. 先に面を選んで E → 結合
  await page.mouse.click(...await scr([200, 50, +dragged])); await page.waitForTimeout(200);
  console.log('  selection', await page.evaluate(() => JSON.stringify(window.__app.selection.map(s => s.kind))));
  await page.keyboard.press('e'); await idle();
  console.log('  op', await page.evaluate(() => window.__app.dialog.active.draft.operation));
  await page.locator('.xbox input').fill('10'); await idle(); await page.keyboard.press('Enter'); await idle();
  console.log('### 2 上面を選んで E → 10 結合:', await meas());
  await browser.close();
})();
