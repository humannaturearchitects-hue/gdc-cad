// パラメータと寸法の画面（モデルのすべての寸法を一覧で直す・「P」でパラメータにする・使用箇所・使用中の削除）
// プレス/プルの矢印、スケッチの寸法を後から直す
// 使い方: テストフォルダにコピーし、ポートを合わせて node edit_params.cjs（IPHONE=1 で iPhone 15）
//  期待: "dims rows >= 8" "after P: 板厚=20 used 2" "sizes 600x400x30 | 300x200x30" "after delete: 30 numeric ok"
//        "presspull arrow 1" "presspull H 35" "sketch dim 700 ok"
const { open } = require('./ux_common.cjs');
(async () => {
  const iphone = !!process.env.IPHONE;
  const { browser, page } = await open({ iphone, promptValue: '板厚' });
  const log = (...a) => console.log(...a);
  for (const t of ['スケッチ XY', '長方形 0,0 600,400', '押し出し 20 名前 床板', 'スケッチ XY オフセット 100', '長方形 0,0 300,200', '押し出し 15 名前 棚', '円柱 直径50 高さ100 位置 100,100,20 名前 柱']) await page.cmd(t);
  const sizes = () => page.evaluate(async () => { const r = await window.__kcall('measure', { ids: window.__app.meshes.map((m) => m.id) }); return r.list.map((b) => [0, 1, 2].map((i) => +(b.bounds[1][i] - b.bounds[0][i]).toFixed(2)).join('x')).join(' | '); });
  const tap = (loc) => iphone ? loc.tap() : loc.click();
  await page.evaluate(() => window.__app.openParams()); await page.waitForTimeout(400);
  log('title', await page.locator('#dialog .dlg-head span:not(.m-grip)').innerText(), 'dims rows', await page.locator('#dialog [data-d]').count());
  await page.screenshot({ path: 'edit_params1.png' });
  // 押し出し1 の距離を「P」でパラメータ 板厚 に
  const row = async (fname, label) => page.evaluate(([fname, label]) => {
    const trs = [...document.querySelectorAll('#dialog .ed-dims tr')]; let cur = '';
    for (const tr of trs) { if (tr.classList.contains('ed-fh')) { cur = tr.innerText.trim(); continue; } if (cur.startsWith(fname) && tr.querySelector('.ed-dl')?.innerText === label) return tr.querySelector('[data-d]').dataset.d; }
    return null;
  }, [fname, label]);
  const k1 = await row('押し出し1', '距離');
  await tap(page.locator(`#dialog [data-mk="${k1}"]`)); await page.waitForTimeout(300);
  // 押し出し2 の距離にも 板厚 と書く
  const k2 = await row('押し出し2', '距離');
  const inp = page.locator(`#dialog [data-d="${k2}"]`); await inp.fill('板厚'); await inp.press('Tab'); await page.waitForTimeout(300);
  // パラメータの値を 30 に
  const pe = page.locator('#dialog [data-k="expr"]').first(); await pe.fill('30'); await pe.press('Tab'); await page.waitForTimeout(300);
  log('after P:', await page.evaluate(() => [...document.querySelectorAll('#dialog .ed-pt tr')].slice(1).map((t) => t.querySelector('[data-k=name]').value + '=' + t.querySelector('[data-k=expr]').value + ' used ' + t.querySelector('.ed-use').innerText.replace(/\D/g, '')).join(',')));
  await page.screenshot({ path: 'edit_params2.png' });
  await tap(page.locator('#dialog [data-o]')); await page.waitForTimeout(500); await page.idle();
  log('sizes', await sizes());
  log('dist exprs', JSON.stringify(await page.evaluate(() => window.__store.project.features.filter((f) => f.type === 'extrude').map((f) => f.distance))));
  // 使っているパラメータを削除 → 今の値の数値に置き換わる
  await page.evaluate(() => window.__app.openParams()); await page.waitForTimeout(400);
  await tap(page.locator('#dialog [data-del="0"]')); await page.waitForTimeout(300);
  await tap(page.locator('#dialog [data-o]')); await page.waitForTimeout(500); await page.idle();
  const dd = await page.evaluate(() => window.__store.project.features.filter((f) => f.type === 'extrude').map((f) => f.distance));
  log('after delete:', dd.join(','), dd.every((x) => x === '30') ? 'numeric ok' : 'NG', 'errors', JSON.stringify(await page.evaluate(() => window.__app.errors)));
  // プレス/プル: 面を選んで Q → 矢印と数値ボックス
  await page.evaluate(() => { window.__app.selection = []; window.__app.reapplyHighlights(); });
  await page.evaluate(() => window.__app.viewer.fit()); await page.waitForTimeout(300);
  const top = await page.evaluate(() => window.__app.viewer.toScreen([450, 300, 30]));
  if (iphone) await page.touchscreen.tap(page.vp.x + top[0], page.vp.y + top[1]); else await page.mouse.click(page.vp.x + top[0], page.vp.y + top[1]);
  await page.waitForTimeout(400);
  await page.evaluate(() => window.__app.runTool('presspull')); await page.waitForTimeout(900);
  log('presspull arrow', await page.locator('.xbox').count());
  await page.locator('.xbox input').fill('5'); await page.locator('.xbox input').press('Enter'); await page.idle();
  log('presspull H', await page.evaluate(async () => { const m = window.__app.meshes.find((m) => m.name === '床板'); const b = (await window.__kcall('measure', { ids: [m.id] })).list[0].bounds; return +(b[1][2] - b[0][2]).toFixed(2); }));
  // スケッチの寸法を後から直す（タイムラインのスケッチ → 寸法の数字をクリック）
  await page.evaluate(() => window.__app.editFeature(window.__store.project.features[0].id)); await page.waitForTimeout(1200);
  const lab = page.locator('.dimlabel', { hasText: '600' }).first();
  await tap(lab); await page.waitForTimeout(400);
  await page.keyboard.press('Control+a'); await page.keyboard.press('Meta+a'); await page.keyboard.type('700'); await page.keyboard.press('Enter'); await page.waitForTimeout(600);
  await page.evaluate(() => window.__app.finishSketch()); await page.idle();
  const w = await page.evaluate(async () => { const m = window.__app.meshes.find((m) => m.name === '床板'); const b = (await window.__kcall('measure', { ids: [m.id] })).list[0].bounds; return +(b[1][0] - b[0][0]).toFixed(2); });
  log('sketch dim', w, w === 700 ? 'ok' : 'NG');
  await browser.close();
})();
