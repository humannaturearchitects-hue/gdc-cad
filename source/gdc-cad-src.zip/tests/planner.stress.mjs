// 内装: ランダムな部屋 × いろいろな方針で、自動配置の決まりが守られているか（node tests/planner.stress.mjs [件数]）
import { randomRoom } from "./interior.stress.mjs";
import { rectRoom, wallsOf, polyArea, rng } from "../src/interior/room.js";
import { parsePolicy, POLICY_EXAMPLES, KINDS } from "../src/interior/policy.js";
import { designPlan, rectInside, builtinParts, cutListAll } from "../src/interior/planner.js";
import { buildSheets } from "../src/interior/sheets.js";

const EXTRA = ["子ども部屋。ベッドと机と本棚", "LDK 6人。ダイニングテーブルとテレビとソファ、食器棚", "和室。収納は少なめ、すっきり", "オフィス 4人", "寝室。キングサイズのベッド、クローゼットは2つ", "書斎。背の低い家具だけ、圧迫感を出さない", "テレビはいらない。リビングにソファと本棚", "店舗。陳列棚を多めに"];
const policies = [...POLICY_EXAMPLES, ...EXTRA];
const N = +process.argv[2] || 80;
const fails = [], stats = { plans: 0, items: 0, warn: 0, want: 0, ms: 0, byKind: {} };
const ov = (a, b) => a.x0 < b.x1 - 1 && b.x0 < a.x1 - 1 && a.y0 < b.y1 - 1 && b.y0 < a.y1 - 1;
for (let s = 1; s <= N; s++) {
  const spec = randomRoom(s);
  const room = { name: "r", height: spec.height, poly: spec.poly, transform: null, source: "test",
    openings: spec.holes.map((h, i) => ({ id: "O" + i, type: h.door ? "door" : "window", wall: h.wall, pos: h.pos, width: h.w, height: h.door ? h.z1 : h.z1 - h.z0, sill: h.door ? 0 : h.z0 })) };
  const pol = policies[s % policies.length];
  const brief = parsePolicy(pol, room);
  const t0 = performance.now();
  let plan;
  try { plan = designPlan(room, brief, 1 + (s % 3)); } catch (e) { fails.push(`seed ${s}: 例外 ${e.message}`); continue; }
  stats.ms += performance.now() - t0;
  for (const w of plan.warn) { const k = w.replace(/（.*|を置け.*|の正面.*/g, ""); stats.byKind[k] = (stats.byKind[k] || 0) + 1; }
  stats.plans++; stats.items += plan.items.length; stats.warn += plan.warn.length; stats.want += brief.items.length;
  const W = wallsOf(room);
  for (const a of plan.items) {
    if (!rectInside(a.F, room.poly)) fails.push(`seed ${s}: ${a.name} がはみ出し`);
    for (const b of plan.items) if (a !== b && a.id < b.id && ov(a.F, b.F)) fails.push(`seed ${s}: ${a.name} と ${b.name} が重なる`);
    for (const o of room.openings) {
      const w = W[o.wall];
      const strip = (d) => { const p = (t, dd) => [w.a[0] + w.u[0] * t + w.n[0] * dd, w.a[1] + w.u[1] * t + w.n[1] * dd]; const A = p(o.pos + 10, 1), B = p(o.pos + o.width - 10, d); return { x0: Math.min(A[0], B[0]), y0: Math.min(A[1], B[1]), x1: Math.max(A[0], B[0]), y1: Math.max(A[1], B[1]) }; };
      if (o.type === "door" && ov(a.F, strip(700))) fails.push(`seed ${s}: ${a.name} がドアの前`);
      if (o.type === "window" && a.h > o.sill && ov(a.F, strip(50))) fails.push(`seed ${s}: ${a.name}（H${a.h}）が窓（窓台 ${o.sill}）をふさぐ`);
    }
    if (a.builtin && a.wall != null) for (const p of builtinParts(a, brief).parts) {
      const b = p.box; if (b[0] < -0.5 || b[3] > a.w + 0.5 || b[5] > a.h + 0.5 || b[2] < -0.5) fails.push(`seed ${s}: ${a.name} の ${p.part} が外形の外`);
      if (b[3] - b[0] <= 0 || b[4] - b[1] <= 0 || b[5] - b[2] <= 0) fails.push(`seed ${s}: ${a.name} の ${p.part} の大きさが 0`);
    }
  }
  try { const sh = buildSheets(room, plan, brief); for (const x of sh) for (const t of x.texts) if (/NaN|undefined|Infinity/.test(t.text)) fails.push(`seed ${s}: 図面の文字 "${t.text}"`); } catch (e) { fails.push(`seed ${s}: 図面で例外 ${e.message}`); }
  for (const r of cutListAll(plan, brief).rows) if (!(r.L > 0 && r.W > 0 && r.qty > 0)) fails.push(`seed ${s}: 部材 ${r.item} ${r.part} の寸法が不正`);
}
const uniq = [...new Set(fails)];
console.log(`配置 ${stats.plans} 案・家具 ${stats.items}/${stats.want}（置けなかった ${stats.warn}）・平均 ${(stats.ms / stats.plans).toFixed(0)}ms/案・決まり違反 ${uniq.length}`);
if (process.env.V !== "0") console.log("置けなかった物:", stats.byKind);
for (const f of uniq.slice(0, 30)) console.log(" " + f);
process.exitCode = uniq.length ? 1 : 0;
