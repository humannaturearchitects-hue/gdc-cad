// 内装: スキャンの読み取り・方針・配置・部材のテスト（node tests/interior.unit.mjs）
import assert from "node:assert/strict";
import { makeSampleScan, extractRoom, rectRoom, wallsOf, polyArea, pointInPoly } from "../src/interior/room.js";
import { normalizePoints, parseOBJ, parsePLY, meshToPoints } from "../src/interior/scan.js";
import { parsePolicy, POLICY_EXAMPLES } from "../src/interior/policy.js";
import { planLayout, builtinParts, partSize, rectInside, cutListAll } from "../src/interior/planner.js";
import { buildSheets, cutCSV } from "../src/interior/sheets.js";

let n = 0;
const t = (name, fn) => { fn(); n++; console.log("ok -", name); };

// 1. 見本スキャン（m・Y 上・23° 回転）から L 字の部屋を読み取る
const s = makeSampleScan();
const N = normalizePoints(s.pts);
const room = extractRoom(N.pts);
t("単位と上方向を自動判定", () => { assert.equal(N.scale, 1000); assert.equal(N.upAxis, "y"); });
t("天井高 ±10mm", () => assert.ok(Math.abs(room.height - 2400) <= 10, room.height));
t("輪郭 6 頂点・各頂点 ±10mm", () => {
  assert.equal(room.poly.length, 6);
  s.truth.poly.forEach((p, i) => { assert.ok(Math.hypot(p[0] - room.poly[i][0], p[1] - room.poly[i][1]) <= 10, `${p} vs ${room.poly[i]}`); });
});
t("ドア 1・窓 2 を見つけ、位置と幅 ±15mm", () => {
  assert.equal(room.openings.length, 3);
  for (const h of s.truth.holes) {
    const o = room.openings.find((x) => x.wall === h.wall);
    assert.ok(o, "wall " + h.wall);
    assert.equal(o.type, h.door ? "door" : "window");
    assert.ok(Math.abs(o.pos - h.pos) <= 15 && Math.abs(o.width - h.w) <= 15, JSON.stringify(o));
    assert.ok(Math.abs((o.type === "door" ? o.height : o.sill) - (h.door ? h.z1 : h.z0)) <= 50, JSON.stringify(o));
  }
});
// 2. 形式の読み込み
t("OBJ（四角形の面）", () => { const m = parseOBJ("v 0 0 0\nv 1 0 0\nv 1 1 0\nv 0 1 0\nf 1 2 3 4\n"); assert.equal(m.tris.length, 6); assert.equal(meshToPoints(m, 100, Math.random).length, 300); });
t("PLY バイナリ", () => {
  const head = "ply\nformat binary_little_endian 1.0\nelement vertex 3\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nelement face 1\nproperty list uchar int vertex_indices\nend_header\n";
  const hb = new TextEncoder().encode(head);
  const buf = new ArrayBuffer(hb.length + 3 * 13 + 1 + 12);
  new Uint8Array(buf).set(hb);
  const dv = new DataView(buf); let o = hb.length;
  for (const v of [[0, 0, 0], [2, 0, 0], [0, 3, 0]]) { for (const c of v) { dv.setFloat32(o, c, true); o += 4; } dv.setUint8(o++, 255); }
  dv.setUint8(o++, 3); for (const i of [0, 1, 2]) { dv.setInt32(o, i, true); o += 4; }
  const m = parsePLY(buf);
  assert.deepEqual([...m.verts], [0, 0, 0, 2, 0, 0, 0, 3, 0]); assert.deepEqual([...m.tris], [0, 1, 2]);
});
// 3. 方針
t("方針の読み取り", () => {
  const b = parsePolicy("寝室。ダブルベッド、テレビはいらない。モダンに", room);
  assert.equal(b.use, "bedroom"); assert.equal(b.style, "modern"); assert.equal(b.bedW, 1400);
  assert.ok(b.exclude.includes("tvboard") && !b.items.includes("tvboard"));
  const c = parsePolicy("小さな物販の店舗。陳列棚とレジカウンター", room);
  assert.ok(!c.items.includes("desk"));
});
// 4. 配置: どの例でも、部屋からはみ出さず・重ならず・ドアの前をふさがない
for (const [i, ex] of POLICY_EXAMPLES.entries()) {
  for (const seed of [1, 2, 3]) t(`配置 例${i + 1} 案${seed}`, () => {
    const b = parsePolicy(ex, room);
    const p = planLayout(room, b, { seed });
    assert.ok(p.items.length >= 2);
    for (const a of p.items) {
      assert.ok(rectInside(a.F, room.poly), a.name + " はみ出し");
      for (const c of p.items) if (a !== c) assert.ok(!(a.x0 < c.x1 - 1 && c.x0 < a.x1 - 1 && a.y0 < c.y1 - 1 && c.y0 < a.y1 - 1), `${a.name} と ${c.name} が重なる`);
      const door = room.openings.find((o) => o.type === "door"); const w = wallsOf(room)[door.wall];
      const front = [w.a[0] + w.u[0] * (door.pos + door.width / 2) + w.n[0] * 400, w.a[1] + w.u[1] * (door.pos + door.width / 2) + w.n[1] * 400];
      assert.ok(!(front[0] > a.x0 && front[0] < a.x1 && front[1] > a.y0 && front[1] < a.y1), a.name + " がドアの前");
    }
    const sh = buildSheets(room, p, b);
    assert.ok(sh.length >= 4);
    assert.ok(cutCSV(p, b).includes("部材"));
  });
}
// 5. 部材: 板はすべて家具の外形の中・定尺を超える板には注意書き
t("部材の寸法", () => {
  const b = parsePolicy(POLICY_EXAMPLES[0], room);
  const p = planLayout(room, b);
  for (const it of p.items.filter((x) => x.builtin)) {
    for (const part of builtinParts(it, b).parts) {
      const bx = part.box;
      assert.ok(bx[0] >= -0.01 && bx[3] <= it.w + 0.01 && bx[1] >= -0.01 && bx[4] <= it.d + 0.01 && bx[2] >= -0.01 && bx[5] <= it.h + 0.01, `${it.name} ${part.part} ${bx}`);
      const z = partSize(part);
      if (z.L > 3020) assert.ok(/継ぎ/.test(part.note), `${part.part} ${z.L}`);
    }
  }
  assert.ok(cutListAll(p, b).rows.every((r) => r.L > 0 && r.W > 0 && r.qty > 0));
});
// 6. 長方形の部屋（スキャンなし）
t("手入力の部屋", () => {
  const r = rectRoom(2730, 2730, 2400);
  r.openings.push({ type: "door", wall: 0, pos: 100, width: 780, height: 2000, sill: 0 });
  const p = planLayout(r, parsePolicy("書斎", r));
  assert.ok(p.items.some((i) => i.kind === "desk"));
  assert.equal(Math.abs(polyArea(r.poly)), 2730 * 2730);
});
console.log(`${n} tests passed`);
