// スケッチ拘束の見える化（自由度・状態・不足・矛盾）の単体テスト
// node tests/constraintcheck.unit.mjs
import { analyzeSketch, explainConflict } from "../src/shared/constraintcheck.js";
import { solveSketch } from "../src/shared/solver.js";
import { makeEvaluator } from "../src/shared/expr.js";
const num = makeEvaluator([]);
let pass = 0, fail = 0;
const expect = (name, cond, info = "") => { if (cond) pass++; else fail++; console.log(`${cond ? "✓" : "✗"} ${name}${info ? "  " + info : ""}`); };
const L = (id, x1, y1, x2, y2) => ({ id, type: "line", x1, y1, x2, y2 });
const summary = (r) => `status=${r.status} dof=${r.dof} count=${r.count} missing=${JSON.stringify(r.missing.map((m) => m.name + ":" + m.what.join("/")))}`;

// --- 長方形（図形 1 つ）: 60×40
{
  const R = (x, y) => [{ id: "r", type: "rect", x, y, w: 60, h: 40 }];
  let r = analyzeSketch(R(10, 10), [], num);
  expect("rect free: dof 4, under", r.dof === 4 && r.status === "under", summary(r));
  r = analyzeSketch(R(0, 0), [], num);
  expect("rect at origin: dof 2 (位置は原点に一致)", r.dof === 2 && r.missing[0].what.join() === "幅,高さ", summary(r));
  const dims = [{ type: "dim", a: "r", key: "w" }, { type: "dim", a: "r", key: "h" }];
  r = analyzeSketch(R(10, 10), dims, num);
  expect("rect + 2 dims: dof 2, 位置が不足", r.dof === 2 && r.missing[0].what.join() === "位置", summary(r));
  r = analyzeSketch(R(10, 10), [...dims, { type: "fix", a: "r", at: {} }], num);
  expect("(1) rect + 2 dims + 固定 → 完全拘束 dof 0", r.status === "full" && r.dof === 0 && r.count === 3, summary(r));
  r = analyzeSketch(R(0, 0), [...dims, { type: "fix", a: "r", at: {} }], num);
  expect("rect at origin + 2 dims + 固定 → 完全拘束（固定は過拘束にしない）", r.status === "full" && r.dof === 0, summary(r));
  r = analyzeSketch(R(10, 10), [dims[0], { type: "fix", a: "r", at: {} }], num);
  expect("(2) 寸法を 1 つ外す → dof 1, 高さが不足", r.status === "under" && r.dof === 1 && r.missing[0].what.join() === "高さ", summary(r));
}

// --- 4 本の線の長方形（拘束付き）
{
  const ents = [L("a", 0, 0, 60, 0), L("b", 60, 0, 60, 40), L("c", 60, 40, 0, 40), L("d", 0, 40, 0, 0)];
  const hv = [{ type: "h", a: "a" }, { type: "v", a: "b" }, { type: "h", a: "c" }, { type: "v", a: "d" }];
  let r = analyzeSketch(ents, hv, num);
  expect("lines rect h/v at origin: dof 2", r.dof === 2 && r.status === "under", summary(r));
  const full = [...hv, { type: "len", a: "a", value: 60 }, { type: "len", a: "b", value: 40 }];
  r = analyzeSketch(ents, full, num);
  expect("(1) lines rect + 2 寸法 + 原点 → 完全拘束 dof 0", r.status === "full" && r.dof === 0 && r.count === 6, summary(r));
  r = analyzeSketch(ents, full.slice(0, 5), num);
  expect("(2) 寸法を外す → dof 1 で不足（縦の線の長さ）", r.status === "under" && r.dof === 1 && r.missing.some((m) => m.what.includes("長さ")), summary(r));
  // 冗長: 向かいの辺にも同じ長さ
  r = analyzeSketch(ents, [...full, { type: "len", a: "c", value: 60 }], num);
  expect("redundant len → 過拘束, 対象は 7 番目", r.status === "over" && r.redundant.join() === "6", summary(r) + " red=" + r.redundant);
  // 矛盾: 向かいの辺を 50 に → 解けない
  const bad = [...full, { type: "len", a: "c", value: 50 }];
  const s = solveSketch(ents, bad, num);
  expect("solver refuses conflicting len", !s.ok);
  const ex = explainConflict(ents, full, bad, num);
  expect("(3) 矛盾の説明: 新しい拘束と相手を特定", /長さ 50（線3）/.test(ex.message) && /長さ 60（線1）/.test(ex.message), ex.message);
  r = analyzeSketch(ents, bad, num);
  expect("stored conflict → status conflict", r.status === "conflict" && r.conflict.includes(6), summary(r) + " conflict=" + r.conflict);
}

// --- 円
{
  const C = [{ id: "c", type: "circle", cx: 20, cy: 15, d: 5 }];
  let r = analyzeSketch(C, [], num);
  expect("circle free dof 3", r.dof === 3 && r.missing[0].what.join() === "直径,位置", summary(r));
  r = analyzeSketch(C, [{ type: "dim", a: "c", key: "d" }, { type: "fix", a: "c", at: { cx: 20, cy: 15 } }], num);
  expect("circle dim + fix → full", r.status === "full", summary(r));
  r = analyzeSketch([{ id: "c", type: "circle", cx: 20, cy: 15, d: "幅" }], [{ type: "fix", a: "c", at: { cx: 20, cy: 15 } }], makeEvaluator([{ name: "幅", expr: "5" }]));
  expect("circle d as expression counts as driven", r.status === "full", summary(r));
}

// --- 空・角度 90° でも勾配が取れる
{
  let r = analyzeSketch([], [], num);
  expect("empty", r.status === "empty");
  r = analyzeSketch([L("p", 0, 0, 100, 0), L("q", 0, 0, 0, 50)], [{ type: "fix", a: "p" }, { type: "ang", a: "p", b: "q", value: 90 }, { type: "len", a: "q", value: 50 }], num);
  expect("angle 90 + len → full", r.status === "full" && r.dof === 0, summary(r));
}
console.log(`constraintcheck unit: ${pass}/${pass + fail} ok`);
if (fail) process.exit(1);
