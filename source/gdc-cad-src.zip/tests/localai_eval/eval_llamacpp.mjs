// 端末内 AI の候補モデル × 説明の比較（CPU の llama.cpp で、端末内 AI と同じ 4bit 量子化の重み）
// 準備: npm i node-llama-cpp（このフォルダの外で）／ GGUF_DIR に Qwen の q4_0 GGUF を置く（例 Qwen/Qwen2.5-1.5B-Instruct-GGUF の qwen2.5-1.5b-instruct-q4_0.gguf）
// 使い方: node eval.mjs <gguf> [grammar=1] [variant=shots|sys] [only=0,1,2]
import { getLlama, LlamaChatSession } from "node-llama-cpp";
import fs from "fs";
import { localMessages, buildGrammar, normalizeRequest, postProcess } from "../../src/localprompt.js";
import { interpret } from "../../src/nlu.js";
const [file, g = "1", variant = "shots", only = "", set = "cases"] = process.argv.slice(2);
const { CASES } = await import(`./${set}.mjs`);
const llama = await getLlama({ gpu: false });
const model = await llama.loadModel({ modelPath: (process.env.GGUF_DIR || "./gguf") + "/" + file });
const ctx = await model.createContext({ contextSize: 2048, threads: 4 });
const session = new LlamaChatSession({ contextSequence: ctx.getSequence() });
const rows = [];
const t00 = Date.now();
const sel = only ? only.split(",").map(Number) : CASES.map((_, i) => i);
for (const i of sel) {
  const c = CASES[i];
  const norm = normalizeRequest(c.t);
  const m = { bodies: c.ctx, features: c.feats || [], selected: [] };
  const msgs = localMessages(norm, m, variant);
  const hist = msgs.slice(0, -1).map((x) => x.role === "system" ? { type: "system", text: x.content } : x.role === "user" ? { type: "user", text: x.content } : { type: "model", response: [x.content] });
  session.setChatHistory(hist);
  const opts = { temperature: 0, maxTokens: 120 };
  if (g === "1") opts.grammar = await llama.createGrammar({ grammar: buildGrammar(m) });
  const t1 = Date.now(); let out = "", err = "";
  try { out = await session.prompt(msgs.at(-1).content, opts); } catch (e) { err = e.message; }
  const ms = Date.now() - t1;
  out = out.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
  const pp = postProcess(out, norm, m);
  const got = pp.ask ? "?" : pp.lines.join("\n");
  const ok = c.want.includes(got);
  // 組み合わせ: 端末の中の読み取り（nlu）が分かるものはそれ、分からないもの（unknown）だけ AI
  const nr = interpret(c.t, { bodies: c.ctx.map((b) => ({ name: b.name, type: "box", min: b.min, max: b.max })), features: (c.feats || []).map((f) => ({ name: f, type: "hole" })), selected: [] });
  // アプリと同じ順: 読み取りがそのまま実行できる → 読み取り。読み取りが聞き返す・分からない → AI
  // （AI も聞き返す・数値が怪しいときで、読み取りが聞き返せるなら、読み取りの質問）
  const nluSure = !nr.unknown && nr.lines.length > 0 && !nr.ask, nluAsks = !nr.unknown && !!nr.ask;
  const nluGot = nr.ask ? "?" : nr.lines.join("\n");
  const hybrid = nluSure ? c.want.includes(nluGot) : nluAsks && (pp.ask || pp.suspicious.length || !got) ? c.want.includes("?") : ok;
  rows.push({ i, t: c.t, out, got, ok, ms, err, fixes: pp.fixes, susp: pp.suspicious, nluOk: c.want.includes(nluGot), nluSure, hybrid });
  console.log(`${ok ? "OK" : "NG"} ${ms}ms #${i} ${c.t} => ${JSON.stringify(out)}${pp.fixes.length ? " fix " + pp.fixes : ""}${pp.suspicious.length ? " SUSP " + pp.suspicious : ""}${err ? " ERR " + err : ""}`);
}
const n = rows.filter((r) => r.ok).length, avg = rows.reduce((s, r) => s + r.ms, 0) / rows.length;
const conf = rows.filter((r) => !r.ok && (r.susp.length || r.got === "?")).length;
const nn = rows.filter((r) => r.nluOk).length, hy = rows.filter((r) => r.hybrid).length;
console.log(`== ${set} ${file} grammar=${g} ${variant}: AI だけ ${n}/${rows.length}（不正解のうち確認・聞き返し ${conf}）, 平均 ${Math.round(avg)}ms ／ 読み取りだけ ${nn} ／ 読み取り＋AI ${hy}, 計 ${Math.round((Date.now() - t00) / 1000)}s`);
fs.mkdirSync("results", { recursive: true });
fs.writeFileSync(`results/${set}_${file}_g${g}_${variant}${only ? "_part" : ""}.json`, JSON.stringify(rows, null, 1));
