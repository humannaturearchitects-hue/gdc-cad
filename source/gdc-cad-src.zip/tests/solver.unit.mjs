import { solveSketch } from "../../src/shared/solver.js";
import { makeEvaluator } from "../../src/shared/expr.js";
const num = makeEvaluator([{ name: "W", expr: "150" }]);
const L = (id, x1, y1, x2, y2) => ({ id, type: "line", x1, y1, x2, y2 });
// 少し歪んだ四角
let ents = [L("a", 0, 0, 98, 3), L("b", 98, 3, 101, 52), L("c", 101, 52, -2, 49), L("d", -2, 49, 0, 0)];
let cons = [{ type: "h", a: "a" }, { type: "h", a: "c" }, { type: "v", a: "b" }, { type: "v", a: "d" }, { type: "len", a: "a", value: "W" }, { type: "len", a: "d", value: "60" }, { type: "fix", a: "a", at: { x1: 0, y1: 0 } }];
let t0 = performance.now(); let r = solveSketch(ents, cons, num); let t1 = performance.now();
console.log("rect solve ok", r.ok, "err", r.error.toExponential(1), (t1 - t0).toFixed(1) + "ms", JSON.stringify(r.entities.map(e => [e.x1, e.y1, e.x2, e.y2])));
// drag corner (b.x2) → width/height are fixed so it should not move much
let r2 = solveSketch(r.entities, cons, num, { drag: { i: 1, fx: "x2", fy: "y2", to: [200, 100] } });
console.log("drag (fully constrained)", r2.ok, JSON.stringify(r2.entities[1]));
// remove len on d → drag changes height only
const cons2 = cons.filter(c => !(c.type === "len" && c.a === "d"));
let r3 = solveSketch(r.entities, cons2, num, { drag: { i: 1, fx: "x2", fy: "y2", to: [200, 100] } });
console.log("drag height free", r3.ok, JSON.stringify(r3.entities.map(e => [e.x1, e.y1, e.x2, e.y2])));
// param change W=200
const num2 = makeEvaluator([{ name: "W", expr: "200" }]);
let r4 = solveSketch(r.entities, cons, num2);
console.log("W=200", r4.ok, JSON.stringify(r4.entities.map(e => [e.x1, e.y1, e.x2, e.y2])));
// parallel / perpendicular / angle
let t = [L("p", 0, 0, 100, 10), L("q", 0, 50, 90, 70)];
let r5 = solveSketch(t, [{ type: "par", a: "p", b: "q" }, { type: "dist", a: "p", b: "q", value: "30" }, { type: "fix", a: "p", at: { x1: 0, y1: 0, x2: 100, y2: 10 } }], num);
console.log("par+dist", r5.ok, JSON.stringify(r5.entities[1]));
let r6 = solveSketch([L("p", 0, 0, 100, 0), L("q", 0, 0, 50, 60)], [{ type: "ang", a: "p", b: "q", value: "45" }, { type: "fix", a: "p" }], num);
console.log("angle 45", r6.ok, JSON.stringify(r6.entities[1]), (Math.atan2(r6.entities[1].y2, r6.entities[1].x2) * 180 / Math.PI).toFixed(3));
// conflict
let r7 = solveSketch([L("p", 0, 0, 100, 5)], [{ type: "h", a: "p" }, { type: "v", a: "p" }, { type: "len", a: "p", value: "50" }], num);
console.log("conflict detected:", !r7.ok);
