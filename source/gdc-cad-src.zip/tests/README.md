# E2E テスト（Playwright）

```bash
npm run build && npx vite preview --port 4173 &
mkdir -p dl
LANG=C.UTF-8 node tests/e2e/features.cjs   # 全フィーチャの再計算
LANG=C.UTF-8 node tests/e2e/exports.cjs    # STEP/STL/OBJ/GLB/BREP/DXF/SVG/PDF 書き出し
LANG=C.UTF-8 node tests/e2e/ui.cjs         # 保存・元に戻す・計測・面上スケッチ
```
