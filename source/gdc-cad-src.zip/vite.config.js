import { defineConfig } from "vite";
import fs from "fs";
import path from "path";

// Emscripten の既定 WASM パス参照を無効化（WASM はメインスレッドから渡すため二重に埋め込まない）
const noDefaultWasm = {
  name: "no-default-wasm",
  enforce: "pre",
  transform(code, id) {
    if (id.includes("replicad_single.js") && code.includes('new URL("replicad_single.wasm",import.meta.url)')) {
      return code.replaceAll('new URL("replicad_single.wasm",import.meta.url)', '"replicad_single.wasm"');
    }
  },
};

// オフライン用: ビルドされた全ファイルを Service Worker の事前キャッシュ一覧に書き込む
const precacheList = {
  name: "precache-list",
  apply: "build",
  closeBundle() {
    const out = "dist";
    const sw = path.join(out, "sw.js");
    if (!fs.existsSync(sw)) return;
    const files = [];
    const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else files.push(p); } };
    walk(out);
    const list = ["./", ...files.map((f) => "./" + path.relative(out, f).split(path.sep).join("/")).filter((f) => f !== "./sw.js")];
    const build = Date.now().toString(36);
    const code = fs.readFileSync(sw, "utf8");
    fs.writeFileSync(sw, `self.__PRECACHE__ = ${JSON.stringify(list)};\nself.__BUILD__ = "${build}";\n` + code);
  },
};

// 単一 HTML 化: JS と CSS をインラインに埋め込む
const singleFile = {
  name: "single-file",
  apply: "build",
  enforce: "post",
  closeBundle() {
    const out = "dist-portable";
    const htmlPath = path.join(out, "index.html");
    if (!fs.existsSync(htmlPath)) return;
    let html = fs.readFileSync(htmlPath, "utf8");
    html = html.replace(/<link rel="stylesheet"[^>]*href="\.\/(assets\/[^"]+\.css)"[^>]*>/g, (_, f) => `<style>${fs.readFileSync(path.join(out, f), "utf8")}</style>`);
    html = html.replace(/<script type="module" crossorigin src="\.\/(assets\/[^"]+\.js)"><\/script>/g, (_, f) => `<script type="module">${fs.readFileSync(path.join(out, f), "utf8").replace(/<\/script/g, "<\\/script")}</script>`);
    html = html.replace(/<link rel="modulepreload"[^>]*>/g, "");
    fs.writeFileSync(path.join(out, "GDC GOOD DESIGN CAD.html"), html);
    fs.rmSync(path.join(out, "assets"), { recursive: true, force: true });
    fs.rmSync(htmlPath);
  },
};
// mode=portable: すべて（WASM・フォント・ワーカー）を1つの HTML に埋め込む
export default defineConfig(({ mode }) => {
  const portable = mode === "portable";
  return {
    base: "./",
    plugins: [noDefaultWasm, ...(portable ? [singleFile] : [precacheList])],
    worker: { format: portable ? "iife" : "es", plugins: () => [noDefaultWasm] },
    build: {
      target: ["es2020", "safari15"],
      chunkSizeWarningLimit: 60000,
      outDir: portable ? "dist-portable" : "dist",
      assetsInlineLimit: portable ? () => true : 0,
      cssCodeSplit: !portable,
      rolldownOptions: portable ? { output: { inlineDynamicImports: true } } : {},
    },
    optimizeDeps: { exclude: ["replicad-opencascadejs"] },
    server: { host: "127.0.0.1", port: 5173 },
  };
});
